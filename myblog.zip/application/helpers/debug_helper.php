<?php

function dv($var) {
    Tracy\Dumper::dump($var);
}