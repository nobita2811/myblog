<?php
    echo isset($this->pagination) ? $this->pagination->create_links() : '';
?>