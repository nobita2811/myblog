
<footer>
                        <div class="navbar-fixed-bottom text-center alert-info">
                            <!-- load script -->
                            <script src="<?= getJs('jquery.min') ?>"></script>
                            <script src="<?= getJs('jquery-ui.min') ?>"></script>
                            <script src="<?= getJs('affix') ?>"></script>

                            <script src="<?= getJs('bootstrap.min') ?>"></script>
                            <script src="<?= getJs('ckeditor/ckeditor'); ?>"></script>
                            <script src="<?= getJs('ckeditor/adapters/jquery'); ?>"></script>
                            <script src="<?= getJs('bootstrap-tokenfield'); ?>"></script>
                            <script src="<?= getJs('jquery-scrolltofixed-min'); ?>"></script>
                            <script src="<?= getJs('jquery.dataTables.min'); ?>"></script>
                            <script src="<?= getJs('jquery.nicescroll.min'); ?>"></script>
                            <script src="<?= getJs('jquery.bxslider.min'); ?>"></script>
                            <script src="<?= getJs('common') ?>"></script>
                        </div>
                    </footer>
                </div>
            </div>
        </div>
    </body>
</html>