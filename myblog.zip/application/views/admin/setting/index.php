<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="jumbotron">
                <h1>Hello, administrator!</h1>
                <p>...</p>
                <p><a class="btn btn-primary btn-lg" href="<?php echo base_url('/admin/settings/deleteUserHistory'); ?>" role="button">Run</a> xóa thông tin lịch sử thành viên xem bài viết (chỉ giữ lại 5 bản ghi)</p>
            </div>
        </div>
    </div>
</div>