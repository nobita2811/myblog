<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-02 09:39:19 --> Config Class Initialized
DEBUG - 2015-02-02 09:39:19 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:39:19 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:39:19 --> URI Class Initialized
DEBUG - 2015-02-02 09:39:19 --> No URI present. Default controller set.
DEBUG - 2015-02-02 09:39:19 --> Router Class Initialized
DEBUG - 2015-02-02 09:39:19 --> Output Class Initialized
DEBUG - 2015-02-02 09:39:19 --> Security Class Initialized
DEBUG - 2015-02-02 09:39:19 --> Input Class Initialized
DEBUG - 2015-02-02 09:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:39:19 --> Language Class Initialized
ERROR - 2015-02-02 09:39:19 --> Severity: Parsing Error --> syntax error, unexpected '.', expecting ']' D:\phutx\project\ups\myblog\application\core\MY_Controller.php 10
DEBUG - 2015-02-02 09:40:12 --> Config Class Initialized
DEBUG - 2015-02-02 09:40:12 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:40:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:40:12 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:40:12 --> URI Class Initialized
DEBUG - 2015-02-02 09:40:12 --> No URI present. Default controller set.
DEBUG - 2015-02-02 09:40:12 --> Router Class Initialized
DEBUG - 2015-02-02 09:40:12 --> Output Class Initialized
DEBUG - 2015-02-02 09:40:12 --> Security Class Initialized
DEBUG - 2015-02-02 09:40:12 --> Input Class Initialized
DEBUG - 2015-02-02 09:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:40:12 --> Language Class Initialized
DEBUG - 2015-02-02 09:40:12 --> Loader Class Initialized
DEBUG - 2015-02-02 09:40:12 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:40:12 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:40:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:40:12 --> CI_Session Class Initialized
ERROR - 2015-02-02 09:40:12 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 09:40:12 --> Session: Creating new session (c7d2da535a7e40f2032c567b8307eb07)
DEBUG - 2015-02-02 09:40:12 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:40:13 --> Model Class Initialized
DEBUG - 2015-02-02 09:40:13 --> Model Class Initialized
DEBUG - 2015-02-02 09:40:13 --> Controller Class Initialized
DEBUG - 2015-02-02 09:40:13 --> Model Class Initialized
DEBUG - 2015-02-02 09:40:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:40:13 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:40:20 --> Final output sent to browser
DEBUG - 2015-02-02 09:40:20 --> Total execution time: 7.9210
DEBUG - 2015-02-02 09:43:19 --> Config Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:43:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:43:19 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:43:19 --> URI Class Initialized
DEBUG - 2015-02-02 09:43:19 --> No URI present. Default controller set.
DEBUG - 2015-02-02 09:43:19 --> Router Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Output Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Security Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Input Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:43:19 --> Language Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Loader Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:43:19 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:43:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:43:19 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:43:19 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:43:19 --> Model Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Model Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Controller Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Model Class Initialized
DEBUG - 2015-02-02 09:43:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:43:19 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:43:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:43:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:43:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:43:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:43:26 --> Final output sent to browser
DEBUG - 2015-02-02 09:43:26 --> Total execution time: 7.0150
DEBUG - 2015-02-02 09:45:56 --> Config Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:45:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:45:56 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:45:56 --> URI Class Initialized
DEBUG - 2015-02-02 09:45:56 --> No URI present. Default controller set.
DEBUG - 2015-02-02 09:45:56 --> Router Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Output Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Security Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Input Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:45:56 --> Language Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Loader Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:45:56 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:45:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:45:56 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Session: Regenerate ID
DEBUG - 2015-02-02 09:45:56 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:45:56 --> Model Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Model Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Controller Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Model Class Initialized
DEBUG - 2015-02-02 09:45:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:45:56 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:45:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:45:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:46:02 --> Final output sent to browser
DEBUG - 2015-02-02 09:46:02 --> Total execution time: 6.5157
DEBUG - 2015-02-02 09:46:18 --> Config Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:46:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:46:18 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:46:18 --> URI Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Router Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Output Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Security Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Input Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:46:18 --> Language Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Loader Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:46:18 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:46:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:46:18 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:46:18 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:46:18 --> Model Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Model Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Controller Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Model Class Initialized
DEBUG - 2015-02-02 09:46:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:46:18 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:46:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:46:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:46:34 --> Final output sent to browser
DEBUG - 2015-02-02 09:46:34 --> Total execution time: 16.2456
DEBUG - 2015-02-02 09:46:46 --> Config Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:46:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:46:46 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:46:46 --> URI Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Router Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Output Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Security Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Input Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:46:46 --> Language Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Loader Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:46:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:46:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:46:46 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:46:46 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:46:46 --> Model Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Model Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Controller Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Model Class Initialized
DEBUG - 2015-02-02 09:46:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:46:46 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:46:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:46:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:46:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:46:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:46:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:46:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:46:57 --> Final output sent to browser
DEBUG - 2015-02-02 09:46:57 --> Total execution time: 11.2981
DEBUG - 2015-02-02 09:47:45 --> Config Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:47:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:47:45 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:47:45 --> URI Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Router Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Output Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Security Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Input Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:47:45 --> Language Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Loader Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:47:45 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:47:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:47:45 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:47:45 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:47:45 --> Model Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Model Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Controller Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Model Class Initialized
DEBUG - 2015-02-02 09:47:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:47:45 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:47:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:47:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:47:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:47:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:47:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:47:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:47:57 --> Final output sent to browser
DEBUG - 2015-02-02 09:47:57 --> Total execution time: 11.6122
DEBUG - 2015-02-02 09:50:26 --> Config Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:50:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:50:26 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:50:26 --> URI Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Router Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Output Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Security Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Input Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:50:26 --> Language Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Loader Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:50:26 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:50:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:50:26 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:50:26 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:50:26 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Controller Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:50:26 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:50:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:50:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:50:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:50:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:50:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:50:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:50:26 --> Final output sent to browser
DEBUG - 2015-02-02 09:50:26 --> Total execution time: 0.6951
DEBUG - 2015-02-02 09:50:31 --> Config Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:50:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:50:31 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:50:31 --> URI Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Router Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Output Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Security Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Input Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:50:31 --> Language Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Loader Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:50:31 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:50:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:50:31 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:50:31 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:50:31 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Controller Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:50:31 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:50:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:50:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:50:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:50:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:50:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:50:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:50:31 --> Final output sent to browser
DEBUG - 2015-02-02 09:50:31 --> Total execution time: 0.6691
DEBUG - 2015-02-02 09:50:49 --> Config Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:50:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:50:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:50:49 --> URI Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Router Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Output Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Security Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Input Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:50:49 --> Language Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Loader Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:50:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:50:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:50:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:50:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:50:49 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Controller Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:50:49 --> Email Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:50:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:50:49 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:50:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:50:49 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:50:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:50:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:50:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:50:50 --> Config Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:50:50 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:50:50 --> URI Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Router Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Output Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Security Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Input Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:50:50 --> Language Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Loader Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:50:50 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:50:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:50:50 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:50:50 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:50:50 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Controller Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:50:50 --> Email Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:50:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:50:50 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:50:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:50:50 --> Model Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:50:50 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:50:50 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:50:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:50:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 09:50:50 --> Final output sent to browser
DEBUG - 2015-02-02 09:50:50 --> Total execution time: 0.2000
DEBUG - 2015-02-02 09:51:06 --> Config Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:51:06 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:51:06 --> URI Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Router Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Output Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Security Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Input Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:51:06 --> Language Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Loader Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:51:06 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Session: Regenerate ID
DEBUG - 2015-02-02 09:51:06 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:51:06 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Controller Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:51:06 --> Email Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:51:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:51:06 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:51:06 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:51:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 09:51:06 --> Config Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:51:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:51:06 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:51:06 --> URI Class Initialized
DEBUG - 2015-02-02 09:51:06 --> No URI present. Default controller set.
DEBUG - 2015-02-02 09:51:06 --> Router Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Output Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Security Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Input Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:51:06 --> Language Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Loader Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:51:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:51:06 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:51:06 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:51:06 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Controller Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 09:51:06 --> Pagination Class Initialized
DEBUG - 2015-02-02 09:51:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 09:51:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 09:51:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 09:51:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 09:51:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 09:51:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 09:51:07 --> Final output sent to browser
DEBUG - 2015-02-02 09:51:07 --> Total execution time: 0.6431
DEBUG - 2015-02-02 09:51:13 --> Config Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:51:13 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:51:13 --> URI Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Router Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Output Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Security Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Input Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:51:13 --> Language Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Loader Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:51:13 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:51:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:51:13 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:51:13 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:51:13 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Controller Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:51:13 --> Email Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:51:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:51:13 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:51:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:51:13 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:51:13 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:51:13 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:51:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:51:13 --> Final output sent to browser
DEBUG - 2015-02-02 09:51:13 --> Total execution time: 0.2720
DEBUG - 2015-02-02 09:51:40 --> Config Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:51:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:51:40 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:51:40 --> URI Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Router Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Output Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Security Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Input Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:51:40 --> Language Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Loader Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:51:40 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:51:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:51:40 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:51:40 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:51:40 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Controller Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:51:40 --> Email Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:51:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:51:40 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:51:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:51:40 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:51:40 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:51:40 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:51:40 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:51:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:51:40 --> Final output sent to browser
DEBUG - 2015-02-02 09:51:40 --> Total execution time: 0.2270
DEBUG - 2015-02-02 09:51:52 --> Config Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:51:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:51:52 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:51:52 --> URI Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Router Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Output Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Security Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Input Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:51:52 --> Language Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Loader Class Initialized
DEBUG - 2015-02-02 09:51:52 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:51:52 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:51:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:51:52 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:51:52 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:51:53 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:53 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:53 --> Controller Class Initialized
DEBUG - 2015-02-02 09:51:53 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:51:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:51:53 --> Email Class Initialized
DEBUG - 2015-02-02 09:51:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:51:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:51:53 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:51:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:51:53 --> Model Class Initialized
DEBUG - 2015-02-02 09:51:53 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:51:53 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:51:53 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:51:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:51:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:51:53 --> Final output sent to browser
DEBUG - 2015-02-02 09:51:53 --> Total execution time: 0.2150
DEBUG - 2015-02-02 09:52:12 --> Config Class Initialized
DEBUG - 2015-02-02 09:52:12 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:52:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:52:12 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:52:12 --> URI Class Initialized
DEBUG - 2015-02-02 09:52:12 --> Router Class Initialized
DEBUG - 2015-02-02 09:52:12 --> Output Class Initialized
DEBUG - 2015-02-02 09:52:12 --> Security Class Initialized
DEBUG - 2015-02-02 09:52:12 --> Input Class Initialized
DEBUG - 2015-02-02 09:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:52:12 --> Language Class Initialized
ERROR - 2015-02-02 09:52:12 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR), expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' D:\phutx\project\ups\myblog\application\controllers\auth.php 20
DEBUG - 2015-02-02 09:52:18 --> Config Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:52:18 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:52:18 --> URI Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Router Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Output Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Security Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Input Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:52:18 --> Language Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Loader Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:52:18 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:52:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:52:18 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:52:18 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:52:18 --> Model Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Model Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Controller Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:52:18 --> Email Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:52:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:52:18 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:52:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:52:18 --> Model Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:52:18 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:52:18 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:52:18 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:52:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:52:19 --> Final output sent to browser
DEBUG - 2015-02-02 09:52:19 --> Total execution time: 0.2630
DEBUG - 2015-02-02 09:53:56 --> Config Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:53:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:53:56 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:53:56 --> URI Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Router Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Output Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Security Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Input Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:53:56 --> Language Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Loader Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:53:56 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:53:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:53:56 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:53:56 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:53:56 --> Model Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Model Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Controller Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:53:56 --> Email Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:53:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:53:56 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:53:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:53:56 --> Model Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:53:56 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:53:56 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:53:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:53:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:53:56 --> Final output sent to browser
DEBUG - 2015-02-02 09:53:56 --> Total execution time: 0.2530
DEBUG - 2015-02-02 09:55:41 --> Config Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:55:41 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:55:41 --> URI Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Router Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Output Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Security Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Input Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:55:41 --> Language Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Loader Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:55:41 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:55:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:55:41 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:55:41 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:55:41 --> Model Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Model Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Controller Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:55:41 --> Email Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:55:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:55:41 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:55:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:55:41 --> Model Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:55:41 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:55:41 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:55:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:55:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:55:41 --> Final output sent to browser
DEBUG - 2015-02-02 09:55:41 --> Total execution time: 0.4280
DEBUG - 2015-02-02 09:56:05 --> Config Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:56:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:56:05 --> URI Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Router Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Output Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Security Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Input Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:56:05 --> Language Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Loader Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:56:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:56:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:56:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:56:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:56:05 --> Model Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Model Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Controller Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:56:05 --> Email Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:56:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:56:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:56:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:56:05 --> Model Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:56:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:56:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:56:05 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 09:56:05 --> Invalid driver requested: Session_userdata
DEBUG - 2015-02-02 09:56:09 --> Config Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:56:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:56:09 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:56:09 --> URI Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Router Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Output Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Security Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Input Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:56:09 --> Language Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Loader Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:56:09 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:56:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:56:09 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Session: Regenerate ID
DEBUG - 2015-02-02 09:56:09 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:56:09 --> Model Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Model Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Controller Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:56:09 --> Email Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:56:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:56:09 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:56:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:56:09 --> Model Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:56:09 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:56:09 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:56:09 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:56:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:56:09 --> Final output sent to browser
DEBUG - 2015-02-02 09:56:09 --> Total execution time: 0.2670
DEBUG - 2015-02-02 09:59:40 --> Config Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:59:40 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:59:40 --> URI Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Router Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Output Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Security Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Input Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:59:40 --> Language Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Loader Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:59:40 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:59:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:59:40 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:59:40 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:59:40 --> Model Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Model Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Controller Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:59:40 --> Email Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:59:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:59:40 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:59:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:59:40 --> Model Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:59:40 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:59:40 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:59:40 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:59:40 --> Final output sent to browser
DEBUG - 2015-02-02 09:59:40 --> Total execution time: 0.2060
DEBUG - 2015-02-02 09:59:59 --> Config Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Hooks Class Initialized
DEBUG - 2015-02-02 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 09:59:59 --> Utf8 Class Initialized
DEBUG - 2015-02-02 09:59:59 --> URI Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Router Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Output Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Security Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Input Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 09:59:59 --> Language Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Loader Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Helper loaded: url_helper
DEBUG - 2015-02-02 09:59:59 --> Helper loaded: link_helper
DEBUG - 2015-02-02 09:59:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 09:59:59 --> CI_Session Class Initialized
DEBUG - 2015-02-02 09:59:59 --> CI_Session routines successfully run
DEBUG - 2015-02-02 09:59:59 --> Model Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Model Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Controller Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Database Driver Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 09:59:59 --> Email Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 09:59:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 09:59:59 --> Helper loaded: language_helper
DEBUG - 2015-02-02 09:59:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 09:59:59 --> Model Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Helper loaded: date_helper
DEBUG - 2015-02-02 09:59:59 --> Helper loaded: form_helper
DEBUG - 2015-02-02 09:59:59 --> Form Validation Class Initialized
DEBUG - 2015-02-02 09:59:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 09:59:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 09:59:59 --> Final output sent to browser
DEBUG - 2015-02-02 09:59:59 --> Total execution time: 0.2050
DEBUG - 2015-02-02 10:00:04 --> Config Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:00:04 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:00:04 --> URI Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Router Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Output Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Security Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Input Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:00:04 --> Language Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Loader Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:00:04 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:00:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:00:04 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:00:04 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:00:04 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Controller Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:00:04 --> Email Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:00:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:00:04 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:00:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:00:04 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:00:04 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:00:04 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:00:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:00:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 10:00:04 --> Final output sent to browser
DEBUG - 2015-02-02 10:00:04 --> Total execution time: 0.2640
DEBUG - 2015-02-02 10:00:22 --> Config Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:00:22 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:00:22 --> URI Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Router Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Output Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Security Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Input Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:00:22 --> Language Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Loader Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:00:22 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:00:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:00:22 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:00:22 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:00:22 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Controller Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:00:22 --> Email Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:00:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:00:22 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:00:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:00:22 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:00:22 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:00:22 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:00:22 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 10:00:22 --> Severity: Notice --> Undefined index: id D:\phutx\project\ups\myblog\application\controllers\auth.php 20
DEBUG - 2015-02-02 10:00:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 10:00:22 --> Final output sent to browser
DEBUG - 2015-02-02 10:00:22 --> Total execution time: 0.2240
DEBUG - 2015-02-02 10:00:30 --> Config Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:00:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:00:30 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:00:30 --> URI Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Router Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Output Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Security Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Input Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:00:30 --> Language Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Loader Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:00:30 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:00:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:00:30 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:00:30 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:00:30 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Controller Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:00:30 --> Email Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:00:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:00:30 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:00:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:00:30 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:00:30 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:00:30 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:00:30 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 10:00:30 --> Severity: Notice --> Trying to get property of non-object D:\phutx\project\ups\myblog\application\controllers\auth.php 20
DEBUG - 2015-02-02 10:00:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 10:00:30 --> Final output sent to browser
DEBUG - 2015-02-02 10:00:30 --> Total execution time: 0.2840
DEBUG - 2015-02-02 10:00:44 --> Config Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:00:44 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:00:44 --> URI Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Router Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Output Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Security Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Input Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:00:44 --> Language Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Loader Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:00:44 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:00:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:00:44 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:00:44 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:00:44 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Controller Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:00:44 --> Email Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:00:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:00:44 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:00:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:00:44 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:00:44 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:00:44 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:00:44 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 10:00:44 --> Severity: Notice --> Undefined index: id D:\phutx\project\ups\myblog\application\controllers\auth.php 20
DEBUG - 2015-02-02 10:00:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 10:00:44 --> Final output sent to browser
DEBUG - 2015-02-02 10:00:44 --> Total execution time: 0.2430
DEBUG - 2015-02-02 10:00:50 --> Config Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:00:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:00:50 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:00:50 --> URI Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Router Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Output Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Security Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Input Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:00:50 --> Language Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Loader Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:00:50 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:00:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:00:50 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:00:50 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:00:50 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Controller Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:00:50 --> Email Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:00:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:00:50 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:00:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:00:50 --> Model Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:00:50 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:00:50 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:00:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:00:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 10:00:50 --> Final output sent to browser
DEBUG - 2015-02-02 10:00:50 --> Total execution time: 0.2260
DEBUG - 2015-02-02 10:01:01 --> Config Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:01:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:01:01 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:01:01 --> URI Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Router Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Output Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Security Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Input Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:01:01 --> Language Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Loader Class Initialized
DEBUG - 2015-02-02 10:01:01 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:01:01 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:01:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:01:01 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:01:01 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:01:02 --> Model Class Initialized
DEBUG - 2015-02-02 10:01:02 --> Model Class Initialized
DEBUG - 2015-02-02 10:01:02 --> Controller Class Initialized
DEBUG - 2015-02-02 10:01:02 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:01:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:01:02 --> Email Class Initialized
DEBUG - 2015-02-02 10:01:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:01:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:01:02 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:01:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:01:02 --> Model Class Initialized
DEBUG - 2015-02-02 10:01:02 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:01:02 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:01:02 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:01:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:01:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 10:01:02 --> Final output sent to browser
DEBUG - 2015-02-02 10:01:02 --> Total execution time: 0.2680
DEBUG - 2015-02-02 10:02:23 --> Config Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:02:23 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:02:23 --> URI Class Initialized
DEBUG - 2015-02-02 10:02:23 --> No URI present. Default controller set.
DEBUG - 2015-02-02 10:02:23 --> Router Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Output Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Security Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Input Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:02:23 --> Language Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Loader Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:02:23 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:02:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:02:23 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Session: Regenerate ID
DEBUG - 2015-02-02 10:02:23 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:02:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:02:23 --> Controller Class Initialized
ERROR - 2015-02-02 10:02:23 --> Severity: Notice --> Undefined property: Welcome::$ion_auth D:\phutx\project\ups\myblog\application\core\MY_Controller.php 40
ERROR - 2015-02-02 10:02:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\vendor\tracy\tracy\src\Tracy\Dumper.php:73) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-02 10:02:23 --> Severity: Error --> Call to a member function is_admin() on a non-object D:\phutx\project\ups\myblog\application\core\MY_Controller.php 40
DEBUG - 2015-02-02 10:04:17 --> Config Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:04:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:04:17 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:04:17 --> URI Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Router Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Output Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Security Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Input Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:04:17 --> Language Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Loader Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:04:17 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:04:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:04:17 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:04:17 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:04:17 --> Model Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Model Class Initialized
DEBUG - 2015-02-02 10:04:17 --> Controller Class Initialized
ERROR - 2015-02-02 10:04:17 --> Severity: Notice --> Undefined property: Categories::$ion_auth D:\phutx\project\ups\myblog\application\core\MY_Controller.php 40
ERROR - 2015-02-02 10:04:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\vendor\tracy\tracy\src\Tracy\Dumper.php:73) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-02 10:04:17 --> Severity: Error --> Call to a member function is_admin() on a non-object D:\phutx\project\ups\myblog\application\core\MY_Controller.php 40
DEBUG - 2015-02-02 10:05:13 --> Config Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:05:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:05:13 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:05:13 --> URI Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Router Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Output Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Security Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Input Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:05:13 --> Language Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Loader Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:05:13 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:05:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:05:13 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:05:13 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:05:13 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:13 --> Controller Class Initialized
ERROR - 2015-02-02 10:05:13 --> Severity: Notice --> Undefined property: Categories::$ion_auth D:\phutx\project\ups\myblog\application\core\MY_Controller.php 40
ERROR - 2015-02-02 10:05:13 --> Severity: Error --> Call to a member function is_admin() on a non-object D:\phutx\project\ups\myblog\application\core\MY_Controller.php 40
DEBUG - 2015-02-02 10:05:37 --> Config Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:05:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:05:37 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:05:37 --> URI Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Router Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Output Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Security Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Input Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:05:37 --> Language Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Loader Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:05:37 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:05:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:05:37 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:05:37 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:05:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Controller Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:05:37 --> Email Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:05:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:05:37 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:05:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:05:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:05:37 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:05:37 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:05:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-02 10:05:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-02 10:05:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-02-02 10:05:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-02 10:05:37 --> Final output sent to browser
DEBUG - 2015-02-02 10:05:37 --> Total execution time: 0.2220
DEBUG - 2015-02-02 10:05:43 --> Config Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:05:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:05:43 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:05:43 --> URI Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Router Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Output Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Security Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Input Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:05:43 --> Language Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Loader Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:05:43 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:05:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:05:43 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:05:43 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:05:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Controller Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:05:43 --> Email Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:05:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:05:43 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:05:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:05:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:05:43 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:05:43 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:05:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:05:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-02 10:05:43 --> Final output sent to browser
DEBUG - 2015-02-02 10:05:43 --> Total execution time: 0.2540
DEBUG - 2015-02-02 10:05:48 --> Config Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:05:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:05:48 --> URI Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Router Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Output Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Security Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Input Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:05:48 --> Language Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Loader Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:05:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:05:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:05:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Controller Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:05:48 --> Email Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:05:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:05:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:05:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:05:48 --> Session: Creating new session (8eec5d06b0f72986d3999522eeb7b687)
DEBUG - 2015-02-02 10:05:48 --> Config Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:05:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:05:48 --> URI Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Router Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Output Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Security Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Input Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:05:48 --> Language Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Loader Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:05:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:05:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:05:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Controller Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:05:48 --> Email Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:05:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:05:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:05:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:05:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:05:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:05:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:05:48 --> Final output sent to browser
DEBUG - 2015-02-02 10:05:48 --> Total execution time: 0.1740
DEBUG - 2015-02-02 10:06:00 --> Config Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:06:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:06:00 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:06:00 --> URI Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Router Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Output Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Security Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Input Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:06:00 --> Language Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Loader Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:06:00 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:06:00 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:06:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Controller Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:06:00 --> Email Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:06:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:06:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:06:00 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:06:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 10:06:00 --> Config Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:06:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:06:00 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:06:00 --> URI Class Initialized
DEBUG - 2015-02-02 10:06:00 --> No URI present. Default controller set.
DEBUG - 2015-02-02 10:06:00 --> Router Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Output Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Security Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Input Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:06:00 --> Language Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Loader Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:06:00 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:06:00 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:06:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Controller Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:06:00 --> Email Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:06:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:06:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:06:00 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:06:00 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 10:06:00 --> Pagination Class Initialized
DEBUG - 2015-02-02 10:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 10:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:06:01 --> Final output sent to browser
DEBUG - 2015-02-02 10:06:01 --> Total execution time: 0.6671
DEBUG - 2015-02-02 10:06:04 --> Config Class Initialized
DEBUG - 2015-02-02 10:06:04 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:06:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:06:04 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:06:04 --> URI Class Initialized
DEBUG - 2015-02-02 10:06:04 --> Router Class Initialized
DEBUG - 2015-02-02 10:06:04 --> Output Class Initialized
DEBUG - 2015-02-02 10:06:04 --> Security Class Initialized
DEBUG - 2015-02-02 10:06:04 --> Input Class Initialized
DEBUG - 2015-02-02 10:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:06:04 --> Language Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Loader Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:06:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:06:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:06:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:06:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:06:05 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Controller Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:06:05 --> Email Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:06:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:06:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:06:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:06:05 --> Model Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:06:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:06:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:06:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Config Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:07:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:07:12 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:07:12 --> URI Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Router Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Output Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Security Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Input Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:07:12 --> Language Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Loader Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:07:12 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:07:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:07:12 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:07:12 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:07:12 --> Model Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Model Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Controller Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:07:12 --> Email Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:07:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:07:12 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:07:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:07:12 --> Model Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:07:12 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:07:12 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:07:12 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Config Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:07:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:07:16 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:07:16 --> URI Class Initialized
DEBUG - 2015-02-02 10:07:16 --> No URI present. Default controller set.
DEBUG - 2015-02-02 10:07:16 --> Router Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Output Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Security Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Input Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:07:16 --> Language Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Loader Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:07:16 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:07:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:07:16 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:07:16 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:07:16 --> Model Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Model Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Controller Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:07:16 --> Email Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:07:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:07:16 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:07:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:07:16 --> Model Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:07:16 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:07:16 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Model Class Initialized
DEBUG - 2015-02-02 10:07:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 10:07:16 --> Pagination Class Initialized
DEBUG - 2015-02-02 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:07:16 --> Final output sent to browser
DEBUG - 2015-02-02 10:07:16 --> Total execution time: 0.7121
DEBUG - 2015-02-02 10:08:37 --> Config Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:08:37 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:08:37 --> URI Class Initialized
DEBUG - 2015-02-02 10:08:37 --> No URI present. Default controller set.
DEBUG - 2015-02-02 10:08:37 --> Router Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Output Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Security Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Input Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:08:37 --> Language Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Loader Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:08:37 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:08:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:08:37 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:08:37 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:08:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Controller Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:08:37 --> Email Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:08:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:08:37 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:08:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:08:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:08:37 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:08:37 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 10:08:37 --> Pagination Class Initialized
DEBUG - 2015-02-02 10:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 10:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:08:37 --> Final output sent to browser
DEBUG - 2015-02-02 10:08:37 --> Total execution time: 0.6841
DEBUG - 2015-02-02 10:08:40 --> Config Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:08:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:08:40 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:08:40 --> URI Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Router Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Output Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Security Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Input Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:08:40 --> Language Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Loader Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:08:40 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:08:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:08:40 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:08:40 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:08:40 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Controller Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:08:40 --> Email Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:08:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:08:40 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:08:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:08:40 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:08:40 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:08:40 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:08:40 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:08:48 --> Config Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:08:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:08:48 --> URI Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Router Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Output Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Security Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Input Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:08:48 --> Language Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Loader Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:08:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:08:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:08:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:08:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:08:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Controller Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:08:48 --> Email Class Initialized
DEBUG - 2015-02-02 10:08:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:08:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:08:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:08:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:08:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:08:49 --> Session: Creating new session (5c73a76a9d1b1c0c530964a4fc3afea5)
DEBUG - 2015-02-02 10:08:49 --> Config Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:08:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:08:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:08:49 --> URI Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Router Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Output Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Security Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Input Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:08:49 --> Language Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Loader Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:08:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:08:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Controller Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:08:49 --> Email Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:08:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:08:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:08:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:08:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:08:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:08:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:08:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
ERROR - 2015-02-02 10:08:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\phutx\project\ups\myblog\application\controllers\auth.php 799
ERROR - 2015-02-02 10:08:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\phutx\project\ups\myblog\application\controllers\auth.php 799
ERROR - 2015-02-02 10:08:49 --> Severity: Notice --> Undefined property: CI_Loader::$pagination D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
ERROR - 2015-02-02 10:08:49 --> Severity: Error --> Call to a member function create_links() on a non-object D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
DEBUG - 2015-02-02 10:09:50 --> Config Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:09:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:09:50 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:09:50 --> URI Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Router Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Output Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Security Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Input Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:09:50 --> Language Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Loader Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:09:50 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:09:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:09:50 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:09:50 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:09:50 --> Model Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Model Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Controller Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:09:50 --> Email Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:09:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:09:50 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:09:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:09:50 --> Model Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:09:50 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:09:50 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:09:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:09:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
ERROR - 2015-02-02 10:09:51 --> Severity: Notice --> Undefined property: CI_Loader::$pagination D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
ERROR - 2015-02-02 10:09:51 --> Severity: Error --> Call to a member function create_links() on a non-object D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
DEBUG - 2015-02-02 10:11:03 --> Config Class Initialized
DEBUG - 2015-02-02 10:11:03 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:11:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:11:03 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:11:03 --> URI Class Initialized
DEBUG - 2015-02-02 10:11:03 --> Router Class Initialized
DEBUG - 2015-02-02 10:11:03 --> Output Class Initialized
DEBUG - 2015-02-02 10:11:03 --> Security Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Input Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:11:04 --> Language Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Loader Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:11:04 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:11:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:11:04 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:11:04 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:11:04 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Controller Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:11:04 --> Email Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:11:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:11:04 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:11:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:11:04 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:11:04 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:11:04 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:11:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:11:04 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:11:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:11:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:11:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:11:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
ERROR - 2015-02-02 10:11:04 --> Severity: Notice --> Undefined property: CI_Loader::$pagination D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
ERROR - 2015-02-02 10:11:04 --> Severity: Error --> Call to a member function create_links() on a non-object D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
DEBUG - 2015-02-02 10:11:06 --> Config Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:11:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:11:06 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:11:06 --> URI Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Router Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Output Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Security Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Input Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:11:06 --> Language Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Loader Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:11:06 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:11:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:11:06 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:11:06 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:11:06 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Controller Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:11:06 --> Email Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:11:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:11:06 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:11:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:11:06 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:11:06 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:11:06 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:11:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:11:06 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:11:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:11:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:11:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:11:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
ERROR - 2015-02-02 10:11:06 --> Severity: Notice --> Undefined property: CI_Loader::$pagination D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
ERROR - 2015-02-02 10:11:06 --> Severity: Error --> Call to a member function create_links() on a non-object D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
DEBUG - 2015-02-02 10:11:53 --> Config Class Initialized
DEBUG - 2015-02-02 10:11:53 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:11:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:11:53 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:11:54 --> URI Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Router Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Output Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Security Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Input Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:11:54 --> Language Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Loader Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:11:54 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:11:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:11:54 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:11:54 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:11:54 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Controller Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:11:54 --> Email Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:11:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:11:54 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:11:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:11:54 --> Model Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:11:54 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:11:54 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:11:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:11:54 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:11:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:11:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:11:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:11:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
ERROR - 2015-02-02 10:11:54 --> Severity: Notice --> Undefined property: CI_Loader::$pagination D:\phutx\project\ups\myblog\application\views\layout\pagination.php 2
DEBUG - 2015-02-02 10:11:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:11:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:11:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:11:54 --> Final output sent to browser
DEBUG - 2015-02-02 10:11:54 --> Total execution time: 0.2010
DEBUG - 2015-02-02 10:12:12 --> Config Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:12:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:12:12 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:12:12 --> URI Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Router Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Output Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Security Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Input Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:12:12 --> Language Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Loader Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:12:12 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:12:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:12:12 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:12:12 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:12:12 --> Model Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Model Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Controller Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:12:12 --> Email Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:12:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:12:12 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:12:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:12:12 --> Model Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:12:12 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:12:12 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:12:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:12:12 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:12:12 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:12:12 --> Final output sent to browser
DEBUG - 2015-02-02 10:12:12 --> Total execution time: 0.2050
DEBUG - 2015-02-02 10:18:43 --> Config Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:18:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:18:43 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:18:43 --> URI Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Router Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Output Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Security Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Input Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:18:43 --> Language Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Loader Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:18:43 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:18:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:18:43 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Session: Regenerate ID
DEBUG - 2015-02-02 10:18:43 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:18:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Controller Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:18:43 --> Email Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:18:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:18:43 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:18:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:18:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:18:43 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:18:43 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:18:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:18:43 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:18:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:18:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:18:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:18:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:18:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:18:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:18:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:18:43 --> Final output sent to browser
DEBUG - 2015-02-02 10:18:43 --> Total execution time: 0.2530
DEBUG - 2015-02-02 10:21:56 --> Config Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:21:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:21:56 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:21:56 --> URI Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Router Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Output Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Security Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Input Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:21:56 --> Language Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Loader Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:21:56 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:21:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:21:56 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:21:56 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:21:56 --> Model Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Model Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Controller Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:21:56 --> Email Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:21:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:21:56 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:21:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:21:56 --> Model Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:21:56 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:21:56 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:21:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:21:56 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:21:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-02 10:21:56 --> Severity: Notice --> Array to string conversion D:\phutx\project\ups\myblog\system\helpers\form_helper.php 931
DEBUG - 2015-02-02 10:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:21:56 --> Final output sent to browser
DEBUG - 2015-02-02 10:21:56 --> Total execution time: 0.2100
DEBUG - 2015-02-02 10:22:48 --> Config Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:22:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:22:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:22:48 --> URI Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Router Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Output Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Security Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Input Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:22:48 --> Language Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Loader Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:22:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:22:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:22:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:22:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:22:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Controller Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:22:48 --> Email Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:22:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:22:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:22:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:22:48 --> Model Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:22:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:22:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:22:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:22:48 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:22:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:22:48 --> Final output sent to browser
DEBUG - 2015-02-02 10:22:48 --> Total execution time: 0.1890
DEBUG - 2015-02-02 10:23:23 --> Config Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:23:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:23:23 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:23:23 --> URI Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Router Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Output Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Security Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Input Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:23:23 --> Language Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Loader Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:23:23 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:23:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:23:23 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:23:23 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:23:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Controller Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:23:23 --> Email Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:23:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:23:23 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:23:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:23:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:23:23 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:23:23 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:23:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:23:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:23:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:23:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:23:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:23:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:23:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:23:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:23:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:23:23 --> Final output sent to browser
DEBUG - 2015-02-02 10:23:23 --> Total execution time: 0.2060
DEBUG - 2015-02-02 10:23:42 --> Config Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:23:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:23:42 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:23:42 --> URI Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Router Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Output Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Security Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Input Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:23:42 --> Language Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Loader Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:23:42 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:23:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:23:42 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:23:42 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:23:42 --> Model Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Model Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Controller Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:23:42 --> Email Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:23:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:23:42 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:23:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:23:42 --> Model Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:23:42 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:23:42 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:23:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:23:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:23:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:23:42 --> Final output sent to browser
DEBUG - 2015-02-02 10:23:42 --> Total execution time: 0.2210
DEBUG - 2015-02-02 10:38:43 --> Config Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:38:43 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:38:43 --> URI Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Router Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Output Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Security Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Input Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:38:43 --> Language Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Loader Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:38:43 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:38:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:38:43 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Session: Regenerate ID
DEBUG - 2015-02-02 10:38:43 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:38:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Controller Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:38:43 --> Email Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:38:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:38:43 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:38:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:38:43 --> Model Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:38:43 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:38:43 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:38:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:38:43 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:38:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:38:43 --> Final output sent to browser
DEBUG - 2015-02-02 10:38:43 --> Total execution time: 0.2150
DEBUG - 2015-02-02 10:53:22 --> Config Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:53:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:53:22 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:53:22 --> URI Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Router Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Output Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Security Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Input Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:53:22 --> Language Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Loader Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:53:22 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:53:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:53:22 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Session: Regenerate ID
DEBUG - 2015-02-02 10:53:22 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:53:22 --> Model Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Model Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Controller Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:53:22 --> Email Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:53:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:53:22 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:53:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:53:22 --> Model Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:53:22 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:53:22 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:53:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:53:22 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:53:22 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:53:22 --> Final output sent to browser
DEBUG - 2015-02-02 10:53:22 --> Total execution time: 0.1960
DEBUG - 2015-02-02 10:53:43 --> Config Class Initialized
DEBUG - 2015-02-02 10:53:43 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:53:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:53:43 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:53:43 --> URI Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Router Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Output Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Security Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Input Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:53:44 --> Language Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Loader Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:53:44 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:53:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:53:44 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:53:44 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:53:44 --> Model Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Model Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Controller Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:53:44 --> Email Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:53:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:53:44 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:53:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:53:44 --> Model Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:53:44 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:53:44 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:53:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:53:44 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:53:44 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:53:44 --> Final output sent to browser
DEBUG - 2015-02-02 10:53:44 --> Total execution time: 0.1980
DEBUG - 2015-02-02 10:54:23 --> Config Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:54:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:54:23 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:54:23 --> URI Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Router Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Output Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Security Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Input Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:54:23 --> Language Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Loader Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:54:23 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:54:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:54:23 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:54:23 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:54:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Controller Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:54:23 --> Email Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:54:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:54:23 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:54:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:54:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:54:23 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:54:23 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:54:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:54:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:54:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:54:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:54:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:54:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:54:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:54:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:54:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:54:23 --> Final output sent to browser
DEBUG - 2015-02-02 10:54:23 --> Total execution time: 0.1970
DEBUG - 2015-02-02 10:55:28 --> Config Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:55:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:55:28 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:55:28 --> URI Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Router Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Output Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Security Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Input Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:55:28 --> Language Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Loader Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:55:28 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:55:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:55:28 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:55:28 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:55:28 --> Model Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Model Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Controller Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:55:28 --> Email Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:55:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:55:28 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:55:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:55:28 --> Model Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:55:28 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:55:28 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:55:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:55:28 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:55:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:55:28 --> Final output sent to browser
DEBUG - 2015-02-02 10:55:28 --> Total execution time: 0.1990
DEBUG - 2015-02-02 10:56:55 --> Config Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:56:55 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:56:55 --> URI Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Router Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Output Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Security Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Input Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:56:55 --> Language Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Loader Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:56:55 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:56:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:56:55 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:56:55 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:56:55 --> Model Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Model Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Controller Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:56:55 --> Email Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:56:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:56:55 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:56:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:56:55 --> Model Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:56:55 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:56:55 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:56:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:56:55 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:56:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:56:55 --> Final output sent to browser
DEBUG - 2015-02-02 10:56:55 --> Total execution time: 0.1880
DEBUG - 2015-02-02 10:57:33 --> Config Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:57:33 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:57:33 --> URI Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Router Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Output Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Security Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Input Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:57:33 --> Language Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Loader Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:57:33 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:57:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:57:33 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:57:33 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Controller Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:57:33 --> Email Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:57:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:57:33 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:57:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:57:33 --> Model Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:57:33 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:57:33 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:57:33 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:57:33 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:57:33 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:57:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:57:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:57:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:57:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:57:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:57:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:57:33 --> Final output sent to browser
DEBUG - 2015-02-02 10:57:33 --> Total execution time: 0.2150
DEBUG - 2015-02-02 10:57:49 --> Config Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:57:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:57:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:57:49 --> URI Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Router Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Output Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Security Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Input Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:57:49 --> Language Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Loader Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:57:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:57:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:57:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:57:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:57:49 --> Model Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Model Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Controller Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:57:49 --> Email Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:57:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:57:49 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:57:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:57:49 --> Model Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:57:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:57:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:57:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:57:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:57:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:57:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:57:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:57:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:57:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:57:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:57:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:57:49 --> Final output sent to browser
DEBUG - 2015-02-02 10:57:49 --> Total execution time: 0.2510
DEBUG - 2015-02-02 10:58:22 --> Config Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:58:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:58:22 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:58:22 --> URI Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Router Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Output Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Security Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Input Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:58:22 --> Language Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Loader Class Initialized
DEBUG - 2015-02-02 10:58:22 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:58:22 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:58:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:58:22 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:58:22 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:58:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:23 --> Controller Class Initialized
DEBUG - 2015-02-02 10:58:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:58:23 --> Email Class Initialized
DEBUG - 2015-02-02 10:58:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:58:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:58:23 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:58:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:58:23 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:23 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:58:23 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:58:23 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:58:23 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:58:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:58:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:58:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:58:23 --> Final output sent to browser
DEBUG - 2015-02-02 10:58:23 --> Total execution time: 0.1860
DEBUG - 2015-02-02 10:58:45 --> Config Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:58:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:58:45 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:58:45 --> URI Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Router Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Output Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Security Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Input Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:58:45 --> Language Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Loader Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:58:45 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:58:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:58:45 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Session: Regenerate ID
DEBUG - 2015-02-02 10:58:45 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:58:45 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Controller Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:58:45 --> Email Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:58:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:58:45 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:58:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:58:45 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:58:45 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:58:45 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:58:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:58:45 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:58:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:58:45 --> Final output sent to browser
DEBUG - 2015-02-02 10:58:45 --> Total execution time: 0.2370
DEBUG - 2015-02-02 10:58:54 --> Config Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:58:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:58:54 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:58:54 --> URI Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Router Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Output Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Security Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Input Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:58:54 --> Language Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Loader Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:58:54 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:58:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:58:54 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:58:54 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:58:54 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Controller Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:58:54 --> Email Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:58:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:58:54 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:58:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:58:54 --> Model Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:58:54 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:58:54 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:58:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:58:54 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:58:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:58:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:58:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:58:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:58:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:58:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:58:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:58:54 --> Final output sent to browser
DEBUG - 2015-02-02 10:58:54 --> Total execution time: 0.2240
DEBUG - 2015-02-02 10:59:00 --> Config Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:59:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:59:00 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:59:00 --> URI Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Router Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Output Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Security Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Input Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:59:00 --> Language Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Loader Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:59:00 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:59:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:59:00 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:59:00 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:59:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Controller Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:59:00 --> Email Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:59:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:59:00 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:59:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:59:00 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:59:00 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:59:00 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:59:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:59:00 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:59:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:59:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:59:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:59:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:59:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:59:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:59:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:59:00 --> Final output sent to browser
DEBUG - 2015-02-02 10:59:00 --> Total execution time: 0.2100
DEBUG - 2015-02-02 10:59:16 --> Config Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:59:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:59:16 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:59:16 --> URI Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Router Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Output Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Security Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Input Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:59:16 --> Language Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Loader Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:59:16 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:59:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:59:16 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:59:16 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:59:16 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Controller Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:59:16 --> Email Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:59:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:59:16 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:59:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:59:16 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:59:16 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:59:16 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:59:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:59:16 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:59:16 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:59:16 --> Final output sent to browser
DEBUG - 2015-02-02 10:59:16 --> Total execution time: 0.2110
DEBUG - 2015-02-02 10:59:53 --> Config Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Hooks Class Initialized
DEBUG - 2015-02-02 10:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 10:59:53 --> Utf8 Class Initialized
DEBUG - 2015-02-02 10:59:53 --> URI Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Router Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Output Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Security Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Input Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 10:59:53 --> Language Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Loader Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Helper loaded: url_helper
DEBUG - 2015-02-02 10:59:53 --> Helper loaded: link_helper
DEBUG - 2015-02-02 10:59:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 10:59:53 --> CI_Session Class Initialized
DEBUG - 2015-02-02 10:59:53 --> CI_Session routines successfully run
DEBUG - 2015-02-02 10:59:53 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Controller Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 10:59:53 --> Email Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 10:59:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 10:59:53 --> Helper loaded: language_helper
DEBUG - 2015-02-02 10:59:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 10:59:53 --> Model Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Database Driver Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Helper loaded: date_helper
DEBUG - 2015-02-02 10:59:53 --> Helper loaded: form_helper
DEBUG - 2015-02-02 10:59:53 --> Form Validation Class Initialized
DEBUG - 2015-02-02 10:59:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 10:59:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 10:59:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 10:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 10:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 10:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 10:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 10:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 10:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 10:59:53 --> Final output sent to browser
DEBUG - 2015-02-02 10:59:53 --> Total execution time: 0.1960
DEBUG - 2015-02-02 11:00:36 --> Config Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:00:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:00:36 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:00:36 --> URI Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Router Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Output Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Security Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Input Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:00:36 --> Language Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Loader Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:00:36 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:00:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:00:36 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:00:36 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:00:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Controller Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:00:36 --> Email Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:00:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:00:36 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:00:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:00:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:00:36 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:00:36 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:00:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:00:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:00:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:00:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:00:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:00:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:00:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:00:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:00:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:00:37 --> Final output sent to browser
DEBUG - 2015-02-02 11:00:37 --> Total execution time: 0.2740
DEBUG - 2015-02-02 11:00:42 --> Config Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:00:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:00:42 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:00:42 --> URI Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Router Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Output Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Security Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Input Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:00:42 --> Language Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Loader Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:00:42 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:00:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:00:42 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:00:42 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:00:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Controller Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:00:42 --> Email Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:00:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:00:42 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:00:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:00:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:00:42 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:00:42 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:00:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:00:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:00:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:00:42 --> Final output sent to browser
DEBUG - 2015-02-02 11:00:42 --> Total execution time: 0.1970
DEBUG - 2015-02-02 11:01:00 --> Config Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:01:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:01:00 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:01:00 --> URI Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Router Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Output Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Security Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Input Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:01:00 --> Language Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Loader Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:01:00 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:01:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:01:00 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:01:00 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:01:00 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Controller Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:01:00 --> Email Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:01:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:01:00 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:01:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:00 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:01:00 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:01:00 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:01:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:01:00 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:01:00 --> Final output sent to browser
DEBUG - 2015-02-02 11:01:00 --> Total execution time: 0.2110
DEBUG - 2015-02-02 11:01:10 --> Config Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:01:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:01:10 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:01:10 --> URI Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Router Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Output Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Security Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Input Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:01:10 --> Language Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Loader Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:01:10 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:01:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:01:10 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:01:10 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:01:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Controller Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:01:10 --> Email Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:01:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:01:10 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:01:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:01:10 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:01:10 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:01:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:01:10 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:10 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:01:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:01:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:01:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:01:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:01:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:01:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:01:10 --> Final output sent to browser
DEBUG - 2015-02-02 11:01:10 --> Total execution time: 0.2290
DEBUG - 2015-02-02 11:01:27 --> Config Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:01:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:01:27 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:01:27 --> URI Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Router Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Output Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Security Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Input Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:01:27 --> Language Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Loader Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:01:27 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:01:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:01:27 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:01:27 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:01:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Controller Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:01:27 --> Email Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:01:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:01:27 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:01:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:01:27 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:01:27 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:01:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:01:27 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:27 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:01:27 --> Final output sent to browser
DEBUG - 2015-02-02 11:01:27 --> Total execution time: 0.2210
DEBUG - 2015-02-02 11:01:41 --> Config Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:01:41 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:01:41 --> URI Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Router Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Output Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Security Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Input Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:01:41 --> Language Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Loader Class Initialized
DEBUG - 2015-02-02 11:01:41 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:01:41 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:01:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:01:41 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:01:42 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:01:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:42 --> Controller Class Initialized
DEBUG - 2015-02-02 11:01:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:01:42 --> Email Class Initialized
DEBUG - 2015-02-02 11:01:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:01:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:01:42 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:01:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:01:42 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:01:42 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:01:42 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:01:42 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:01:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:01:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:01:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:01:42 --> Final output sent to browser
DEBUG - 2015-02-02 11:01:42 --> Total execution time: 0.1960
DEBUG - 2015-02-02 11:02:05 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:05 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:05 --> Language Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Loader Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:02:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:02:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:02:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:02:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:02:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Controller Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:02:05 --> Email Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:02:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:02:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:02:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:02:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:02:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:02:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:02:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:02:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:02:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:02:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-02 11:02:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:02:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:02:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:02:05 --> Final output sent to browser
DEBUG - 2015-02-02 11:02:05 --> Total execution time: 0.2190
DEBUG - 2015-02-02 11:02:16 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:16 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:16 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:16 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:16 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:16 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:16 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:16 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:16 --> Language Class Initialized
ERROR - 2015-02-02 11:02:16 --> 404 Page Not Found: Auth/create
DEBUG - 2015-02-02 11:02:19 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:19 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:19 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:19 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:19 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:19 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:19 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:19 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:19 --> Language Class Initialized
ERROR - 2015-02-02 11:02:19 --> 404 Page Not Found: Auth/create_account
DEBUG - 2015-02-02 11:02:30 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:30 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:30 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:30 --> Language Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Loader Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:02:30 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:02:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:02:30 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:02:30 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:02:30 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Controller Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:02:30 --> Email Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:02:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:02:30 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:02:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:30 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:02:30 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:02:30 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:02:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:02:30 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:30 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:02:31 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:31 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:31 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:31 --> Language Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Loader Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:02:31 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:02:31 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:02:31 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Controller Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:02:31 --> Email Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:02:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:31 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:02:31 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:02:31 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:02:31 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:31 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:31 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:31 --> Language Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Loader Class Initialized
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:02:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:02:31 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:02:31 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:02:32 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:32 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:32 --> Controller Class Initialized
DEBUG - 2015-02-02 11:02:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:02:32 --> Email Class Initialized
DEBUG - 2015-02-02 11:02:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:02:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:02:32 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:02:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:32 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:32 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:02:32 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:02:32 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:02:32 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:02:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:02:32 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:02:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:02:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:02:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:02:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:02:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:02:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:02:32 --> Final output sent to browser
DEBUG - 2015-02-02 11:02:32 --> Total execution time: 0.2410
DEBUG - 2015-02-02 11:02:56 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:56 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:56 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:56 --> Language Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Loader Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:02:56 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:02:56 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:02:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Controller Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:02:56 --> Email Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:02:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:02:56 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:02:56 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:02:56 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:56 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:56 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:56 --> Language Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Loader Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:02:56 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:02:56 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:02:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Controller Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:02:56 --> Email Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:02:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:02:56 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:02:56 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:02:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:02:56 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:02:57 --> Config Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:02:57 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:02:57 --> URI Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Router Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Output Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Security Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Input Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:02:57 --> Language Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Loader Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:02:57 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:02:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:02:57 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:02:57 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:02:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Controller Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:02:57 --> Email Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:02:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:02:57 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:02:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:02:57 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:02:57 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:02:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:02:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:02:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:02:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:02:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:02:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:02:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:02:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:02:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:02:57 --> Final output sent to browser
DEBUG - 2015-02-02 11:02:57 --> Total execution time: 0.1840
DEBUG - 2015-02-02 11:03:13 --> Config Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:03:13 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:03:13 --> URI Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Router Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Output Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Security Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Input Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:03:13 --> Language Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Loader Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:03:13 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:03:13 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Controller Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:03:13 --> Email Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:03:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:03:13 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:03:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:03:13 --> Config Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:03:13 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:03:13 --> URI Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Router Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Output Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Security Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Input Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:03:13 --> Language Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Loader Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:03:13 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:03:13 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Controller Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:03:13 --> Email Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:03:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:03:13 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:03:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:03:13 --> Config Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:03:13 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:03:13 --> URI Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Router Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Output Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Security Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Input Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:03:13 --> Language Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Loader Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:03:13 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:03:13 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Controller Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:03:13 --> Email Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:03:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:03:13 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:03:13 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:03:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:03:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:03:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:03:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:03:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:03:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:03:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:03:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:03:13 --> Final output sent to browser
DEBUG - 2015-02-02 11:03:13 --> Total execution time: 0.1820
DEBUG - 2015-02-02 11:03:37 --> Config Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:03:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:03:37 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:03:37 --> URI Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Router Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Output Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Security Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Input Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:03:37 --> Language Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Loader Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:03:37 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:03:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:03:37 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:03:37 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:03:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Controller Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:03:37 --> Email Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:03:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:03:37 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:03:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:03:37 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:03:37 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:03:37 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:03:37 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:03:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:03:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:03:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:03:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:03:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:03:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:03:37 --> Final output sent to browser
DEBUG - 2015-02-02 11:03:37 --> Total execution time: 0.2020
DEBUG - 2015-02-02 11:03:40 --> Config Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:03:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:03:40 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:03:40 --> URI Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Router Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Output Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Security Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Input Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:03:40 --> Language Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Loader Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:03:40 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:03:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:03:40 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:03:40 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:03:40 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Controller Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:03:40 --> Email Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:03:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:03:40 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:03:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:40 --> Model Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:03:40 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:03:40 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:03:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:03:40 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:03:40 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:03:40 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:03:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:03:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:03:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:03:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:03:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:03:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:03:40 --> Final output sent to browser
DEBUG - 2015-02-02 11:03:40 --> Total execution time: 0.2250
DEBUG - 2015-02-02 11:06:28 --> Config Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:06:28 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:06:28 --> URI Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Router Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Output Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Security Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Input Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:06:28 --> Language Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Loader Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:06:28 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:06:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:06:28 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:06:28 --> Session: Regenerate ID
DEBUG - 2015-02-02 11:06:28 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:06:29 --> Model Class Initialized
DEBUG - 2015-02-02 11:06:29 --> Model Class Initialized
DEBUG - 2015-02-02 11:06:29 --> Controller Class Initialized
DEBUG - 2015-02-02 11:06:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:06:29 --> Email Class Initialized
DEBUG - 2015-02-02 11:06:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:06:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:06:29 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:06:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:06:29 --> Model Class Initialized
DEBUG - 2015-02-02 11:06:29 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:06:29 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:06:29 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:06:29 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:06:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:06:29 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:06:29 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:06:29 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:06:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:06:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:06:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:06:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:06:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:06:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:06:29 --> Final output sent to browser
DEBUG - 2015-02-02 11:06:29 --> Total execution time: 0.2000
DEBUG - 2015-02-02 11:07:44 --> Config Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:07:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:07:44 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:07:44 --> URI Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Router Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Output Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Security Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Input Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:07:44 --> Language Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Loader Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:07:44 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:07:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:07:44 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:07:44 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:07:44 --> Model Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Model Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Controller Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:07:44 --> Email Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:07:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:07:44 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:07:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:07:44 --> Model Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:07:44 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:07:44 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:07:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:07:44 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:07:44 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:07:44 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:07:44 --> Final output sent to browser
DEBUG - 2015-02-02 11:07:44 --> Total execution time: 0.2160
DEBUG - 2015-02-02 11:10:21 --> Config Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:10:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:10:21 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:10:21 --> URI Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Router Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Output Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Security Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Input Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:10:21 --> Language Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Loader Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:10:21 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:10:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:10:21 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:10:21 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:10:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Controller Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:10:21 --> Email Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:10:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:10:21 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:10:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:10:21 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:10:21 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:10:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:10:21 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:21 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:10:21 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:10:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:10:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:10:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:10:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:10:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:10:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:10:21 --> Final output sent to browser
DEBUG - 2015-02-02 11:10:21 --> Total execution time: 0.2390
DEBUG - 2015-02-02 11:10:24 --> Config Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:10:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:10:24 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:10:24 --> URI Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Router Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Output Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Security Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Input Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:10:24 --> Language Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Loader Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:10:24 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:10:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:10:24 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:10:24 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:10:24 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Controller Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:10:24 --> Email Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:10:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:10:24 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:10:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:24 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:10:24 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:10:24 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:10:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:10:24 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:24 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:10:24 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:10:24 --> Final output sent to browser
DEBUG - 2015-02-02 11:10:24 --> Total execution time: 0.1950
DEBUG - 2015-02-02 11:10:38 --> Config Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:10:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:10:38 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:10:38 --> URI Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Router Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Output Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Security Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Input Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:10:38 --> Language Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Loader Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:10:38 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:10:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:10:38 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:10:38 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:10:38 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Controller Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:10:38 --> Email Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:10:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:10:38 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:10:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:38 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:10:38 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:10:38 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:10:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:10:38 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:38 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:10:38 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:10:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:10:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:10:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:10:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:10:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:10:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:10:38 --> Final output sent to browser
DEBUG - 2015-02-02 11:10:38 --> Total execution time: 0.2800
DEBUG - 2015-02-02 11:10:43 --> Config Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:10:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:10:43 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:10:43 --> URI Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Router Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Output Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Security Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Input Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:10:43 --> Language Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Loader Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:10:43 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:10:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:10:43 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:10:43 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:10:43 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Controller Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:10:43 --> Email Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:10:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:10:43 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:10:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:43 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:10:43 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:10:43 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:10:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:10:43 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:43 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:10:43 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:10:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:10:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:10:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:10:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:10:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:10:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:10:43 --> Final output sent to browser
DEBUG - 2015-02-02 11:10:43 --> Total execution time: 0.4220
DEBUG - 2015-02-02 11:10:47 --> Config Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:10:47 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:10:47 --> URI Class Initialized
DEBUG - 2015-02-02 11:10:47 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:10:47 --> Router Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Output Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Security Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Input Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:10:47 --> Language Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Loader Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:10:47 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:10:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:10:47 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:10:47 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:10:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Controller Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:10:47 --> Email Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:10:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:10:47 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:10:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:10:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:10:47 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:10:47 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:10:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:10:47 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:10:48 --> Final output sent to browser
DEBUG - 2015-02-02 11:10:48 --> Total execution time: 1.1551
DEBUG - 2015-02-02 11:11:06 --> Config Class Initialized
DEBUG - 2015-02-02 11:11:06 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:11:06 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:11:06 --> URI Class Initialized
DEBUG - 2015-02-02 11:11:06 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:11:06 --> Router Class Initialized
DEBUG - 2015-02-02 11:11:06 --> Output Class Initialized
DEBUG - 2015-02-02 11:11:06 --> Security Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Input Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:11:07 --> Language Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Loader Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:11:07 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:11:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:11:07 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:11:07 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:11:07 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Controller Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:11:07 --> Email Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:11:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:11:07 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:11:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:07 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:11:07 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:11:07 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:11:07 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:11:08 --> Final output sent to browser
DEBUG - 2015-02-02 11:11:08 --> Total execution time: 1.4491
DEBUG - 2015-02-02 11:11:11 --> Config Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:11:11 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:11:11 --> URI Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Router Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Output Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Security Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Input Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:11:11 --> Language Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Loader Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:11:11 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:11:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:11:11 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:11:11 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:11:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Controller Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:11:11 --> Email Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:11:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:11:11 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:11:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:11:11 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:11:11 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:11:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:11:11 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:11 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:11:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:11:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:11:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:11:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:11:12 --> Final output sent to browser
DEBUG - 2015-02-02 11:11:12 --> Total execution time: 0.2890
DEBUG - 2015-02-02 11:11:16 --> Config Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:11:16 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:11:16 --> URI Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Router Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Output Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Security Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Input Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:11:16 --> Language Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Loader Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:11:16 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:11:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:11:16 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:11:16 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:11:16 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Controller Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:11:16 --> Email Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:11:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:11:16 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:11:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:16 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:16 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:11:17 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:11:17 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:11:17 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:11:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:11:17 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:17 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:11:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:11:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:11:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:11:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:11:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:11:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:11:17 --> Final output sent to browser
DEBUG - 2015-02-02 11:11:17 --> Total execution time: 0.1980
DEBUG - 2015-02-02 11:11:24 --> Config Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:11:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:11:24 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:11:24 --> URI Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Router Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Output Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Security Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Input Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:11:24 --> Language Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Loader Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:11:24 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:11:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:11:24 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:11:24 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:11:24 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Controller Class Initialized
DEBUG - 2015-02-02 11:11:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:11:25 --> Email Class Initialized
DEBUG - 2015-02-02 11:11:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:11:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:11:25 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:11:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:25 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:25 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:11:25 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:11:25 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:11:25 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:11:25 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:11:25 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:11:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:11:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:11:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:11:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:11:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:11:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:11:25 --> Final output sent to browser
DEBUG - 2015-02-02 11:11:25 --> Total execution time: 0.7551
DEBUG - 2015-02-02 11:11:27 --> Config Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:11:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:11:27 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:11:27 --> URI Class Initialized
DEBUG - 2015-02-02 11:11:27 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:11:27 --> Router Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Output Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Security Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Input Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:11:27 --> Language Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Loader Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:11:27 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:11:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:11:27 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:11:27 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:11:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Controller Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:11:27 --> Email Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:11:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:11:27 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:11:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:11:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:11:27 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:11:27 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:11:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:11:27 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:11:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:11:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:11:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:11:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:11:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:11:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:11:28 --> Final output sent to browser
DEBUG - 2015-02-02 11:11:28 --> Total execution time: 1.2971
DEBUG - 2015-02-02 11:12:09 --> Config Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:12:09 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:12:09 --> URI Class Initialized
DEBUG - 2015-02-02 11:12:09 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:12:09 --> Router Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Output Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Security Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Input Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:12:09 --> Language Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Loader Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:12:09 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:12:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:12:09 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Session: Regenerate ID
DEBUG - 2015-02-02 11:12:09 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:12:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Controller Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:12:09 --> Email Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:12:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:12:09 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:12:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:12:09 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:12:09 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:12:09 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:12:10 --> Final output sent to browser
DEBUG - 2015-02-02 11:12:10 --> Total execution time: 1.2531
DEBUG - 2015-02-02 11:12:11 --> Config Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:12:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:12:11 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:12:11 --> URI Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Router Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Output Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Security Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Input Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:12:11 --> Language Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Loader Class Initialized
DEBUG - 2015-02-02 11:12:11 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:12:11 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:12:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:12:11 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:12:11 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:12:12 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:12 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:12 --> Controller Class Initialized
DEBUG - 2015-02-02 11:12:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:12:12 --> Email Class Initialized
DEBUG - 2015-02-02 11:12:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:12:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:12:12 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:12:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:12 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:12 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:12:12 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:12:12 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:12:12 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:12:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:12:12 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:12 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:12:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:12:12 --> Final output sent to browser
DEBUG - 2015-02-02 11:12:12 --> Total execution time: 0.2730
DEBUG - 2015-02-02 11:12:13 --> Config Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:12:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:12:13 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:12:13 --> URI Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Router Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Output Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Security Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Input Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:12:13 --> Language Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Loader Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:12:13 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:12:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:12:13 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:12:13 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:12:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Controller Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:12:13 --> Email Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:12:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:12:13 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:12:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:12:13 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:12:13 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:12:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:12:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:13 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:12:13 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:12:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:12:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:12:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:12:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:12:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:12:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:12:13 --> Final output sent to browser
DEBUG - 2015-02-02 11:12:13 --> Total execution time: 0.2590
DEBUG - 2015-02-02 11:12:53 --> Config Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:12:53 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:12:53 --> URI Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Router Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Output Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Security Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Input Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:12:53 --> Language Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Loader Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:12:53 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:12:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:12:53 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:12:53 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:12:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Controller Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:12:53 --> Email Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:12:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:12:53 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:12:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:12:53 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:12:53 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:12:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:12:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:53 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:12:53 --> Could not find the language line "create_user_validation_phone_label"
ERROR - 2015-02-02 11:12:54 --> Invalid driver requested: Session_userdata
DEBUG - 2015-02-02 11:12:59 --> Config Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:12:59 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:12:59 --> URI Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Router Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Output Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Security Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Input Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:12:59 --> Language Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Loader Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:12:59 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:12:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:12:59 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:12:59 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:12:59 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Controller Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:12:59 --> Email Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:12:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:12:59 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:12:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:59 --> Model Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:12:59 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:12:59 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:12:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:12:59 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:12:59 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:12:59 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:13:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:13:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:13:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:13:00 --> Final output sent to browser
DEBUG - 2015-02-02 11:13:00 --> Total execution time: 0.2320
DEBUG - 2015-02-02 11:13:13 --> Config Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:13:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:13:13 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:13:13 --> URI Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Router Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Output Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Security Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Input Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:13:13 --> Language Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Loader Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:13:13 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:13:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:13:13 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:13:13 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:13:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Controller Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:13:13 --> Email Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:13:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:13:13 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:13:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:13:13 --> Model Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:13:13 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:13:13 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:13:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:13:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:13:13 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:13:13 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:13:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:13:14 --> Final output sent to browser
DEBUG - 2015-02-02 11:13:14 --> Total execution time: 0.2100
DEBUG - 2015-02-02 11:14:46 --> Config Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:14:46 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:14:46 --> URI Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Router Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Output Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Security Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Input Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:14:46 --> Language Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Loader Class Initialized
DEBUG - 2015-02-02 11:14:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:14:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:14:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:14:47 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:14:47 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:14:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:14:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:14:47 --> Controller Class Initialized
DEBUG - 2015-02-02 11:14:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:14:47 --> Email Class Initialized
DEBUG - 2015-02-02 11:14:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:14:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:14:47 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:14:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:14:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:14:47 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:14:47 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:14:47 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:14:47 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:14:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:14:47 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:14:47 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:14:47 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:14:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:14:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:14:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:14:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:14:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:14:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:14:47 --> Final output sent to browser
DEBUG - 2015-02-02 11:14:47 --> Total execution time: 0.5201
DEBUG - 2015-02-02 11:14:49 --> Config Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:14:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:14:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:14:49 --> URI Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Router Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Output Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Security Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Input Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:14:49 --> Language Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Loader Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:14:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:14:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:14:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:14:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:14:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Controller Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:14:49 --> Email Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:14:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:14:49 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:14:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:14:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:14:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:14:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:14:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:14:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:14:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:14:49 --> Final output sent to browser
DEBUG - 2015-02-02 11:14:49 --> Total execution time: 0.2470
DEBUG - 2015-02-02 11:15:05 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:05 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:05 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:05 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:15:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:15:05 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:05 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:05 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:15:05 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:05 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:06 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:06 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:06 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:06 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:06 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:15:06 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:06 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:06 --> Total execution time: 0.7001
DEBUG - 2015-02-02 11:15:10 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:10 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:10 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:10 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:15:10 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:10 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:10 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:10 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:10 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:10 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:10 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:10 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:10 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:15:10 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:15:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:15:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:10 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:10 --> Total execution time: 0.7131
DEBUG - 2015-02-02 11:15:14 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:14 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:14 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:14 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:14 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:14 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:14 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:14 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:14 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:14 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:14 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:14 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:14 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:14 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:14 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:14 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:14 --> Total execution time: 0.2020
DEBUG - 2015-02-02 11:15:15 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:15 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:15 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:15 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:15 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:15 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:15 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:15 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:15 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:15 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:15 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:15 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:15 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:15 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:15 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:15 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:15:15 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-02 11:15:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-02 11:15:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:15 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:16 --> Total execution time: 0.2140
DEBUG - 2015-02-02 11:15:16 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:16 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:16 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:16 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:16 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:16 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:16 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:16 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:17 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:17 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:17 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:17 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:17 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:17 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:17 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:17 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:17 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:17 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:15:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:15:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:17 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:17 --> Total execution time: 0.2280
DEBUG - 2015-02-02 11:15:36 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:36 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:36 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:36 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:36 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:36 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:36 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:36 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:36 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:36 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:36 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:15:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:15:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:36 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:36 --> Total execution time: 0.2520
DEBUG - 2015-02-02 11:15:53 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:53 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:53 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:53 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:53 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:53 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:53 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:53 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:53 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:53 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:53 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:53 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:53 --> Total execution time: 0.2140
DEBUG - 2015-02-02 11:15:57 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:57 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:57 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:57 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:57 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:57 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:57 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:57 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:57 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:57 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:57 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:15:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:15:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:57 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:57 --> Total execution time: 0.2490
DEBUG - 2015-02-02 11:15:59 --> Config Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:15:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:15:59 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:15:59 --> URI Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Router Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Output Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Security Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Input Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:15:59 --> Language Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Loader Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:15:59 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:15:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:15:59 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:15:59 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:15:59 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Controller Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:15:59 --> Email Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:15:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:15:59 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:15:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:59 --> Model Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:15:59 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:15:59 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:15:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:15:59 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:15:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:15:59 --> Final output sent to browser
DEBUG - 2015-02-02 11:15:59 --> Total execution time: 0.2170
DEBUG - 2015-02-02 11:16:05 --> Config Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:16:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:16:05 --> URI Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Router Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Output Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Security Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Input Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:16:05 --> Language Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Loader Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:16:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:16:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:16:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Controller Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:16:05 --> Email Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:16:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:16:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:16:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:16:05 --> Session: Creating new session (6c95564ff4c122d98dbc4e31f87fa3c3)
DEBUG - 2015-02-02 11:16:05 --> Config Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:16:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:16:05 --> URI Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Router Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Output Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Security Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Input Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:16:05 --> Language Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Loader Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:16:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:16:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:16:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Controller Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:16:05 --> Email Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:16:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:16:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:16:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:16:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:16:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:16:05 --> Final output sent to browser
DEBUG - 2015-02-02 11:16:05 --> Total execution time: 0.1960
DEBUG - 2015-02-02 11:16:36 --> Config Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:16:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:16:36 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:16:36 --> URI Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Router Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Output Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Security Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Input Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:16:36 --> Language Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Loader Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:16:36 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:16:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:16:36 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:16:36 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:16:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Controller Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:16:36 --> Email Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:16:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:16:36 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:16:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:16:36 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:16:36 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:16:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:16:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:16:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:16:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:16:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:16:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:16:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:16:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:16:36 --> Final output sent to browser
DEBUG - 2015-02-02 11:16:36 --> Total execution time: 0.1930
DEBUG - 2015-02-02 11:16:37 --> Config Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:16:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:16:37 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:16:37 --> URI Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Router Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Output Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Security Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Input Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:16:37 --> Language Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Loader Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:16:37 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:16:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:16:37 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:16:37 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:16:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:37 --> Controller Class Initialized
DEBUG - 2015-02-02 11:16:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:16:38 --> Email Class Initialized
DEBUG - 2015-02-02 11:16:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:16:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:16:38 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:16:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:38 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:38 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:16:38 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:16:38 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:16:38 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:16:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:16:38 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:38 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:16:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:16:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:16:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:16:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:16:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:16:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:16:38 --> Final output sent to browser
DEBUG - 2015-02-02 11:16:38 --> Total execution time: 0.2130
DEBUG - 2015-02-02 11:16:49 --> Config Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:16:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:16:49 --> URI Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Router Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Output Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Security Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Input Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:16:49 --> Language Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Loader Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:16:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:16:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:16:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Controller Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:16:49 --> Email Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:16:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:16:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:16:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:16:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:16:49 --> Config Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:16:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:16:49 --> URI Class Initialized
DEBUG - 2015-02-02 11:16:49 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:16:49 --> Router Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Output Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Security Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Input Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:16:49 --> Language Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Loader Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:16:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:16:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:16:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Controller Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:16:49 --> Email Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:16:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:16:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:16:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:16:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:16:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:16:49 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:16:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:16:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:16:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:16:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:16:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:16:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:16:50 --> Final output sent to browser
DEBUG - 2015-02-02 11:16:50 --> Total execution time: 0.7161
DEBUG - 2015-02-02 11:17:46 --> Config Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:17:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:17:46 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:17:46 --> URI Class Initialized
DEBUG - 2015-02-02 11:17:46 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:17:46 --> Router Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Output Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Security Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Input Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:17:46 --> Language Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Loader Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:17:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:17:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:17:46 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:17:46 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:17:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Controller Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:17:46 --> Email Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:17:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:17:46 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:17:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:17:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:17:46 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:17:46 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:17:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:17:46 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:17:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:17:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:17:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:17:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:17:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:17:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:17:47 --> Final output sent to browser
DEBUG - 2015-02-02 11:17:47 --> Total execution time: 0.8561
DEBUG - 2015-02-02 11:17:48 --> Config Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:17:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:17:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:17:48 --> URI Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Router Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Output Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Security Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Input Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:17:48 --> Language Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Loader Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:17:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:17:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:17:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:17:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:17:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Controller Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:17:48 --> Email Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:17:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:17:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:17:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:17:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:17:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:17:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:17:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:17:48 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:17:48 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:17:49 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:17:49 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:17:49 --> Final output sent to browser
DEBUG - 2015-02-02 11:17:49 --> Total execution time: 0.3270
DEBUG - 2015-02-02 11:19:27 --> Config Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:19:27 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:19:27 --> URI Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Router Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Output Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Security Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Input Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:19:27 --> Language Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Loader Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:19:27 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:19:27 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:19:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Controller Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:19:27 --> Email Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:19:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:19:27 --> Model Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:19:27 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:19:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:19:27 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:19:27 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:19:27 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:19:27 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:19:27 --> Final output sent to browser
DEBUG - 2015-02-02 11:19:27 --> Total execution time: 0.4860
DEBUG - 2015-02-02 11:19:51 --> Config Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:19:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:19:51 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:19:51 --> URI Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Router Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Output Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Security Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Input Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:19:51 --> Language Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Loader Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:19:51 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:19:51 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:19:51 --> Model Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Model Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Controller Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:19:51 --> Email Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:19:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:19:51 --> Model Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:19:51 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:19:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:19:51 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:19:51 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:19:51 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:19:51 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:19:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:19:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:19:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:19:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:19:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:19:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:19:51 --> Final output sent to browser
DEBUG - 2015-02-02 11:19:51 --> Total execution time: 0.2620
DEBUG - 2015-02-02 11:21:30 --> Config Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:21:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:21:30 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:21:30 --> URI Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Router Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Output Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Security Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Input Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:21:30 --> Language Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Loader Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:21:30 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:21:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:21:30 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Session: Regenerate ID
DEBUG - 2015-02-02 11:21:30 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:21:30 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Controller Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:21:30 --> Email Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:21:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:21:30 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:21:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:30 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:21:30 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:21:30 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:21:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:21:30 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:30 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:21:30 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:21:31 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:21:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:21:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:21:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:21:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:21:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:21:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:21:31 --> Final output sent to browser
DEBUG - 2015-02-02 11:21:31 --> Total execution time: 0.2710
DEBUG - 2015-02-02 11:21:35 --> Config Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:21:35 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:21:35 --> URI Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Router Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Output Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Security Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Input Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:21:35 --> Language Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Loader Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:21:35 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:21:35 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:21:35 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Controller Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:21:35 --> Email Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:21:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:35 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:21:35 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:21:35 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:21:35 --> Config Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:21:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:21:35 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:21:35 --> URI Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Router Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Output Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Security Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Input Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:21:35 --> Language Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Loader Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:21:35 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:21:35 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:21:35 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Controller Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:21:35 --> Email Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:21:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:35 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:21:35 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:21:35 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:21:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:21:35 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:21:42 --> Config Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:21:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:21:42 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:21:42 --> URI Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Router Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Output Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Security Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Input Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:21:42 --> Language Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Loader Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:21:42 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:21:42 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:21:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Controller Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:21:42 --> Email Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:21:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:21:42 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:21:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:21:42 --> Config Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:21:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:21:42 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:21:42 --> URI Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Router Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Output Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Security Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Input Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:21:42 --> Language Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Loader Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:21:42 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:21:42 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:21:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Controller Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:21:42 --> Email Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:21:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:21:42 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:21:42 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:21:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:21:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:21:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:23:38 --> Config Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:23:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:23:38 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:23:38 --> URI Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Router Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Output Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Security Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Input Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:23:38 --> Language Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Loader Class Initialized
DEBUG - 2015-02-02 11:23:38 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:23:38 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:23:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:23:38 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:23:38 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:23:39 --> Model Class Initialized
DEBUG - 2015-02-02 11:23:39 --> Model Class Initialized
DEBUG - 2015-02-02 11:23:39 --> Controller Class Initialized
DEBUG - 2015-02-02 11:23:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:23:39 --> Email Class Initialized
DEBUG - 2015-02-02 11:23:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:23:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:23:39 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:23:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:23:39 --> Model Class Initialized
DEBUG - 2015-02-02 11:23:39 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:23:39 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:23:39 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:23:39 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:23:39 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:23:39 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:23:39 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:23:39 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:23:39 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:23:39 --> Final output sent to browser
DEBUG - 2015-02-02 11:23:39 --> Total execution time: 0.2400
DEBUG - 2015-02-02 11:24:06 --> Config Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:24:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:24:06 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:24:06 --> URI Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Router Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Output Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Security Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Input Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:24:06 --> Language Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Loader Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:24:06 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:24:06 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:24:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Controller Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:24:06 --> Email Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:24:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:24:06 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:24:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:24:06 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:06 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:24:06 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:24:06 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:24:06 --> Final output sent to browser
DEBUG - 2015-02-02 11:24:06 --> Total execution time: 0.2471
DEBUG - 2015-02-02 11:24:14 --> Config Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:24:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:24:14 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:24:14 --> URI Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Router Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Output Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Security Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Input Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:24:14 --> Language Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Loader Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:24:14 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:24:14 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:24:14 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Controller Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:24:14 --> Email Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:24:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:14 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:24:14 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:24:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:24:14 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:14 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:24:14 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:24:14 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:24:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:24:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:24:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:24:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:24:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:24:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:24:14 --> Final output sent to browser
DEBUG - 2015-02-02 11:24:14 --> Total execution time: 0.3171
DEBUG - 2015-02-02 11:24:21 --> Config Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:24:21 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:24:21 --> URI Class Initialized
DEBUG - 2015-02-02 11:24:21 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:24:21 --> Router Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Output Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Security Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Input Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:24:21 --> Language Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Loader Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:24:21 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:24:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:24:21 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:24:21 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Controller Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:24:21 --> Email Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:24:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:24:21 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:24:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:24:21 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:24:21 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:24:21 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:24:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:24:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:24:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:24:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:24:22 --> Final output sent to browser
DEBUG - 2015-02-02 11:24:22 --> Total execution time: 0.7652
DEBUG - 2015-02-02 11:24:36 --> Config Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:24:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:24:36 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:24:36 --> URI Class Initialized
DEBUG - 2015-02-02 11:24:36 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:24:36 --> Router Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Output Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Security Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Input Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:24:36 --> Language Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Loader Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:24:36 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:24:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:24:36 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:24:36 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:24:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Controller Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:24:36 --> Email Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:24:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:24:36 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:24:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:24:36 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:24:36 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:24:36 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:24:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:24:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:24:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:24:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:24:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:24:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:24:37 --> Final output sent to browser
DEBUG - 2015-02-02 11:24:37 --> Total execution time: 0.6931
DEBUG - 2015-02-02 11:24:46 --> Config Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:24:46 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:24:46 --> URI Class Initialized
DEBUG - 2015-02-02 11:24:46 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:24:46 --> Router Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Output Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Security Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Input Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:24:46 --> Language Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Loader Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:24:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:24:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:24:46 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:24:46 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:24:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Controller Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:24:46 --> Email Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:24:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:24:46 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:24:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:24:46 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:24:46 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:24:46 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:24:46 --> Final output sent to browser
DEBUG - 2015-02-02 11:24:46 --> Total execution time: 0.7321
DEBUG - 2015-02-02 11:24:54 --> Config Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:24:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:24:54 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:24:54 --> URI Class Initialized
DEBUG - 2015-02-02 11:24:54 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:24:54 --> Router Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Output Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Security Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Input Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:24:54 --> Language Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Loader Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:24:54 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:24:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:24:54 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:24:54 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:24:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Controller Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:24:54 --> Email Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:24:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:24:54 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:24:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:24:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:24:54 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:24:54 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:24:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:24:54 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:24:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:24:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:24:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:24:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:24:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:24:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:24:55 --> Final output sent to browser
DEBUG - 2015-02-02 11:24:55 --> Total execution time: 0.7011
DEBUG - 2015-02-02 11:25:06 --> Config Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:25:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:25:06 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:25:06 --> URI Class Initialized
DEBUG - 2015-02-02 11:25:06 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:25:06 --> Router Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Output Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Security Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Input Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:25:06 --> Language Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Loader Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:25:06 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:25:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:25:06 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:25:06 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:25:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Controller Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:25:06 --> Email Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:25:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:25:06 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:25:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:25:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:25:06 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:25:06 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:25:06 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:25:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:25:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:25:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:25:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:25:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:25:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:25:07 --> Final output sent to browser
DEBUG - 2015-02-02 11:25:07 --> Total execution time: 0.7932
DEBUG - 2015-02-02 11:25:20 --> Config Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:25:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:25:20 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:25:20 --> URI Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Router Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Output Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Security Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Input Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:25:20 --> Language Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Loader Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:25:20 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:25:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:25:20 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:25:20 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:25:20 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Controller Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:25:20 --> Email Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:25:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:25:20 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:25:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:25:20 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:25:20 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:25:20 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Model Class Initialized
DEBUG - 2015-02-02 11:25:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:25:20 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:25:20 --> Final output sent to browser
DEBUG - 2015-02-02 11:25:20 --> Total execution time: 0.7181
DEBUG - 2015-02-02 11:26:55 --> Config Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:26:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:26:55 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:26:55 --> URI Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Router Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Output Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Security Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Input Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:26:55 --> Language Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Loader Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:26:55 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:26:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:26:55 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Session: Regenerate ID
DEBUG - 2015-02-02 11:26:55 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:26:55 --> Model Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Model Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Controller Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:26:55 --> Email Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:26:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:26:55 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:26:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:26:55 --> Model Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:26:55 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:26:55 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Model Class Initialized
DEBUG - 2015-02-02 11:26:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:26:55 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:26:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:26:56 --> Final output sent to browser
DEBUG - 2015-02-02 11:26:56 --> Total execution time: 0.8952
DEBUG - 2015-02-02 11:27:09 --> Config Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:27:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:27:09 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:27:09 --> URI Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Router Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Output Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Security Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Input Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:27:09 --> Language Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Loader Class Initialized
DEBUG - 2015-02-02 11:27:09 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:27:09 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:27:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:27:09 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:27:10 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Controller Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:27:10 --> Email Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:27:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:27:10 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:27:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:27:10 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:27:10 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:27:10 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:27:10 --> Final output sent to browser
DEBUG - 2015-02-02 11:27:10 --> Total execution time: 0.7942
DEBUG - 2015-02-02 11:27:17 --> Config Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:27:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:27:17 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:27:17 --> URI Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Router Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Output Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Security Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Input Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:27:17 --> Language Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Loader Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:27:17 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:27:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:27:17 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:27:17 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:27:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Controller Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:27:17 --> Email Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:27:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:27:17 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:27:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:27:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:27:17 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:27:17 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:27:17 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:27:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:27:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:27:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:27:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:27:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:27:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:27:18 --> Final output sent to browser
DEBUG - 2015-02-02 11:27:18 --> Total execution time: 0.7341
DEBUG - 2015-02-02 11:27:21 --> Config Class Initialized
DEBUG - 2015-02-02 11:27:21 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:27:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:27:21 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:27:21 --> URI Class Initialized
DEBUG - 2015-02-02 11:27:21 --> Router Class Initialized
DEBUG - 2015-02-02 11:27:21 --> Output Class Initialized
DEBUG - 2015-02-02 11:27:21 --> Security Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Input Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:27:22 --> Language Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Loader Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:27:22 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:27:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:27:22 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:27:22 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:27:22 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Controller Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:27:22 --> Email Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:27:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:27:22 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:27:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:27:22 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:27:22 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:27:22 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:27:22 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:27:22 --> Final output sent to browser
DEBUG - 2015-02-02 11:27:22 --> Total execution time: 0.7151
DEBUG - 2015-02-02 11:27:26 --> Config Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:27:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:27:26 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:27:26 --> URI Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Router Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Output Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Security Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Input Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:27:26 --> Language Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Loader Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:27:26 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:27:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:27:26 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:27:26 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:27:26 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Controller Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:27:26 --> Email Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:27:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:27:26 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:27:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:27:26 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:27:26 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:27:26 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:27:26 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:27:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:27:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:27:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:27:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:27:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:27:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:27:27 --> Final output sent to browser
DEBUG - 2015-02-02 11:27:27 --> Total execution time: 0.7331
DEBUG - 2015-02-02 11:27:31 --> Config Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:27:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:27:31 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:27:31 --> URI Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Router Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Output Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Security Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Input Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:27:31 --> Language Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Loader Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:27:31 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:27:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:27:31 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:27:31 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:27:31 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Controller Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:27:31 --> Email Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:27:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:27:31 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:27:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:27:31 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:27:31 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:27:31 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Model Class Initialized
DEBUG - 2015-02-02 11:27:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:27:31 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:27:31 --> Final output sent to browser
DEBUG - 2015-02-02 11:27:31 --> Total execution time: 0.8241
DEBUG - 2015-02-02 11:28:19 --> Config Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:28:19 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:28:19 --> URI Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Router Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Output Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Security Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Input Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:28:19 --> Language Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Loader Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:28:19 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:28:19 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:28:19 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Controller Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:28:19 --> Email Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:28:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:28:19 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:28:19 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:28:19 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:28:19 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:28:19 --> Session: Creating new session (9a73b2679b946d2c38b4671bb981757e)
DEBUG - 2015-02-02 11:28:19 --> Config Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:28:19 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:28:19 --> URI Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Router Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Output Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Security Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Input Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:28:19 --> Language Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Loader Class Initialized
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:28:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:28:19 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:28:19 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:28:20 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:20 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:20 --> Controller Class Initialized
DEBUG - 2015-02-02 11:28:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:28:20 --> Email Class Initialized
DEBUG - 2015-02-02 11:28:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:28:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:28:20 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:28:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:28:20 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:20 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:28:20 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:28:20 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:28:20 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:28:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:28:20 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:28:20 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:28:20 --> Final output sent to browser
DEBUG - 2015-02-02 11:28:20 --> Total execution time: 0.2150
DEBUG - 2015-02-02 11:28:28 --> Config Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:28:28 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:28:28 --> URI Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Router Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Output Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Security Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Input Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:28:28 --> Language Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Loader Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:28:28 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:28:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:28:28 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:28:28 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:28:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Controller Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:28:28 --> Email Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:28:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:28:28 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:28:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:28:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:28 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:28:29 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:28:29 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:28:29 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:28:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:28:29 --> Config Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:28:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:28:29 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:28:29 --> URI Class Initialized
DEBUG - 2015-02-02 11:28:29 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:28:29 --> Router Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Output Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Security Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Input Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:28:29 --> Language Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Loader Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:28:29 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:28:29 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:28:29 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Controller Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:28:29 --> Email Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:28:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:28:29 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:28:29 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:28:29 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Model Class Initialized
DEBUG - 2015-02-02 11:28:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:28:29 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:28:30 --> Final output sent to browser
DEBUG - 2015-02-02 11:28:30 --> Total execution time: 0.7211
DEBUG - 2015-02-02 11:29:47 --> Config Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:29:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:29:47 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:29:47 --> URI Class Initialized
DEBUG - 2015-02-02 11:29:47 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:29:47 --> Router Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Output Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Security Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Input Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:29:47 --> Language Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Loader Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:29:47 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:29:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:29:47 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:29:47 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:29:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Controller Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:29:47 --> Email Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:29:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:29:47 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:29:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:29:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:29:47 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:29:47 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:29:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:29:47 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:29:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:29:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:29:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:29:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:29:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:29:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:29:48 --> Final output sent to browser
DEBUG - 2015-02-02 11:29:48 --> Total execution time: 0.7241
DEBUG - 2015-02-02 11:29:56 --> Config Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:29:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:29:56 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:29:56 --> URI Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Router Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Output Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Security Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Input Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:29:56 --> Language Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Loader Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:29:56 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:29:56 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:29:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Controller Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:29:56 --> Email Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:29:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:29:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:29:56 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:29:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:29:56 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:29:56 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-02 11:29:56 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-02 11:29:56 --> Helper loaded: string_helper
DEBUG - 2015-02-02 11:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-02 11:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:29:56 --> Final output sent to browser
DEBUG - 2015-02-02 11:29:56 --> Total execution time: 0.3670
DEBUG - 2015-02-02 11:30:02 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:02 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:02 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:02 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:02 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:02 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:02 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:02 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:02 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:02 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:02 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:02 --> Session: Creating new session (0c9e3ecc5cd5925eb6cccfbd14b88725)
DEBUG - 2015-02-02 11:30:02 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:02 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:02 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:02 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:02 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:02 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:02 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:02 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:02 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:02 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:02 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:02 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:30:02 --> Final output sent to browser
DEBUG - 2015-02-02 11:30:02 --> Total execution time: 0.2090
DEBUG - 2015-02-02 11:30:10 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:10 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:10 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:10 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:10 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:10 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:10 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:10 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:10 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:11 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:11 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:11 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:11 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:11 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:11 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-02-02 11:30:11 --> Severity: Notice --> Undefined property: stdClass::$group D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 1729
DEBUG - 2015-02-02 11:30:11 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:11 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:11 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:11 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:30:11 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:11 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:11 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:11 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:11 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:11 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:11 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:30:11 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:30:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:30:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:30:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:30:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:30:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:30:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:30:12 --> Final output sent to browser
DEBUG - 2015-02-02 11:30:12 --> Total execution time: 0.7031
DEBUG - 2015-02-02 11:30:28 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:28 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:28 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:28 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:28 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:28 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:28 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:28 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:28 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:28 --> Session: Creating new session (f56ae73e6f0167d60bc3eac983b1c3e8)
DEBUG - 2015-02-02 11:30:28 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:28 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:28 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:28 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:28 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:28 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:28 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:28 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:28 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:28 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:30:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:30:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:30:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:30:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:30:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:30:28 --> Final output sent to browser
DEBUG - 2015-02-02 11:30:28 --> Total execution time: 0.2590
DEBUG - 2015-02-02 11:30:46 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:46 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:46 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:46 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:46 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:46 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:46 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:46 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:46 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:46 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:46 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:30:47 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:47 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:47 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:47 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:30:47 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:47 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:47 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:47 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:47 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:47 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:47 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:47 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:47 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:30:47 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:30:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:30:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:30:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:30:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:30:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:30:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:30:47 --> Final output sent to browser
DEBUG - 2015-02-02 11:30:47 --> Total execution time: 0.7421
DEBUG - 2015-02-02 11:30:56 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:56 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:56 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:56 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:56 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:56 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:56 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:56 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:56 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:56 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:57 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:57 --> Session: Creating new session (2d4fdba45df08dd826503f96769b30bc)
DEBUG - 2015-02-02 11:30:57 --> Config Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:30:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:30:57 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:30:57 --> URI Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Router Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Output Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Security Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Input Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:30:57 --> Language Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Loader Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:30:57 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:30:57 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:30:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Controller Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:30:57 --> Email Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:30:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:30:57 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:30:57 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:30:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:30:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:30:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:30:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:30:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:30:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:30:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:30:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:30:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:30:57 --> Final output sent to browser
DEBUG - 2015-02-02 11:30:57 --> Total execution time: 0.2170
DEBUG - 2015-02-02 11:31:05 --> Config Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:31:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:31:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:31:05 --> URI Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Router Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Output Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Security Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Input Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:31:05 --> Language Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Loader Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:31:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:31:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:31:05 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:31:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:31:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Controller Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:31:05 --> Email Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:31:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:31:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:31:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:31:05 --> Model Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:31:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:31:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:31:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:31:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:31:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:31:05 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:37:20 --> Config Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:37:20 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:37:20 --> URI Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Router Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Output Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Security Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Input Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:37:20 --> Language Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Loader Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:37:20 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:37:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:37:20 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:37:20 --> Session: Regenerate ID
DEBUG - 2015-02-02 11:37:20 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:37:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:21 --> Controller Class Initialized
DEBUG - 2015-02-02 11:37:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:37:21 --> Email Class Initialized
DEBUG - 2015-02-02 11:37:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:37:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:37:21 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:37:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:37:21 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:21 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:37:21 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:37:21 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:37:21 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:37:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:37:21 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:37:21 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:37:21 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-02-02 11:37:21 --> Query error: Table 'funny.user_groups' doesn't exist - Invalid query: SELECT `email`, `username`, `email`, `id`, `password`, `active`, `last_login`
FROM `users`
JOIN `user_groups` ON `user_group`.`user_id` = `users`.`id`
JOIN `groups` ON `groups`.`id` = `user_groups`.`group_id`
WHERE `email` = 'svtxphu@gmail.com'
ORDER BY `id` DESC
 LIMIT 1
DEBUG - 2015-02-02 11:37:21 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-02 11:37:40 --> Config Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:37:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:37:40 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:37:40 --> URI Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Router Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Output Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Security Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Input Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:37:40 --> Language Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Loader Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:37:40 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:37:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:37:40 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:37:40 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:37:40 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Controller Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:37:40 --> Email Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:37:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:37:40 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:37:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:37:40 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:37:40 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:37:40 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:37:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:37:40 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:37:40 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:37:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-02-02 11:37:40 --> Query error: Column 'id' in field list is ambiguous - Invalid query: SELECT `email`, `username`, `email`, `id`, `password`, `active`, `last_login`
FROM `users`
JOIN `users_groups` ON `users_group`.`user_id` = `users`.`id`
JOIN `groups` ON `groups`.`id` = `users_groups`.`group_id`
WHERE `email` = 'svtxphu@gmail.com'
ORDER BY `id` DESC
 LIMIT 1
DEBUG - 2015-02-02 11:37:40 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-02 11:37:57 --> Config Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:37:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:37:57 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:37:57 --> URI Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Router Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Output Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Security Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Input Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:37:57 --> Language Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Loader Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:37:57 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:37:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:37:57 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:37:57 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:37:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Controller Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:37:57 --> Email Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:37:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:37:57 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:37:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:37:57 --> Model Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:37:57 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:37:57 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:37:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:37:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:37:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:37:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-02-02 11:37:57 --> Query error: Unknown column 'users_group.user_id' in 'on clause' - Invalid query: SELECT `email`, `username`, `email`, `users`.`id`, `password`, `active`, `last_login`
FROM `users`
JOIN `users_groups` ON `users_group`.`user_id` = `users`.`id`
JOIN `groups` ON `groups`.`id` = `users_groups`.`group_id`
WHERE `email` = 'svtxphu@gmail.com'
ORDER BY `id` DESC
 LIMIT 1
DEBUG - 2015-02-02 11:37:57 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-02 11:38:07 --> Config Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:38:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:38:07 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:38:07 --> URI Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Router Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Output Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Security Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Input Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:38:07 --> Language Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Loader Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:38:07 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:38:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:38:07 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:38:07 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:38:07 --> Model Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Model Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Controller Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:38:07 --> Email Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:38:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:38:07 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:38:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:38:07 --> Model Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:38:07 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:38:07 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:38:07 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:38:07 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:38:07 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:38:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:38:28 --> Config Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:38:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:38:28 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:38:28 --> URI Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Router Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Output Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Security Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Input Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:38:28 --> Language Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Loader Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:38:28 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:38:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:38:28 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:38:28 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:38:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Controller Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:38:28 --> Email Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:38:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:38:28 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:38:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:38:28 --> Model Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:38:28 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:38:28 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:38:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:38:28 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:38:28 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:38:28 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:39:08 --> Config Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:39:08 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:39:08 --> URI Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Router Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Output Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Security Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Input Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:39:08 --> Language Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Loader Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:39:08 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:39:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:39:08 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:39:08 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:39:08 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Controller Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:39:08 --> Email Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:39:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:39:08 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:39:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:08 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:39:08 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:39:08 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:39:08 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:39:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:39:08 --> Config Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:39:08 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:39:08 --> URI Class Initialized
DEBUG - 2015-02-02 11:39:08 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:39:08 --> Router Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Output Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Security Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Input Class Initialized
DEBUG - 2015-02-02 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:39:08 --> Language Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Loader Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:39:09 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:39:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:39:09 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:39:09 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:39:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Controller Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:39:09 --> Email Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:39:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:39:09 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:39:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:39:09 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:39:09 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:39:09 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:39:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:39:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:39:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:39:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:39:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:39:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:39:09 --> Final output sent to browser
DEBUG - 2015-02-02 11:39:09 --> Total execution time: 0.7051
DEBUG - 2015-02-02 11:39:41 --> Config Class Initialized
DEBUG - 2015-02-02 11:39:41 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:39:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:39:41 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:39:41 --> URI Class Initialized
DEBUG - 2015-02-02 11:39:41 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:39:41 --> Router Class Initialized
DEBUG - 2015-02-02 11:39:41 --> Output Class Initialized
DEBUG - 2015-02-02 11:39:41 --> Security Class Initialized
DEBUG - 2015-02-02 11:39:41 --> Input Class Initialized
DEBUG - 2015-02-02 11:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:39:41 --> Language Class Initialized
DEBUG - 2015-02-02 11:39:41 --> Loader Class Initialized
DEBUG - 2015-02-02 11:39:41 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:39:41 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:39:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:39:41 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:39:41 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:39:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Controller Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:39:42 --> Email Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:39:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:39:42 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:39:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:39:42 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:39:42 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:39:42 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:39:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:39:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:39:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:39:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:39:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:39:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:39:42 --> Final output sent to browser
DEBUG - 2015-02-02 11:39:42 --> Total execution time: 0.6941
DEBUG - 2015-02-02 11:39:45 --> Config Class Initialized
DEBUG - 2015-02-02 11:39:45 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:39:45 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:39:46 --> URI Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Router Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Output Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Security Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Input Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:39:46 --> Language Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Loader Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:39:46 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:39:46 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:39:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Controller Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:39:46 --> Email Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:39:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:39:46 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:39:46 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:39:46 --> Session: Creating new session (23b0863a80cc55ebd4f6b73e8bb828c4)
DEBUG - 2015-02-02 11:39:46 --> Config Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:39:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:39:46 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:39:46 --> URI Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Router Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Output Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Security Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Input Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:39:46 --> Language Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Loader Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:39:46 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:39:46 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:39:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Controller Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:39:46 --> Email Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:39:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:46 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:39:46 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:39:46 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:39:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:39:46 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:39:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:39:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:39:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:39:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:39:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:39:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:39:46 --> Final output sent to browser
DEBUG - 2015-02-02 11:39:46 --> Total execution time: 0.1970
DEBUG - 2015-02-02 11:39:53 --> Config Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:39:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:39:53 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:39:53 --> URI Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Router Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Output Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Security Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Input Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:39:53 --> Language Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Loader Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:39:53 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:39:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:39:53 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:39:53 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:39:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Controller Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:39:53 --> Email Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:39:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:39:53 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:39:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:53 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:39:53 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:39:53 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:39:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:39:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:39:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:39:54 --> Config Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:39:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:39:54 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:39:54 --> URI Class Initialized
DEBUG - 2015-02-02 11:39:54 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:39:54 --> Router Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Output Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Security Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Input Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:39:54 --> Language Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Loader Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:39:54 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:39:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:39:54 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:39:54 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:39:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Controller Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:39:54 --> Email Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:39:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:39:54 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:39:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:39:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:39:54 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:39:54 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Model Class Initialized
DEBUG - 2015-02-02 11:39:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:39:54 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:39:54 --> Final output sent to browser
DEBUG - 2015-02-02 11:39:54 --> Total execution time: 0.7111
DEBUG - 2015-02-02 11:40:17 --> Config Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:40:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:40:17 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:40:17 --> URI Class Initialized
DEBUG - 2015-02-02 11:40:17 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:40:17 --> Router Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Output Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Security Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Input Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:40:17 --> Language Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Loader Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:40:17 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:40:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:40:17 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:40:17 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:40:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Controller Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:40:17 --> Email Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:40:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:40:17 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:40:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:40:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:40:17 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:40:17 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Model Class Initialized
DEBUG - 2015-02-02 11:40:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:40:17 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:40:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:40:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:40:18 --> Final output sent to browser
DEBUG - 2015-02-02 11:40:18 --> Total execution time: 0.7011
DEBUG - 2015-02-02 11:41:37 --> Config Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:41:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:41:37 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:41:37 --> URI Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Router Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Output Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Security Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Input Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:41:37 --> Language Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Loader Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:41:37 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:41:37 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:41:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Controller Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:41:37 --> Email Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:41:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:41:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:41:37 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:41:37 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:41:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:41:37 --> Session: Creating new session (7cb9a8c7842ad5ab917eb56696ad5b10)
DEBUG - 2015-02-02 11:41:37 --> Config Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:41:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:41:37 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:41:37 --> URI Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Router Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Output Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Security Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Input Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:41:37 --> Language Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Loader Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:41:37 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:41:37 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:41:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Controller Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:41:37 --> Email Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:41:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:41:37 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:41:37 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:41:37 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:41:37 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:41:37 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:41:37 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:41:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:41:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:41:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-02 11:41:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:41:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:41:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:41:37 --> Final output sent to browser
DEBUG - 2015-02-02 11:41:37 --> Total execution time: 0.1980
DEBUG - 2015-02-02 11:41:48 --> Config Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:41:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:41:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:41:48 --> URI Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Router Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Output Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Security Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Input Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:41:48 --> Language Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Loader Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:41:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:41:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:41:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Controller Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:41:48 --> Email Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:41:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:41:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:41:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-02 11:41:48 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-02 11:41:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-02 11:41:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-02 11:41:48 --> Config Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:41:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:41:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:41:48 --> URI Class Initialized
DEBUG - 2015-02-02 11:41:48 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:41:48 --> Router Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Output Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Security Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Input Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:41:48 --> Language Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Loader Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:41:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:41:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:41:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Controller Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:41:48 --> Email Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:41:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:41:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:41:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:41:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Model Class Initialized
DEBUG - 2015-02-02 11:41:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:41:48 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:41:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:41:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:41:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:41:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:41:49 --> Final output sent to browser
DEBUG - 2015-02-02 11:41:49 --> Total execution time: 0.6971
DEBUG - 2015-02-02 11:56:49 --> Config Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 11:56:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 11:56:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 11:56:49 --> URI Class Initialized
DEBUG - 2015-02-02 11:56:49 --> No URI present. Default controller set.
DEBUG - 2015-02-02 11:56:49 --> Router Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Output Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Security Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Input Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 11:56:49 --> Language Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Loader Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 11:56:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 11:56:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 11:56:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Session: Regenerate ID
DEBUG - 2015-02-02 11:56:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 11:56:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Controller Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 11:56:49 --> Email Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 11:56:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 11:56:49 --> Helper loaded: language_helper
DEBUG - 2015-02-02 11:56:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 11:56:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Database Driver Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Helper loaded: date_helper
DEBUG - 2015-02-02 11:56:49 --> Helper loaded: form_helper
DEBUG - 2015-02-02 11:56:49 --> Form Validation Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Model Class Initialized
DEBUG - 2015-02-02 11:56:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 11:56:49 --> Pagination Class Initialized
DEBUG - 2015-02-02 11:56:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 11:56:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 11:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 11:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 11:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 11:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 11:56:50 --> Final output sent to browser
DEBUG - 2015-02-02 11:56:50 --> Total execution time: 0.6680
DEBUG - 2015-02-02 12:11:50 --> Config Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Hooks Class Initialized
DEBUG - 2015-02-02 12:11:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 12:11:50 --> Utf8 Class Initialized
DEBUG - 2015-02-02 12:11:50 --> URI Class Initialized
DEBUG - 2015-02-02 12:11:50 --> No URI present. Default controller set.
DEBUG - 2015-02-02 12:11:50 --> Router Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Output Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Security Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Input Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 12:11:50 --> Language Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Loader Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Helper loaded: url_helper
DEBUG - 2015-02-02 12:11:50 --> Helper loaded: link_helper
DEBUG - 2015-02-02 12:11:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 12:11:50 --> CI_Session Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Session: Regenerate ID
DEBUG - 2015-02-02 12:11:50 --> CI_Session routines successfully run
DEBUG - 2015-02-02 12:11:50 --> Model Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Model Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Controller Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 12:11:50 --> Email Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 12:11:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 12:11:50 --> Helper loaded: language_helper
DEBUG - 2015-02-02 12:11:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 12:11:50 --> Model Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Database Driver Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Helper loaded: date_helper
DEBUG - 2015-02-02 12:11:50 --> Helper loaded: form_helper
DEBUG - 2015-02-02 12:11:50 --> Form Validation Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Model Class Initialized
DEBUG - 2015-02-02 12:11:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 12:11:50 --> Pagination Class Initialized
DEBUG - 2015-02-02 12:11:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 12:11:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 12:11:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 12:11:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 12:11:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 12:11:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 12:11:51 --> Final output sent to browser
DEBUG - 2015-02-02 12:11:51 --> Total execution time: 0.6931
DEBUG - 2015-02-02 12:26:51 --> Config Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Hooks Class Initialized
DEBUG - 2015-02-02 12:26:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 12:26:51 --> Utf8 Class Initialized
DEBUG - 2015-02-02 12:26:51 --> URI Class Initialized
DEBUG - 2015-02-02 12:26:51 --> No URI present. Default controller set.
DEBUG - 2015-02-02 12:26:51 --> Router Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Output Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Security Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Input Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 12:26:51 --> Language Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Loader Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Helper loaded: url_helper
DEBUG - 2015-02-02 12:26:51 --> Helper loaded: link_helper
DEBUG - 2015-02-02 12:26:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 12:26:51 --> CI_Session Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Session: Regenerate ID
DEBUG - 2015-02-02 12:26:51 --> CI_Session routines successfully run
DEBUG - 2015-02-02 12:26:51 --> Model Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Model Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Controller Class Initialized
DEBUG - 2015-02-02 12:26:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 12:26:52 --> Email Class Initialized
DEBUG - 2015-02-02 12:26:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 12:26:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 12:26:52 --> Helper loaded: language_helper
DEBUG - 2015-02-02 12:26:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 12:26:52 --> Model Class Initialized
DEBUG - 2015-02-02 12:26:52 --> Database Driver Class Initialized
DEBUG - 2015-02-02 12:26:52 --> Helper loaded: date_helper
DEBUG - 2015-02-02 12:26:52 --> Helper loaded: form_helper
DEBUG - 2015-02-02 12:26:52 --> Form Validation Class Initialized
DEBUG - 2015-02-02 12:26:52 --> Model Class Initialized
DEBUG - 2015-02-02 12:26:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 12:26:52 --> Pagination Class Initialized
DEBUG - 2015-02-02 12:26:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 12:26:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 12:26:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 12:26:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 12:26:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 12:26:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 12:26:52 --> Final output sent to browser
DEBUG - 2015-02-02 12:26:52 --> Total execution time: 0.7181
DEBUG - 2015-02-02 12:41:53 --> Config Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Hooks Class Initialized
DEBUG - 2015-02-02 12:41:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 12:41:53 --> Utf8 Class Initialized
DEBUG - 2015-02-02 12:41:53 --> URI Class Initialized
DEBUG - 2015-02-02 12:41:53 --> No URI present. Default controller set.
DEBUG - 2015-02-02 12:41:53 --> Router Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Output Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Security Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Input Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 12:41:53 --> Language Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Loader Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Helper loaded: url_helper
DEBUG - 2015-02-02 12:41:53 --> Helper loaded: link_helper
DEBUG - 2015-02-02 12:41:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 12:41:53 --> CI_Session Class Initialized
ERROR - 2015-02-02 12:41:53 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 12:41:53 --> Session: Creating new session (cdaccd58dc914c5cd076b480c8c637b9)
DEBUG - 2015-02-02 12:41:53 --> CI_Session routines successfully run
DEBUG - 2015-02-02 12:41:53 --> Model Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Model Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Controller Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 12:41:53 --> Email Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 12:41:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 12:41:53 --> Helper loaded: language_helper
DEBUG - 2015-02-02 12:41:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 12:41:53 --> Model Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Database Driver Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Helper loaded: date_helper
DEBUG - 2015-02-02 12:41:53 --> Helper loaded: form_helper
DEBUG - 2015-02-02 12:41:53 --> Form Validation Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Model Class Initialized
DEBUG - 2015-02-02 12:41:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 12:41:53 --> Pagination Class Initialized
DEBUG - 2015-02-02 12:41:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 12:41:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 12:41:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 12:41:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 12:41:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 12:41:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 12:41:53 --> Final output sent to browser
DEBUG - 2015-02-02 12:41:53 --> Total execution time: 0.8241
DEBUG - 2015-02-02 12:56:54 --> Config Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Hooks Class Initialized
DEBUG - 2015-02-02 12:56:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 12:56:54 --> Utf8 Class Initialized
DEBUG - 2015-02-02 12:56:54 --> URI Class Initialized
DEBUG - 2015-02-02 12:56:54 --> No URI present. Default controller set.
DEBUG - 2015-02-02 12:56:54 --> Router Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Output Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Security Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Input Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 12:56:54 --> Language Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Loader Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Helper loaded: url_helper
DEBUG - 2015-02-02 12:56:54 --> Helper loaded: link_helper
DEBUG - 2015-02-02 12:56:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 12:56:54 --> CI_Session Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Session: Regenerate ID
DEBUG - 2015-02-02 12:56:54 --> CI_Session routines successfully run
DEBUG - 2015-02-02 12:56:54 --> Model Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Model Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Controller Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 12:56:54 --> Email Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 12:56:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 12:56:54 --> Helper loaded: language_helper
DEBUG - 2015-02-02 12:56:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 12:56:54 --> Model Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Database Driver Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Helper loaded: date_helper
DEBUG - 2015-02-02 12:56:54 --> Helper loaded: form_helper
DEBUG - 2015-02-02 12:56:54 --> Form Validation Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Model Class Initialized
DEBUG - 2015-02-02 12:56:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 12:56:54 --> Pagination Class Initialized
DEBUG - 2015-02-02 12:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 12:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 12:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 12:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 12:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 12:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 12:56:55 --> Final output sent to browser
DEBUG - 2015-02-02 12:56:55 --> Total execution time: 0.7821
DEBUG - 2015-02-02 13:11:55 --> Config Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Hooks Class Initialized
DEBUG - 2015-02-02 13:11:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 13:11:55 --> Utf8 Class Initialized
DEBUG - 2015-02-02 13:11:55 --> URI Class Initialized
DEBUG - 2015-02-02 13:11:55 --> No URI present. Default controller set.
DEBUG - 2015-02-02 13:11:55 --> Router Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Output Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Security Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Input Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 13:11:55 --> Language Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Loader Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Helper loaded: url_helper
DEBUG - 2015-02-02 13:11:55 --> Helper loaded: link_helper
DEBUG - 2015-02-02 13:11:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 13:11:55 --> CI_Session Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Session: Regenerate ID
DEBUG - 2015-02-02 13:11:55 --> CI_Session routines successfully run
DEBUG - 2015-02-02 13:11:55 --> Model Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Model Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Controller Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 13:11:55 --> Email Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 13:11:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 13:11:55 --> Helper loaded: language_helper
DEBUG - 2015-02-02 13:11:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 13:11:55 --> Model Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Database Driver Class Initialized
DEBUG - 2015-02-02 13:11:55 --> Helper loaded: date_helper
DEBUG - 2015-02-02 13:11:56 --> Helper loaded: form_helper
DEBUG - 2015-02-02 13:11:56 --> Form Validation Class Initialized
DEBUG - 2015-02-02 13:11:56 --> Model Class Initialized
DEBUG - 2015-02-02 13:11:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 13:11:56 --> Pagination Class Initialized
DEBUG - 2015-02-02 13:11:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 13:11:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 13:11:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 13:11:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 13:11:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 13:11:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 13:11:56 --> Final output sent to browser
DEBUG - 2015-02-02 13:11:56 --> Total execution time: 0.8050
DEBUG - 2015-02-02 13:26:57 --> Config Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Hooks Class Initialized
DEBUG - 2015-02-02 13:26:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 13:26:57 --> Utf8 Class Initialized
DEBUG - 2015-02-02 13:26:57 --> URI Class Initialized
DEBUG - 2015-02-02 13:26:57 --> No URI present. Default controller set.
DEBUG - 2015-02-02 13:26:57 --> Router Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Output Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Security Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Input Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 13:26:57 --> Language Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Loader Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Helper loaded: url_helper
DEBUG - 2015-02-02 13:26:57 --> Helper loaded: link_helper
DEBUG - 2015-02-02 13:26:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 13:26:57 --> CI_Session Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Session: Regenerate ID
DEBUG - 2015-02-02 13:26:57 --> CI_Session routines successfully run
DEBUG - 2015-02-02 13:26:57 --> Model Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Model Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Controller Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 13:26:57 --> Email Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 13:26:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 13:26:57 --> Helper loaded: language_helper
DEBUG - 2015-02-02 13:26:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 13:26:57 --> Model Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Database Driver Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Helper loaded: date_helper
DEBUG - 2015-02-02 13:26:57 --> Helper loaded: form_helper
DEBUG - 2015-02-02 13:26:57 --> Form Validation Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Model Class Initialized
DEBUG - 2015-02-02 13:26:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 13:26:57 --> Pagination Class Initialized
DEBUG - 2015-02-02 13:26:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 13:26:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 13:26:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 13:26:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 13:26:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 13:26:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 13:26:57 --> Final output sent to browser
DEBUG - 2015-02-02 13:26:57 --> Total execution time: 0.7661
DEBUG - 2015-02-02 13:41:58 --> Config Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Hooks Class Initialized
DEBUG - 2015-02-02 13:41:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 13:41:58 --> Utf8 Class Initialized
DEBUG - 2015-02-02 13:41:58 --> URI Class Initialized
DEBUG - 2015-02-02 13:41:58 --> No URI present. Default controller set.
DEBUG - 2015-02-02 13:41:58 --> Router Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Output Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Security Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Input Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 13:41:58 --> Language Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Loader Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Helper loaded: url_helper
DEBUG - 2015-02-02 13:41:58 --> Helper loaded: link_helper
DEBUG - 2015-02-02 13:41:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 13:41:58 --> CI_Session Class Initialized
ERROR - 2015-02-02 13:41:58 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 13:41:58 --> Session: Creating new session (f717cb479c4f200454a7e930ebe062f5)
DEBUG - 2015-02-02 13:41:58 --> CI_Session routines successfully run
DEBUG - 2015-02-02 13:41:58 --> Model Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Model Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Controller Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 13:41:58 --> Email Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 13:41:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 13:41:58 --> Helper loaded: language_helper
DEBUG - 2015-02-02 13:41:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 13:41:58 --> Model Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Database Driver Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Helper loaded: date_helper
DEBUG - 2015-02-02 13:41:58 --> Helper loaded: form_helper
DEBUG - 2015-02-02 13:41:58 --> Form Validation Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Model Class Initialized
DEBUG - 2015-02-02 13:41:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 13:41:58 --> Pagination Class Initialized
DEBUG - 2015-02-02 13:41:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 13:41:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 13:41:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 13:41:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 13:41:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 13:41:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 13:41:59 --> Final output sent to browser
DEBUG - 2015-02-02 13:41:59 --> Total execution time: 0.7050
DEBUG - 2015-02-02 13:56:59 --> Config Class Initialized
DEBUG - 2015-02-02 13:56:59 --> Hooks Class Initialized
DEBUG - 2015-02-02 13:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 13:57:00 --> Utf8 Class Initialized
DEBUG - 2015-02-02 13:57:00 --> URI Class Initialized
DEBUG - 2015-02-02 13:57:00 --> No URI present. Default controller set.
DEBUG - 2015-02-02 13:57:00 --> Router Class Initialized
DEBUG - 2015-02-02 13:57:00 --> Output Class Initialized
DEBUG - 2015-02-02 13:57:00 --> Security Class Initialized
DEBUG - 2015-02-02 13:57:00 --> Input Class Initialized
DEBUG - 2015-02-02 13:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 13:57:00 --> Language Class Initialized
DEBUG - 2015-02-02 13:57:00 --> Loader Class Initialized
DEBUG - 2015-02-02 13:57:00 --> Helper loaded: url_helper
DEBUG - 2015-02-02 13:57:00 --> Helper loaded: link_helper
DEBUG - 2015-02-02 13:57:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 13:57:00 --> CI_Session Class Initialized
ERROR - 2015-02-02 13:57:00 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 13:57:00 --> Session: Creating new session (4f6045bcea103eff720fb8d2a5834eb3)
DEBUG - 2015-02-02 13:57:00 --> CI_Session routines successfully run
DEBUG - 2015-02-02 13:57:01 --> Model Class Initialized
DEBUG - 2015-02-02 13:57:01 --> Model Class Initialized
DEBUG - 2015-02-02 13:57:01 --> Controller Class Initialized
DEBUG - 2015-02-02 13:57:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 13:57:01 --> Email Class Initialized
DEBUG - 2015-02-02 13:57:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 13:57:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 13:57:01 --> Helper loaded: language_helper
DEBUG - 2015-02-02 13:57:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 13:57:01 --> Model Class Initialized
DEBUG - 2015-02-02 13:57:02 --> Database Driver Class Initialized
DEBUG - 2015-02-02 13:57:02 --> Helper loaded: date_helper
DEBUG - 2015-02-02 13:57:02 --> Helper loaded: form_helper
DEBUG - 2015-02-02 13:57:02 --> Form Validation Class Initialized
DEBUG - 2015-02-02 13:57:02 --> Model Class Initialized
DEBUG - 2015-02-02 13:57:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 13:57:02 --> Pagination Class Initialized
DEBUG - 2015-02-02 13:57:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 13:57:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 13:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 13:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 13:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 13:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 13:57:05 --> Final output sent to browser
DEBUG - 2015-02-02 13:57:05 --> Total execution time: 5.3025
DEBUG - 2015-02-02 14:12:05 --> Config Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Hooks Class Initialized
DEBUG - 2015-02-02 14:12:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 14:12:05 --> Utf8 Class Initialized
DEBUG - 2015-02-02 14:12:05 --> URI Class Initialized
DEBUG - 2015-02-02 14:12:05 --> No URI present. Default controller set.
DEBUG - 2015-02-02 14:12:05 --> Router Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Output Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Security Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Input Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 14:12:05 --> Language Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Loader Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Helper loaded: url_helper
DEBUG - 2015-02-02 14:12:05 --> Helper loaded: link_helper
DEBUG - 2015-02-02 14:12:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 14:12:05 --> CI_Session Class Initialized
ERROR - 2015-02-02 14:12:05 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 14:12:05 --> Session: Creating new session (a645219c46c0f6ae0306ee952a920ea2)
DEBUG - 2015-02-02 14:12:05 --> CI_Session routines successfully run
DEBUG - 2015-02-02 14:12:05 --> Model Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Model Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Controller Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 14:12:05 --> Email Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 14:12:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 14:12:05 --> Helper loaded: language_helper
DEBUG - 2015-02-02 14:12:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 14:12:05 --> Model Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Database Driver Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Helper loaded: date_helper
DEBUG - 2015-02-02 14:12:05 --> Helper loaded: form_helper
DEBUG - 2015-02-02 14:12:05 --> Form Validation Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Model Class Initialized
DEBUG - 2015-02-02 14:12:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 14:12:05 --> Pagination Class Initialized
DEBUG - 2015-02-02 14:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 14:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 14:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 14:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 14:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 14:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 14:12:06 --> Final output sent to browser
DEBUG - 2015-02-02 14:12:06 --> Total execution time: 0.8101
DEBUG - 2015-02-02 14:27:10 --> Config Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Hooks Class Initialized
DEBUG - 2015-02-02 14:27:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 14:27:10 --> Utf8 Class Initialized
DEBUG - 2015-02-02 14:27:10 --> URI Class Initialized
DEBUG - 2015-02-02 14:27:10 --> No URI present. Default controller set.
DEBUG - 2015-02-02 14:27:10 --> Router Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Output Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Security Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Input Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 14:27:10 --> Language Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Loader Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Helper loaded: url_helper
DEBUG - 2015-02-02 14:27:10 --> Helper loaded: link_helper
DEBUG - 2015-02-02 14:27:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 14:27:10 --> CI_Session Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Session: Regenerate ID
DEBUG - 2015-02-02 14:27:10 --> CI_Session routines successfully run
DEBUG - 2015-02-02 14:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Controller Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 14:27:10 --> Email Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 14:27:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 14:27:10 --> Helper loaded: language_helper
DEBUG - 2015-02-02 14:27:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 14:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Database Driver Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Helper loaded: date_helper
DEBUG - 2015-02-02 14:27:10 --> Helper loaded: form_helper
DEBUG - 2015-02-02 14:27:10 --> Form Validation Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Model Class Initialized
DEBUG - 2015-02-02 14:27:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 14:27:10 --> Pagination Class Initialized
DEBUG - 2015-02-02 14:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 14:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 14:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 14:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 14:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 14:27:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 14:27:10 --> Final output sent to browser
DEBUG - 2015-02-02 14:27:10 --> Total execution time: 0.8861
DEBUG - 2015-02-02 14:42:15 --> Config Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Hooks Class Initialized
DEBUG - 2015-02-02 14:42:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 14:42:15 --> Utf8 Class Initialized
DEBUG - 2015-02-02 14:42:15 --> URI Class Initialized
DEBUG - 2015-02-02 14:42:15 --> No URI present. Default controller set.
DEBUG - 2015-02-02 14:42:15 --> Router Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Output Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Security Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Input Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 14:42:15 --> Language Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Loader Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Helper loaded: url_helper
DEBUG - 2015-02-02 14:42:15 --> Helper loaded: link_helper
DEBUG - 2015-02-02 14:42:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 14:42:15 --> CI_Session Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Session: Regenerate ID
DEBUG - 2015-02-02 14:42:15 --> CI_Session routines successfully run
DEBUG - 2015-02-02 14:42:15 --> Model Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Model Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Controller Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 14:42:15 --> Email Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 14:42:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 14:42:15 --> Helper loaded: language_helper
DEBUG - 2015-02-02 14:42:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 14:42:15 --> Model Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Database Driver Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Helper loaded: date_helper
DEBUG - 2015-02-02 14:42:15 --> Helper loaded: form_helper
DEBUG - 2015-02-02 14:42:15 --> Form Validation Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Model Class Initialized
DEBUG - 2015-02-02 14:42:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 14:42:15 --> Pagination Class Initialized
DEBUG - 2015-02-02 14:42:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 14:42:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 14:42:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 14:42:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 14:42:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 14:42:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 14:42:16 --> Final output sent to browser
DEBUG - 2015-02-02 14:42:16 --> Total execution time: 0.7251
DEBUG - 2015-02-02 14:57:16 --> Config Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Hooks Class Initialized
DEBUG - 2015-02-02 14:57:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 14:57:16 --> Utf8 Class Initialized
DEBUG - 2015-02-02 14:57:16 --> URI Class Initialized
DEBUG - 2015-02-02 14:57:16 --> No URI present. Default controller set.
DEBUG - 2015-02-02 14:57:16 --> Router Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Output Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Security Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Input Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 14:57:16 --> Language Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Loader Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Helper loaded: url_helper
DEBUG - 2015-02-02 14:57:16 --> Helper loaded: link_helper
DEBUG - 2015-02-02 14:57:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 14:57:16 --> CI_Session Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Session: Regenerate ID
DEBUG - 2015-02-02 14:57:16 --> CI_Session routines successfully run
DEBUG - 2015-02-02 14:57:16 --> Model Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Model Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Controller Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 14:57:16 --> Email Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 14:57:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 14:57:16 --> Helper loaded: language_helper
DEBUG - 2015-02-02 14:57:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 14:57:16 --> Model Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Database Driver Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Helper loaded: date_helper
DEBUG - 2015-02-02 14:57:16 --> Helper loaded: form_helper
DEBUG - 2015-02-02 14:57:16 --> Form Validation Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Model Class Initialized
DEBUG - 2015-02-02 14:57:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 14:57:16 --> Pagination Class Initialized
DEBUG - 2015-02-02 14:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 14:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 14:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 14:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 14:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 14:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 14:57:17 --> Final output sent to browser
DEBUG - 2015-02-02 14:57:17 --> Total execution time: 0.7610
DEBUG - 2015-02-02 15:12:18 --> Config Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Hooks Class Initialized
DEBUG - 2015-02-02 15:12:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 15:12:18 --> Utf8 Class Initialized
DEBUG - 2015-02-02 15:12:18 --> URI Class Initialized
DEBUG - 2015-02-02 15:12:18 --> No URI present. Default controller set.
DEBUG - 2015-02-02 15:12:18 --> Router Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Output Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Security Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Input Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 15:12:18 --> Language Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Loader Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Helper loaded: url_helper
DEBUG - 2015-02-02 15:12:18 --> Helper loaded: link_helper
DEBUG - 2015-02-02 15:12:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 15:12:18 --> CI_Session Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Session: Regenerate ID
DEBUG - 2015-02-02 15:12:18 --> CI_Session routines successfully run
DEBUG - 2015-02-02 15:12:18 --> Model Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Model Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Controller Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 15:12:18 --> Email Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 15:12:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 15:12:18 --> Helper loaded: language_helper
DEBUG - 2015-02-02 15:12:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 15:12:18 --> Model Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Database Driver Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Helper loaded: date_helper
DEBUG - 2015-02-02 15:12:18 --> Helper loaded: form_helper
DEBUG - 2015-02-02 15:12:18 --> Form Validation Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Model Class Initialized
DEBUG - 2015-02-02 15:12:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 15:12:18 --> Pagination Class Initialized
DEBUG - 2015-02-02 15:12:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 15:12:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 15:12:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 15:12:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 15:12:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 15:12:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 15:12:18 --> Final output sent to browser
DEBUG - 2015-02-02 15:12:18 --> Total execution time: 0.8221
DEBUG - 2015-02-02 15:31:47 --> Config Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Hooks Class Initialized
DEBUG - 2015-02-02 15:31:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 15:31:47 --> Utf8 Class Initialized
DEBUG - 2015-02-02 15:31:47 --> URI Class Initialized
DEBUG - 2015-02-02 15:31:47 --> No URI present. Default controller set.
DEBUG - 2015-02-02 15:31:47 --> Router Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Output Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Security Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Input Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 15:31:47 --> Language Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Loader Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Helper loaded: url_helper
DEBUG - 2015-02-02 15:31:47 --> Helper loaded: link_helper
DEBUG - 2015-02-02 15:31:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 15:31:47 --> CI_Session Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Session: Regenerate ID
DEBUG - 2015-02-02 15:31:47 --> CI_Session routines successfully run
DEBUG - 2015-02-02 15:31:47 --> Model Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Model Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Controller Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 15:31:47 --> Email Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 15:31:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 15:31:47 --> Helper loaded: language_helper
DEBUG - 2015-02-02 15:31:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 15:31:47 --> Model Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Database Driver Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Helper loaded: date_helper
DEBUG - 2015-02-02 15:31:47 --> Helper loaded: form_helper
DEBUG - 2015-02-02 15:31:47 --> Form Validation Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Model Class Initialized
DEBUG - 2015-02-02 15:31:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 15:31:47 --> Pagination Class Initialized
DEBUG - 2015-02-02 15:31:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 15:31:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 15:31:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 15:31:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 15:31:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 15:31:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 15:31:48 --> Final output sent to browser
DEBUG - 2015-02-02 15:31:48 --> Total execution time: 0.9451
DEBUG - 2015-02-02 15:46:48 --> Config Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 15:46:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 15:46:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 15:46:48 --> URI Class Initialized
DEBUG - 2015-02-02 15:46:48 --> No URI present. Default controller set.
DEBUG - 2015-02-02 15:46:48 --> Router Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Output Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Security Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Input Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 15:46:48 --> Language Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Loader Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 15:46:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 15:46:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 15:46:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Session: Regenerate ID
DEBUG - 2015-02-02 15:46:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 15:46:48 --> Model Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Model Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Controller Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 15:46:48 --> Email Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 15:46:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 15:46:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 15:46:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 15:46:48 --> Model Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 15:46:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 15:46:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Model Class Initialized
DEBUG - 2015-02-02 15:46:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 15:46:48 --> Pagination Class Initialized
DEBUG - 2015-02-02 15:46:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 15:46:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 15:46:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 15:46:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 15:46:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 15:46:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 15:46:49 --> Final output sent to browser
DEBUG - 2015-02-02 15:46:49 --> Total execution time: 0.7141
DEBUG - 2015-02-02 16:01:49 --> Config Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Hooks Class Initialized
DEBUG - 2015-02-02 16:01:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 16:01:49 --> Utf8 Class Initialized
DEBUG - 2015-02-02 16:01:49 --> URI Class Initialized
DEBUG - 2015-02-02 16:01:49 --> No URI present. Default controller set.
DEBUG - 2015-02-02 16:01:49 --> Router Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Output Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Security Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Input Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 16:01:49 --> Language Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Loader Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Helper loaded: url_helper
DEBUG - 2015-02-02 16:01:49 --> Helper loaded: link_helper
DEBUG - 2015-02-02 16:01:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 16:01:49 --> CI_Session Class Initialized
DEBUG - 2015-02-02 16:01:49 --> Session: Regenerate ID
DEBUG - 2015-02-02 16:01:49 --> CI_Session routines successfully run
DEBUG - 2015-02-02 16:01:50 --> Model Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Model Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Controller Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 16:01:50 --> Email Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 16:01:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 16:01:50 --> Helper loaded: language_helper
DEBUG - 2015-02-02 16:01:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 16:01:50 --> Model Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Database Driver Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Helper loaded: date_helper
DEBUG - 2015-02-02 16:01:50 --> Helper loaded: form_helper
DEBUG - 2015-02-02 16:01:50 --> Form Validation Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Model Class Initialized
DEBUG - 2015-02-02 16:01:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 16:01:50 --> Pagination Class Initialized
DEBUG - 2015-02-02 16:01:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 16:01:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 16:01:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 16:01:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 16:01:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 16:01:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 16:01:50 --> Final output sent to browser
DEBUG - 2015-02-02 16:01:50 --> Total execution time: 0.6781
DEBUG - 2015-02-02 16:16:51 --> Config Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Hooks Class Initialized
DEBUG - 2015-02-02 16:16:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 16:16:51 --> Utf8 Class Initialized
DEBUG - 2015-02-02 16:16:51 --> URI Class Initialized
DEBUG - 2015-02-02 16:16:51 --> No URI present. Default controller set.
DEBUG - 2015-02-02 16:16:51 --> Router Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Output Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Security Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Input Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 16:16:51 --> Language Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Loader Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Helper loaded: url_helper
DEBUG - 2015-02-02 16:16:51 --> Helper loaded: link_helper
DEBUG - 2015-02-02 16:16:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 16:16:51 --> CI_Session Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Session: Regenerate ID
DEBUG - 2015-02-02 16:16:51 --> CI_Session routines successfully run
DEBUG - 2015-02-02 16:16:51 --> Model Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Model Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Controller Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 16:16:51 --> Email Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 16:16:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 16:16:51 --> Helper loaded: language_helper
DEBUG - 2015-02-02 16:16:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 16:16:51 --> Model Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Database Driver Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Helper loaded: date_helper
DEBUG - 2015-02-02 16:16:51 --> Helper loaded: form_helper
DEBUG - 2015-02-02 16:16:51 --> Form Validation Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Model Class Initialized
DEBUG - 2015-02-02 16:16:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 16:16:51 --> Pagination Class Initialized
DEBUG - 2015-02-02 16:16:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 16:16:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 16:16:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 16:16:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 16:16:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 16:16:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 16:16:51 --> Final output sent to browser
DEBUG - 2015-02-02 16:16:51 --> Total execution time: 0.7291
DEBUG - 2015-02-02 16:31:52 --> Config Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Hooks Class Initialized
DEBUG - 2015-02-02 16:31:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 16:31:52 --> Utf8 Class Initialized
DEBUG - 2015-02-02 16:31:52 --> URI Class Initialized
DEBUG - 2015-02-02 16:31:52 --> No URI present. Default controller set.
DEBUG - 2015-02-02 16:31:52 --> Router Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Output Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Security Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Input Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 16:31:52 --> Language Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Loader Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Helper loaded: url_helper
DEBUG - 2015-02-02 16:31:52 --> Helper loaded: link_helper
DEBUG - 2015-02-02 16:31:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 16:31:52 --> CI_Session Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Session: Regenerate ID
DEBUG - 2015-02-02 16:31:52 --> CI_Session routines successfully run
DEBUG - 2015-02-02 16:31:52 --> Model Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Model Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Controller Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 16:31:52 --> Email Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 16:31:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 16:31:52 --> Helper loaded: language_helper
DEBUG - 2015-02-02 16:31:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 16:31:52 --> Model Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Database Driver Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Helper loaded: date_helper
DEBUG - 2015-02-02 16:31:52 --> Helper loaded: form_helper
DEBUG - 2015-02-02 16:31:52 --> Form Validation Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Model Class Initialized
DEBUG - 2015-02-02 16:31:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 16:31:52 --> Pagination Class Initialized
DEBUG - 2015-02-02 16:31:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 16:31:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 16:31:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 16:31:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 16:31:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 16:31:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 16:31:52 --> Final output sent to browser
DEBUG - 2015-02-02 16:31:52 --> Total execution time: 0.6839
DEBUG - 2015-02-02 16:46:53 --> Config Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Hooks Class Initialized
DEBUG - 2015-02-02 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 16:46:53 --> Utf8 Class Initialized
DEBUG - 2015-02-02 16:46:53 --> URI Class Initialized
DEBUG - 2015-02-02 16:46:53 --> No URI present. Default controller set.
DEBUG - 2015-02-02 16:46:53 --> Router Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Output Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Security Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Input Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 16:46:53 --> Language Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Loader Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Helper loaded: url_helper
DEBUG - 2015-02-02 16:46:53 --> Helper loaded: link_helper
DEBUG - 2015-02-02 16:46:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 16:46:53 --> CI_Session Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Session: Regenerate ID
DEBUG - 2015-02-02 16:46:53 --> CI_Session routines successfully run
DEBUG - 2015-02-02 16:46:53 --> Model Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Model Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Controller Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 16:46:53 --> Email Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 16:46:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 16:46:53 --> Helper loaded: language_helper
DEBUG - 2015-02-02 16:46:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 16:46:53 --> Model Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Database Driver Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Helper loaded: date_helper
DEBUG - 2015-02-02 16:46:53 --> Helper loaded: form_helper
DEBUG - 2015-02-02 16:46:53 --> Form Validation Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Model Class Initialized
DEBUG - 2015-02-02 16:46:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 16:46:53 --> Pagination Class Initialized
DEBUG - 2015-02-02 16:46:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 16:46:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 16:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 16:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 16:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 16:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 16:46:54 --> Final output sent to browser
DEBUG - 2015-02-02 16:46:54 --> Total execution time: 0.6910
DEBUG - 2015-02-02 17:01:55 --> Config Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Hooks Class Initialized
DEBUG - 2015-02-02 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 17:01:55 --> Utf8 Class Initialized
DEBUG - 2015-02-02 17:01:55 --> URI Class Initialized
DEBUG - 2015-02-02 17:01:55 --> No URI present. Default controller set.
DEBUG - 2015-02-02 17:01:55 --> Router Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Output Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Security Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Input Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 17:01:55 --> Language Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Loader Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Helper loaded: url_helper
DEBUG - 2015-02-02 17:01:55 --> Helper loaded: link_helper
DEBUG - 2015-02-02 17:01:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 17:01:55 --> CI_Session Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Session: Regenerate ID
DEBUG - 2015-02-02 17:01:55 --> CI_Session routines successfully run
DEBUG - 2015-02-02 17:01:55 --> Model Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Model Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Controller Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 17:01:55 --> Email Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 17:01:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 17:01:55 --> Helper loaded: language_helper
DEBUG - 2015-02-02 17:01:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 17:01:55 --> Model Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Database Driver Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Helper loaded: date_helper
DEBUG - 2015-02-02 17:01:55 --> Helper loaded: form_helper
DEBUG - 2015-02-02 17:01:55 --> Form Validation Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Model Class Initialized
DEBUG - 2015-02-02 17:01:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 17:01:55 --> Pagination Class Initialized
DEBUG - 2015-02-02 17:01:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 17:01:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 17:01:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 17:01:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 17:01:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 17:01:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 17:01:56 --> Final output sent to browser
DEBUG - 2015-02-02 17:01:56 --> Total execution time: 0.7511
DEBUG - 2015-02-02 17:16:57 --> Config Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Hooks Class Initialized
DEBUG - 2015-02-02 17:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 17:16:57 --> Utf8 Class Initialized
DEBUG - 2015-02-02 17:16:57 --> URI Class Initialized
DEBUG - 2015-02-02 17:16:57 --> No URI present. Default controller set.
DEBUG - 2015-02-02 17:16:57 --> Router Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Output Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Security Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Input Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 17:16:57 --> Language Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Loader Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Helper loaded: url_helper
DEBUG - 2015-02-02 17:16:57 --> Helper loaded: link_helper
DEBUG - 2015-02-02 17:16:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 17:16:57 --> CI_Session Class Initialized
DEBUG - 2015-02-02 17:16:57 --> Session: Regenerate ID
DEBUG - 2015-02-02 17:16:57 --> CI_Session routines successfully run
DEBUG - 2015-02-02 17:16:58 --> Model Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Model Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Controller Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 17:16:58 --> Email Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 17:16:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 17:16:58 --> Helper loaded: language_helper
DEBUG - 2015-02-02 17:16:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 17:16:58 --> Model Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Database Driver Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Helper loaded: date_helper
DEBUG - 2015-02-02 17:16:58 --> Helper loaded: form_helper
DEBUG - 2015-02-02 17:16:58 --> Form Validation Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Model Class Initialized
DEBUG - 2015-02-02 17:16:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 17:16:58 --> Pagination Class Initialized
DEBUG - 2015-02-02 17:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 17:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 17:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 17:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 17:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 17:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 17:16:58 --> Final output sent to browser
DEBUG - 2015-02-02 17:16:58 --> Total execution time: 0.7011
DEBUG - 2015-02-02 17:45:07 --> Config Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Hooks Class Initialized
DEBUG - 2015-02-02 17:45:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 17:45:08 --> Utf8 Class Initialized
DEBUG - 2015-02-02 17:45:08 --> URI Class Initialized
DEBUG - 2015-02-02 17:45:08 --> No URI present. Default controller set.
DEBUG - 2015-02-02 17:45:08 --> Router Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Output Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Security Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Input Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 17:45:08 --> Language Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Loader Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Helper loaded: url_helper
DEBUG - 2015-02-02 17:45:08 --> Helper loaded: link_helper
DEBUG - 2015-02-02 17:45:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 17:45:08 --> CI_Session Class Initialized
ERROR - 2015-02-02 17:45:08 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 17:45:08 --> Session: Creating new session (dda773b9df2e5b2f5c0e60f15183c294)
DEBUG - 2015-02-02 17:45:08 --> CI_Session routines successfully run
DEBUG - 2015-02-02 17:45:08 --> Model Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Model Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Controller Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 17:45:08 --> Email Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 17:45:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 17:45:08 --> Helper loaded: language_helper
DEBUG - 2015-02-02 17:45:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 17:45:08 --> Model Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Database Driver Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Helper loaded: date_helper
DEBUG - 2015-02-02 17:45:08 --> Helper loaded: form_helper
DEBUG - 2015-02-02 17:45:08 --> Form Validation Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Model Class Initialized
DEBUG - 2015-02-02 17:45:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 17:45:08 --> Pagination Class Initialized
DEBUG - 2015-02-02 17:45:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 17:45:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 17:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 17:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 17:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 17:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 17:45:09 --> Final output sent to browser
DEBUG - 2015-02-02 17:45:09 --> Total execution time: 1.4521
DEBUG - 2015-02-02 18:00:11 --> Config Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Hooks Class Initialized
DEBUG - 2015-02-02 18:00:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 18:00:11 --> Utf8 Class Initialized
DEBUG - 2015-02-02 18:00:11 --> URI Class Initialized
DEBUG - 2015-02-02 18:00:11 --> No URI present. Default controller set.
DEBUG - 2015-02-02 18:00:11 --> Router Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Output Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Security Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Input Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 18:00:11 --> Language Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Loader Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Helper loaded: url_helper
DEBUG - 2015-02-02 18:00:11 --> Helper loaded: link_helper
DEBUG - 2015-02-02 18:00:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 18:00:11 --> CI_Session Class Initialized
ERROR - 2015-02-02 18:00:11 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 18:00:11 --> Session: Creating new session (2532c8c023d3413a38660b2e605ea92d)
DEBUG - 2015-02-02 18:00:11 --> CI_Session routines successfully run
DEBUG - 2015-02-02 18:00:11 --> Model Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Model Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Controller Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 18:00:11 --> Email Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 18:00:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 18:00:11 --> Helper loaded: language_helper
DEBUG - 2015-02-02 18:00:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 18:00:11 --> Model Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Database Driver Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Helper loaded: date_helper
DEBUG - 2015-02-02 18:00:11 --> Helper loaded: form_helper
DEBUG - 2015-02-02 18:00:11 --> Form Validation Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Model Class Initialized
DEBUG - 2015-02-02 18:00:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 18:00:11 --> Pagination Class Initialized
DEBUG - 2015-02-02 18:00:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 18:00:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 18:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 18:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 18:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 18:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 18:00:12 --> Final output sent to browser
DEBUG - 2015-02-02 18:00:12 --> Total execution time: 0.7451
DEBUG - 2015-02-02 18:15:12 --> Config Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Hooks Class Initialized
DEBUG - 2015-02-02 18:15:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 18:15:12 --> Utf8 Class Initialized
DEBUG - 2015-02-02 18:15:12 --> URI Class Initialized
DEBUG - 2015-02-02 18:15:12 --> No URI present. Default controller set.
DEBUG - 2015-02-02 18:15:12 --> Router Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Output Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Security Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Input Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 18:15:12 --> Language Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Loader Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Helper loaded: url_helper
DEBUG - 2015-02-02 18:15:12 --> Helper loaded: link_helper
DEBUG - 2015-02-02 18:15:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 18:15:12 --> CI_Session Class Initialized
ERROR - 2015-02-02 18:15:12 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 18:15:12 --> Session: Creating new session (fb08820454647a1efed31c8c68a544cc)
DEBUG - 2015-02-02 18:15:12 --> CI_Session routines successfully run
DEBUG - 2015-02-02 18:15:12 --> Model Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Model Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Controller Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 18:15:12 --> Email Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 18:15:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 18:15:12 --> Helper loaded: language_helper
DEBUG - 2015-02-02 18:15:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 18:15:12 --> Model Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Database Driver Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Helper loaded: date_helper
DEBUG - 2015-02-02 18:15:12 --> Helper loaded: form_helper
DEBUG - 2015-02-02 18:15:12 --> Form Validation Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Model Class Initialized
DEBUG - 2015-02-02 18:15:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 18:15:12 --> Pagination Class Initialized
DEBUG - 2015-02-02 18:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 18:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 18:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 18:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 18:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 18:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 18:15:13 --> Final output sent to browser
DEBUG - 2015-02-02 18:15:13 --> Total execution time: 0.6601
DEBUG - 2015-02-02 18:30:13 --> Config Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Hooks Class Initialized
DEBUG - 2015-02-02 18:30:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 18:30:14 --> Utf8 Class Initialized
DEBUG - 2015-02-02 18:30:14 --> URI Class Initialized
DEBUG - 2015-02-02 18:30:14 --> No URI present. Default controller set.
DEBUG - 2015-02-02 18:30:14 --> Router Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Output Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Security Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Input Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 18:30:14 --> Language Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Loader Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Helper loaded: url_helper
DEBUG - 2015-02-02 18:30:14 --> Helper loaded: link_helper
DEBUG - 2015-02-02 18:30:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 18:30:14 --> CI_Session Class Initialized
ERROR - 2015-02-02 18:30:14 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 18:30:14 --> Session: Creating new session (14fa8c992fb467e741090de2e16f4204)
DEBUG - 2015-02-02 18:30:14 --> CI_Session routines successfully run
DEBUG - 2015-02-02 18:30:14 --> Model Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Model Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Controller Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 18:30:14 --> Email Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 18:30:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 18:30:14 --> Helper loaded: language_helper
DEBUG - 2015-02-02 18:30:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 18:30:14 --> Model Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Database Driver Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Helper loaded: date_helper
DEBUG - 2015-02-02 18:30:14 --> Helper loaded: form_helper
DEBUG - 2015-02-02 18:30:14 --> Form Validation Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Model Class Initialized
DEBUG - 2015-02-02 18:30:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 18:30:14 --> Pagination Class Initialized
DEBUG - 2015-02-02 18:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 18:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 18:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 18:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 18:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 18:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 18:30:14 --> Final output sent to browser
DEBUG - 2015-02-02 18:30:14 --> Total execution time: 0.6910
DEBUG - 2015-02-02 18:45:15 --> Config Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Hooks Class Initialized
DEBUG - 2015-02-02 18:45:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 18:45:15 --> Utf8 Class Initialized
DEBUG - 2015-02-02 18:45:15 --> URI Class Initialized
DEBUG - 2015-02-02 18:45:15 --> No URI present. Default controller set.
DEBUG - 2015-02-02 18:45:15 --> Router Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Output Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Security Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Input Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 18:45:15 --> Language Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Loader Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Helper loaded: url_helper
DEBUG - 2015-02-02 18:45:15 --> Helper loaded: link_helper
DEBUG - 2015-02-02 18:45:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 18:45:15 --> CI_Session Class Initialized
ERROR - 2015-02-02 18:45:15 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 18:45:15 --> Session: Creating new session (cd44b87b8c2c4e9006a1526a0522cdc3)
DEBUG - 2015-02-02 18:45:15 --> CI_Session routines successfully run
DEBUG - 2015-02-02 18:45:15 --> Model Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Model Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Controller Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 18:45:15 --> Email Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 18:45:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 18:45:15 --> Helper loaded: language_helper
DEBUG - 2015-02-02 18:45:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 18:45:15 --> Model Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Database Driver Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Helper loaded: date_helper
DEBUG - 2015-02-02 18:45:15 --> Helper loaded: form_helper
DEBUG - 2015-02-02 18:45:15 --> Form Validation Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Model Class Initialized
DEBUG - 2015-02-02 18:45:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 18:45:15 --> Pagination Class Initialized
DEBUG - 2015-02-02 18:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 18:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 18:45:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 18:45:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 18:45:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 18:45:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 18:45:16 --> Final output sent to browser
DEBUG - 2015-02-02 18:45:16 --> Total execution time: 0.8231
DEBUG - 2015-02-02 19:00:16 --> Config Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Hooks Class Initialized
DEBUG - 2015-02-02 19:00:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 19:00:16 --> Utf8 Class Initialized
DEBUG - 2015-02-02 19:00:16 --> URI Class Initialized
DEBUG - 2015-02-02 19:00:16 --> No URI present. Default controller set.
DEBUG - 2015-02-02 19:00:16 --> Router Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Output Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Security Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Input Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 19:00:16 --> Language Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Loader Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Helper loaded: url_helper
DEBUG - 2015-02-02 19:00:16 --> Helper loaded: link_helper
DEBUG - 2015-02-02 19:00:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 19:00:16 --> CI_Session Class Initialized
ERROR - 2015-02-02 19:00:16 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-02 19:00:16 --> Session: Creating new session (f2f5009e8dbef60b90134e9b628c43b6)
DEBUG - 2015-02-02 19:00:16 --> CI_Session routines successfully run
DEBUG - 2015-02-02 19:00:16 --> Model Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Model Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Controller Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 19:00:16 --> Email Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 19:00:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 19:00:16 --> Helper loaded: language_helper
DEBUG - 2015-02-02 19:00:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 19:00:16 --> Model Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Database Driver Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Helper loaded: date_helper
DEBUG - 2015-02-02 19:00:16 --> Helper loaded: form_helper
DEBUG - 2015-02-02 19:00:16 --> Form Validation Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Model Class Initialized
DEBUG - 2015-02-02 19:00:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 19:00:16 --> Pagination Class Initialized
DEBUG - 2015-02-02 19:00:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 19:00:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 19:00:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 19:00:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 19:00:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 19:00:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 19:00:17 --> Final output sent to browser
DEBUG - 2015-02-02 19:00:17 --> Total execution time: 0.7371
DEBUG - 2015-02-02 19:15:18 --> Config Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Hooks Class Initialized
DEBUG - 2015-02-02 19:15:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 19:15:18 --> Utf8 Class Initialized
DEBUG - 2015-02-02 19:15:18 --> URI Class Initialized
DEBUG - 2015-02-02 19:15:18 --> No URI present. Default controller set.
DEBUG - 2015-02-02 19:15:18 --> Router Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Output Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Security Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Input Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 19:15:18 --> Language Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Loader Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Helper loaded: url_helper
DEBUG - 2015-02-02 19:15:18 --> Helper loaded: link_helper
DEBUG - 2015-02-02 19:15:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 19:15:18 --> CI_Session Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Session: Regenerate ID
DEBUG - 2015-02-02 19:15:18 --> CI_Session routines successfully run
DEBUG - 2015-02-02 19:15:18 --> Model Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Model Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Controller Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 19:15:18 --> Email Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 19:15:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 19:15:18 --> Helper loaded: language_helper
DEBUG - 2015-02-02 19:15:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 19:15:18 --> Model Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Database Driver Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Helper loaded: date_helper
DEBUG - 2015-02-02 19:15:18 --> Helper loaded: form_helper
DEBUG - 2015-02-02 19:15:18 --> Form Validation Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Model Class Initialized
DEBUG - 2015-02-02 19:15:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 19:15:18 --> Pagination Class Initialized
DEBUG - 2015-02-02 19:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 19:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 19:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 19:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 19:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 19:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 19:15:19 --> Final output sent to browser
DEBUG - 2015-02-02 19:15:19 --> Total execution time: 0.6540
DEBUG - 2015-02-02 19:30:20 --> Config Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Hooks Class Initialized
DEBUG - 2015-02-02 19:30:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 19:30:20 --> Utf8 Class Initialized
DEBUG - 2015-02-02 19:30:20 --> URI Class Initialized
DEBUG - 2015-02-02 19:30:20 --> No URI present. Default controller set.
DEBUG - 2015-02-02 19:30:20 --> Router Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Output Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Security Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Input Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 19:30:20 --> Language Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Loader Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Helper loaded: url_helper
DEBUG - 2015-02-02 19:30:20 --> Helper loaded: link_helper
DEBUG - 2015-02-02 19:30:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 19:30:20 --> CI_Session Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Session: Regenerate ID
DEBUG - 2015-02-02 19:30:20 --> CI_Session routines successfully run
DEBUG - 2015-02-02 19:30:20 --> Model Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Model Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Controller Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 19:30:20 --> Email Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 19:30:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 19:30:20 --> Helper loaded: language_helper
DEBUG - 2015-02-02 19:30:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 19:30:20 --> Model Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Database Driver Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Helper loaded: date_helper
DEBUG - 2015-02-02 19:30:20 --> Helper loaded: form_helper
DEBUG - 2015-02-02 19:30:20 --> Form Validation Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Model Class Initialized
DEBUG - 2015-02-02 19:30:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 19:30:20 --> Pagination Class Initialized
DEBUG - 2015-02-02 19:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 19:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 19:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 19:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 19:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 19:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 19:30:21 --> Final output sent to browser
DEBUG - 2015-02-02 19:30:21 --> Total execution time: 0.6431
DEBUG - 2015-02-02 19:45:21 --> Config Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Hooks Class Initialized
DEBUG - 2015-02-02 19:45:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 19:45:21 --> Utf8 Class Initialized
DEBUG - 2015-02-02 19:45:21 --> URI Class Initialized
DEBUG - 2015-02-02 19:45:21 --> No URI present. Default controller set.
DEBUG - 2015-02-02 19:45:21 --> Router Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Output Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Security Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Input Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 19:45:21 --> Language Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Loader Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Helper loaded: url_helper
DEBUG - 2015-02-02 19:45:21 --> Helper loaded: link_helper
DEBUG - 2015-02-02 19:45:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 19:45:21 --> CI_Session Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Session: Regenerate ID
DEBUG - 2015-02-02 19:45:21 --> CI_Session routines successfully run
DEBUG - 2015-02-02 19:45:21 --> Model Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Model Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Controller Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 19:45:21 --> Email Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 19:45:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 19:45:21 --> Helper loaded: language_helper
DEBUG - 2015-02-02 19:45:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 19:45:21 --> Model Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Database Driver Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Helper loaded: date_helper
DEBUG - 2015-02-02 19:45:21 --> Helper loaded: form_helper
DEBUG - 2015-02-02 19:45:21 --> Form Validation Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Model Class Initialized
DEBUG - 2015-02-02 19:45:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 19:45:21 --> Pagination Class Initialized
DEBUG - 2015-02-02 19:45:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 19:45:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 19:45:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 19:45:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 19:45:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 19:45:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 19:45:22 --> Final output sent to browser
DEBUG - 2015-02-02 19:45:22 --> Total execution time: 0.6551
DEBUG - 2015-02-02 20:00:22 --> Config Class Initialized
DEBUG - 2015-02-02 20:00:22 --> Hooks Class Initialized
DEBUG - 2015-02-02 20:00:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 20:00:22 --> Utf8 Class Initialized
DEBUG - 2015-02-02 20:00:22 --> URI Class Initialized
DEBUG - 2015-02-02 20:00:22 --> No URI present. Default controller set.
DEBUG - 2015-02-02 20:00:22 --> Router Class Initialized
DEBUG - 2015-02-02 20:00:22 --> Output Class Initialized
DEBUG - 2015-02-02 20:00:22 --> Security Class Initialized
DEBUG - 2015-02-02 20:00:22 --> Input Class Initialized
DEBUG - 2015-02-02 20:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 20:00:23 --> Language Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Loader Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Helper loaded: url_helper
DEBUG - 2015-02-02 20:00:23 --> Helper loaded: link_helper
DEBUG - 2015-02-02 20:00:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 20:00:23 --> CI_Session Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Session: Regenerate ID
DEBUG - 2015-02-02 20:00:23 --> CI_Session routines successfully run
DEBUG - 2015-02-02 20:00:23 --> Model Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Model Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Controller Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 20:00:23 --> Email Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 20:00:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 20:00:23 --> Helper loaded: language_helper
DEBUG - 2015-02-02 20:00:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 20:00:23 --> Model Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Database Driver Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Helper loaded: date_helper
DEBUG - 2015-02-02 20:00:23 --> Helper loaded: form_helper
DEBUG - 2015-02-02 20:00:23 --> Form Validation Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Model Class Initialized
DEBUG - 2015-02-02 20:00:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 20:00:23 --> Pagination Class Initialized
DEBUG - 2015-02-02 20:00:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 20:00:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 20:00:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 20:00:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 20:00:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 20:00:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 20:00:23 --> Final output sent to browser
DEBUG - 2015-02-02 20:00:23 --> Total execution time: 0.7440
DEBUG - 2015-02-02 20:15:24 --> Config Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Hooks Class Initialized
DEBUG - 2015-02-02 20:15:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 20:15:24 --> Utf8 Class Initialized
DEBUG - 2015-02-02 20:15:24 --> URI Class Initialized
DEBUG - 2015-02-02 20:15:24 --> No URI present. Default controller set.
DEBUG - 2015-02-02 20:15:24 --> Router Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Output Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Security Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Input Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 20:15:24 --> Language Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Loader Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Helper loaded: url_helper
DEBUG - 2015-02-02 20:15:24 --> Helper loaded: link_helper
DEBUG - 2015-02-02 20:15:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 20:15:24 --> CI_Session Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Session: Regenerate ID
DEBUG - 2015-02-02 20:15:24 --> CI_Session routines successfully run
DEBUG - 2015-02-02 20:15:24 --> Model Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Model Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Controller Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 20:15:24 --> Email Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 20:15:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 20:15:24 --> Helper loaded: language_helper
DEBUG - 2015-02-02 20:15:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 20:15:24 --> Model Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Database Driver Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Helper loaded: date_helper
DEBUG - 2015-02-02 20:15:24 --> Helper loaded: form_helper
DEBUG - 2015-02-02 20:15:24 --> Form Validation Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Model Class Initialized
DEBUG - 2015-02-02 20:15:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 20:15:24 --> Pagination Class Initialized
DEBUG - 2015-02-02 20:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 20:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 20:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 20:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 20:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 20:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 20:15:24 --> Final output sent to browser
DEBUG - 2015-02-02 20:15:24 --> Total execution time: 0.6341
DEBUG - 2015-02-02 20:30:26 --> Config Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Hooks Class Initialized
DEBUG - 2015-02-02 20:30:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 20:30:26 --> Utf8 Class Initialized
DEBUG - 2015-02-02 20:30:26 --> URI Class Initialized
DEBUG - 2015-02-02 20:30:26 --> No URI present. Default controller set.
DEBUG - 2015-02-02 20:30:26 --> Router Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Output Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Security Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Input Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 20:30:26 --> Language Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Loader Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Helper loaded: url_helper
DEBUG - 2015-02-02 20:30:26 --> Helper loaded: link_helper
DEBUG - 2015-02-02 20:30:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 20:30:26 --> CI_Session Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Session: Regenerate ID
DEBUG - 2015-02-02 20:30:26 --> CI_Session routines successfully run
DEBUG - 2015-02-02 20:30:26 --> Model Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Model Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Controller Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 20:30:26 --> Email Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 20:30:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 20:30:26 --> Helper loaded: language_helper
DEBUG - 2015-02-02 20:30:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 20:30:26 --> Model Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Database Driver Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Helper loaded: date_helper
DEBUG - 2015-02-02 20:30:26 --> Helper loaded: form_helper
DEBUG - 2015-02-02 20:30:26 --> Form Validation Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Model Class Initialized
DEBUG - 2015-02-02 20:30:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 20:30:26 --> Pagination Class Initialized
DEBUG - 2015-02-02 20:30:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 20:30:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 20:30:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 20:30:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 20:30:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 20:30:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 20:30:26 --> Final output sent to browser
DEBUG - 2015-02-02 20:30:27 --> Total execution time: 0.6601
DEBUG - 2015-02-02 20:45:32 --> Config Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Hooks Class Initialized
DEBUG - 2015-02-02 20:45:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 20:45:32 --> Utf8 Class Initialized
DEBUG - 2015-02-02 20:45:32 --> URI Class Initialized
DEBUG - 2015-02-02 20:45:32 --> No URI present. Default controller set.
DEBUG - 2015-02-02 20:45:32 --> Router Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Output Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Security Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Input Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 20:45:32 --> Language Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Loader Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Helper loaded: url_helper
DEBUG - 2015-02-02 20:45:32 --> Helper loaded: link_helper
DEBUG - 2015-02-02 20:45:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 20:45:32 --> CI_Session Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Session: Regenerate ID
DEBUG - 2015-02-02 20:45:32 --> CI_Session routines successfully run
DEBUG - 2015-02-02 20:45:32 --> Model Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Model Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Controller Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 20:45:32 --> Email Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 20:45:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 20:45:32 --> Helper loaded: language_helper
DEBUG - 2015-02-02 20:45:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 20:45:32 --> Model Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Database Driver Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Helper loaded: date_helper
DEBUG - 2015-02-02 20:45:32 --> Helper loaded: form_helper
DEBUG - 2015-02-02 20:45:32 --> Form Validation Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Model Class Initialized
DEBUG - 2015-02-02 20:45:32 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 20:45:32 --> Pagination Class Initialized
DEBUG - 2015-02-02 20:45:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 20:45:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 20:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 20:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 20:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 20:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 20:45:33 --> Final output sent to browser
DEBUG - 2015-02-02 20:45:33 --> Total execution time: 0.6391
DEBUG - 2015-02-02 21:00:38 --> Config Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Hooks Class Initialized
DEBUG - 2015-02-02 21:00:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 21:00:38 --> Utf8 Class Initialized
DEBUG - 2015-02-02 21:00:38 --> URI Class Initialized
DEBUG - 2015-02-02 21:00:38 --> No URI present. Default controller set.
DEBUG - 2015-02-02 21:00:38 --> Router Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Output Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Security Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Input Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 21:00:38 --> Language Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Loader Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Helper loaded: url_helper
DEBUG - 2015-02-02 21:00:38 --> Helper loaded: link_helper
DEBUG - 2015-02-02 21:00:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 21:00:38 --> CI_Session Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Session: Regenerate ID
DEBUG - 2015-02-02 21:00:38 --> CI_Session routines successfully run
DEBUG - 2015-02-02 21:00:38 --> Model Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Model Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Controller Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 21:00:38 --> Email Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 21:00:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 21:00:38 --> Helper loaded: language_helper
DEBUG - 2015-02-02 21:00:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 21:00:38 --> Model Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Database Driver Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Helper loaded: date_helper
DEBUG - 2015-02-02 21:00:38 --> Helper loaded: form_helper
DEBUG - 2015-02-02 21:00:38 --> Form Validation Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Model Class Initialized
DEBUG - 2015-02-02 21:00:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 21:00:38 --> Pagination Class Initialized
DEBUG - 2015-02-02 21:00:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 21:00:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 21:00:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 21:00:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 21:00:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 21:00:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 21:00:39 --> Final output sent to browser
DEBUG - 2015-02-02 21:00:39 --> Total execution time: 0.6520
DEBUG - 2015-02-02 21:15:39 --> Config Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Hooks Class Initialized
DEBUG - 2015-02-02 21:15:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 21:15:39 --> Utf8 Class Initialized
DEBUG - 2015-02-02 21:15:39 --> URI Class Initialized
DEBUG - 2015-02-02 21:15:39 --> No URI present. Default controller set.
DEBUG - 2015-02-02 21:15:39 --> Router Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Output Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Security Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Input Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 21:15:39 --> Language Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Loader Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Helper loaded: url_helper
DEBUG - 2015-02-02 21:15:39 --> Helper loaded: link_helper
DEBUG - 2015-02-02 21:15:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 21:15:39 --> CI_Session Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Session: Regenerate ID
DEBUG - 2015-02-02 21:15:39 --> CI_Session routines successfully run
DEBUG - 2015-02-02 21:15:39 --> Model Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Model Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Controller Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 21:15:39 --> Email Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 21:15:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 21:15:39 --> Helper loaded: language_helper
DEBUG - 2015-02-02 21:15:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 21:15:39 --> Model Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Database Driver Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Helper loaded: date_helper
DEBUG - 2015-02-02 21:15:39 --> Helper loaded: form_helper
DEBUG - 2015-02-02 21:15:39 --> Form Validation Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Model Class Initialized
DEBUG - 2015-02-02 21:15:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 21:15:39 --> Pagination Class Initialized
DEBUG - 2015-02-02 21:15:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 21:15:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 21:15:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 21:15:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 21:15:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 21:15:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 21:15:40 --> Final output sent to browser
DEBUG - 2015-02-02 21:15:40 --> Total execution time: 0.6271
DEBUG - 2015-02-02 21:30:40 --> Config Class Initialized
DEBUG - 2015-02-02 21:30:40 --> Hooks Class Initialized
DEBUG - 2015-02-02 21:30:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 21:30:40 --> Utf8 Class Initialized
DEBUG - 2015-02-02 21:30:40 --> URI Class Initialized
DEBUG - 2015-02-02 21:30:40 --> No URI present. Default controller set.
DEBUG - 2015-02-02 21:30:40 --> Router Class Initialized
DEBUG - 2015-02-02 21:30:40 --> Output Class Initialized
DEBUG - 2015-02-02 21:30:40 --> Security Class Initialized
DEBUG - 2015-02-02 21:30:40 --> Input Class Initialized
DEBUG - 2015-02-02 21:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 21:30:40 --> Language Class Initialized
DEBUG - 2015-02-02 21:30:40 --> Loader Class Initialized
DEBUG - 2015-02-02 21:30:40 --> Helper loaded: url_helper
DEBUG - 2015-02-02 21:30:40 --> Helper loaded: link_helper
DEBUG - 2015-02-02 21:30:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 21:30:40 --> CI_Session Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Session: Regenerate ID
DEBUG - 2015-02-02 21:30:41 --> CI_Session routines successfully run
DEBUG - 2015-02-02 21:30:41 --> Model Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Model Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Controller Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 21:30:41 --> Email Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 21:30:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 21:30:41 --> Helper loaded: language_helper
DEBUG - 2015-02-02 21:30:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 21:30:41 --> Model Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Database Driver Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Helper loaded: date_helper
DEBUG - 2015-02-02 21:30:41 --> Helper loaded: form_helper
DEBUG - 2015-02-02 21:30:41 --> Form Validation Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Model Class Initialized
DEBUG - 2015-02-02 21:30:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 21:30:41 --> Pagination Class Initialized
DEBUG - 2015-02-02 21:30:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 21:30:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 21:30:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 21:30:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 21:30:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 21:30:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 21:30:41 --> Final output sent to browser
DEBUG - 2015-02-02 21:30:41 --> Total execution time: 0.6260
DEBUG - 2015-02-02 21:45:42 --> Config Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Hooks Class Initialized
DEBUG - 2015-02-02 21:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 21:45:42 --> Utf8 Class Initialized
DEBUG - 2015-02-02 21:45:42 --> URI Class Initialized
DEBUG - 2015-02-02 21:45:42 --> No URI present. Default controller set.
DEBUG - 2015-02-02 21:45:42 --> Router Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Output Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Security Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Input Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 21:45:42 --> Language Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Loader Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Helper loaded: url_helper
DEBUG - 2015-02-02 21:45:42 --> Helper loaded: link_helper
DEBUG - 2015-02-02 21:45:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 21:45:42 --> CI_Session Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Session: Regenerate ID
DEBUG - 2015-02-02 21:45:42 --> CI_Session routines successfully run
DEBUG - 2015-02-02 21:45:42 --> Model Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Model Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Controller Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 21:45:42 --> Email Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 21:45:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 21:45:42 --> Helper loaded: language_helper
DEBUG - 2015-02-02 21:45:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 21:45:42 --> Model Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Database Driver Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Helper loaded: date_helper
DEBUG - 2015-02-02 21:45:42 --> Helper loaded: form_helper
DEBUG - 2015-02-02 21:45:42 --> Form Validation Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Model Class Initialized
DEBUG - 2015-02-02 21:45:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 21:45:42 --> Pagination Class Initialized
DEBUG - 2015-02-02 21:45:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 21:45:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 21:45:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 21:45:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 21:45:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 21:45:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 21:45:42 --> Final output sent to browser
DEBUG - 2015-02-02 21:45:42 --> Total execution time: 0.6661
DEBUG - 2015-02-02 22:00:43 --> Config Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Hooks Class Initialized
DEBUG - 2015-02-02 22:00:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 22:00:43 --> Utf8 Class Initialized
DEBUG - 2015-02-02 22:00:43 --> URI Class Initialized
DEBUG - 2015-02-02 22:00:43 --> No URI present. Default controller set.
DEBUG - 2015-02-02 22:00:43 --> Router Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Output Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Security Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Input Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 22:00:43 --> Language Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Loader Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Helper loaded: url_helper
DEBUG - 2015-02-02 22:00:43 --> Helper loaded: link_helper
DEBUG - 2015-02-02 22:00:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 22:00:43 --> CI_Session Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Session: Regenerate ID
DEBUG - 2015-02-02 22:00:43 --> CI_Session routines successfully run
DEBUG - 2015-02-02 22:00:43 --> Model Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Model Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Controller Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 22:00:43 --> Email Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 22:00:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 22:00:43 --> Helper loaded: language_helper
DEBUG - 2015-02-02 22:00:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 22:00:43 --> Model Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Database Driver Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Helper loaded: date_helper
DEBUG - 2015-02-02 22:00:43 --> Helper loaded: form_helper
DEBUG - 2015-02-02 22:00:43 --> Form Validation Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Model Class Initialized
DEBUG - 2015-02-02 22:00:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 22:00:43 --> Pagination Class Initialized
DEBUG - 2015-02-02 22:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 22:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 22:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 22:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 22:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 22:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 22:00:43 --> Final output sent to browser
DEBUG - 2015-02-02 22:00:43 --> Total execution time: 0.6651
DEBUG - 2015-02-02 22:15:44 --> Config Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Hooks Class Initialized
DEBUG - 2015-02-02 22:15:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 22:15:44 --> Utf8 Class Initialized
DEBUG - 2015-02-02 22:15:44 --> URI Class Initialized
DEBUG - 2015-02-02 22:15:44 --> No URI present. Default controller set.
DEBUG - 2015-02-02 22:15:44 --> Router Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Output Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Security Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Input Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 22:15:44 --> Language Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Loader Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Helper loaded: url_helper
DEBUG - 2015-02-02 22:15:44 --> Helper loaded: link_helper
DEBUG - 2015-02-02 22:15:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 22:15:44 --> CI_Session Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Session: Regenerate ID
DEBUG - 2015-02-02 22:15:44 --> CI_Session routines successfully run
DEBUG - 2015-02-02 22:15:44 --> Model Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Model Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Controller Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 22:15:44 --> Email Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 22:15:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 22:15:44 --> Helper loaded: language_helper
DEBUG - 2015-02-02 22:15:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 22:15:44 --> Model Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Database Driver Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Helper loaded: date_helper
DEBUG - 2015-02-02 22:15:44 --> Helper loaded: form_helper
DEBUG - 2015-02-02 22:15:44 --> Form Validation Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Model Class Initialized
DEBUG - 2015-02-02 22:15:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 22:15:44 --> Pagination Class Initialized
DEBUG - 2015-02-02 22:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 22:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 22:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 22:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 22:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 22:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 22:15:44 --> Final output sent to browser
DEBUG - 2015-02-02 22:15:44 --> Total execution time: 0.6321
DEBUG - 2015-02-02 22:30:45 --> Config Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Hooks Class Initialized
DEBUG - 2015-02-02 22:30:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 22:30:45 --> Utf8 Class Initialized
DEBUG - 2015-02-02 22:30:45 --> URI Class Initialized
DEBUG - 2015-02-02 22:30:45 --> No URI present. Default controller set.
DEBUG - 2015-02-02 22:30:45 --> Router Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Output Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Security Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Input Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 22:30:45 --> Language Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Loader Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Helper loaded: url_helper
DEBUG - 2015-02-02 22:30:45 --> Helper loaded: link_helper
DEBUG - 2015-02-02 22:30:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 22:30:45 --> CI_Session Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Session: Regenerate ID
DEBUG - 2015-02-02 22:30:45 --> CI_Session routines successfully run
DEBUG - 2015-02-02 22:30:45 --> Model Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Model Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Controller Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 22:30:45 --> Email Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 22:30:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 22:30:45 --> Helper loaded: language_helper
DEBUG - 2015-02-02 22:30:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 22:30:45 --> Model Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Database Driver Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Helper loaded: date_helper
DEBUG - 2015-02-02 22:30:45 --> Helper loaded: form_helper
DEBUG - 2015-02-02 22:30:45 --> Form Validation Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Model Class Initialized
DEBUG - 2015-02-02 22:30:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 22:30:45 --> Pagination Class Initialized
DEBUG - 2015-02-02 22:30:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 22:30:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 22:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 22:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 22:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 22:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 22:30:46 --> Final output sent to browser
DEBUG - 2015-02-02 22:30:46 --> Total execution time: 0.6331
DEBUG - 2015-02-02 22:45:46 --> Config Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Hooks Class Initialized
DEBUG - 2015-02-02 22:45:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 22:45:46 --> Utf8 Class Initialized
DEBUG - 2015-02-02 22:45:46 --> URI Class Initialized
DEBUG - 2015-02-02 22:45:46 --> No URI present. Default controller set.
DEBUG - 2015-02-02 22:45:46 --> Router Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Output Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Security Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Input Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 22:45:46 --> Language Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Loader Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Helper loaded: url_helper
DEBUG - 2015-02-02 22:45:46 --> Helper loaded: link_helper
DEBUG - 2015-02-02 22:45:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 22:45:46 --> CI_Session Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Session: Regenerate ID
DEBUG - 2015-02-02 22:45:46 --> CI_Session routines successfully run
DEBUG - 2015-02-02 22:45:46 --> Model Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Model Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Controller Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 22:45:46 --> Email Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 22:45:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 22:45:46 --> Helper loaded: language_helper
DEBUG - 2015-02-02 22:45:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 22:45:46 --> Model Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Database Driver Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Helper loaded: date_helper
DEBUG - 2015-02-02 22:45:46 --> Helper loaded: form_helper
DEBUG - 2015-02-02 22:45:46 --> Form Validation Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Model Class Initialized
DEBUG - 2015-02-02 22:45:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 22:45:46 --> Pagination Class Initialized
DEBUG - 2015-02-02 22:45:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 22:45:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 22:45:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 22:45:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 22:45:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 22:45:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 22:45:47 --> Final output sent to browser
DEBUG - 2015-02-02 22:45:47 --> Total execution time: 0.6551
DEBUG - 2015-02-02 23:00:47 --> Config Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Hooks Class Initialized
DEBUG - 2015-02-02 23:00:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 23:00:47 --> Utf8 Class Initialized
DEBUG - 2015-02-02 23:00:47 --> URI Class Initialized
DEBUG - 2015-02-02 23:00:47 --> No URI present. Default controller set.
DEBUG - 2015-02-02 23:00:47 --> Router Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Output Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Security Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Input Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 23:00:47 --> Language Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Loader Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Helper loaded: url_helper
DEBUG - 2015-02-02 23:00:47 --> Helper loaded: link_helper
DEBUG - 2015-02-02 23:00:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 23:00:47 --> CI_Session Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Session: Regenerate ID
DEBUG - 2015-02-02 23:00:47 --> CI_Session routines successfully run
DEBUG - 2015-02-02 23:00:47 --> Model Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Model Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Controller Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 23:00:47 --> Email Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 23:00:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 23:00:47 --> Helper loaded: language_helper
DEBUG - 2015-02-02 23:00:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 23:00:47 --> Model Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Database Driver Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Helper loaded: date_helper
DEBUG - 2015-02-02 23:00:47 --> Helper loaded: form_helper
DEBUG - 2015-02-02 23:00:47 --> Form Validation Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Model Class Initialized
DEBUG - 2015-02-02 23:00:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 23:00:47 --> Pagination Class Initialized
DEBUG - 2015-02-02 23:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 23:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 23:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 23:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 23:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 23:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 23:00:48 --> Final output sent to browser
DEBUG - 2015-02-02 23:00:48 --> Total execution time: 0.6301
DEBUG - 2015-02-02 23:15:48 --> Config Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Hooks Class Initialized
DEBUG - 2015-02-02 23:15:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 23:15:48 --> Utf8 Class Initialized
DEBUG - 2015-02-02 23:15:48 --> URI Class Initialized
DEBUG - 2015-02-02 23:15:48 --> No URI present. Default controller set.
DEBUG - 2015-02-02 23:15:48 --> Router Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Output Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Security Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Input Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 23:15:48 --> Language Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Loader Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Helper loaded: url_helper
DEBUG - 2015-02-02 23:15:48 --> Helper loaded: link_helper
DEBUG - 2015-02-02 23:15:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 23:15:48 --> CI_Session Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Session: Regenerate ID
DEBUG - 2015-02-02 23:15:48 --> CI_Session routines successfully run
DEBUG - 2015-02-02 23:15:48 --> Model Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Model Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Controller Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 23:15:48 --> Email Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 23:15:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 23:15:48 --> Helper loaded: language_helper
DEBUG - 2015-02-02 23:15:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 23:15:48 --> Model Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Database Driver Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Helper loaded: date_helper
DEBUG - 2015-02-02 23:15:48 --> Helper loaded: form_helper
DEBUG - 2015-02-02 23:15:48 --> Form Validation Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Model Class Initialized
DEBUG - 2015-02-02 23:15:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 23:15:48 --> Pagination Class Initialized
DEBUG - 2015-02-02 23:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 23:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 23:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 23:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 23:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 23:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 23:15:49 --> Final output sent to browser
DEBUG - 2015-02-02 23:15:49 --> Total execution time: 0.6441
DEBUG - 2015-02-02 23:30:50 --> Config Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Hooks Class Initialized
DEBUG - 2015-02-02 23:30:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 23:30:50 --> Utf8 Class Initialized
DEBUG - 2015-02-02 23:30:50 --> URI Class Initialized
DEBUG - 2015-02-02 23:30:50 --> No URI present. Default controller set.
DEBUG - 2015-02-02 23:30:50 --> Router Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Output Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Security Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Input Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 23:30:50 --> Language Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Loader Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Helper loaded: url_helper
DEBUG - 2015-02-02 23:30:50 --> Helper loaded: link_helper
DEBUG - 2015-02-02 23:30:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 23:30:50 --> CI_Session Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Session: Regenerate ID
DEBUG - 2015-02-02 23:30:50 --> CI_Session routines successfully run
DEBUG - 2015-02-02 23:30:50 --> Model Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Model Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Controller Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 23:30:50 --> Email Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 23:30:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 23:30:50 --> Helper loaded: language_helper
DEBUG - 2015-02-02 23:30:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 23:30:50 --> Model Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Database Driver Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Helper loaded: date_helper
DEBUG - 2015-02-02 23:30:50 --> Helper loaded: form_helper
DEBUG - 2015-02-02 23:30:50 --> Form Validation Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Model Class Initialized
DEBUG - 2015-02-02 23:30:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 23:30:50 --> Pagination Class Initialized
DEBUG - 2015-02-02 23:30:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 23:30:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 23:30:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 23:30:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 23:30:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 23:30:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 23:30:50 --> Final output sent to browser
DEBUG - 2015-02-02 23:30:50 --> Total execution time: 0.6251
DEBUG - 2015-02-02 23:45:51 --> Config Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Hooks Class Initialized
DEBUG - 2015-02-02 23:45:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-02 23:45:51 --> Utf8 Class Initialized
DEBUG - 2015-02-02 23:45:51 --> URI Class Initialized
DEBUG - 2015-02-02 23:45:51 --> No URI present. Default controller set.
DEBUG - 2015-02-02 23:45:51 --> Router Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Output Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Security Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Input Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-02 23:45:51 --> Language Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Loader Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Helper loaded: url_helper
DEBUG - 2015-02-02 23:45:51 --> Helper loaded: link_helper
DEBUG - 2015-02-02 23:45:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-02 23:45:51 --> CI_Session Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Session: Regenerate ID
DEBUG - 2015-02-02 23:45:51 --> CI_Session routines successfully run
DEBUG - 2015-02-02 23:45:51 --> Model Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Model Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Controller Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-02 23:45:51 --> Email Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-02 23:45:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-02 23:45:51 --> Helper loaded: language_helper
DEBUG - 2015-02-02 23:45:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-02 23:45:51 --> Model Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Database Driver Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Helper loaded: date_helper
DEBUG - 2015-02-02 23:45:51 --> Helper loaded: form_helper
DEBUG - 2015-02-02 23:45:51 --> Form Validation Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Model Class Initialized
DEBUG - 2015-02-02 23:45:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-02 23:45:51 --> Pagination Class Initialized
DEBUG - 2015-02-02 23:45:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-02 23:45:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-02 23:45:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-02 23:45:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-02 23:45:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-02 23:45:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-02 23:45:51 --> Final output sent to browser
DEBUG - 2015-02-02 23:45:51 --> Total execution time: 0.6321
