<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-04 00:14:45 --> Config Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Hooks Class Initialized
DEBUG - 2015-02-04 00:14:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 00:14:45 --> Utf8 Class Initialized
DEBUG - 2015-02-04 00:14:45 --> URI Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Router Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Output Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Security Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Input Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 00:14:45 --> Language Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Loader Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Helper loaded: url_helper
DEBUG - 2015-02-04 00:14:45 --> Helper loaded: link_helper
DEBUG - 2015-02-04 00:14:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 00:14:45 --> CI_Session Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Session: Regenerate ID
DEBUG - 2015-02-04 00:14:45 --> CI_Session routines successfully run
DEBUG - 2015-02-04 00:14:45 --> Model Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Model Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Controller Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 00:14:45 --> Email Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 00:14:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 00:14:45 --> Helper loaded: language_helper
DEBUG - 2015-02-04 00:14:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 00:14:45 --> Model Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Database Driver Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Helper loaded: date_helper
DEBUG - 2015-02-04 00:14:45 --> Helper loaded: form_helper
DEBUG - 2015-02-04 00:14:45 --> Form Validation Class Initialized
DEBUG - 2015-02-04 00:14:45 --> Model Class Initialized
DEBUG - 2015-02-04 00:14:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 00:14:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 00:14:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 00:14:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 00:14:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 00:14:46 --> Final output sent to browser
DEBUG - 2015-02-04 00:14:46 --> Total execution time: 0.3650
DEBUG - 2015-02-04 00:29:48 --> Config Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 00:29:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 00:29:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 00:29:48 --> URI Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Router Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Output Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Security Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Input Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 00:29:48 --> Language Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Loader Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Helper loaded: url_helper
DEBUG - 2015-02-04 00:29:48 --> Helper loaded: link_helper
DEBUG - 2015-02-04 00:29:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 00:29:48 --> CI_Session Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Session: Regenerate ID
DEBUG - 2015-02-04 00:29:48 --> CI_Session routines successfully run
DEBUG - 2015-02-04 00:29:48 --> Model Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Model Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Controller Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 00:29:48 --> Email Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 00:29:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 00:29:48 --> Helper loaded: language_helper
DEBUG - 2015-02-04 00:29:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 00:29:48 --> Model Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Helper loaded: date_helper
DEBUG - 2015-02-04 00:29:48 --> Helper loaded: form_helper
DEBUG - 2015-02-04 00:29:48 --> Form Validation Class Initialized
DEBUG - 2015-02-04 00:29:48 --> Model Class Initialized
DEBUG - 2015-02-04 00:29:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 00:29:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 00:29:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 00:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 00:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 00:29:49 --> Final output sent to browser
DEBUG - 2015-02-04 00:29:49 --> Total execution time: 0.3900
DEBUG - 2015-02-04 00:44:50 --> Config Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Hooks Class Initialized
DEBUG - 2015-02-04 00:44:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 00:44:50 --> Utf8 Class Initialized
DEBUG - 2015-02-04 00:44:50 --> URI Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Router Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Output Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Security Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Input Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 00:44:50 --> Language Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Loader Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Helper loaded: url_helper
DEBUG - 2015-02-04 00:44:50 --> Helper loaded: link_helper
DEBUG - 2015-02-04 00:44:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 00:44:50 --> CI_Session Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Session: Regenerate ID
DEBUG - 2015-02-04 00:44:50 --> CI_Session routines successfully run
DEBUG - 2015-02-04 00:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Controller Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 00:44:50 --> Email Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 00:44:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 00:44:50 --> Helper loaded: language_helper
DEBUG - 2015-02-04 00:44:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 00:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Database Driver Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Helper loaded: date_helper
DEBUG - 2015-02-04 00:44:50 --> Helper loaded: form_helper
DEBUG - 2015-02-04 00:44:50 --> Form Validation Class Initialized
DEBUG - 2015-02-04 00:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 00:44:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 00:44:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 00:44:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 00:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 00:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 00:44:51 --> Final output sent to browser
DEBUG - 2015-02-04 00:44:51 --> Total execution time: 0.3480
DEBUG - 2015-02-04 00:59:52 --> Config Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Hooks Class Initialized
DEBUG - 2015-02-04 00:59:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 00:59:52 --> Utf8 Class Initialized
DEBUG - 2015-02-04 00:59:52 --> URI Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Router Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Output Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Security Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Input Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 00:59:52 --> Language Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Loader Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Helper loaded: url_helper
DEBUG - 2015-02-04 00:59:52 --> Helper loaded: link_helper
DEBUG - 2015-02-04 00:59:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 00:59:52 --> CI_Session Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Session: Regenerate ID
DEBUG - 2015-02-04 00:59:52 --> CI_Session routines successfully run
DEBUG - 2015-02-04 00:59:52 --> Model Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Model Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Controller Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 00:59:52 --> Email Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 00:59:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 00:59:52 --> Helper loaded: language_helper
DEBUG - 2015-02-04 00:59:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 00:59:52 --> Model Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Database Driver Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Helper loaded: date_helper
DEBUG - 2015-02-04 00:59:52 --> Helper loaded: form_helper
DEBUG - 2015-02-04 00:59:52 --> Form Validation Class Initialized
DEBUG - 2015-02-04 00:59:52 --> Model Class Initialized
DEBUG - 2015-02-04 00:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 00:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 00:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 00:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 00:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 00:59:53 --> Final output sent to browser
DEBUG - 2015-02-04 00:59:53 --> Total execution time: 0.3730
DEBUG - 2015-02-04 01:14:54 --> Config Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Hooks Class Initialized
DEBUG - 2015-02-04 01:14:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 01:14:54 --> Utf8 Class Initialized
DEBUG - 2015-02-04 01:14:54 --> URI Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Router Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Output Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Security Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Input Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 01:14:54 --> Language Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Loader Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Helper loaded: url_helper
DEBUG - 2015-02-04 01:14:54 --> Helper loaded: link_helper
DEBUG - 2015-02-04 01:14:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 01:14:54 --> CI_Session Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Session: Regenerate ID
DEBUG - 2015-02-04 01:14:54 --> CI_Session routines successfully run
DEBUG - 2015-02-04 01:14:54 --> Model Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Model Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Controller Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 01:14:54 --> Email Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 01:14:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 01:14:54 --> Helper loaded: language_helper
DEBUG - 2015-02-04 01:14:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 01:14:54 --> Model Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Database Driver Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Helper loaded: date_helper
DEBUG - 2015-02-04 01:14:54 --> Helper loaded: form_helper
DEBUG - 2015-02-04 01:14:54 --> Form Validation Class Initialized
DEBUG - 2015-02-04 01:14:54 --> Model Class Initialized
DEBUG - 2015-02-04 01:14:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 01:14:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 01:14:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 01:14:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 01:14:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 01:14:55 --> Final output sent to browser
DEBUG - 2015-02-04 01:14:55 --> Total execution time: 0.3840
DEBUG - 2015-02-04 01:29:56 --> Config Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 01:29:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 01:29:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 01:29:56 --> URI Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Router Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Output Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Security Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Input Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 01:29:56 --> Language Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Loader Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Helper loaded: url_helper
DEBUG - 2015-02-04 01:29:56 --> Helper loaded: link_helper
DEBUG - 2015-02-04 01:29:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 01:29:56 --> CI_Session Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Session: Regenerate ID
DEBUG - 2015-02-04 01:29:56 --> CI_Session routines successfully run
DEBUG - 2015-02-04 01:29:56 --> Model Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Model Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Controller Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 01:29:56 --> Email Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 01:29:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 01:29:56 --> Helper loaded: language_helper
DEBUG - 2015-02-04 01:29:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 01:29:56 --> Model Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Database Driver Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Helper loaded: date_helper
DEBUG - 2015-02-04 01:29:56 --> Helper loaded: form_helper
DEBUG - 2015-02-04 01:29:56 --> Form Validation Class Initialized
DEBUG - 2015-02-04 01:29:56 --> Model Class Initialized
DEBUG - 2015-02-04 01:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 01:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 01:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 01:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 01:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 01:29:57 --> Final output sent to browser
DEBUG - 2015-02-04 01:29:57 --> Total execution time: 0.3540
DEBUG - 2015-02-04 01:44:58 --> Config Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Hooks Class Initialized
DEBUG - 2015-02-04 01:44:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 01:44:58 --> Utf8 Class Initialized
DEBUG - 2015-02-04 01:44:58 --> URI Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Router Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Output Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Security Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Input Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 01:44:58 --> Language Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Loader Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Helper loaded: url_helper
DEBUG - 2015-02-04 01:44:58 --> Helper loaded: link_helper
DEBUG - 2015-02-04 01:44:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 01:44:58 --> CI_Session Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Session: Regenerate ID
DEBUG - 2015-02-04 01:44:58 --> CI_Session routines successfully run
DEBUG - 2015-02-04 01:44:58 --> Model Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Model Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Controller Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 01:44:58 --> Email Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 01:44:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 01:44:58 --> Helper loaded: language_helper
DEBUG - 2015-02-04 01:44:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 01:44:58 --> Model Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Database Driver Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Helper loaded: date_helper
DEBUG - 2015-02-04 01:44:58 --> Helper loaded: form_helper
DEBUG - 2015-02-04 01:44:58 --> Form Validation Class Initialized
DEBUG - 2015-02-04 01:44:58 --> Model Class Initialized
DEBUG - 2015-02-04 01:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 01:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 01:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 01:44:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 01:44:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 01:44:59 --> Final output sent to browser
DEBUG - 2015-02-04 01:44:59 --> Total execution time: 0.3400
DEBUG - 2015-02-04 02:00:00 --> Config Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 02:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 02:00:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 02:00:00 --> URI Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Router Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Output Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Security Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Input Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 02:00:00 --> Language Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Loader Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 02:00:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 02:00:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 02:00:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Session: Regenerate ID
DEBUG - 2015-02-04 02:00:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 02:00:00 --> Model Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Model Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Controller Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 02:00:00 --> Email Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 02:00:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 02:00:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 02:00:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 02:00:00 --> Model Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 02:00:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 02:00:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 02:00:00 --> Model Class Initialized
DEBUG - 2015-02-04 02:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 02:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 02:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 02:00:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 02:00:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 02:00:01 --> Final output sent to browser
DEBUG - 2015-02-04 02:00:01 --> Total execution time: 0.3910
DEBUG - 2015-02-04 02:15:02 --> Config Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Hooks Class Initialized
DEBUG - 2015-02-04 02:15:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 02:15:02 --> Utf8 Class Initialized
DEBUG - 2015-02-04 02:15:02 --> URI Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Router Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Output Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Security Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Input Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 02:15:02 --> Language Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Loader Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Helper loaded: url_helper
DEBUG - 2015-02-04 02:15:02 --> Helper loaded: link_helper
DEBUG - 2015-02-04 02:15:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 02:15:02 --> CI_Session Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Session: Regenerate ID
DEBUG - 2015-02-04 02:15:02 --> CI_Session routines successfully run
DEBUG - 2015-02-04 02:15:02 --> Model Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Model Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Controller Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 02:15:02 --> Email Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 02:15:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 02:15:02 --> Helper loaded: language_helper
DEBUG - 2015-02-04 02:15:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 02:15:02 --> Model Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Database Driver Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Helper loaded: date_helper
DEBUG - 2015-02-04 02:15:02 --> Helper loaded: form_helper
DEBUG - 2015-02-04 02:15:02 --> Form Validation Class Initialized
DEBUG - 2015-02-04 02:15:02 --> Model Class Initialized
DEBUG - 2015-02-04 02:15:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 02:15:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 02:15:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 02:15:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 02:15:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 02:15:03 --> Final output sent to browser
DEBUG - 2015-02-04 02:15:03 --> Total execution time: 0.3710
DEBUG - 2015-02-04 02:30:04 --> Config Class Initialized
DEBUG - 2015-02-04 02:30:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 02:30:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 02:30:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 02:30:04 --> URI Class Initialized
DEBUG - 2015-02-04 02:30:05 --> Router Class Initialized
DEBUG - 2015-02-04 02:30:05 --> Output Class Initialized
DEBUG - 2015-02-04 02:30:05 --> Security Class Initialized
DEBUG - 2015-02-04 02:30:05 --> Input Class Initialized
DEBUG - 2015-02-04 02:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 02:30:06 --> Language Class Initialized
DEBUG - 2015-02-04 02:30:07 --> Loader Class Initialized
DEBUG - 2015-02-04 02:30:08 --> Helper loaded: url_helper
DEBUG - 2015-02-04 02:30:08 --> Helper loaded: link_helper
DEBUG - 2015-02-04 02:30:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 02:30:08 --> CI_Session Class Initialized
DEBUG - 2015-02-04 02:30:08 --> Session: Regenerate ID
DEBUG - 2015-02-04 02:30:08 --> CI_Session routines successfully run
DEBUG - 2015-02-04 02:30:12 --> Model Class Initialized
DEBUG - 2015-02-04 02:30:12 --> Model Class Initialized
DEBUG - 2015-02-04 02:30:13 --> Controller Class Initialized
DEBUG - 2015-02-04 02:30:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 02:30:14 --> Email Class Initialized
DEBUG - 2015-02-04 02:30:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 02:30:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 02:30:15 --> Helper loaded: language_helper
DEBUG - 2015-02-04 02:30:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 02:30:15 --> Model Class Initialized
DEBUG - 2015-02-04 02:30:15 --> Database Driver Class Initialized
DEBUG - 2015-02-04 02:30:15 --> Helper loaded: date_helper
DEBUG - 2015-02-04 02:30:16 --> Helper loaded: form_helper
DEBUG - 2015-02-04 02:30:16 --> Form Validation Class Initialized
DEBUG - 2015-02-04 02:30:17 --> Model Class Initialized
DEBUG - 2015-02-04 02:30:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 02:30:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 02:30:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 02:30:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 02:30:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 02:30:27 --> Final output sent to browser
DEBUG - 2015-02-04 02:30:27 --> Total execution time: 23.2023
DEBUG - 2015-02-04 02:45:29 --> Config Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Hooks Class Initialized
DEBUG - 2015-02-04 02:45:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 02:45:29 --> Utf8 Class Initialized
DEBUG - 2015-02-04 02:45:29 --> URI Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Router Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Output Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Security Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Input Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 02:45:29 --> Language Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Loader Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Helper loaded: url_helper
DEBUG - 2015-02-04 02:45:29 --> Helper loaded: link_helper
DEBUG - 2015-02-04 02:45:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 02:45:29 --> CI_Session Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Session: Regenerate ID
DEBUG - 2015-02-04 02:45:29 --> CI_Session routines successfully run
DEBUG - 2015-02-04 02:45:29 --> Model Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Model Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Controller Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 02:45:29 --> Email Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 02:45:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 02:45:29 --> Helper loaded: language_helper
DEBUG - 2015-02-04 02:45:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 02:45:29 --> Model Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Database Driver Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Helper loaded: date_helper
DEBUG - 2015-02-04 02:45:29 --> Helper loaded: form_helper
DEBUG - 2015-02-04 02:45:29 --> Form Validation Class Initialized
DEBUG - 2015-02-04 02:45:29 --> Model Class Initialized
DEBUG - 2015-02-04 02:45:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 02:45:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 02:45:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 02:45:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 02:45:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 02:45:30 --> Final output sent to browser
DEBUG - 2015-02-04 02:45:30 --> Total execution time: 0.6279
DEBUG - 2015-02-04 03:00:32 --> Config Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Hooks Class Initialized
DEBUG - 2015-02-04 03:00:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 03:00:32 --> Utf8 Class Initialized
DEBUG - 2015-02-04 03:00:32 --> URI Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Router Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Output Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Security Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Input Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 03:00:32 --> Language Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Loader Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Helper loaded: url_helper
DEBUG - 2015-02-04 03:00:32 --> Helper loaded: link_helper
DEBUG - 2015-02-04 03:00:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 03:00:32 --> CI_Session Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Session: Regenerate ID
DEBUG - 2015-02-04 03:00:32 --> CI_Session routines successfully run
DEBUG - 2015-02-04 03:00:32 --> Model Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Model Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Controller Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 03:00:32 --> Email Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 03:00:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 03:00:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 03:00:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 03:00:32 --> Model Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 03:00:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 03:00:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 03:00:32 --> Model Class Initialized
DEBUG - 2015-02-04 03:00:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 03:00:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 03:00:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 03:00:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 03:00:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 03:00:33 --> Final output sent to browser
DEBUG - 2015-02-04 03:00:33 --> Total execution time: 0.3520
DEBUG - 2015-02-04 03:15:34 --> Config Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Hooks Class Initialized
DEBUG - 2015-02-04 03:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 03:15:34 --> Utf8 Class Initialized
DEBUG - 2015-02-04 03:15:34 --> URI Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Router Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Output Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Security Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Input Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 03:15:34 --> Language Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Loader Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Helper loaded: url_helper
DEBUG - 2015-02-04 03:15:34 --> Helper loaded: link_helper
DEBUG - 2015-02-04 03:15:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 03:15:34 --> CI_Session Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Session: Regenerate ID
DEBUG - 2015-02-04 03:15:34 --> CI_Session routines successfully run
DEBUG - 2015-02-04 03:15:34 --> Model Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Model Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Controller Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 03:15:34 --> Email Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 03:15:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 03:15:34 --> Helper loaded: language_helper
DEBUG - 2015-02-04 03:15:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 03:15:34 --> Model Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Database Driver Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Helper loaded: date_helper
DEBUG - 2015-02-04 03:15:34 --> Helper loaded: form_helper
DEBUG - 2015-02-04 03:15:34 --> Form Validation Class Initialized
DEBUG - 2015-02-04 03:15:34 --> Model Class Initialized
DEBUG - 2015-02-04 03:15:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 03:15:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 03:15:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 03:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 03:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 03:15:35 --> Final output sent to browser
DEBUG - 2015-02-04 03:15:35 --> Total execution time: 0.3560
DEBUG - 2015-02-04 03:30:36 --> Config Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Hooks Class Initialized
DEBUG - 2015-02-04 03:30:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 03:30:36 --> Utf8 Class Initialized
DEBUG - 2015-02-04 03:30:36 --> URI Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Router Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Output Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Security Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Input Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 03:30:36 --> Language Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Loader Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Helper loaded: url_helper
DEBUG - 2015-02-04 03:30:36 --> Helper loaded: link_helper
DEBUG - 2015-02-04 03:30:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 03:30:36 --> CI_Session Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Session: Regenerate ID
DEBUG - 2015-02-04 03:30:36 --> CI_Session routines successfully run
DEBUG - 2015-02-04 03:30:36 --> Model Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Model Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Controller Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 03:30:36 --> Email Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 03:30:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 03:30:36 --> Helper loaded: language_helper
DEBUG - 2015-02-04 03:30:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 03:30:36 --> Model Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Database Driver Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Helper loaded: date_helper
DEBUG - 2015-02-04 03:30:36 --> Helper loaded: form_helper
DEBUG - 2015-02-04 03:30:36 --> Form Validation Class Initialized
DEBUG - 2015-02-04 03:30:36 --> Model Class Initialized
DEBUG - 2015-02-04 03:30:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 03:30:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 03:30:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 03:30:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 03:30:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 03:30:37 --> Final output sent to browser
DEBUG - 2015-02-04 03:30:37 --> Total execution time: 0.4400
DEBUG - 2015-02-04 03:45:38 --> Config Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 03:45:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 03:45:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 03:45:38 --> URI Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Router Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Output Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Security Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Input Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 03:45:38 --> Language Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Loader Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 03:45:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 03:45:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 03:45:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Session: Regenerate ID
DEBUG - 2015-02-04 03:45:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 03:45:38 --> Model Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Model Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Controller Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 03:45:38 --> Email Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 03:45:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 03:45:38 --> Helper loaded: language_helper
DEBUG - 2015-02-04 03:45:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 03:45:38 --> Model Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Helper loaded: date_helper
DEBUG - 2015-02-04 03:45:38 --> Helper loaded: form_helper
DEBUG - 2015-02-04 03:45:38 --> Form Validation Class Initialized
DEBUG - 2015-02-04 03:45:38 --> Model Class Initialized
DEBUG - 2015-02-04 03:45:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 03:45:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 03:45:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 03:45:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 03:45:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 03:45:39 --> Final output sent to browser
DEBUG - 2015-02-04 03:45:39 --> Total execution time: 0.3760
DEBUG - 2015-02-04 04:00:40 --> Config Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Hooks Class Initialized
DEBUG - 2015-02-04 04:00:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 04:00:40 --> Utf8 Class Initialized
DEBUG - 2015-02-04 04:00:40 --> URI Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Router Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Output Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Security Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Input Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 04:00:40 --> Language Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Loader Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Helper loaded: url_helper
DEBUG - 2015-02-04 04:00:40 --> Helper loaded: link_helper
DEBUG - 2015-02-04 04:00:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 04:00:40 --> CI_Session Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Session: Regenerate ID
DEBUG - 2015-02-04 04:00:40 --> CI_Session routines successfully run
DEBUG - 2015-02-04 04:00:40 --> Model Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Model Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Controller Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 04:00:40 --> Email Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 04:00:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 04:00:40 --> Helper loaded: language_helper
DEBUG - 2015-02-04 04:00:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 04:00:40 --> Model Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Helper loaded: date_helper
DEBUG - 2015-02-04 04:00:40 --> Helper loaded: form_helper
DEBUG - 2015-02-04 04:00:40 --> Form Validation Class Initialized
DEBUG - 2015-02-04 04:00:40 --> Model Class Initialized
DEBUG - 2015-02-04 04:00:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 04:00:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 04:00:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 04:00:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 04:00:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 04:00:41 --> Final output sent to browser
DEBUG - 2015-02-04 04:00:41 --> Total execution time: 0.3660
DEBUG - 2015-02-04 04:15:42 --> Config Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Hooks Class Initialized
DEBUG - 2015-02-04 04:15:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 04:15:42 --> Utf8 Class Initialized
DEBUG - 2015-02-04 04:15:42 --> URI Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Router Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Output Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Security Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Input Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 04:15:42 --> Language Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Loader Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Helper loaded: url_helper
DEBUG - 2015-02-04 04:15:42 --> Helper loaded: link_helper
DEBUG - 2015-02-04 04:15:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 04:15:42 --> CI_Session Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Session: Regenerate ID
DEBUG - 2015-02-04 04:15:42 --> CI_Session routines successfully run
DEBUG - 2015-02-04 04:15:42 --> Model Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Model Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Controller Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 04:15:42 --> Email Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 04:15:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 04:15:42 --> Helper loaded: language_helper
DEBUG - 2015-02-04 04:15:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 04:15:42 --> Model Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Database Driver Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Helper loaded: date_helper
DEBUG - 2015-02-04 04:15:42 --> Helper loaded: form_helper
DEBUG - 2015-02-04 04:15:42 --> Form Validation Class Initialized
DEBUG - 2015-02-04 04:15:42 --> Model Class Initialized
DEBUG - 2015-02-04 04:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 04:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 04:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 04:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 04:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 04:15:43 --> Final output sent to browser
DEBUG - 2015-02-04 04:15:43 --> Total execution time: 0.3570
DEBUG - 2015-02-04 04:30:44 --> Config Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Hooks Class Initialized
DEBUG - 2015-02-04 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 04:30:44 --> Utf8 Class Initialized
DEBUG - 2015-02-04 04:30:44 --> URI Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Router Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Output Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Security Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Input Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 04:30:44 --> Language Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Loader Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Helper loaded: url_helper
DEBUG - 2015-02-04 04:30:44 --> Helper loaded: link_helper
DEBUG - 2015-02-04 04:30:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 04:30:44 --> CI_Session Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Session: Regenerate ID
DEBUG - 2015-02-04 04:30:44 --> CI_Session routines successfully run
DEBUG - 2015-02-04 04:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Controller Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 04:30:44 --> Email Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 04:30:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 04:30:44 --> Helper loaded: language_helper
DEBUG - 2015-02-04 04:30:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 04:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Database Driver Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Helper loaded: date_helper
DEBUG - 2015-02-04 04:30:44 --> Helper loaded: form_helper
DEBUG - 2015-02-04 04:30:44 --> Form Validation Class Initialized
DEBUG - 2015-02-04 04:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 04:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 04:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 04:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 04:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 04:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 04:30:44 --> Final output sent to browser
DEBUG - 2015-02-04 04:30:44 --> Total execution time: 0.3350
DEBUG - 2015-02-04 04:45:46 --> Config Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Hooks Class Initialized
DEBUG - 2015-02-04 04:45:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 04:45:46 --> Utf8 Class Initialized
DEBUG - 2015-02-04 04:45:46 --> URI Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Router Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Output Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Security Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Input Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 04:45:46 --> Language Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Loader Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Helper loaded: url_helper
DEBUG - 2015-02-04 04:45:46 --> Helper loaded: link_helper
DEBUG - 2015-02-04 04:45:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 04:45:46 --> CI_Session Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Session: Regenerate ID
DEBUG - 2015-02-04 04:45:46 --> CI_Session routines successfully run
DEBUG - 2015-02-04 04:45:46 --> Model Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Model Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Controller Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 04:45:46 --> Email Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 04:45:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 04:45:46 --> Helper loaded: language_helper
DEBUG - 2015-02-04 04:45:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 04:45:46 --> Model Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Database Driver Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Helper loaded: date_helper
DEBUG - 2015-02-04 04:45:46 --> Helper loaded: form_helper
DEBUG - 2015-02-04 04:45:46 --> Form Validation Class Initialized
DEBUG - 2015-02-04 04:45:46 --> Model Class Initialized
DEBUG - 2015-02-04 04:45:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 04:45:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 04:45:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 04:45:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 04:45:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 04:45:46 --> Final output sent to browser
DEBUG - 2015-02-04 04:45:46 --> Total execution time: 0.3400
DEBUG - 2015-02-04 05:00:48 --> Config Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 05:00:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 05:00:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 05:00:48 --> URI Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Router Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Output Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Security Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Input Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 05:00:48 --> Language Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Loader Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Helper loaded: url_helper
DEBUG - 2015-02-04 05:00:48 --> Helper loaded: link_helper
DEBUG - 2015-02-04 05:00:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 05:00:48 --> CI_Session Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Session: Regenerate ID
DEBUG - 2015-02-04 05:00:48 --> CI_Session routines successfully run
DEBUG - 2015-02-04 05:00:48 --> Model Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Model Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Controller Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 05:00:48 --> Email Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 05:00:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 05:00:48 --> Helper loaded: language_helper
DEBUG - 2015-02-04 05:00:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 05:00:48 --> Model Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Helper loaded: date_helper
DEBUG - 2015-02-04 05:00:48 --> Helper loaded: form_helper
DEBUG - 2015-02-04 05:00:48 --> Form Validation Class Initialized
DEBUG - 2015-02-04 05:00:48 --> Model Class Initialized
DEBUG - 2015-02-04 05:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 05:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 05:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 05:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 05:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 05:00:48 --> Final output sent to browser
DEBUG - 2015-02-04 05:00:48 --> Total execution time: 0.3350
DEBUG - 2015-02-04 05:15:50 --> Config Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Hooks Class Initialized
DEBUG - 2015-02-04 05:15:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 05:15:50 --> Utf8 Class Initialized
DEBUG - 2015-02-04 05:15:50 --> URI Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Router Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Output Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Security Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Input Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 05:15:50 --> Language Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Loader Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Helper loaded: url_helper
DEBUG - 2015-02-04 05:15:50 --> Helper loaded: link_helper
DEBUG - 2015-02-04 05:15:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 05:15:50 --> CI_Session Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Session: Regenerate ID
DEBUG - 2015-02-04 05:15:50 --> CI_Session routines successfully run
DEBUG - 2015-02-04 05:15:50 --> Model Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Model Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Controller Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 05:15:50 --> Email Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 05:15:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 05:15:50 --> Helper loaded: language_helper
DEBUG - 2015-02-04 05:15:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 05:15:50 --> Model Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Database Driver Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Helper loaded: date_helper
DEBUG - 2015-02-04 05:15:50 --> Helper loaded: form_helper
DEBUG - 2015-02-04 05:15:50 --> Form Validation Class Initialized
DEBUG - 2015-02-04 05:15:50 --> Model Class Initialized
DEBUG - 2015-02-04 05:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 05:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 05:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 05:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 05:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 05:15:50 --> Final output sent to browser
DEBUG - 2015-02-04 05:15:50 --> Total execution time: 0.3380
DEBUG - 2015-02-04 05:30:52 --> Config Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Hooks Class Initialized
DEBUG - 2015-02-04 05:30:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 05:30:52 --> Utf8 Class Initialized
DEBUG - 2015-02-04 05:30:52 --> URI Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Router Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Output Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Security Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Input Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 05:30:52 --> Language Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Loader Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Helper loaded: url_helper
DEBUG - 2015-02-04 05:30:52 --> Helper loaded: link_helper
DEBUG - 2015-02-04 05:30:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 05:30:52 --> CI_Session Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Session: Regenerate ID
DEBUG - 2015-02-04 05:30:52 --> CI_Session routines successfully run
DEBUG - 2015-02-04 05:30:52 --> Model Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Model Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Controller Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 05:30:52 --> Email Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 05:30:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 05:30:52 --> Helper loaded: language_helper
DEBUG - 2015-02-04 05:30:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 05:30:52 --> Model Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Database Driver Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Helper loaded: date_helper
DEBUG - 2015-02-04 05:30:52 --> Helper loaded: form_helper
DEBUG - 2015-02-04 05:30:52 --> Form Validation Class Initialized
DEBUG - 2015-02-04 05:30:52 --> Model Class Initialized
DEBUG - 2015-02-04 05:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 05:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 05:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 05:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 05:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 05:30:52 --> Final output sent to browser
DEBUG - 2015-02-04 05:30:52 --> Total execution time: 0.3630
DEBUG - 2015-02-04 05:45:54 --> Config Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Hooks Class Initialized
DEBUG - 2015-02-04 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 05:45:54 --> Utf8 Class Initialized
DEBUG - 2015-02-04 05:45:54 --> URI Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Router Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Output Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Security Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Input Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 05:45:54 --> Language Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Loader Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Helper loaded: url_helper
DEBUG - 2015-02-04 05:45:54 --> Helper loaded: link_helper
DEBUG - 2015-02-04 05:45:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 05:45:54 --> CI_Session Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Session: Regenerate ID
DEBUG - 2015-02-04 05:45:54 --> CI_Session routines successfully run
DEBUG - 2015-02-04 05:45:54 --> Model Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Model Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Controller Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 05:45:54 --> Email Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 05:45:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 05:45:54 --> Helper loaded: language_helper
DEBUG - 2015-02-04 05:45:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 05:45:54 --> Model Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Database Driver Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Helper loaded: date_helper
DEBUG - 2015-02-04 05:45:54 --> Helper loaded: form_helper
DEBUG - 2015-02-04 05:45:54 --> Form Validation Class Initialized
DEBUG - 2015-02-04 05:45:54 --> Model Class Initialized
DEBUG - 2015-02-04 05:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 05:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 05:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 05:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 05:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 05:45:54 --> Final output sent to browser
DEBUG - 2015-02-04 05:45:54 --> Total execution time: 0.3880
DEBUG - 2015-02-04 06:00:56 --> Config Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 06:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 06:00:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 06:00:56 --> URI Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Router Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Output Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Security Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Input Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 06:00:56 --> Language Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Loader Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Helper loaded: url_helper
DEBUG - 2015-02-04 06:00:56 --> Helper loaded: link_helper
DEBUG - 2015-02-04 06:00:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 06:00:56 --> CI_Session Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Session: Regenerate ID
DEBUG - 2015-02-04 06:00:56 --> CI_Session routines successfully run
DEBUG - 2015-02-04 06:00:56 --> Model Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Model Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Controller Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 06:00:56 --> Email Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 06:00:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 06:00:56 --> Helper loaded: language_helper
DEBUG - 2015-02-04 06:00:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 06:00:56 --> Model Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Database Driver Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Helper loaded: date_helper
DEBUG - 2015-02-04 06:00:56 --> Helper loaded: form_helper
DEBUG - 2015-02-04 06:00:56 --> Form Validation Class Initialized
DEBUG - 2015-02-04 06:00:56 --> Model Class Initialized
DEBUG - 2015-02-04 06:00:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 06:00:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 06:00:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 06:00:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 06:00:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 06:00:56 --> Final output sent to browser
DEBUG - 2015-02-04 06:00:56 --> Total execution time: 0.3790
DEBUG - 2015-02-04 06:15:58 --> Config Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Hooks Class Initialized
DEBUG - 2015-02-04 06:15:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 06:15:58 --> Utf8 Class Initialized
DEBUG - 2015-02-04 06:15:58 --> URI Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Router Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Output Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Security Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Input Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 06:15:58 --> Language Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Loader Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Helper loaded: url_helper
DEBUG - 2015-02-04 06:15:58 --> Helper loaded: link_helper
DEBUG - 2015-02-04 06:15:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 06:15:58 --> CI_Session Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Session: Regenerate ID
DEBUG - 2015-02-04 06:15:58 --> CI_Session routines successfully run
DEBUG - 2015-02-04 06:15:58 --> Model Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Model Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Controller Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 06:15:58 --> Email Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 06:15:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 06:15:58 --> Helper loaded: language_helper
DEBUG - 2015-02-04 06:15:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 06:15:58 --> Model Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Database Driver Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Helper loaded: date_helper
DEBUG - 2015-02-04 06:15:58 --> Helper loaded: form_helper
DEBUG - 2015-02-04 06:15:58 --> Form Validation Class Initialized
DEBUG - 2015-02-04 06:15:58 --> Model Class Initialized
DEBUG - 2015-02-04 06:15:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 06:15:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 06:15:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 06:15:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 06:15:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 06:15:58 --> Final output sent to browser
DEBUG - 2015-02-04 06:15:58 --> Total execution time: 0.3890
DEBUG - 2015-02-04 06:31:00 --> Config Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 06:31:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 06:31:00 --> URI Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Router Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Output Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Security Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Input Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 06:31:00 --> Language Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Loader Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 06:31:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 06:31:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 06:31:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Session: Regenerate ID
DEBUG - 2015-02-04 06:31:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 06:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Controller Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 06:31:00 --> Email Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 06:31:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 06:31:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 06:31:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 06:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 06:31:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 06:31:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 06:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 06:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 06:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 06:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 06:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 06:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 06:31:00 --> Final output sent to browser
DEBUG - 2015-02-04 06:31:00 --> Total execution time: 0.3670
DEBUG - 2015-02-04 06:46:02 --> Config Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Hooks Class Initialized
DEBUG - 2015-02-04 06:46:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 06:46:02 --> Utf8 Class Initialized
DEBUG - 2015-02-04 06:46:02 --> URI Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Router Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Output Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Security Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Input Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 06:46:02 --> Language Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Loader Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Helper loaded: url_helper
DEBUG - 2015-02-04 06:46:02 --> Helper loaded: link_helper
DEBUG - 2015-02-04 06:46:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 06:46:02 --> CI_Session Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Session: Regenerate ID
DEBUG - 2015-02-04 06:46:02 --> CI_Session routines successfully run
DEBUG - 2015-02-04 06:46:02 --> Model Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Model Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Controller Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 06:46:02 --> Email Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 06:46:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 06:46:02 --> Helper loaded: language_helper
DEBUG - 2015-02-04 06:46:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 06:46:02 --> Model Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Database Driver Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Helper loaded: date_helper
DEBUG - 2015-02-04 06:46:02 --> Helper loaded: form_helper
DEBUG - 2015-02-04 06:46:02 --> Form Validation Class Initialized
DEBUG - 2015-02-04 06:46:02 --> Model Class Initialized
DEBUG - 2015-02-04 06:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 06:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 06:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 06:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 06:46:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 06:46:02 --> Final output sent to browser
DEBUG - 2015-02-04 06:46:02 --> Total execution time: 0.3480
DEBUG - 2015-02-04 07:01:04 --> Config Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 07:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 07:01:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 07:01:04 --> URI Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Router Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Output Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Security Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Input Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 07:01:04 --> Language Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Loader Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Helper loaded: url_helper
DEBUG - 2015-02-04 07:01:04 --> Helper loaded: link_helper
DEBUG - 2015-02-04 07:01:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 07:01:04 --> CI_Session Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Session: Regenerate ID
DEBUG - 2015-02-04 07:01:04 --> CI_Session routines successfully run
DEBUG - 2015-02-04 07:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Controller Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 07:01:04 --> Email Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 07:01:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 07:01:04 --> Helper loaded: language_helper
DEBUG - 2015-02-04 07:01:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 07:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Database Driver Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Helper loaded: date_helper
DEBUG - 2015-02-04 07:01:04 --> Helper loaded: form_helper
DEBUG - 2015-02-04 07:01:04 --> Form Validation Class Initialized
DEBUG - 2015-02-04 07:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 07:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 07:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 07:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 07:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 07:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 07:01:04 --> Final output sent to browser
DEBUG - 2015-02-04 07:01:04 --> Total execution time: 0.3360
DEBUG - 2015-02-04 07:16:06 --> Config Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Hooks Class Initialized
DEBUG - 2015-02-04 07:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 07:16:06 --> Utf8 Class Initialized
DEBUG - 2015-02-04 07:16:06 --> URI Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Router Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Output Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Security Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Input Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 07:16:06 --> Language Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Loader Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Helper loaded: url_helper
DEBUG - 2015-02-04 07:16:06 --> Helper loaded: link_helper
DEBUG - 2015-02-04 07:16:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 07:16:06 --> CI_Session Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Session: Regenerate ID
DEBUG - 2015-02-04 07:16:06 --> CI_Session routines successfully run
DEBUG - 2015-02-04 07:16:06 --> Model Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Model Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Controller Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 07:16:06 --> Email Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 07:16:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 07:16:06 --> Helper loaded: language_helper
DEBUG - 2015-02-04 07:16:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 07:16:06 --> Model Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Database Driver Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Helper loaded: date_helper
DEBUG - 2015-02-04 07:16:06 --> Helper loaded: form_helper
DEBUG - 2015-02-04 07:16:06 --> Form Validation Class Initialized
DEBUG - 2015-02-04 07:16:06 --> Model Class Initialized
DEBUG - 2015-02-04 07:16:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 07:16:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 07:16:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 07:16:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 07:16:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 07:16:06 --> Final output sent to browser
DEBUG - 2015-02-04 07:16:06 --> Total execution time: 0.3348
DEBUG - 2015-02-04 07:31:07 --> Config Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Hooks Class Initialized
DEBUG - 2015-02-04 07:31:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 07:31:07 --> Utf8 Class Initialized
DEBUG - 2015-02-04 07:31:07 --> URI Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Router Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Output Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Security Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Input Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 07:31:07 --> Language Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Loader Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Helper loaded: url_helper
DEBUG - 2015-02-04 07:31:07 --> Helper loaded: link_helper
DEBUG - 2015-02-04 07:31:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 07:31:07 --> CI_Session Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Session: Regenerate ID
DEBUG - 2015-02-04 07:31:07 --> CI_Session routines successfully run
DEBUG - 2015-02-04 07:31:07 --> Model Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Model Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Controller Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 07:31:07 --> Email Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 07:31:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 07:31:07 --> Helper loaded: language_helper
DEBUG - 2015-02-04 07:31:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 07:31:07 --> Model Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Database Driver Class Initialized
DEBUG - 2015-02-04 07:31:07 --> Helper loaded: date_helper
DEBUG - 2015-02-04 07:31:08 --> Helper loaded: form_helper
DEBUG - 2015-02-04 07:31:08 --> Form Validation Class Initialized
DEBUG - 2015-02-04 07:31:08 --> Model Class Initialized
DEBUG - 2015-02-04 07:31:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 07:31:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 07:31:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 07:31:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 07:31:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 07:31:08 --> Final output sent to browser
DEBUG - 2015-02-04 07:31:08 --> Total execution time: 0.3440
DEBUG - 2015-02-04 07:46:09 --> Config Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Hooks Class Initialized
DEBUG - 2015-02-04 07:46:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 07:46:09 --> Utf8 Class Initialized
DEBUG - 2015-02-04 07:46:09 --> URI Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Router Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Output Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Security Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Input Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 07:46:09 --> Language Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Loader Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Helper loaded: url_helper
DEBUG - 2015-02-04 07:46:09 --> Helper loaded: link_helper
DEBUG - 2015-02-04 07:46:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 07:46:09 --> CI_Session Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Session: Regenerate ID
DEBUG - 2015-02-04 07:46:09 --> CI_Session routines successfully run
DEBUG - 2015-02-04 07:46:09 --> Model Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Model Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Controller Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 07:46:09 --> Email Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 07:46:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 07:46:09 --> Helper loaded: language_helper
DEBUG - 2015-02-04 07:46:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 07:46:09 --> Model Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Database Driver Class Initialized
DEBUG - 2015-02-04 07:46:09 --> Helper loaded: date_helper
DEBUG - 2015-02-04 07:46:10 --> Helper loaded: form_helper
DEBUG - 2015-02-04 07:46:10 --> Form Validation Class Initialized
DEBUG - 2015-02-04 07:46:10 --> Model Class Initialized
DEBUG - 2015-02-04 07:46:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 07:46:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 07:46:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 07:46:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 07:46:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 07:46:10 --> Final output sent to browser
DEBUG - 2015-02-04 07:46:10 --> Total execution time: 0.3630
DEBUG - 2015-02-04 08:01:11 --> Config Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:01:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:01:11 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:01:11 --> URI Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Router Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Output Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Security Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Input Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:01:11 --> Language Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Loader Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:01:11 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:01:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:01:11 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Session: Regenerate ID
DEBUG - 2015-02-04 08:01:11 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:01:11 --> Model Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Model Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Controller Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:01:11 --> Email Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:01:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:01:11 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:01:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:01:11 --> Model Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:01:11 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:01:11 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:01:11 --> Model Class Initialized
DEBUG - 2015-02-04 08:01:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:01:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:01:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 08:01:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:01:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 08:01:12 --> Final output sent to browser
DEBUG - 2015-02-04 08:01:12 --> Total execution time: 0.3580
DEBUG - 2015-02-04 08:09:45 --> Config Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:09:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:09:45 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:09:45 --> URI Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Router Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Output Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Security Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Input Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:09:45 --> Language Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Loader Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:09:45 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:09:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:09:45 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Session: Regenerate ID
DEBUG - 2015-02-04 08:09:45 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:09:45 --> Model Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Model Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Controller Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:09:45 --> Email Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:09:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:09:45 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:09:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:09:45 --> Model Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:09:45 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:09:46 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:09:46 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:09:46 --> Model Class Initialized
DEBUG - 2015-02-04 08:09:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:09:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:09:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 08:24:38 --> Config Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:24:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:24:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:24:38 --> URI Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Router Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Output Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Security Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Input Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:24:38 --> Language Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Loader Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:24:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:24:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:24:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Session: Regenerate ID
DEBUG - 2015-02-04 08:24:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:24:38 --> Model Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Model Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Controller Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:24:38 --> Email Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:24:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:24:38 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:24:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:24:38 --> Model Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:24:38 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:24:38 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Model Class Initialized
DEBUG - 2015-02-04 08:24:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:24:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:24:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 08:24:38 --> Upload Class Initialized
DEBUG - 2015-02-04 08:24:38 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-02-04 08:24:38 --> The upload path does not appear to be valid.
ERROR - 2015-02-04 08:24:39 --> Severity: Notice --> Undefined index: Trang Giới Thiệu D:\phutx\project\ups\myblog\application\models\Article_model.php 99
ERROR - 2015-02-04 08:24:39 --> Severity: Notice --> Undefined index: Thời trang D:\phutx\project\ups\myblog\application\models\Article_model.php 99
ERROR - 2015-02-04 08:24:39 --> Severity: Notice --> Undefined index: Xã hội D:\phutx\project\ups\myblog\application\models\Article_model.php 99
ERROR - 2015-02-04 08:24:39 --> Severity: Notice --> Undefined index: Công nghệ D:\phutx\project\ups\myblog\application\models\Article_model.php 99
ERROR - 2015-02-04 08:24:39 --> Severity: Notice --> Undefined index: Vui choi D:\phutx\project\ups\myblog\application\models\Article_model.php 115
ERROR - 2015-02-04 08:24:39 --> Severity: Notice --> Undefined index: Giai tri D:\phutx\project\ups\myblog\application\models\Article_model.php 115
ERROR - 2015-02-04 08:24:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\system\core\Exceptions.php:272) D:\phutx\project\ups\myblog\system\libraries\Session\drivers\Session_cookie.php 781
ERROR - 2015-02-04 08:24:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\system\core\Exceptions.php:272) D:\phutx\project\ups\myblog\system\helpers\url_helper.php 564
DEBUG - 2015-02-04 08:25:30 --> Config Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:25:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:25:30 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:25:30 --> URI Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Router Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Output Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Security Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Input Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:25:30 --> Language Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Loader Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:25:30 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:25:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:25:30 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:25:30 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:25:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Controller Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:25:30 --> Email Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:25:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:25:30 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:25:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:25:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:25:30 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:25:30 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:25:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:25:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-04 08:25:30 --> Upload Class Initialized
DEBUG - 2015-02-04 08:25:30 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-02-04 08:25:30 --> The upload path does not appear to be valid.
DEBUG - 2015-02-04 08:25:31 --> Config Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:25:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:25:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:25:31 --> URI Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Router Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Output Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Security Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Input Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:25:31 --> Language Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Loader Class Initialized
DEBUG - 2015-02-04 08:25:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:25:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:25:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:25:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:25:32 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:25:32 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:32 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:32 --> Controller Class Initialized
DEBUG - 2015-02-04 08:25:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:25:32 --> Email Class Initialized
DEBUG - 2015-02-04 08:25:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:25:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:25:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:25:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:25:32 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:25:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:25:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:25:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:25:32 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:25:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:25:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 08:25:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:25:32 --> Final output sent to browser
DEBUG - 2015-02-04 08:25:32 --> Total execution time: 0.8391
DEBUG - 2015-02-04 08:25:40 --> Config Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:25:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:25:40 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:25:40 --> URI Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Router Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Output Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Security Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Input Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:25:40 --> Language Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Loader Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:25:40 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:25:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:25:40 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:25:40 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:25:40 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Controller Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:25:40 --> Email Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:25:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:25:40 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:25:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:25:40 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:25:40 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:25:40 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:25:40 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Config Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:25:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:25:41 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:25:41 --> URI Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Router Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Output Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Security Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Input Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:25:41 --> Language Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Loader Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:25:41 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:25:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:25:41 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:25:41 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:25:41 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Controller Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:25:41 --> Email Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:25:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:25:41 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:25:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:25:41 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:25:41 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:25:41 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:25:41 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:25:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:25:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 08:25:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:25:41 --> Final output sent to browser
DEBUG - 2015-02-04 08:25:41 --> Total execution time: 0.6601
DEBUG - 2015-02-04 08:25:53 --> Config Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:25:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:25:53 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:25:53 --> URI Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Router Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Output Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Security Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Input Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:25:53 --> Language Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Loader Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:25:53 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:25:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:25:53 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:25:53 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:25:53 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Controller Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:25:53 --> Email Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:25:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:25:53 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:25:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:25:53 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:25:53 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:25:53 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:25:53 --> Model Class Initialized
DEBUG - 2015-02-04 08:25:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:25:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 08:25:54 --> Severity: Notice --> Undefined variable: category D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 6
ERROR - 2015-02-04 08:25:54 --> Severity: Error --> Call to a member function getName() on a non-object D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 6
DEBUG - 2015-02-04 08:27:02 --> Config Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:27:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:27:02 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:27:02 --> URI Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Router Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Output Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Security Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Input Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:27:02 --> Language Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Loader Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:27:02 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:27:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:27:02 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:27:02 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:27:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Controller Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:27:02 --> Email Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:27:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:27:02 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:27:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:27:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:27:02 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:27:02 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:27:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:27:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:27:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:27:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 08:27:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:27:03 --> Final output sent to browser
DEBUG - 2015-02-04 08:27:03 --> Total execution time: 0.6171
DEBUG - 2015-02-04 08:32:15 --> Config Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:32:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:32:15 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:32:15 --> URI Class Initialized
DEBUG - 2015-02-04 08:32:15 --> No URI present. Default controller set.
DEBUG - 2015-02-04 08:32:15 --> Router Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Output Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Security Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Input Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:32:15 --> Language Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Loader Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:32:15 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:32:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:32:15 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:32:15 --> Session: Regenerate ID
DEBUG - 2015-02-04 08:32:15 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:32:16 --> Model Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Model Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Controller Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:32:16 --> Email Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:32:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:32:16 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:32:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:32:16 --> Model Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:32:16 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:32:16 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Model Class Initialized
DEBUG - 2015-02-04 08:32:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 08:32:16 --> Pagination Class Initialized
DEBUG - 2015-02-04 08:32:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 08:32:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 08:32:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 08:32:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 08:32:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 08:32:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 08:32:17 --> Final output sent to browser
DEBUG - 2015-02-04 08:32:17 --> Total execution time: 1.2771
DEBUG - 2015-02-04 08:42:01 --> Config Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:42:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:42:01 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:42:01 --> URI Class Initialized
DEBUG - 2015-02-04 08:42:01 --> No URI present. Default controller set.
DEBUG - 2015-02-04 08:42:01 --> Router Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Output Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Security Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Input Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:42:01 --> Language Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Loader Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:42:01 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:42:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:42:01 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:42:01 --> Session: Regenerate ID
DEBUG - 2015-02-04 08:42:01 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:42:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Controller Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:42:02 --> Email Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:42:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:42:02 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:42:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:42:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:42:02 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:42:02 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 08:42:02 --> Pagination Class Initialized
DEBUG - 2015-02-04 08:42:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 08:42:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 08:42:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 08:42:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 08:42:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 08:42:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 08:42:02 --> Final output sent to browser
DEBUG - 2015-02-04 08:42:02 --> Total execution time: 0.8091
DEBUG - 2015-02-04 08:42:04 --> Config Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:42:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:42:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:42:04 --> URI Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Router Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Output Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Security Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Input Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:42:04 --> Language Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Loader Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:42:04 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:42:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:42:04 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:42:04 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:42:04 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Controller Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:42:04 --> Email Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:42:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:42:04 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:42:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:42:04 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:42:04 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:42:04 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:42:04 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:42:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:42:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 08:42:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:42:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 08:42:05 --> Final output sent to browser
DEBUG - 2015-02-04 08:42:05 --> Total execution time: 0.8681
DEBUG - 2015-02-04 08:42:05 --> Config Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:42:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:42:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:42:05 --> URI Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Router Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Output Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Security Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Input Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:42:05 --> Language Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Loader Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:42:05 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:42:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:42:05 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:42:05 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:42:05 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Controller Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:42:05 --> Email Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:42:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:42:05 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:42:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:42:05 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:42:05 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:42:05 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:42:05 --> Model Class Initialized
DEBUG - 2015-02-04 08:42:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 08:42:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-04 08:42:06 --> Severity: Error --> Call to a member function getFileName() on a non-object D:\phutx\project\ups\myblog\application\views\article\index.php 22
DEBUG - 2015-02-04 08:42:07 --> Config Class Initialized
DEBUG - 2015-02-04 08:42:07 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:42:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:42:07 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Config Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:43:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:43:01 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:43:01 --> URI Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Router Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Output Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Security Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Input Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:43:01 --> Language Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Loader Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:43:01 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:43:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:43:01 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:43:01 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:43:01 --> Model Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Model Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Controller Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:43:01 --> Email Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:43:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:43:01 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:43:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:43:01 --> Model Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:43:01 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:43:01 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:43:01 --> Model Class Initialized
DEBUG - 2015-02-04 08:43:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 08:43:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 08:43:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 08:43:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 08:43:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 08:43:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 08:43:02 --> Final output sent to browser
DEBUG - 2015-02-04 08:43:02 --> Total execution time: 0.9961
DEBUG - 2015-02-04 08:44:19 --> Config Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:44:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:44:19 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:44:19 --> URI Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Router Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Output Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Security Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Input Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:44:19 --> Language Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Loader Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:44:19 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:44:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:44:19 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:44:19 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:44:19 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Controller Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:44:19 --> Email Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:44:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:44:19 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:44:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:44:19 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:44:19 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:44:19 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:44:19 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:44:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:44:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-04 08:44:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:44:20 --> Final output sent to browser
DEBUG - 2015-02-04 08:44:20 --> Total execution time: 0.4850
DEBUG - 2015-02-04 08:44:27 --> Config Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:44:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:44:27 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:44:27 --> URI Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Router Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Output Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Security Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Input Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:44:27 --> Language Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Loader Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:44:27 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:44:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:44:27 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:44:27 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:44:27 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Controller Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:44:27 --> Email Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:44:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:44:27 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:44:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:44:27 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:44:27 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:44:27 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:44:27 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:44:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:44:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 08:44:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:44:27 --> Final output sent to browser
DEBUG - 2015-02-04 08:44:27 --> Total execution time: 0.7181
DEBUG - 2015-02-04 08:44:30 --> Config Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:44:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:44:30 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:44:30 --> URI Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Router Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Output Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Security Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Input Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:44:30 --> Language Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Loader Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:44:30 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:44:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:44:30 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:44:30 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:44:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Controller Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:44:30 --> Email Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:44:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:44:30 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:44:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:44:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:44:30 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:44:30 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:44:30 --> Model Class Initialized
DEBUG - 2015-02-04 08:44:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:44:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:44:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 08:44:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:44:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 08:44:31 --> Final output sent to browser
DEBUG - 2015-02-04 08:44:31 --> Total execution time: 0.7681
DEBUG - 2015-02-04 08:54:37 --> Config Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:54:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:54:37 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:54:37 --> URI Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Router Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Output Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Security Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Input Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:54:37 --> Language Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Loader Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:54:37 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:54:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:54:37 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Session: Regenerate ID
DEBUG - 2015-02-04 08:54:37 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:54:37 --> Model Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Model Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Controller Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:54:37 --> Email Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:54:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:54:37 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:54:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:54:37 --> Model Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:54:37 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:54:37 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:54:37 --> Model Class Initialized
DEBUG - 2015-02-04 08:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 08:54:38 --> Severity: Error --> Call to undefined method Entity\Articles::getSource() D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 21
DEBUG - 2015-02-04 08:55:21 --> Config Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:55:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:55:21 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:55:21 --> URI Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Router Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Output Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Security Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Input Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:55:21 --> Language Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Loader Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:55:21 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:55:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:55:21 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:55:21 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:55:21 --> Model Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Model Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Controller Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:55:21 --> Email Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:55:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:55:21 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:55:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:55:21 --> Model Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:55:21 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:55:21 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:55:21 --> Model Class Initialized
DEBUG - 2015-02-04 08:55:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:55:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:55:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 08:55:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:55:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 08:55:21 --> Final output sent to browser
DEBUG - 2015-02-04 08:55:21 --> Total execution time: 0.7161
DEBUG - 2015-02-04 08:57:06 --> Config Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Hooks Class Initialized
DEBUG - 2015-02-04 08:57:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 08:57:06 --> Utf8 Class Initialized
DEBUG - 2015-02-04 08:57:06 --> URI Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Router Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Output Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Security Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Input Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 08:57:06 --> Language Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Loader Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Helper loaded: url_helper
DEBUG - 2015-02-04 08:57:06 --> Helper loaded: link_helper
DEBUG - 2015-02-04 08:57:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 08:57:06 --> CI_Session Class Initialized
DEBUG - 2015-02-04 08:57:06 --> CI_Session routines successfully run
DEBUG - 2015-02-04 08:57:06 --> Model Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Model Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Controller Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 08:57:06 --> Email Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 08:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 08:57:06 --> Helper loaded: language_helper
DEBUG - 2015-02-04 08:57:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 08:57:06 --> Model Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Database Driver Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Helper loaded: date_helper
DEBUG - 2015-02-04 08:57:06 --> Helper loaded: form_helper
DEBUG - 2015-02-04 08:57:06 --> Form Validation Class Initialized
DEBUG - 2015-02-04 08:57:06 --> Model Class Initialized
DEBUG - 2015-02-04 08:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 08:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 08:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 08:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 08:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 08:57:06 --> Final output sent to browser
DEBUG - 2015-02-04 08:57:06 --> Total execution time: 0.7331
DEBUG - 2015-02-04 09:05:36 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:36 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:36 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:36 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:05:36 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:05:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:05:36 --> CI_Session Class Initialized
ERROR - 2015-02-04 09:05:36 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-04 09:05:36 --> Session: Creating new session (a7200d9e0af95c8483ce26501a2599fa)
DEBUG - 2015-02-04 09:05:36 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:05:36 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Controller Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:05:36 --> Email Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:05:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:05:36 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:05:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:36 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:05:36 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:05:36 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:05:36 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:40 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:40 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:40 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:05:40 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:05:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:05:40 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:05:40 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:05:40 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Controller Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:05:40 --> Email Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:05:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:05:40 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:05:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:40 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:05:40 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:05:40 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:05:40 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:43 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:43 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:43 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:05:43 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:05:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:05:43 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:05:43 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:05:43 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Controller Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:05:43 --> Email Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:05:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:05:43 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:05:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:43 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:05:43 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:05:43 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:05:43 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:45 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:45 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:45 --> No URI present. Default controller set.
DEBUG - 2015-02-04 09:05:45 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:45 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:45 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:05:45 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:05:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:05:45 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:05:45 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:05:46 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Controller Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:05:46 --> Email Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:05:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:05:46 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:05:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:46 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:05:46 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:05:46 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 09:05:46 --> Pagination Class Initialized
DEBUG - 2015-02-04 09:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 09:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 09:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 09:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 09:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 09:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 09:05:46 --> Final output sent to browser
DEBUG - 2015-02-04 09:05:46 --> Total execution time: 0.6791
DEBUG - 2015-02-04 09:05:48 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:48 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:48 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:05:48 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:05:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:05:48 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:05:48 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:05:48 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Controller Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:05:48 --> Email Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:05:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:05:48 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:05:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:48 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:05:48 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:05:48 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:05:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-04 09:05:48 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-04 09:05:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 09:05:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 09:05:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-04 09:05:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 09:05:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 09:05:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 09:05:48 --> Final output sent to browser
DEBUG - 2015-02-04 09:05:48 --> Total execution time: 0.2490
DEBUG - 2015-02-04 09:05:57 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:57 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:57 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:57 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:05:57 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:05:57 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:05:57 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Controller Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:05:57 --> Email Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:05:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:57 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:05:57 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-04 09:05:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-04 09:05:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-04 09:05:57 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:57 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:57 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:57 --> No URI present. Default controller set.
DEBUG - 2015-02-04 09:05:57 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:57 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:05:57 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:05:57 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:05:57 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Controller Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:05:57 --> Email Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:05:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:05:57 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:05:57 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:05:57 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Model Class Initialized
DEBUG - 2015-02-04 09:05:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 09:05:57 --> Pagination Class Initialized
DEBUG - 2015-02-04 09:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 09:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 09:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 09:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 09:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 09:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 09:05:58 --> Final output sent to browser
DEBUG - 2015-02-04 09:05:58 --> Total execution time: 0.6671
DEBUG - 2015-02-04 09:05:59 --> Config Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:05:59 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:05:59 --> URI Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Router Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Output Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Security Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Input Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:05:59 --> Language Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Loader Class Initialized
DEBUG - 2015-02-04 09:05:59 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:06:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:06:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:06:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:06:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:06:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:00 --> Controller Class Initialized
DEBUG - 2015-02-04 09:06:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:06:00 --> Email Class Initialized
DEBUG - 2015-02-04 09:06:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:06:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:06:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:06:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:06:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:06:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:06:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:06:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:06:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:06:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:06:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-04 09:06:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:06:00 --> Final output sent to browser
DEBUG - 2015-02-04 09:06:00 --> Total execution time: 0.3120
DEBUG - 2015-02-04 09:06:03 --> Config Class Initialized
DEBUG - 2015-02-04 09:06:03 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:06:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:06:03 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:06:07 --> Config Class Initialized
DEBUG - 2015-02-04 09:06:07 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:06:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:06:07 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:06:07 --> URI Class Initialized
DEBUG - 2015-02-04 09:06:07 --> Router Class Initialized
DEBUG - 2015-02-04 09:06:07 --> Output Class Initialized
DEBUG - 2015-02-04 09:06:07 --> Security Class Initialized
DEBUG - 2015-02-04 09:06:07 --> Input Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:06:08 --> Language Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Loader Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:06:08 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:06:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:06:08 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:06:08 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:06:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Controller Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:06:08 --> Email Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:06:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:06:08 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:06:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:06:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:06:08 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:06:08 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:06:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:06:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:06:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 09:06:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:06:08 --> Final output sent to browser
DEBUG - 2015-02-04 09:06:08 --> Total execution time: 0.6671
DEBUG - 2015-02-04 09:06:12 --> Config Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:06:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:06:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:06:12 --> URI Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Router Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Output Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Security Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Input Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:06:12 --> Language Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Loader Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:06:12 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:06:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:06:12 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:06:12 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:06:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Controller Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:06:12 --> Email Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:06:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:06:12 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:06:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:06:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:06:12 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:06:12 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:06:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:06:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:06:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:06:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:06:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:06:12 --> Final output sent to browser
DEBUG - 2015-02-04 09:06:12 --> Total execution time: 0.7161
DEBUG - 2015-02-04 09:06:19 --> Config Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:06:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:06:19 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:06:19 --> URI Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Router Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Output Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Security Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Input Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:06:19 --> Language Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Loader Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:06:19 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:06:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:06:19 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:06:19 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:06:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Controller Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:06:19 --> Email Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:06:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:06:19 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:06:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:06:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:06:19 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:06:19 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:06:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:06:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:06:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:06:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:06:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:06:20 --> Final output sent to browser
DEBUG - 2015-02-04 09:06:20 --> Total execution time: 0.7271
DEBUG - 2015-02-04 09:06:48 --> Config Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:06:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:06:49 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:06:49 --> URI Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Router Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Output Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Security Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Input Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:06:49 --> Language Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Loader Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:06:49 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:06:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:06:49 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:06:49 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:06:49 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Controller Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:06:49 --> Email Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:06:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:06:49 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:06:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:06:49 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:06:49 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:06:49 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:06:49 --> Model Class Initialized
DEBUG - 2015-02-04 09:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:06:49 --> Final output sent to browser
DEBUG - 2015-02-04 09:06:49 --> Total execution time: 0.7091
DEBUG - 2015-02-04 09:08:52 --> Config Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:08:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:08:52 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:08:52 --> URI Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Router Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Output Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Security Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Input Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:08:52 --> Language Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Loader Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:08:52 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:08:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:08:52 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:08:52 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:08:52 --> Model Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Model Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Controller Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:08:52 --> Email Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:08:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:08:52 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:08:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:08:52 --> Model Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:08:52 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:08:52 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:08:52 --> Model Class Initialized
DEBUG - 2015-02-04 09:08:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:08:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:08:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:08:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:08:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:08:52 --> Final output sent to browser
DEBUG - 2015-02-04 09:08:52 --> Total execution time: 0.7631
DEBUG - 2015-02-04 09:09:48 --> Config Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:09:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:09:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:09:48 --> URI Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Router Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Output Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Security Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Input Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:09:48 --> Language Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Loader Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:09:48 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:09:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:09:48 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:09:48 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:09:48 --> Model Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Model Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Controller Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:09:48 --> Email Class Initialized
DEBUG - 2015-02-04 09:09:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:09:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:09:48 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:09:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:09:49 --> Model Class Initialized
DEBUG - 2015-02-04 09:09:49 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:09:49 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:09:49 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:09:49 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:09:49 --> Model Class Initialized
DEBUG - 2015-02-04 09:09:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:09:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:09:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:09:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:09:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:09:49 --> Final output sent to browser
DEBUG - 2015-02-04 09:09:49 --> Total execution time: 0.7121
DEBUG - 2015-02-04 09:10:23 --> Config Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:10:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:10:23 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:10:23 --> URI Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Router Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Output Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Security Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Input Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:10:23 --> Language Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Loader Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:10:23 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:10:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:10:23 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:10:23 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:10:23 --> Model Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Model Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Controller Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:10:23 --> Email Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:10:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:10:23 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:10:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:10:23 --> Model Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:10:23 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:10:23 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:10:23 --> Model Class Initialized
DEBUG - 2015-02-04 09:10:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:10:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:10:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:10:24 --> Final output sent to browser
DEBUG - 2015-02-04 09:10:24 --> Total execution time: 0.7191
DEBUG - 2015-02-04 09:12:07 --> Config Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:12:07 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:12:07 --> URI Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Router Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Output Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Security Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Input Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:12:07 --> Language Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Loader Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:12:07 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:12:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:12:07 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:12:07 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:12:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Controller Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:12:07 --> Email Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:12:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:12:07 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:12:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:12:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:12:07 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:12:07 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:12:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:12:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:12:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:12:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:12:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:12:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:12:08 --> Final output sent to browser
DEBUG - 2015-02-04 09:12:08 --> Total execution time: 0.6721
DEBUG - 2015-02-04 09:14:31 --> Config Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:14:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:14:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:14:31 --> URI Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Router Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Output Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Security Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Input Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:14:31 --> Language Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Loader Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:14:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:14:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:14:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:14:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:14:31 --> Model Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Model Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Controller Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:14:31 --> Email Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:14:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:14:31 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:14:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:14:31 --> Model Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:14:31 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:14:31 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:14:31 --> Model Class Initialized
DEBUG - 2015-02-04 09:14:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:14:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:14:31 --> Severity: error --> Exception: OneToMany mapping on field 'categories' requires the 'mappedBy' attribute. D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Mapping\MappingException.php 150
DEBUG - 2015-02-04 09:16:13 --> Config Class Initialized
DEBUG - 2015-02-04 09:16:13 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:16:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:16:13 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:16:14 --> URI Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Router Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Output Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Security Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Input Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:16:14 --> Language Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Loader Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:16:14 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:16:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:16:14 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:16:14 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:16:14 --> Model Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Model Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Controller Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:16:14 --> Email Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:16:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:16:14 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:16:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:16:14 --> Model Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:16:14 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:16:14 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:16:14 --> Model Class Initialized
DEBUG - 2015-02-04 09:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:16:14 --> Severity: error --> Exception: The target-entity Entity\article cannot be found in 'Entity\Articles#categories'. D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Mapping\MappingException.php 428
DEBUG - 2015-02-04 09:17:04 --> Config Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:17:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:17:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:17:04 --> URI Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Router Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Output Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Security Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Input Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:17:04 --> Language Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Loader Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:17:04 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:17:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:17:04 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:17:04 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:17:04 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Controller Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:17:04 --> Email Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:17:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:17:04 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:17:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:17:04 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:17:04 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:17:04 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:17:04 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:17:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:17:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:17:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:17:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:17:05 --> Final output sent to browser
DEBUG - 2015-02-04 09:17:05 --> Total execution time: 1.1301
DEBUG - 2015-02-04 09:17:35 --> Config Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:17:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:17:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:17:35 --> URI Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Router Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Output Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Security Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Input Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:17:35 --> Language Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Loader Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:17:35 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:17:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:17:35 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:17:35 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Controller Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:17:35 --> Email Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:17:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:17:35 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:17:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:17:35 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:17:35 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:17:36 --> Final output sent to browser
DEBUG - 2015-02-04 09:17:36 --> Total execution time: 0.9781
DEBUG - 2015-02-04 09:19:00 --> Config Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:19:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:19:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:19:00 --> URI Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Router Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Output Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Security Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Input Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:19:00 --> Language Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Loader Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:19:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:19:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:19:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:19:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:19:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Controller Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:19:00 --> Email Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:19:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:19:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:19:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:19:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:19:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:19:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:19:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:19:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:19:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:19:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:19:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:19:01 --> Final output sent to browser
DEBUG - 2015-02-04 09:19:01 --> Total execution time: 1.0401
DEBUG - 2015-02-04 09:19:52 --> Config Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:19:52 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:19:52 --> URI Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Router Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Output Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Security Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Input Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:19:52 --> Language Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Loader Class Initialized
DEBUG - 2015-02-04 09:19:52 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:19:52 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:19:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:19:52 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:19:52 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:19:53 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:53 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:53 --> Controller Class Initialized
DEBUG - 2015-02-04 09:19:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:19:53 --> Email Class Initialized
DEBUG - 2015-02-04 09:19:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:19:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:19:53 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:19:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:19:53 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:53 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:19:53 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:19:53 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:19:53 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:19:53 --> Model Class Initialized
DEBUG - 2015-02-04 09:19:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:19:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:19:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 09:19:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:19:53 --> Final output sent to browser
DEBUG - 2015-02-04 09:19:53 --> Total execution time: 0.7741
DEBUG - 2015-02-04 09:20:00 --> Config Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:20:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:20:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:20:00 --> URI Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Router Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Output Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Security Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Input Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:20:00 --> Language Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Loader Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:20:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:20:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:20:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:20:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:20:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Controller Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:20:00 --> Email Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:20:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:20:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:20:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:20:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:20:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:20:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:20:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:20:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:20:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:20:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:20:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:20:01 --> Final output sent to browser
DEBUG - 2015-02-04 09:20:01 --> Total execution time: 0.9811
DEBUG - 2015-02-04 09:20:34 --> Config Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:20:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:20:34 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:20:34 --> URI Class Initialized
DEBUG - 2015-02-04 09:20:34 --> No URI present. Default controller set.
DEBUG - 2015-02-04 09:20:34 --> Router Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Output Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Security Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Input Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:20:34 --> Language Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Loader Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:20:34 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:20:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:20:34 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:20:34 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Controller Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:20:34 --> Email Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:20:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:20:34 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:20:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:20:34 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:20:34 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 09:20:34 --> Pagination Class Initialized
DEBUG - 2015-02-04 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 09:20:35 --> Final output sent to browser
DEBUG - 2015-02-04 09:20:35 --> Total execution time: 0.7881
DEBUG - 2015-02-04 09:20:38 --> Config Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:20:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:20:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:20:38 --> URI Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Router Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Output Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Security Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Input Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:20:38 --> Language Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Loader Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:20:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:20:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:20:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:20:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:20:38 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Controller Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:20:38 --> Email Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:20:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:20:38 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:20:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:20:38 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:20:38 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:20:38 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:20:38 --> Model Class Initialized
DEBUG - 2015-02-04 09:20:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 09:20:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 09:20:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 09:20:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 09:20:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 09:20:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 09:20:39 --> Final output sent to browser
DEBUG - 2015-02-04 09:20:39 --> Total execution time: 0.9211
DEBUG - 2015-02-04 09:25:02 --> Config Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:25:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:25:02 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:25:02 --> URI Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Router Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Output Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Security Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Input Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:25:02 --> Language Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Loader Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:25:02 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:25:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:25:02 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:25:02 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:25:02 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Controller Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:25:02 --> Email Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:25:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:25:02 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:25:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:25:02 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:25:02 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:25:02 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:25:02 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:25:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:25:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:25:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:25:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:25:03 --> Final output sent to browser
DEBUG - 2015-02-04 09:25:03 --> Total execution time: 1.0121
DEBUG - 2015-02-04 09:25:33 --> Config Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:25:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:25:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:25:33 --> URI Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Router Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Output Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Security Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Input Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:25:33 --> Language Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Loader Class Initialized
DEBUG - 2015-02-04 09:25:33 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:25:33 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:25:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:25:33 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:25:33 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:25:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:34 --> Controller Class Initialized
DEBUG - 2015-02-04 09:25:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:25:34 --> Email Class Initialized
DEBUG - 2015-02-04 09:25:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:25:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:25:34 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:25:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:25:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:34 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:25:34 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:25:34 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:25:34 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:25:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:25:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:25:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:25:34 --> Severity: Error --> Call to undefined method Doctrine\ORM\PersistentCollection::getCategory() D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 2
DEBUG - 2015-02-04 09:26:22 --> Config Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:26:22 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:26:22 --> URI Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Router Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Output Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Security Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Input Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:26:22 --> Language Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Loader Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:26:22 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:26:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:26:22 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:26:22 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:26:22 --> Model Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Model Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Controller Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:26:22 --> Email Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:26:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:26:22 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:26:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:26:22 --> Model Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:26:22 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:26:22 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:26:22 --> Model Class Initialized
DEBUG - 2015-02-04 09:26:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:26:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:26:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:26:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:26:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:26:23 --> Final output sent to browser
DEBUG - 2015-02-04 09:26:23 --> Total execution time: 0.9451
DEBUG - 2015-02-04 09:27:42 --> Config Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:27:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:27:42 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:27:42 --> URI Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Router Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Output Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Security Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Input Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:27:42 --> Language Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Loader Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:27:42 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:27:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:27:42 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:27:42 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:27:42 --> Model Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Model Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Controller Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:27:42 --> Email Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:27:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:27:42 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:27:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:27:42 --> Model Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:27:42 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:27:42 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:27:42 --> Model Class Initialized
DEBUG - 2015-02-04 09:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:27:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:27:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:27:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:27:43 --> Final output sent to browser
DEBUG - 2015-02-04 09:27:43 --> Total execution time: 0.8901
DEBUG - 2015-02-04 09:28:19 --> Config Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:28:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:28:19 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:28:19 --> URI Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Router Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Output Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Security Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Input Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:28:19 --> Language Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Loader Class Initialized
DEBUG - 2015-02-04 09:28:19 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:28:19 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:28:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:28:19 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:28:19 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:28:20 --> Model Class Initialized
DEBUG - 2015-02-04 09:28:20 --> Model Class Initialized
DEBUG - 2015-02-04 09:28:20 --> Controller Class Initialized
DEBUG - 2015-02-04 09:28:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:28:20 --> Email Class Initialized
DEBUG - 2015-02-04 09:28:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:28:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:28:20 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:28:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:28:20 --> Model Class Initialized
DEBUG - 2015-02-04 09:28:20 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:28:20 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:28:20 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:28:20 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:28:20 --> Model Class Initialized
DEBUG - 2015-02-04 09:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:28:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:28:20 --> Severity: Notice --> Undefined index: Article D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1608
ERROR - 2015-02-04 09:28:20 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1613
ERROR - 2015-02-04 09:28:20 --> Severity: Notice --> Undefined index: Article D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\PersistentCollection.php 175
ERROR - 2015-02-04 09:28:20 --> Severity: Error --> Call to a member function setValue() on a non-object D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\PersistentCollection.php 175
DEBUG - 2015-02-04 09:30:08 --> Config Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:30:08 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:30:08 --> URI Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Router Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Output Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Security Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Input Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:30:08 --> Language Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Loader Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:30:08 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:30:08 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:30:08 --> Config Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:30:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:30:08 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:30:08 --> URI Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Router Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Output Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Security Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Input Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Language Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Controller Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:30:08 --> Loader Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Email Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:30:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:30:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:30:08 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:30:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:30:08 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:30:08 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Controller Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:30:08 --> Email Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:30:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:30:08 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:30:08 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:30:08 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:30:09 --> Final output sent to browser
DEBUG - 2015-02-04 09:30:09 --> Total execution time: 1.1671
DEBUG - 2015-02-04 09:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:30:09 --> Final output sent to browser
DEBUG - 2015-02-04 09:30:09 --> Total execution time: 1.2721
DEBUG - 2015-02-04 09:30:43 --> Config Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:30:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:30:43 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:30:43 --> URI Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Router Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Output Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Security Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Input Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:30:43 --> Language Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Loader Class Initialized
DEBUG - 2015-02-04 09:30:43 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:30:43 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:30:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:30:43 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:30:43 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:44 --> Controller Class Initialized
DEBUG - 2015-02-04 09:30:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:30:44 --> Email Class Initialized
DEBUG - 2015-02-04 09:30:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:30:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:30:44 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:30:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:44 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:30:44 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:30:44 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:30:44 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:30:44 --> Model Class Initialized
DEBUG - 2015-02-04 09:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:30:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:30:44 --> Final output sent to browser
DEBUG - 2015-02-04 09:30:44 --> Total execution time: 1.0161
DEBUG - 2015-02-04 09:31:00 --> Config Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:31:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:31:00 --> URI Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Router Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Output Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Security Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Input Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:31:00 --> Language Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Loader Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:31:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:31:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:31:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:31:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Controller Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:31:00 --> Email Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:31:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:31:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:31:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:31:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:31:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:31:00 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:31:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:31:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:31:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:31:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:31:01 --> Final output sent to browser
DEBUG - 2015-02-04 09:31:01 --> Total execution time: 0.9151
DEBUG - 2015-02-04 09:31:31 --> Config Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:31:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:31:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:31:31 --> URI Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Router Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Output Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Security Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Input Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:31:31 --> Language Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Loader Class Initialized
DEBUG - 2015-02-04 09:31:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:31:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:31:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:31:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:31:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:31:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:32 --> Controller Class Initialized
DEBUG - 2015-02-04 09:31:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:31:32 --> Email Class Initialized
DEBUG - 2015-02-04 09:31:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:31:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:31:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:31:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:31:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:31:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:31:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:31:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:31:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:31:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:31:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:31:32 --> Severity: Notice --> Undefined index: Article D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1608
ERROR - 2015-02-04 09:31:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1613
ERROR - 2015-02-04 09:31:32 --> Severity: Notice --> Undefined index: Article D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\PersistentCollection.php 175
ERROR - 2015-02-04 09:31:32 --> Severity: Error --> Call to a member function setValue() on a non-object D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\PersistentCollection.php 175
DEBUG - 2015-02-04 09:32:31 --> Config Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:32:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:32:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:32:31 --> URI Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Router Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Output Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Security Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Input Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:32:31 --> Language Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Loader Class Initialized
DEBUG - 2015-02-04 09:32:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:32:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:32:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:32:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:32:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:32 --> Controller Class Initialized
DEBUG - 2015-02-04 09:32:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:32:32 --> Email Class Initialized
DEBUG - 2015-02-04 09:32:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:32:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:32:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:32:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:32:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:32:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:32:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:32:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:32:32 --> Severity: Notice --> Undefined index: Article D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1608
ERROR - 2015-02-04 09:32:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1613
ERROR - 2015-02-04 09:32:32 --> Severity: Notice --> Undefined index: Article D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\PersistentCollection.php 175
ERROR - 2015-02-04 09:32:32 --> Severity: Error --> Call to a member function setValue() on a non-object D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\PersistentCollection.php 175
DEBUG - 2015-02-04 09:32:41 --> Config Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:32:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:32:41 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:32:41 --> URI Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Router Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Output Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Security Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Input Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:32:41 --> Language Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Loader Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:32:41 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:32:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:32:41 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:32:41 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:32:41 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Controller Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:32:41 --> Email Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:32:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:32:41 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:32:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:32:41 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:32:41 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:32:41 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:32:41 --> Model Class Initialized
DEBUG - 2015-02-04 09:32:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:32:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:32:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:32:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:32:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:32:42 --> Final output sent to browser
DEBUG - 2015-02-04 09:32:42 --> Total execution time: 1.0071
DEBUG - 2015-02-04 09:33:26 --> Config Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:33:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:33:26 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:33:26 --> URI Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Router Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Output Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Security Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Input Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:33:26 --> Language Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Loader Class Initialized
DEBUG - 2015-02-04 09:33:26 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:33:26 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:33:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:33:26 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:33:26 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:33:27 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:27 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:27 --> Controller Class Initialized
DEBUG - 2015-02-04 09:33:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:33:27 --> Email Class Initialized
DEBUG - 2015-02-04 09:33:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:33:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:33:27 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:33:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:33:27 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:27 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:33:27 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:33:27 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:33:27 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:33:27 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:33:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:33:27 --> Severity: Error --> Call to undefined method Doctrine\ORM\PersistentCollection::getAssociation() D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 4
DEBUG - 2015-02-04 09:33:37 --> Config Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:33:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:33:37 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:33:37 --> URI Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Router Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Output Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Security Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Input Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:33:37 --> Language Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Loader Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:33:37 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:33:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:33:37 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:33:37 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:33:37 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Controller Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:33:37 --> Email Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:33:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:33:37 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:33:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:33:37 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:33:37 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:33:37 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:33:37 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:33:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:33:38 --> Severity: Error --> Call to undefined method Doctrine\ORM\PersistentCollection::association() D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 4
DEBUG - 2015-02-04 09:33:54 --> Config Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:33:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:33:54 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:33:54 --> URI Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Router Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Output Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Security Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Input Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:33:54 --> Language Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Loader Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:33:54 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:33:54 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:33:54 --> Config Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:33:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:33:54 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:33:54 --> URI Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Router Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Output Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Security Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Input Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:33:54 --> Language Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Loader Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:33:54 --> Controller Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:33:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:33:54 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Email Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:33:54 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:33:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:33:54 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:33:54 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:33:54 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:33:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:33:55 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Controller Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:33:55 --> Email Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:33:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:33:55 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:33:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:33:55 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:33:55 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:33:55 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:33:55 --> Model Class Initialized
DEBUG - 2015-02-04 09:33:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:33:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:33:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:33:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:33:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:33:55 --> Final output sent to browser
DEBUG - 2015-02-04 09:33:55 --> Total execution time: 1.2611
DEBUG - 2015-02-04 09:33:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:33:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:33:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:33:56 --> Final output sent to browser
DEBUG - 2015-02-04 09:33:56 --> Total execution time: 1.1991
DEBUG - 2015-02-04 09:36:01 --> Config Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:36:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:36:01 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:36:01 --> URI Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Router Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Output Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Security Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Input Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:36:01 --> Language Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Loader Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:36:01 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:36:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:36:01 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:36:01 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:36:01 --> Model Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Model Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Controller Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:36:01 --> Email Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:36:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:36:01 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:36:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:36:01 --> Model Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:36:01 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:36:01 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:36:01 --> Model Class Initialized
DEBUG - 2015-02-04 09:36:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:36:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:36:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:36:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:36:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:36:02 --> Final output sent to browser
DEBUG - 2015-02-04 09:36:02 --> Total execution time: 1.0731
DEBUG - 2015-02-04 09:39:35 --> Config Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:39:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:39:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:39:35 --> URI Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Router Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Output Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Security Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Input Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:39:35 --> Language Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Loader Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:39:35 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:39:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:39:35 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:39:35 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:39:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Controller Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:39:35 --> Email Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:39:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:39:35 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:39:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:39:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:39:35 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:39:35 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:39:35 --> Model Class Initialized
DEBUG - 2015-02-04 09:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 09:39:36 --> Severity: Warning --> ReflectionObject::__construct() expects parameter 1 to be object, array given D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 2
ERROR - 2015-02-04 09:39:36 --> Severity: Error --> ReflectionClass::getMethods(): Internal error: Failed to retrieve the reflection object D:\phutx\project\ups\myblog\application\views\admin\article\edit.php 3
DEBUG - 2015-02-04 09:40:02 --> Config Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:40:02 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:40:02 --> URI Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Router Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Output Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Security Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Input Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:40:02 --> Language Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Loader Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:40:02 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:40:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:40:02 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:40:02 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:40:02 --> Model Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Model Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Controller Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:40:02 --> Email Class Initialized
DEBUG - 2015-02-04 09:40:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:40:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:40:03 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:40:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:40:03 --> Model Class Initialized
DEBUG - 2015-02-04 09:40:03 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:40:03 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:40:03 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:40:03 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:40:03 --> Model Class Initialized
DEBUG - 2015-02-04 09:40:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:40:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:40:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:40:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:40:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:40:03 --> Final output sent to browser
DEBUG - 2015-02-04 09:40:03 --> Total execution time: 0.9561
DEBUG - 2015-02-04 09:41:33 --> Config Class Initialized
DEBUG - 2015-02-04 09:41:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:41:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:41:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:41:33 --> URI Class Initialized
DEBUG - 2015-02-04 09:41:33 --> Router Class Initialized
DEBUG - 2015-02-04 09:41:33 --> Output Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Security Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Input Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:41:34 --> Language Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Loader Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:41:34 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:41:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:41:34 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:41:34 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:41:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Controller Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:41:34 --> Email Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:41:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:41:34 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:41:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:41:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:41:34 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:41:34 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:41:34 --> Model Class Initialized
DEBUG - 2015-02-04 09:41:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:41:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:41:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:41:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:41:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:41:34 --> Final output sent to browser
DEBUG - 2015-02-04 09:41:34 --> Total execution time: 0.8691
DEBUG - 2015-02-04 09:43:04 --> Config Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:43:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:43:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:43:04 --> URI Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Router Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Output Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Security Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Input Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:43:04 --> Language Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Loader Class Initialized
DEBUG - 2015-02-04 09:43:04 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:43:04 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:43:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:43:04 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:43:04 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:43:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:43:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:43:05 --> Controller Class Initialized
DEBUG - 2015-02-04 09:43:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:43:05 --> Email Class Initialized
DEBUG - 2015-02-04 09:43:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:43:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:43:05 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:43:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:43:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:43:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:43:05 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:43:05 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:43:05 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:43:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:43:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:43:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:43:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:43:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:43:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:43:05 --> Final output sent to browser
DEBUG - 2015-02-04 09:43:05 --> Total execution time: 0.8401
DEBUG - 2015-02-04 09:45:03 --> Config Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:45:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:45:03 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:45:03 --> URI Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Router Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Output Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Security Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Input Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:45:03 --> Language Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Loader Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:45:03 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:45:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:45:03 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:45:03 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:45:03 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Controller Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:45:03 --> Email Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:45:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:45:03 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:45:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:45:03 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:45:03 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:45:03 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:45:03 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:45:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:45:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:45:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:45:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:45:04 --> Final output sent to browser
DEBUG - 2015-02-04 09:45:04 --> Total execution time: 0.8781
DEBUG - 2015-02-04 09:45:21 --> Config Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:45:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:45:21 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:45:21 --> URI Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Router Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Output Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Security Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Input Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:45:21 --> Language Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Loader Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:45:21 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:45:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:45:21 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:45:21 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:45:21 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Controller Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:45:21 --> Email Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:45:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:45:21 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:45:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:45:21 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:45:21 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:45:21 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:45:21 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:45:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:45:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:45:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:45:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:45:21 --> Final output sent to browser
DEBUG - 2015-02-04 09:45:21 --> Total execution time: 0.8461
DEBUG - 2015-02-04 09:45:33 --> Config Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:45:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:45:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:45:33 --> URI Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Router Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Output Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Security Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Input Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:45:33 --> Language Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Loader Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:45:33 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:45:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:45:33 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:45:33 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:45:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Controller Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:45:33 --> Email Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:45:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:45:33 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:45:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:45:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:45:33 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:45:33 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:45:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
ERROR - 2015-02-04 09:45:33 --> Severity: Error --> Call to undefined method Entity\Articles::setName() D:\phutx\project\ups\myblog\application\models\Article_model.php 44
DEBUG - 2015-02-04 09:50:19 --> Config Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:50:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:50:19 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:50:19 --> URI Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Router Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Output Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Security Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Input Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:50:19 --> Language Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Loader Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:50:19 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:50:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:50:19 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:50:19 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:50:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Controller Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:50:19 --> Email Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:50:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:50:19 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:50:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:50:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:50:19 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:50:19 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:50:19 --> Model Class Initialized
DEBUG - 2015-02-04 09:50:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:50:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:50:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:53:25 --> Config Class Initialized
DEBUG - 2015-02-04 09:53:25 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:53:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:53:25 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:53:25 --> URI Class Initialized
DEBUG - 2015-02-04 09:53:25 --> Router Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Output Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Security Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Input Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:53:26 --> Language Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Loader Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:53:26 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:53:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:53:26 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:53:26 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:53:26 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Controller Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:53:26 --> Email Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:53:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:53:26 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:53:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:53:26 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:53:26 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:53:26 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:53:26 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:53:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:53:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:53:27 --> Config Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:53:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:53:27 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:53:27 --> URI Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Router Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Output Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Security Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Input Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:53:27 --> Language Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Loader Class Initialized
DEBUG - 2015-02-04 09:53:27 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:53:27 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:53:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:53:27 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:53:27 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:53:28 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:28 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:28 --> Controller Class Initialized
DEBUG - 2015-02-04 09:53:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:53:28 --> Email Class Initialized
DEBUG - 2015-02-04 09:53:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:53:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:53:28 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:53:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:53:28 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:28 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:53:28 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:53:28 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:53:28 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:53:28 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:53:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:53:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 09:53:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:53:28 --> Final output sent to browser
DEBUG - 2015-02-04 09:53:28 --> Total execution time: 0.8131
DEBUG - 2015-02-04 09:53:33 --> Config Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:53:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:53:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:53:33 --> URI Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Router Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Output Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Security Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Input Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:53:33 --> Language Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Loader Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:53:33 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:53:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:53:33 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:53:33 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:53:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Controller Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:53:33 --> Email Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:53:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:53:33 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:53:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:53:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:53:33 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:53:33 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:53:33 --> Model Class Initialized
DEBUG - 2015-02-04 09:53:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:53:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:53:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:53:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:53:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:53:33 --> Final output sent to browser
DEBUG - 2015-02-04 09:53:33 --> Total execution time: 0.8401
DEBUG - 2015-02-04 09:54:05 --> Config Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:54:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:54:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:54:05 --> URI Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Router Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Output Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Security Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Input Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:54:05 --> Language Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Loader Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:54:05 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:54:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:54:05 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:54:05 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:54:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Controller Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:54:05 --> Email Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:54:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:54:05 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:54:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:54:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:54:05 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:54:05 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:54:05 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:54:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:54:07 --> Config Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:54:07 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:54:07 --> URI Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Router Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Output Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Security Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Input Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:54:07 --> Language Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Loader Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:54:07 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:54:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:54:07 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:54:07 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:54:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Controller Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:54:07 --> Email Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:54:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:54:07 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:54:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:54:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:54:07 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:54:07 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:54:07 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 09:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:54:07 --> Final output sent to browser
DEBUG - 2015-02-04 09:54:07 --> Total execution time: 0.7831
DEBUG - 2015-02-04 09:54:12 --> Config Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:54:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:54:12 --> URI Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Router Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Output Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Security Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Input Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:54:12 --> Language Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Loader Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:54:12 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:54:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:54:12 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:54:12 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:54:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Controller Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:54:12 --> Email Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:54:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:54:12 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:54:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:54:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:54:12 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:54:12 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:54:12 --> Model Class Initialized
DEBUG - 2015-02-04 09:54:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:54:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:54:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:54:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:54:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:54:12 --> Final output sent to browser
DEBUG - 2015-02-04 09:54:12 --> Total execution time: 0.8781
DEBUG - 2015-02-04 09:58:38 --> Config Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:58:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:58:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:58:38 --> URI Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Router Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Output Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Security Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Input Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:58:38 --> Language Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Loader Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:58:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:58:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:58:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:58:38 --> Session: Regenerate ID
DEBUG - 2015-02-04 09:58:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:58:39 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:39 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:39 --> Controller Class Initialized
DEBUG - 2015-02-04 09:58:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:58:39 --> Email Class Initialized
DEBUG - 2015-02-04 09:58:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:58:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:58:39 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:58:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:58:39 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:39 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:58:39 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:58:39 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:58:39 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:58:39 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:58:40 --> Config Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:58:40 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:58:40 --> URI Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Router Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Output Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Security Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Input Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:58:40 --> Language Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Loader Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:58:40 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:58:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:58:40 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:58:40 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:58:40 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Controller Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:58:40 --> Email Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:58:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:58:40 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:58:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:58:40 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:58:40 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:58:40 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:58:40 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:58:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:58:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 09:58:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:58:41 --> Final output sent to browser
DEBUG - 2015-02-04 09:58:41 --> Total execution time: 0.7761
DEBUG - 2015-02-04 09:58:44 --> Config Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Hooks Class Initialized
DEBUG - 2015-02-04 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 09:58:44 --> Utf8 Class Initialized
DEBUG - 2015-02-04 09:58:44 --> URI Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Router Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Output Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Security Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Input Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 09:58:44 --> Language Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Loader Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Helper loaded: url_helper
DEBUG - 2015-02-04 09:58:44 --> Helper loaded: link_helper
DEBUG - 2015-02-04 09:58:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 09:58:44 --> CI_Session Class Initialized
DEBUG - 2015-02-04 09:58:44 --> CI_Session routines successfully run
DEBUG - 2015-02-04 09:58:44 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Controller Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 09:58:44 --> Email Class Initialized
DEBUG - 2015-02-04 09:58:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 09:58:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 09:58:44 --> Helper loaded: language_helper
DEBUG - 2015-02-04 09:58:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 09:58:44 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:45 --> Database Driver Class Initialized
DEBUG - 2015-02-04 09:58:45 --> Helper loaded: date_helper
DEBUG - 2015-02-04 09:58:45 --> Helper loaded: form_helper
DEBUG - 2015-02-04 09:58:45 --> Form Validation Class Initialized
DEBUG - 2015-02-04 09:58:45 --> Model Class Initialized
DEBUG - 2015-02-04 09:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 09:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 09:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 09:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 09:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 09:58:45 --> Final output sent to browser
DEBUG - 2015-02-04 09:58:45 --> Total execution time: 0.8551
DEBUG - 2015-02-04 10:13:46 --> Config Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Hooks Class Initialized
DEBUG - 2015-02-04 10:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 10:13:46 --> Utf8 Class Initialized
DEBUG - 2015-02-04 10:13:46 --> URI Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Router Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Output Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Security Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Input Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 10:13:46 --> Language Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Loader Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Helper loaded: url_helper
DEBUG - 2015-02-04 10:13:46 --> Helper loaded: link_helper
DEBUG - 2015-02-04 10:13:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 10:13:46 --> CI_Session Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Session: Regenerate ID
DEBUG - 2015-02-04 10:13:46 --> CI_Session routines successfully run
DEBUG - 2015-02-04 10:13:46 --> Model Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Model Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Controller Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 10:13:46 --> Email Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 10:13:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 10:13:46 --> Helper loaded: language_helper
DEBUG - 2015-02-04 10:13:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 10:13:46 --> Model Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Database Driver Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Helper loaded: date_helper
DEBUG - 2015-02-04 10:13:46 --> Helper loaded: form_helper
DEBUG - 2015-02-04 10:13:46 --> Form Validation Class Initialized
DEBUG - 2015-02-04 10:13:46 --> Model Class Initialized
DEBUG - 2015-02-04 10:13:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 10:13:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 10:13:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 10:13:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 10:13:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 10:13:47 --> Final output sent to browser
DEBUG - 2015-02-04 10:13:47 --> Total execution time: 0.8571
DEBUG - 2015-02-04 10:28:47 --> Config Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 10:28:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 10:28:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 10:28:48 --> URI Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Router Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Output Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Security Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Input Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 10:28:48 --> Language Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Loader Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Helper loaded: url_helper
DEBUG - 2015-02-04 10:28:48 --> Helper loaded: link_helper
DEBUG - 2015-02-04 10:28:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 10:28:48 --> CI_Session Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Session: Regenerate ID
DEBUG - 2015-02-04 10:28:48 --> CI_Session routines successfully run
DEBUG - 2015-02-04 10:28:48 --> Model Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Model Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Controller Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 10:28:48 --> Email Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 10:28:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 10:28:48 --> Helper loaded: language_helper
DEBUG - 2015-02-04 10:28:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 10:28:48 --> Model Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Helper loaded: date_helper
DEBUG - 2015-02-04 10:28:48 --> Helper loaded: form_helper
DEBUG - 2015-02-04 10:28:48 --> Form Validation Class Initialized
DEBUG - 2015-02-04 10:28:48 --> Model Class Initialized
DEBUG - 2015-02-04 10:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 10:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 10:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 10:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 10:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 10:28:48 --> Final output sent to browser
DEBUG - 2015-02-04 10:28:48 --> Total execution time: 0.8231
DEBUG - 2015-02-04 10:43:49 --> Config Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Hooks Class Initialized
DEBUG - 2015-02-04 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 10:43:49 --> Utf8 Class Initialized
DEBUG - 2015-02-04 10:43:49 --> URI Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Router Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Output Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Security Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Input Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 10:43:49 --> Language Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Loader Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Helper loaded: url_helper
DEBUG - 2015-02-04 10:43:49 --> Helper loaded: link_helper
DEBUG - 2015-02-04 10:43:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 10:43:49 --> CI_Session Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Session: Regenerate ID
DEBUG - 2015-02-04 10:43:49 --> CI_Session routines successfully run
DEBUG - 2015-02-04 10:43:49 --> Model Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Model Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Controller Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 10:43:49 --> Email Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 10:43:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 10:43:49 --> Helper loaded: language_helper
DEBUG - 2015-02-04 10:43:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 10:43:49 --> Model Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Database Driver Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Helper loaded: date_helper
DEBUG - 2015-02-04 10:43:49 --> Helper loaded: form_helper
DEBUG - 2015-02-04 10:43:49 --> Form Validation Class Initialized
DEBUG - 2015-02-04 10:43:49 --> Model Class Initialized
DEBUG - 2015-02-04 10:43:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 10:43:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 10:43:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 10:43:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 10:43:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 10:43:50 --> Final output sent to browser
DEBUG - 2015-02-04 10:43:50 --> Total execution time: 0.8241
DEBUG - 2015-02-04 10:58:51 --> Config Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Hooks Class Initialized
DEBUG - 2015-02-04 10:58:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 10:58:51 --> Utf8 Class Initialized
DEBUG - 2015-02-04 10:58:51 --> URI Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Router Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Output Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Security Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Input Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 10:58:51 --> Language Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Loader Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Helper loaded: url_helper
DEBUG - 2015-02-04 10:58:51 --> Helper loaded: link_helper
DEBUG - 2015-02-04 10:58:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 10:58:51 --> CI_Session Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Session: Regenerate ID
DEBUG - 2015-02-04 10:58:51 --> CI_Session routines successfully run
DEBUG - 2015-02-04 10:58:51 --> Model Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Model Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Controller Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 10:58:51 --> Email Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 10:58:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 10:58:51 --> Helper loaded: language_helper
DEBUG - 2015-02-04 10:58:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 10:58:51 --> Model Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Database Driver Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Helper loaded: date_helper
DEBUG - 2015-02-04 10:58:51 --> Helper loaded: form_helper
DEBUG - 2015-02-04 10:58:51 --> Form Validation Class Initialized
DEBUG - 2015-02-04 10:58:51 --> Model Class Initialized
DEBUG - 2015-02-04 10:58:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 10:58:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 10:58:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 10:58:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 10:58:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 10:58:52 --> Final output sent to browser
DEBUG - 2015-02-04 10:58:52 --> Total execution time: 0.8191
DEBUG - 2015-02-04 11:13:53 --> Config Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Hooks Class Initialized
DEBUG - 2015-02-04 11:13:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 11:13:53 --> Utf8 Class Initialized
DEBUG - 2015-02-04 11:13:53 --> URI Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Router Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Output Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Security Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Input Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 11:13:53 --> Language Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Loader Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Helper loaded: url_helper
DEBUG - 2015-02-04 11:13:53 --> Helper loaded: link_helper
DEBUG - 2015-02-04 11:13:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 11:13:53 --> CI_Session Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Session: Regenerate ID
DEBUG - 2015-02-04 11:13:53 --> CI_Session routines successfully run
DEBUG - 2015-02-04 11:13:53 --> Model Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Model Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Controller Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 11:13:53 --> Email Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 11:13:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 11:13:53 --> Helper loaded: language_helper
DEBUG - 2015-02-04 11:13:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 11:13:53 --> Model Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Database Driver Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Helper loaded: date_helper
DEBUG - 2015-02-04 11:13:53 --> Helper loaded: form_helper
DEBUG - 2015-02-04 11:13:53 --> Form Validation Class Initialized
DEBUG - 2015-02-04 11:13:53 --> Model Class Initialized
DEBUG - 2015-02-04 11:13:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 11:13:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 11:13:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 11:13:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 11:13:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 11:13:54 --> Final output sent to browser
DEBUG - 2015-02-04 11:13:54 --> Total execution time: 0.8221
DEBUG - 2015-02-04 11:28:55 --> Config Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Hooks Class Initialized
DEBUG - 2015-02-04 11:28:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 11:28:55 --> Utf8 Class Initialized
DEBUG - 2015-02-04 11:28:55 --> URI Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Router Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Output Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Security Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Input Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 11:28:55 --> Language Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Loader Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Helper loaded: url_helper
DEBUG - 2015-02-04 11:28:55 --> Helper loaded: link_helper
DEBUG - 2015-02-04 11:28:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 11:28:55 --> CI_Session Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Session: Regenerate ID
DEBUG - 2015-02-04 11:28:55 --> CI_Session routines successfully run
DEBUG - 2015-02-04 11:28:55 --> Model Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Model Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Controller Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 11:28:55 --> Email Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 11:28:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 11:28:55 --> Helper loaded: language_helper
DEBUG - 2015-02-04 11:28:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 11:28:55 --> Model Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Database Driver Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Helper loaded: date_helper
DEBUG - 2015-02-04 11:28:55 --> Helper loaded: form_helper
DEBUG - 2015-02-04 11:28:55 --> Form Validation Class Initialized
DEBUG - 2015-02-04 11:28:55 --> Model Class Initialized
DEBUG - 2015-02-04 11:28:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 11:28:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 11:28:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 11:28:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 11:28:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 11:28:56 --> Final output sent to browser
DEBUG - 2015-02-04 11:28:56 --> Total execution time: 0.8351
DEBUG - 2015-02-04 11:43:57 --> Config Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Hooks Class Initialized
DEBUG - 2015-02-04 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 11:43:57 --> Utf8 Class Initialized
DEBUG - 2015-02-04 11:43:57 --> URI Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Router Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Output Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Security Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Input Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 11:43:57 --> Language Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Loader Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Helper loaded: url_helper
DEBUG - 2015-02-04 11:43:57 --> Helper loaded: link_helper
DEBUG - 2015-02-04 11:43:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 11:43:57 --> CI_Session Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Session: Regenerate ID
DEBUG - 2015-02-04 11:43:57 --> CI_Session routines successfully run
DEBUG - 2015-02-04 11:43:57 --> Model Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Model Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Controller Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 11:43:57 --> Email Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 11:43:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 11:43:57 --> Helper loaded: language_helper
DEBUG - 2015-02-04 11:43:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 11:43:57 --> Model Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Database Driver Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Helper loaded: date_helper
DEBUG - 2015-02-04 11:43:57 --> Helper loaded: form_helper
DEBUG - 2015-02-04 11:43:57 --> Form Validation Class Initialized
DEBUG - 2015-02-04 11:43:57 --> Model Class Initialized
DEBUG - 2015-02-04 11:43:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 11:43:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 11:43:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 11:43:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 11:43:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 11:43:58 --> Final output sent to browser
DEBUG - 2015-02-04 11:43:58 --> Total execution time: 0.8351
DEBUG - 2015-02-04 11:58:58 --> Config Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Hooks Class Initialized
DEBUG - 2015-02-04 11:58:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 11:58:58 --> Utf8 Class Initialized
DEBUG - 2015-02-04 11:58:58 --> URI Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Router Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Output Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Security Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Input Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 11:58:58 --> Language Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Loader Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Helper loaded: url_helper
DEBUG - 2015-02-04 11:58:58 --> Helper loaded: link_helper
DEBUG - 2015-02-04 11:58:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 11:58:58 --> CI_Session Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Session: Regenerate ID
DEBUG - 2015-02-04 11:58:58 --> CI_Session routines successfully run
DEBUG - 2015-02-04 11:58:58 --> Model Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Model Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Controller Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 11:58:58 --> Email Class Initialized
DEBUG - 2015-02-04 11:58:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 11:58:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 11:58:59 --> Helper loaded: language_helper
DEBUG - 2015-02-04 11:58:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 11:58:59 --> Model Class Initialized
DEBUG - 2015-02-04 11:58:59 --> Database Driver Class Initialized
DEBUG - 2015-02-04 11:58:59 --> Helper loaded: date_helper
DEBUG - 2015-02-04 11:58:59 --> Helper loaded: form_helper
DEBUG - 2015-02-04 11:58:59 --> Form Validation Class Initialized
DEBUG - 2015-02-04 11:58:59 --> Model Class Initialized
DEBUG - 2015-02-04 11:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 11:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 11:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 11:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 11:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 11:58:59 --> Final output sent to browser
DEBUG - 2015-02-04 11:58:59 --> Total execution time: 0.8330
DEBUG - 2015-02-04 12:14:00 --> Config Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:14:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:14:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:14:00 --> URI Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Router Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Output Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Security Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Input Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:14:00 --> Language Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Loader Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:14:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:14:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:14:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Session: Regenerate ID
DEBUG - 2015-02-04 12:14:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:14:00 --> Model Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Model Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Controller Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:14:00 --> Email Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:14:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:14:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:14:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:14:00 --> Model Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:14:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:14:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:14:00 --> Model Class Initialized
DEBUG - 2015-02-04 12:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:14:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 12:14:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 12:14:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 12:14:01 --> Final output sent to browser
DEBUG - 2015-02-04 12:14:01 --> Total execution time: 0.8301
DEBUG - 2015-02-04 12:29:02 --> Config Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:29:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:29:02 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:29:02 --> URI Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Router Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Output Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Security Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Input Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:29:02 --> Language Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Loader Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:29:02 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:29:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:29:02 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Session: Regenerate ID
DEBUG - 2015-02-04 12:29:02 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:29:02 --> Model Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Model Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Controller Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:29:02 --> Email Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:29:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:29:02 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:29:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:29:02 --> Model Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:29:02 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:29:02 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:29:02 --> Model Class Initialized
DEBUG - 2015-02-04 12:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 12:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 12:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 12:29:02 --> Final output sent to browser
DEBUG - 2015-02-04 12:29:02 --> Total execution time: 0.8501
DEBUG - 2015-02-04 12:32:12 --> Config Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:32:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:32:12 --> URI Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Router Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Output Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Security Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Input Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:32:12 --> Language Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Loader Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:32:12 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:32:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:32:12 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:32:12 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:32:12 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Controller Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:32:12 --> Email Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:32:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:32:12 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:32:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:32:12 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:32:12 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:32:12 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:32:12 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:32:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:32:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 12:32:15 --> Config Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:32:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:32:15 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:32:15 --> URI Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Router Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Output Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Security Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Input Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:32:15 --> Language Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Loader Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:32:15 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:32:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:32:15 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:32:15 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:32:15 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Controller Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:32:15 --> Email Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:32:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:32:15 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:32:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:32:15 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:32:15 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:32:15 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:32:15 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:32:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:32:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 12:32:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 12:32:15 --> Final output sent to browser
DEBUG - 2015-02-04 12:32:15 --> Total execution time: 0.7461
DEBUG - 2015-02-04 12:32:18 --> Config Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:32:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:32:18 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:32:18 --> URI Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Router Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Output Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Security Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Input Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:32:18 --> Language Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Loader Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:32:18 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:32:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:32:18 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:32:18 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Controller Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:32:18 --> Email Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:32:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:32:18 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:32:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:32:18 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:32:18 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:32:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:32:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 12:32:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 12:32:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 12:32:19 --> Final output sent to browser
DEBUG - 2015-02-04 12:32:19 --> Total execution time: 0.8661
DEBUG - 2015-02-04 12:32:32 --> Config Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:32:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:32:32 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:32:32 --> URI Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Router Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Output Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Security Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Input Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:32:32 --> Language Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Loader Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:32:32 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:32:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:32:32 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:32:32 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Controller Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:32:32 --> Email Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:32:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:32:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:32:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:32:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:32:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:32:32 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:32:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:32:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 12:32:34 --> Config Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:32:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:32:34 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:32:34 --> URI Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Router Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Output Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Security Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Input Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:32:34 --> Language Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Loader Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:32:34 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:32:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:32:34 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:32:34 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:32:34 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Controller Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:32:34 --> Email Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:32:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:32:34 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:32:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:32:34 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:32:34 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:32:35 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:32:35 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:32:35 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:32:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:32:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 12:32:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 12:32:35 --> Final output sent to browser
DEBUG - 2015-02-04 12:32:35 --> Total execution time: 0.7321
DEBUG - 2015-02-04 12:32:38 --> Config Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:32:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:32:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:32:38 --> URI Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Router Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Output Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Security Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Input Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:32:38 --> Language Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Loader Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:32:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:32:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:32:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:32:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:32:38 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Controller Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:32:38 --> Email Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:32:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:32:38 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:32:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:32:38 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:32:38 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:32:38 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:32:38 --> Model Class Initialized
DEBUG - 2015-02-04 12:32:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:32:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:32:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 12:32:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 12:32:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 12:32:39 --> Final output sent to browser
DEBUG - 2015-02-04 12:32:39 --> Total execution time: 0.8721
DEBUG - 2015-02-04 12:47:39 --> Config Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Hooks Class Initialized
DEBUG - 2015-02-04 12:47:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 12:47:39 --> Utf8 Class Initialized
DEBUG - 2015-02-04 12:47:39 --> URI Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Router Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Output Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Security Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Input Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 12:47:39 --> Language Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Loader Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Helper loaded: url_helper
DEBUG - 2015-02-04 12:47:39 --> Helper loaded: link_helper
DEBUG - 2015-02-04 12:47:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 12:47:39 --> CI_Session Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Session: Regenerate ID
DEBUG - 2015-02-04 12:47:39 --> CI_Session routines successfully run
DEBUG - 2015-02-04 12:47:39 --> Model Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Model Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Controller Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 12:47:39 --> Email Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 12:47:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 12:47:39 --> Helper loaded: language_helper
DEBUG - 2015-02-04 12:47:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 12:47:39 --> Model Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Database Driver Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Helper loaded: date_helper
DEBUG - 2015-02-04 12:47:39 --> Helper loaded: form_helper
DEBUG - 2015-02-04 12:47:39 --> Form Validation Class Initialized
DEBUG - 2015-02-04 12:47:39 --> Model Class Initialized
DEBUG - 2015-02-04 12:47:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 12:47:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 12:47:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 12:47:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 12:47:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 12:47:40 --> Final output sent to browser
DEBUG - 2015-02-04 12:47:40 --> Total execution time: 0.8351
DEBUG - 2015-02-04 13:02:41 --> Config Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:02:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:02:41 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:02:41 --> URI Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Router Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Output Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Security Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Input Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:02:41 --> Language Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Loader Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:02:41 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:02:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:02:41 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:02:41 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:02:41 --> Model Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Model Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Controller Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:02:41 --> Email Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:02:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:02:41 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:02:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:02:41 --> Model Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:02:41 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:02:41 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:02:41 --> Model Class Initialized
DEBUG - 2015-02-04 13:02:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:02:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:02:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 13:02:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:02:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 13:02:41 --> Final output sent to browser
DEBUG - 2015-02-04 13:02:41 --> Total execution time: 0.8441
DEBUG - 2015-02-04 13:17:42 --> Config Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:17:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:17:42 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:17:42 --> URI Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Router Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Output Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Security Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Input Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:17:42 --> Language Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Loader Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:17:42 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:17:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:17:42 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:17:42 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:17:42 --> Model Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Model Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Controller Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:17:42 --> Email Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:17:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:17:42 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:17:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:17:42 --> Model Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:17:42 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:17:42 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:17:42 --> Model Class Initialized
DEBUG - 2015-02-04 13:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:17:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-04 13:17:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:17:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-04 13:17:43 --> Final output sent to browser
DEBUG - 2015-02-04 13:17:43 --> Total execution time: 0.9331
DEBUG - 2015-02-04 13:21:06 --> Config Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:21:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:21:06 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:21:06 --> URI Class Initialized
DEBUG - 2015-02-04 13:21:06 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:21:06 --> Router Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Output Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Security Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Input Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:21:06 --> Language Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Loader Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:21:06 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:21:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:21:06 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:21:06 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:21:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Controller Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:21:06 --> Email Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:21:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:21:06 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:21:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:21:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:21:06 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:21:06 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:21:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:21:06 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:21:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:21:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:21:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:21:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:21:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:21:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:21:07 --> Final output sent to browser
DEBUG - 2015-02-04 13:21:07 --> Total execution time: 1.1921
DEBUG - 2015-02-04 13:22:06 --> Config Class Initialized
DEBUG - 2015-02-04 13:22:06 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:22:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:22:06 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:22:06 --> URI Class Initialized
DEBUG - 2015-02-04 13:22:06 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:22:06 --> Router Class Initialized
DEBUG - 2015-02-04 13:22:06 --> Output Class Initialized
DEBUG - 2015-02-04 13:22:06 --> Security Class Initialized
DEBUG - 2015-02-04 13:22:06 --> Input Class Initialized
DEBUG - 2015-02-04 13:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:22:06 --> Language Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Loader Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:22:07 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:22:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:22:07 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:22:07 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:22:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Controller Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:22:07 --> Email Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:22:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:22:07 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:22:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:22:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:22:07 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:22:07 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:22:07 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:22:07 --> Final output sent to browser
DEBUG - 2015-02-04 13:22:07 --> Total execution time: 0.9021
DEBUG - 2015-02-04 13:22:39 --> Config Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:22:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:22:39 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:22:39 --> URI Class Initialized
DEBUG - 2015-02-04 13:22:39 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:22:39 --> Router Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Output Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Security Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Input Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:22:39 --> Language Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Loader Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:22:39 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:22:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:22:39 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:22:39 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:22:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Controller Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:22:39 --> Email Class Initialized
DEBUG - 2015-02-04 13:22:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:22:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:22:39 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:22:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:22:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:22:40 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:22:40 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:22:40 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:22:40 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:22:40 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:22:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:22:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:22:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:22:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:22:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:22:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:22:40 --> Final output sent to browser
DEBUG - 2015-02-04 13:22:40 --> Total execution time: 0.8271
DEBUG - 2015-02-04 13:22:46 --> Config Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:22:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:22:46 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:22:46 --> URI Class Initialized
DEBUG - 2015-02-04 13:22:46 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:22:46 --> Router Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Output Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Security Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Input Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:22:46 --> Language Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Loader Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:22:46 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:22:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:22:46 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:22:46 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:22:46 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Controller Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:22:46 --> Email Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:22:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:22:46 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:22:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:22:46 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:22:46 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:22:46 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Model Class Initialized
DEBUG - 2015-02-04 13:22:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:22:46 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:22:47 --> Final output sent to browser
DEBUG - 2015-02-04 13:22:47 --> Total execution time: 0.7951
DEBUG - 2015-02-04 13:23:33 --> Config Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:23:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:23:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:23:33 --> URI Class Initialized
DEBUG - 2015-02-04 13:23:33 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:23:33 --> Router Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Output Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Security Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Input Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:23:33 --> Language Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Loader Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:23:33 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:23:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:23:33 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:23:33 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:23:33 --> Model Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Model Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Controller Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:23:33 --> Email Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:23:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:23:33 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:23:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:23:33 --> Model Class Initialized
DEBUG - 2015-02-04 13:23:33 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:23:34 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:23:34 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:23:34 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:23:34 --> Model Class Initialized
DEBUG - 2015-02-04 13:23:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:23:34 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:23:34 --> Final output sent to browser
DEBUG - 2015-02-04 13:23:34 --> Total execution time: 0.8261
DEBUG - 2015-02-04 13:24:19 --> Config Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:24:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:24:19 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:24:19 --> URI Class Initialized
DEBUG - 2015-02-04 13:24:19 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:24:19 --> Router Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Output Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Security Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Input Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:24:19 --> Language Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Loader Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:24:19 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:24:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:24:19 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:24:19 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:24:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Controller Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:24:19 --> Email Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:24:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:24:19 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:24:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:24:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:24:19 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:24:19 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:24:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:24:19 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:24:20 --> Final output sent to browser
DEBUG - 2015-02-04 13:24:20 --> Total execution time: 0.8581
DEBUG - 2015-02-04 13:26:34 --> Config Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:26:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:26:34 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:26:34 --> URI Class Initialized
DEBUG - 2015-02-04 13:26:34 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:26:34 --> Router Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Output Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Security Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Input Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:26:34 --> Language Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Loader Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:26:34 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:26:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:26:34 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:26:34 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:26:34 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Controller Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:26:34 --> Email Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:26:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:26:34 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:26:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:26:34 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:26:34 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:26:34 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:26:34 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:26:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:26:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:26:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:26:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:26:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:26:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:26:35 --> Final output sent to browser
DEBUG - 2015-02-04 13:26:35 --> Total execution time: 0.8031
DEBUG - 2015-02-04 13:26:38 --> Config Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:26:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:26:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:26:38 --> URI Class Initialized
DEBUG - 2015-02-04 13:26:38 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:26:38 --> Router Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Output Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Security Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Input Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:26:38 --> Language Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Loader Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:26:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:26:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:26:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:26:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:26:38 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Controller Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:26:38 --> Email Class Initialized
DEBUG - 2015-02-04 13:26:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:26:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:26:38 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:26:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:26:38 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:39 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:26:39 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:26:39 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:26:39 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:26:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:26:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:26:39 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:26:39 --> Final output sent to browser
DEBUG - 2015-02-04 13:26:39 --> Total execution time: 0.9031
DEBUG - 2015-02-04 13:27:33 --> Config Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:27:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:27:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:27:33 --> URI Class Initialized
DEBUG - 2015-02-04 13:27:33 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:27:33 --> Router Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Output Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Security Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Input Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:27:33 --> Language Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Loader Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:27:33 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:27:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:27:33 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:27:33 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:27:33 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Controller Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:27:33 --> Email Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:27:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:27:33 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:27:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:27:33 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:27:33 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:27:33 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:27:33 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:27:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:27:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:27:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:27:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:27:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:27:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:27:34 --> Final output sent to browser
DEBUG - 2015-02-04 13:27:34 --> Total execution time: 0.8371
DEBUG - 2015-02-04 13:27:39 --> Config Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:27:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:27:39 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:27:39 --> URI Class Initialized
DEBUG - 2015-02-04 13:27:39 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:27:39 --> Router Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Output Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Security Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Input Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:27:39 --> Language Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Loader Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:27:39 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:27:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:27:39 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:27:39 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:27:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Controller Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:27:39 --> Email Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:27:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:27:39 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:27:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:27:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:27:39 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:27:39 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Model Class Initialized
DEBUG - 2015-02-04 13:27:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:27:39 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:27:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:27:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:27:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:27:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:27:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:27:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:27:39 --> Final output sent to browser
DEBUG - 2015-02-04 13:27:39 --> Total execution time: 0.8191
DEBUG - 2015-02-04 13:28:32 --> Config Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:28:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:28:32 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:28:32 --> URI Class Initialized
DEBUG - 2015-02-04 13:28:32 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:28:32 --> Router Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Output Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Security Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Input Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:28:32 --> Language Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Loader Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:28:32 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:28:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:28:32 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:28:32 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:28:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Controller Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:28:32 --> Email Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:28:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:28:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:28:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:28:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:28:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:28:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:32 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:28:32 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:28:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:28:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:28:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:28:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:28:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:28:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:28:33 --> Final output sent to browser
DEBUG - 2015-02-04 13:28:33 --> Total execution time: 0.8631
DEBUG - 2015-02-04 13:28:56 --> Config Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:28:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:28:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:28:56 --> URI Class Initialized
DEBUG - 2015-02-04 13:28:56 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:28:56 --> Router Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Output Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Security Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Input Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:28:56 --> Language Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Loader Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:28:56 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:28:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:28:56 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:28:56 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:28:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Controller Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:28:56 --> Email Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:28:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:28:56 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:28:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:28:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:28:56 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:28:56 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:28:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:28:56 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:28:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:28:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:28:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:28:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:28:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:28:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:28:57 --> Final output sent to browser
DEBUG - 2015-02-04 13:28:57 --> Total execution time: 0.8211
DEBUG - 2015-02-04 13:29:11 --> Config Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:29:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:29:11 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:29:11 --> URI Class Initialized
DEBUG - 2015-02-04 13:29:11 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:29:11 --> Router Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Output Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Security Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Input Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:29:11 --> Language Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Loader Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:29:11 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:29:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:29:11 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:29:11 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:29:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Controller Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:29:11 --> Email Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:29:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:29:11 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:29:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:29:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:29:11 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:29:11 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:29:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:29:11 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:29:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:29:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:29:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:29:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:29:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:29:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:29:12 --> Final output sent to browser
DEBUG - 2015-02-04 13:29:12 --> Total execution time: 0.8651
DEBUG - 2015-02-04 13:30:13 --> Config Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:30:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:30:13 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:30:13 --> URI Class Initialized
DEBUG - 2015-02-04 13:30:13 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:30:13 --> Router Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Output Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Security Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Input Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:30:13 --> Language Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Loader Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:30:13 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:30:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:30:13 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:30:13 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:30:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Controller Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:30:13 --> Email Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:30:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:30:13 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:30:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:30:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:30:13 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:30:13 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:30:13 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:30:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:30:14 --> Final output sent to browser
DEBUG - 2015-02-04 13:30:14 --> Total execution time: 0.7701
DEBUG - 2015-02-04 13:30:31 --> Config Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:30:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:30:31 --> URI Class Initialized
DEBUG - 2015-02-04 13:30:31 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:30:31 --> Router Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Output Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Security Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Input Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:30:31 --> Language Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Loader Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:30:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:30:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:30:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:30:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:30:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Controller Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:30:31 --> Email Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:30:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:30:31 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:30:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:30:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:30:31 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:30:31 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:30:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:30:31 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:30:32 --> Final output sent to browser
DEBUG - 2015-02-04 13:30:32 --> Total execution time: 0.9131
DEBUG - 2015-02-04 13:31:55 --> Config Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:31:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:31:55 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:31:55 --> URI Class Initialized
DEBUG - 2015-02-04 13:31:55 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:31:55 --> Router Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Output Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Security Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Input Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:31:55 --> Language Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Loader Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:31:55 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:31:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:31:55 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:31:55 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:31:55 --> Model Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Model Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Controller Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:31:55 --> Email Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:31:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:31:55 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:31:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:31:55 --> Model Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:31:55 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:31:55 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Model Class Initialized
DEBUG - 2015-02-04 13:31:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:31:55 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:31:56 --> Final output sent to browser
DEBUG - 2015-02-04 13:31:56 --> Total execution time: 0.8541
DEBUG - 2015-02-04 13:32:18 --> Config Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:32:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:32:18 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:32:18 --> URI Class Initialized
DEBUG - 2015-02-04 13:32:18 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:32:18 --> Router Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Output Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Security Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Input Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:32:18 --> Language Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Loader Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:32:18 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:32:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:32:18 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:32:18 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Controller Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:32:18 --> Email Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:32:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:32:18 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:32:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:32:18 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:32:18 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:32:18 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:32:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:32:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:32:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:32:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:32:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:32:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:32:19 --> Final output sent to browser
DEBUG - 2015-02-04 13:32:19 --> Total execution time: 0.8161
DEBUG - 2015-02-04 13:32:56 --> Config Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:32:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:32:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:32:56 --> URI Class Initialized
DEBUG - 2015-02-04 13:32:56 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:32:56 --> Router Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Output Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Security Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Input Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:32:56 --> Language Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Loader Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:32:56 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:32:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:32:56 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:32:56 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:32:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Controller Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:32:56 --> Email Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:32:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:32:56 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:32:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:32:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:32:56 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:32:56 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:32:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:32:56 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:32:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:32:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:32:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:32:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:32:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:32:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:32:56 --> Final output sent to browser
DEBUG - 2015-02-04 13:32:56 --> Total execution time: 0.7781
DEBUG - 2015-02-04 13:33:24 --> Config Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:33:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:33:24 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:33:24 --> URI Class Initialized
DEBUG - 2015-02-04 13:33:24 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:33:24 --> Router Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Output Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Security Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Input Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:33:24 --> Language Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Loader Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:33:24 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:33:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:33:24 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:33:24 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:33:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Controller Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:33:24 --> Email Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:33:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:33:24 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:33:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:33:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:33:24 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:33:24 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:33:24 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:33:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:33:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:33:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:33:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:33:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:33:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:33:25 --> Final output sent to browser
DEBUG - 2015-02-04 13:33:25 --> Total execution time: 0.8431
DEBUG - 2015-02-04 13:33:35 --> Config Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:33:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:33:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:33:35 --> URI Class Initialized
DEBUG - 2015-02-04 13:33:35 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:33:35 --> Router Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Output Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Security Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Input Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:33:35 --> Language Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Loader Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:33:35 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:33:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:33:35 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:33:35 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:33:35 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Controller Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:33:35 --> Email Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:33:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:33:35 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:33:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:33:35 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:33:35 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:33:35 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Model Class Initialized
DEBUG - 2015-02-04 13:33:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:33:35 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:33:36 --> Final output sent to browser
DEBUG - 2015-02-04 13:33:36 --> Total execution time: 0.9361
DEBUG - 2015-02-04 13:34:05 --> Config Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:34:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:34:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:34:05 --> URI Class Initialized
DEBUG - 2015-02-04 13:34:05 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:34:05 --> Router Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Output Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Security Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Input Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:34:05 --> Language Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Loader Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:34:05 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:34:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:34:05 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:34:05 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:34:05 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Controller Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:34:05 --> Email Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:34:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:34:05 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:34:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:34:05 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:34:05 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:34:05 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:34:05 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:34:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:34:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:34:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:34:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:34:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:34:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:34:05 --> Final output sent to browser
DEBUG - 2015-02-04 13:34:05 --> Total execution time: 0.8601
DEBUG - 2015-02-04 13:34:19 --> Config Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:34:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:34:19 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:34:19 --> URI Class Initialized
DEBUG - 2015-02-04 13:34:19 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:34:19 --> Router Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Output Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Security Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Input Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:34:19 --> Language Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Loader Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:34:19 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:34:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:34:19 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:34:19 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:34:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Controller Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:34:19 --> Email Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:34:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:34:19 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:34:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:34:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:34:19 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:34:19 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Model Class Initialized
DEBUG - 2015-02-04 13:34:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:34:19 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:34:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:34:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:34:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:34:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:34:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:34:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:34:20 --> Final output sent to browser
DEBUG - 2015-02-04 13:34:20 --> Total execution time: 0.8051
DEBUG - 2015-02-04 13:36:18 --> Config Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:36:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:36:18 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:36:18 --> URI Class Initialized
DEBUG - 2015-02-04 13:36:18 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:36:18 --> Router Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Output Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Security Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Input Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:36:18 --> Language Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Loader Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:36:18 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:36:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:36:18 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:36:18 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:36:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Controller Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:36:18 --> Email Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:36:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:36:18 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:36:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:36:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:36:18 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:36:18 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:36:18 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:36:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:36:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:36:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:36:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:36:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:36:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:36:18 --> Final output sent to browser
DEBUG - 2015-02-04 13:36:18 --> Total execution time: 0.8381
DEBUG - 2015-02-04 13:36:29 --> Config Class Initialized
DEBUG - 2015-02-04 13:36:29 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:36:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:36:29 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:36:29 --> URI Class Initialized
DEBUG - 2015-02-04 13:36:29 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:36:29 --> Router Class Initialized
DEBUG - 2015-02-04 13:36:29 --> Output Class Initialized
DEBUG - 2015-02-04 13:36:29 --> Security Class Initialized
DEBUG - 2015-02-04 13:36:29 --> Input Class Initialized
DEBUG - 2015-02-04 13:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:36:29 --> Language Class Initialized
DEBUG - 2015-02-04 13:36:29 --> Loader Class Initialized
DEBUG - 2015-02-04 13:36:29 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:36:29 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:36:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:36:29 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:36:29 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:36:30 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Controller Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:36:30 --> Email Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:36:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:36:30 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:36:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:36:30 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:36:30 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:36:30 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Model Class Initialized
DEBUG - 2015-02-04 13:36:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:36:30 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:36:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:36:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:36:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:36:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:36:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:36:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:36:30 --> Final output sent to browser
DEBUG - 2015-02-04 13:36:30 --> Total execution time: 0.7851
DEBUG - 2015-02-04 13:37:20 --> Config Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:37:20 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:37:20 --> URI Class Initialized
DEBUG - 2015-02-04 13:37:20 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:37:20 --> Router Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Output Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Security Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Input Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:37:20 --> Language Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Loader Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:37:20 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:37:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:37:20 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:37:20 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:37:20 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Controller Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:37:20 --> Email Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:37:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:37:20 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:37:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:37:20 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:37:20 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:37:20 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:37:20 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:37:21 --> Final output sent to browser
DEBUG - 2015-02-04 13:37:21 --> Total execution time: 0.8431
DEBUG - 2015-02-04 13:37:56 --> Config Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:37:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:37:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:37:56 --> URI Class Initialized
DEBUG - 2015-02-04 13:37:56 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:37:56 --> Router Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Output Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Security Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Input Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:37:56 --> Language Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Loader Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:37:56 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:37:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:37:56 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:37:56 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:37:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Controller Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:37:56 --> Email Class Initialized
DEBUG - 2015-02-04 13:37:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:37:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:37:56 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:37:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:37:56 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:57 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:37:57 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:37:57 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:37:57 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:37:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:37:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:37:57 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:37:57 --> Final output sent to browser
DEBUG - 2015-02-04 13:37:57 --> Total execution time: 0.7951
DEBUG - 2015-02-04 13:38:43 --> Config Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:38:43 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:38:43 --> URI Class Initialized
DEBUG - 2015-02-04 13:38:43 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:38:43 --> Router Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Output Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Security Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Input Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:38:43 --> Language Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Loader Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:38:43 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:38:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:38:43 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:38:43 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:38:43 --> Model Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Model Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Controller Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:38:43 --> Email Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:38:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:38:43 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:38:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:38:43 --> Model Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:38:43 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:38:43 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Model Class Initialized
DEBUG - 2015-02-04 13:38:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:38:43 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:38:43 --> Final output sent to browser
DEBUG - 2015-02-04 13:38:43 --> Total execution time: 0.7711
DEBUG - 2015-02-04 13:39:49 --> Config Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:39:49 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:39:49 --> URI Class Initialized
DEBUG - 2015-02-04 13:39:49 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:39:49 --> Router Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Output Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Security Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Input Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:39:49 --> Language Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Loader Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:39:49 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:39:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:39:49 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:39:49 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:39:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Controller Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:39:49 --> Email Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:39:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:39:49 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:39:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:39:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:39:49 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:39:49 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:39:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:39:49 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:39:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:39:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:39:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:39:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:39:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:39:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:39:50 --> Final output sent to browser
DEBUG - 2015-02-04 13:39:50 --> Total execution time: 0.8681
DEBUG - 2015-02-04 13:40:01 --> Config Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:40:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:40:01 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:40:01 --> URI Class Initialized
DEBUG - 2015-02-04 13:40:01 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:40:01 --> Router Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Output Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Security Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Input Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:40:01 --> Language Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Loader Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:40:01 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:40:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:40:01 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:40:01 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:40:01 --> Model Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Model Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Controller Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:40:01 --> Email Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:40:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:40:01 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:40:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:40:01 --> Model Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:40:01 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:40:01 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Model Class Initialized
DEBUG - 2015-02-04 13:40:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:40:01 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:40:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:40:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:40:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:40:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:40:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:40:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:40:02 --> Final output sent to browser
DEBUG - 2015-02-04 13:40:02 --> Total execution time: 0.8231
DEBUG - 2015-02-04 13:42:00 --> Config Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:42:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:42:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:42:00 --> URI Class Initialized
DEBUG - 2015-02-04 13:42:00 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:42:00 --> Router Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Output Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Security Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Input Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:42:00 --> Language Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Loader Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:42:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:42:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:42:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:42:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:42:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Controller Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:42:00 --> Email Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:42:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:42:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:42:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:42:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:42:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:42:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:42:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:42:00 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:42:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:42:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:42:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:42:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:42:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:42:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:42:01 --> Final output sent to browser
DEBUG - 2015-02-04 13:42:01 --> Total execution time: 0.8361
DEBUG - 2015-02-04 13:43:29 --> Config Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:43:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:43:29 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:43:29 --> URI Class Initialized
DEBUG - 2015-02-04 13:43:29 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:43:29 --> Router Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Output Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Security Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Input Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:43:29 --> Language Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Loader Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:43:29 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:43:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:43:29 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:43:29 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:43:29 --> Model Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Model Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Controller Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:43:29 --> Email Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:43:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:43:29 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:43:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:43:29 --> Model Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:43:29 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:43:29 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Model Class Initialized
DEBUG - 2015-02-04 13:43:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:43:29 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:43:29 --> Final output sent to browser
DEBUG - 2015-02-04 13:43:29 --> Total execution time: 0.8261
DEBUG - 2015-02-04 13:44:04 --> Config Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:44:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:44:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:44:04 --> URI Class Initialized
DEBUG - 2015-02-04 13:44:04 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:44:04 --> Router Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Output Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Security Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Input Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:44:04 --> Language Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Loader Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:44:04 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:44:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:44:04 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:44:04 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:44:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Controller Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:44:04 --> Email Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:44:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:44:04 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:44:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:44:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:44:04 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:44:04 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:44:04 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:44:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:44:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:44:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:44:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:44:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:44:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:44:05 --> Final output sent to browser
DEBUG - 2015-02-04 13:44:05 --> Total execution time: 0.7881
DEBUG - 2015-02-04 13:44:31 --> Config Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:44:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:44:31 --> URI Class Initialized
DEBUG - 2015-02-04 13:44:31 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:44:31 --> Router Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Output Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Security Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Input Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:44:31 --> Language Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Loader Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:44:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:44:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:44:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:44:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:44:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Controller Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:44:31 --> Email Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:44:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:44:31 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:44:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:44:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:44:31 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:44:31 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:44:31 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:44:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:44:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:44:32 --> Final output sent to browser
DEBUG - 2015-02-04 13:44:32 --> Total execution time: 0.8471
DEBUG - 2015-02-04 13:44:50 --> Config Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:44:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:44:50 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:44:50 --> URI Class Initialized
DEBUG - 2015-02-04 13:44:50 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:44:50 --> Router Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Output Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Security Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Input Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:44:50 --> Language Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Loader Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:44:50 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:44:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:44:50 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:44:50 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Controller Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:44:50 --> Email Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:44:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:44:50 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:44:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:44:50 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:44:50 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:44:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:44:50 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:44:51 --> Final output sent to browser
DEBUG - 2015-02-04 13:44:51 --> Total execution time: 0.7781
DEBUG - 2015-02-04 13:45:04 --> Config Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:45:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:45:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:45:04 --> URI Class Initialized
DEBUG - 2015-02-04 13:45:04 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:45:04 --> Router Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Output Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Security Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Input Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:45:04 --> Language Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Loader Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:45:04 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:45:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:45:04 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:45:04 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:45:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Controller Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:45:04 --> Email Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:45:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:45:04 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:45:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:45:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:45:04 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:45:04 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:45:04 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:45:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:45:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:45:05 --> Final output sent to browser
DEBUG - 2015-02-04 13:45:05 --> Total execution time: 0.7841
DEBUG - 2015-02-04 13:45:10 --> Config Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:45:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:45:10 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:45:10 --> URI Class Initialized
DEBUG - 2015-02-04 13:45:10 --> No URI present. Default controller set.
DEBUG - 2015-02-04 13:45:10 --> Router Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Output Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Security Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Input Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:45:10 --> Language Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Loader Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:45:10 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:45:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:45:10 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:45:10 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:45:10 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Controller Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:45:10 --> Email Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:45:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:45:10 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:45:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:45:10 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:45:10 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:45:10 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-04 13:45:10 --> Pagination Class Initialized
DEBUG - 2015-02-04 13:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-04 13:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:45:10 --> Final output sent to browser
DEBUG - 2015-02-04 13:45:10 --> Total execution time: 0.7781
DEBUG - 2015-02-04 13:45:57 --> Config Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:45:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:45:57 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:45:57 --> URI Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Router Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Output Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Security Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Input Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:45:57 --> Language Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Loader Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:45:57 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:45:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:45:57 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:45:57 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:45:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Controller Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:45:57 --> Email Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:45:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:45:57 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:45:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:45:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:45:57 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:45:57 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:45:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:45:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:45:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:45:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-04 13:45:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:45:57 --> Final output sent to browser
DEBUG - 2015-02-04 13:45:57 --> Total execution time: 0.4210
DEBUG - 2015-02-04 13:46:06 --> Config Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:46:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:46:06 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:46:06 --> URI Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Router Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Output Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Security Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Input Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:46:06 --> Language Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Loader Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:46:06 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:46:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:46:06 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:46:06 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:46:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Controller Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:46:06 --> Email Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:46:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:46:06 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:46:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:46:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:46:06 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:46:06 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:46:06 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:46:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:46:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-04 13:46:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:46:06 --> Final output sent to browser
DEBUG - 2015-02-04 13:46:06 --> Total execution time: 0.3880
DEBUG - 2015-02-04 13:46:08 --> Config Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:46:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:46:08 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:46:08 --> URI Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Router Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Output Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Security Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Input Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:46:08 --> Language Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Loader Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:46:08 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:46:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:46:08 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:46:08 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:46:08 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Controller Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:46:08 --> Email Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:46:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:46:08 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:46:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:46:08 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:46:08 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:46:08 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:46:08 --> Model Class Initialized
DEBUG - 2015-02-04 13:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:46:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:46:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:46:09 --> Final output sent to browser
DEBUG - 2015-02-04 13:46:09 --> Total execution time: 0.8111
DEBUG - 2015-02-04 13:47:50 --> Config Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:47:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:47:50 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:47:50 --> URI Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Router Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Output Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Security Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Input Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:47:50 --> Language Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Loader Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:47:50 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:47:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:47:50 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:47:50 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:47:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Controller Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:47:50 --> Email Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:47:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:47:50 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:47:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:47:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:47:50 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:47:50 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:47:50 --> Model Class Initialized
DEBUG - 2015-02-04 13:47:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:47:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:47:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:47:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:47:50 --> Final output sent to browser
DEBUG - 2015-02-04 13:47:50 --> Total execution time: 0.7971
DEBUG - 2015-02-04 13:49:17 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:17 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:17 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:17 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:17 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:17 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:49:17 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:17 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:17 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:17 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:17 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:17 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:17 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:17 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:49:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 13:49:18 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:49:18 --> Severity: Error --> Call to a member function getSlugname() on a non-object D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
DEBUG - 2015-02-04 13:49:23 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:23 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:23 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:23 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:23 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:23 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:23 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:23 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:23 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:23 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:23 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:23 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:23 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:23 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:49:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:49:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:49:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:49:24 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:24 --> Total execution time: 0.8121
DEBUG - 2015-02-04 13:49:24 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:24 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:24 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:24 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:24 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:24 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:24 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:24 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:24 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:24 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:24 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:24 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:24 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:24 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:24 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:24 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:24 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:24 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:24 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:24 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:24 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:24 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:24 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:24 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:24 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:24 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:24 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:24 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:24 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:24 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:24 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:24 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:24 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:24 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:24 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:24 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:24 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:24 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:25 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:27 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:27 --> Total execution time: 3.4423
DEBUG - 2015-02-04 13:49:27 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:27 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:27 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:27 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:27 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:27 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:27 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:27 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:27 --> Total execution time: 3.5494
DEBUG - 2015-02-04 13:49:27 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:28 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:28 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:28 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:28 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:28 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:28 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:28 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:28 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:28 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:28 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:28 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:28 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:28 --> Total execution time: 3.6454
DEBUG - 2015-02-04 13:49:28 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:28 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:28 --> Total execution time: 3.8054
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:28 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:28 --> Total execution time: 3.8364
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:28 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:28 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:28 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:28 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:28 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:28 --> Total execution time: 4.0234
ERROR - 2015-02-04 13:49:29 --> Severity: Warning --> rename(D:\phutx\project\ups\myblog\application\/models/proxies\__CG__EntityUsers.php.54d1c0f9253c45.08490808,D:\phutx\project\ups\myblog\application\/models/proxies\__CG__EntityUsers.php): Access is denied. (code: 5) D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Proxy\ProxyFactory.php 194
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:29 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:29 --> Total execution time: 1.5102
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:29 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:29 --> Total execution time: 1.5962
DEBUG - 2015-02-04 13:49:32 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:32 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:32 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:32 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:32 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:32 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:32 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:32 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:32 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:33 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:33 --> Total execution time: 1.0261
DEBUG - 2015-02-04 13:49:40 --> Config Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:49:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:49:40 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:49:40 --> URI Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Router Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Output Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Security Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Input Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:49:40 --> Language Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Loader Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:49:40 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:49:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:49:40 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:49:40 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:49:40 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Controller Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:49:40 --> Email Class Initialized
DEBUG - 2015-02-04 13:49:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:49:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:49:40 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:49:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:49:41 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:49:41 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:49:41 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:49:41 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:49:41 --> Model Class Initialized
DEBUG - 2015-02-04 13:49:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 13:49:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 13:49:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 13:49:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 13:49:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 13:49:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 13:49:41 --> Final output sent to browser
DEBUG - 2015-02-04 13:49:41 --> Total execution time: 0.8801
DEBUG - 2015-02-04 13:50:12 --> Config Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:50:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:50:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:50:12 --> URI Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Router Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Output Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Security Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Input Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:50:12 --> Language Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Loader Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:50:12 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:50:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:50:12 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:50:12 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:50:12 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Controller Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:50:12 --> Email Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:50:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:50:12 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:50:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:50:12 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:50:12 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:50:12 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:50:12 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:50:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 13:50:13 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:13 --> Severity: Error --> Call to a member function getFile() on a non-object D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
DEBUG - 2015-02-04 13:50:21 --> Config Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:50:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:50:21 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:50:21 --> URI Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Router Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Output Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Security Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Input Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:50:21 --> Language Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Loader Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:50:21 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:50:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:50:21 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:50:21 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:50:21 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Controller Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:50:21 --> Email Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:50:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:50:21 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:50:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:50:21 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:50:21 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:50:21 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:50:21 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:50:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 13:50:21 --> Severity: 4096 --> Object of class Proxies\__CG__\Entity\Files could not be converted to string D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:21 --> Severity: 4096 --> Object of class Proxies\__CG__\Entity\Files could not be converted to string D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:21 --> Severity: 4096 --> Object of class Proxies\__CG__\Entity\Files could not be converted to string D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:21 --> Severity: 4096 --> Object of class Proxies\__CG__\Entity\Files could not be converted to string D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:21 --> Severity: 4096 --> Object of class Proxies\__CG__\Entity\Files could not be converted to string D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:21 --> Severity: 4096 --> Object of class Proxies\__CG__\Entity\Files could not be converted to string D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:21 --> Severity: 4096 --> Object of class Proxies\__CG__\Entity\Files could not be converted to string D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
ERROR - 2015-02-04 13:50:21 --> Severity: Error --> Call to a member function getFileName() on a non-object D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
DEBUG - 2015-02-04 13:50:49 --> Config Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:50:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:50:49 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:50:49 --> URI Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Router Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Output Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Security Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Input Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:50:49 --> Language Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Loader Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:50:49 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:50:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:50:49 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:50:49 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:50:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Controller Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:50:49 --> Email Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:50:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:50:49 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:50:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:50:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:50:49 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:50:49 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:50:49 --> Model Class Initialized
DEBUG - 2015-02-04 13:50:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:50:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 13:50:50 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) D:\phutx\project\ups\myblog\application\views\admin\article\index.php 33
DEBUG - 2015-02-04 13:51:13 --> Config Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:51:13 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:51:13 --> URI Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Router Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Output Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Security Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Input Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:51:13 --> Language Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Loader Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:51:13 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:51:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:51:13 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:51:13 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:51:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Controller Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:51:13 --> Email Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:51:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:51:13 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:51:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:51:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:51:13 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:51:13 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:51:13 --> Model Class Initialized
DEBUG - 2015-02-04 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:51:13 --> Final output sent to browser
DEBUG - 2015-02-04 13:51:13 --> Total execution time: 0.7751
DEBUG - 2015-02-04 13:53:16 --> Config Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:53:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:53:16 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:53:16 --> URI Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Router Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Output Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Security Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Input Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:53:16 --> Language Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Loader Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:53:16 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:53:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:53:16 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:53:16 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:53:16 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Controller Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:53:16 --> Email Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:53:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:53:16 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:53:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:53:16 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:53:16 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:53:16 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:53:16 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:53:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:53:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:53:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:53:17 --> Final output sent to browser
DEBUG - 2015-02-04 13:53:17 --> Total execution time: 0.7891
DEBUG - 2015-02-04 13:53:57 --> Config Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:53:57 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:53:57 --> URI Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Router Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Output Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Security Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Input Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:53:57 --> Language Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Loader Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:53:57 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:53:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:53:57 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:53:57 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:53:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Controller Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:53:57 --> Email Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:53:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:53:57 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:53:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:53:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:53:57 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:53:57 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:53:57 --> Model Class Initialized
DEBUG - 2015-02-04 13:53:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:53:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:53:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:53:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:53:58 --> Final output sent to browser
DEBUG - 2015-02-04 13:53:58 --> Total execution time: 0.8451
DEBUG - 2015-02-04 13:55:00 --> Config Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:55:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:55:00 --> URI Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Router Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Output Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Security Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Input Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:55:00 --> Language Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Loader Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:55:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:55:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:55:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Session: Regenerate ID
DEBUG - 2015-02-04 13:55:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:55:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Controller Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:55:00 --> Email Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:55:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:55:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:55:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:55:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:55:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:55:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:55:00 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:55:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:55:01 --> Final output sent to browser
DEBUG - 2015-02-04 13:55:01 --> Total execution time: 0.8241
DEBUG - 2015-02-04 13:55:28 --> Config Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:55:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:55:28 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:55:28 --> URI Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Router Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Output Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Security Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Input Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:55:28 --> Language Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Loader Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:55:28 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:55:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:55:28 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:55:28 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:55:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Controller Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:55:28 --> Email Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:55:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:55:28 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:55:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:55:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:55:28 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:55:28 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:55:28 --> Model Class Initialized
DEBUG - 2015-02-04 13:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:55:28 --> Final output sent to browser
DEBUG - 2015-02-04 13:55:28 --> Total execution time: 0.7841
DEBUG - 2015-02-04 13:56:06 --> Config Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:56:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:56:06 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:56:06 --> URI Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Router Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Output Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Security Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Input Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:56:06 --> Language Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Loader Class Initialized
DEBUG - 2015-02-04 13:56:06 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:56:06 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:56:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:56:06 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:56:06 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:56:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:07 --> Controller Class Initialized
DEBUG - 2015-02-04 13:56:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:56:07 --> Email Class Initialized
DEBUG - 2015-02-04 13:56:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:56:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:56:07 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:56:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:56:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:07 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:56:07 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:56:07 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:56:07 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:56:07 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:56:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:56:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:56:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:56:07 --> Final output sent to browser
DEBUG - 2015-02-04 13:56:07 --> Total execution time: 0.7801
DEBUG - 2015-02-04 13:56:22 --> Config Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:56:22 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:56:22 --> URI Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Router Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Output Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Security Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Input Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:56:22 --> Language Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Loader Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:56:22 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:56:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:56:22 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:56:22 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:56:22 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Controller Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:56:22 --> Email Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:56:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:56:22 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:56:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:56:22 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:56:22 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:56:22 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:56:22 --> Model Class Initialized
DEBUG - 2015-02-04 13:56:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:56:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:56:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:56:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:56:23 --> Final output sent to browser
DEBUG - 2015-02-04 13:56:23 --> Total execution time: 0.8621
DEBUG - 2015-02-04 13:57:02 --> Config Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:57:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:57:02 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:57:02 --> URI Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Router Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Output Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Security Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Input Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:57:02 --> Language Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Loader Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:57:02 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:57:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:57:02 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:57:02 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:57:02 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Controller Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:57:02 --> Email Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:57:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:57:02 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:57:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:57:02 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:57:02 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:57:02 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:57:02 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:57:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:57:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:57:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:57:03 --> Final output sent to browser
DEBUG - 2015-02-04 13:57:03 --> Total execution time: 0.8131
DEBUG - 2015-02-04 13:57:11 --> Config Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Hooks Class Initialized
DEBUG - 2015-02-04 13:57:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 13:57:11 --> Utf8 Class Initialized
DEBUG - 2015-02-04 13:57:11 --> URI Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Router Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Output Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Security Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Input Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 13:57:11 --> Language Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Loader Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Helper loaded: url_helper
DEBUG - 2015-02-04 13:57:11 --> Helper loaded: link_helper
DEBUG - 2015-02-04 13:57:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 13:57:11 --> CI_Session Class Initialized
DEBUG - 2015-02-04 13:57:11 --> CI_Session routines successfully run
DEBUG - 2015-02-04 13:57:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Controller Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 13:57:11 --> Email Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 13:57:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 13:57:11 --> Helper loaded: language_helper
DEBUG - 2015-02-04 13:57:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 13:57:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Database Driver Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Helper loaded: date_helper
DEBUG - 2015-02-04 13:57:11 --> Helper loaded: form_helper
DEBUG - 2015-02-04 13:57:11 --> Form Validation Class Initialized
DEBUG - 2015-02-04 13:57:11 --> Model Class Initialized
DEBUG - 2015-02-04 13:57:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 13:57:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 13:57:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 13:57:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 13:57:12 --> Final output sent to browser
DEBUG - 2015-02-04 13:57:12 --> Total execution time: 0.8561
DEBUG - 2015-02-04 14:01:13 --> Config Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:01:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:01:13 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:01:13 --> URI Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Router Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Output Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Security Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Input Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:01:13 --> Language Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Loader Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:01:13 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:01:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:01:13 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Session: Regenerate ID
DEBUG - 2015-02-04 14:01:13 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:01:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Controller Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:01:13 --> Email Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:01:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:01:13 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:01:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:01:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:01:13 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:01:13 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:01:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:04:25 --> Config Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:04:25 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:04:25 --> URI Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Router Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Output Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Security Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Input Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:04:25 --> Language Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Loader Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:04:25 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:04:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:04:25 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:04:25 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:04:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Controller Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:04:25 --> Email Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:04:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:04:25 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:04:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:04:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:04:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:04:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:04:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:04:25 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getCat() must be an instance of Entity\ArticleCategories, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 42 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 24
ERROR - 2015-02-04 14:04:26 --> Severity: 4096 --> Argument 1 passed to getTag() must be an instance of Entity\ArticleTags, array given, called in D:\phutx\project\ups\myblog\application\views\admin\article\index.php on line 43 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-04 14:04:26 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:26 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
DEBUG - 2015-02-04 14:04:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:04:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:04:26 --> Final output sent to browser
DEBUG - 2015-02-04 14:04:26 --> Total execution time: 1.0551
DEBUG - 2015-02-04 14:04:54 --> Config Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:04:54 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:04:54 --> URI Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Router Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Output Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Security Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Input Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:04:54 --> Language Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Loader Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:04:54 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:04:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:04:54 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:04:54 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:04:54 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Controller Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:04:54 --> Email Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:04:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:04:54 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:04:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:04:54 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:04:54 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:04:54 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:04:54 --> Model Class Initialized
DEBUG - 2015-02-04 14:04:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:04:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Notice --> Undefined variable: return D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
ERROR - 2015-02-04 14:04:55 --> Severity: Warning --> implode(): Invalid arguments passed D:\phutx\project\ups\myblog\application\helpers\link_helper.php 36
DEBUG - 2015-02-04 14:04:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:04:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:04:55 --> Final output sent to browser
DEBUG - 2015-02-04 14:04:55 --> Total execution time: 1.0151
DEBUG - 2015-02-04 14:05:25 --> Config Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:05:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:05:25 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:05:25 --> URI Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Router Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Output Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Security Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Input Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:05:25 --> Language Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Loader Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:05:25 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:05:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:05:25 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:05:25 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:05:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Controller Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:05:25 --> Email Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:05:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:05:25 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:05:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:05:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:05:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:05:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:05:25 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:05:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:05:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:05:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:05:26 --> Final output sent to browser
DEBUG - 2015-02-04 14:05:26 --> Total execution time: 1.0171
DEBUG - 2015-02-04 14:05:35 --> Config Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:05:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:05:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:05:35 --> URI Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Router Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Output Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Security Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Input Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:05:35 --> Language Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Loader Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:05:35 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:05:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:05:35 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:05:35 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:05:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Controller Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:05:35 --> Email Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:05:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:05:35 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:05:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:05:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:05:35 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:05:35 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:05:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:05:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:05:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:05:36 --> Final output sent to browser
DEBUG - 2015-02-04 14:05:36 --> Total execution time: 1.0861
DEBUG - 2015-02-04 14:07:56 --> Config Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:07:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:07:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:07:56 --> URI Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Router Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Output Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Security Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Input Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:07:56 --> Language Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Loader Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:07:56 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:07:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:07:56 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Session: Regenerate ID
DEBUG - 2015-02-04 14:07:56 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:07:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Controller Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:07:56 --> Email Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:07:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:07:56 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:07:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:07:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:07:56 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:07:56 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:07:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:07:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:07:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:07:57 --> Final output sent to browser
DEBUG - 2015-02-04 14:07:57 --> Total execution time: 1.0331
DEBUG - 2015-02-04 14:08:51 --> Config Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:08:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:08:51 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:08:51 --> URI Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Router Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Output Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Security Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Input Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:08:51 --> Language Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Loader Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:08:51 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:08:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:08:51 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:08:51 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:08:51 --> Model Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Model Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Controller Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:08:51 --> Email Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:08:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:08:51 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:08:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:08:51 --> Model Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:08:51 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:08:51 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:08:51 --> Model Class Initialized
DEBUG - 2015-02-04 14:08:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:08:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:08:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:08:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:08:52 --> Final output sent to browser
DEBUG - 2015-02-04 14:08:52 --> Total execution time: 1.0211
DEBUG - 2015-02-04 14:09:21 --> Config Class Initialized
DEBUG - 2015-02-04 14:09:21 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:09:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:09:22 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:09:22 --> URI Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Router Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Output Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Security Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Input Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:09:22 --> Language Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Loader Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:09:22 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:09:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:09:22 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:09:22 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:09:22 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Controller Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:09:22 --> Email Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:09:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:09:22 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:09:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:09:22 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:09:22 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:09:22 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:09:22 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:09:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:09:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:09:23 --> Final output sent to browser
DEBUG - 2015-02-04 14:09:23 --> Total execution time: 1.0231
DEBUG - 2015-02-04 14:09:26 --> Config Class Initialized
DEBUG - 2015-02-04 14:09:26 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:09:26 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:09:27 --> URI Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Router Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Output Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Security Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Input Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:09:27 --> Language Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Loader Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:09:27 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:09:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:09:27 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:09:27 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:09:27 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Controller Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:09:27 --> Email Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:09:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:09:27 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:09:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:09:27 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:09:27 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:09:27 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:09:27 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:09:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:09:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:09:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:09:28 --> Final output sent to browser
DEBUG - 2015-02-04 14:09:28 --> Total execution time: 1.0241
DEBUG - 2015-02-04 14:09:31 --> Config Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:09:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:09:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:09:31 --> URI Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Router Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Output Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Security Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Input Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:09:31 --> Language Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Loader Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:09:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:09:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:09:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:09:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Controller Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:09:31 --> Email Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:09:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:09:31 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:09:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:09:31 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:09:31 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:09:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:09:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:09:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:09:32 --> Final output sent to browser
DEBUG - 2015-02-04 14:09:32 --> Total execution time: 1.1101
DEBUG - 2015-02-04 14:09:42 --> Config Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:09:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:09:42 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:09:42 --> URI Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Router Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Output Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Security Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Input Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:09:42 --> Language Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Loader Class Initialized
DEBUG - 2015-02-04 14:09:42 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:09:42 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:09:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:09:42 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:09:42 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:09:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:43 --> Controller Class Initialized
DEBUG - 2015-02-04 14:09:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:09:43 --> Email Class Initialized
DEBUG - 2015-02-04 14:09:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:09:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:09:43 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:09:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:09:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:43 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:09:43 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:09:43 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:09:43 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:09:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:09:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:09:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:09:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:09:43 --> Final output sent to browser
DEBUG - 2015-02-04 14:09:43 --> Total execution time: 0.9921
DEBUG - 2015-02-04 14:09:48 --> Config Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:09:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:09:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:09:48 --> URI Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Router Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Output Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Security Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Input Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:09:48 --> Language Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Loader Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:09:48 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:09:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:09:48 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:09:48 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:09:48 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Controller Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:09:48 --> Email Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:09:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:09:48 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:09:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:09:48 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:09:48 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:09:48 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:09:48 --> Model Class Initialized
DEBUG - 2015-02-04 14:09:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:09:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:09:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:09:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:09:49 --> Final output sent to browser
DEBUG - 2015-02-04 14:09:49 --> Total execution time: 1.0121
DEBUG - 2015-02-04 14:24:50 --> Config Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:24:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:24:50 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:24:50 --> URI Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Router Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Output Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Security Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Input Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:24:50 --> Language Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Loader Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:24:50 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:24:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:24:50 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Session: Regenerate ID
DEBUG - 2015-02-04 14:24:50 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:24:50 --> Model Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Model Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Controller Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:24:50 --> Email Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:24:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:24:50 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:24:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:24:50 --> Model Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:24:50 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:24:50 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:24:50 --> Model Class Initialized
DEBUG - 2015-02-04 14:24:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:24:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:24:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:24:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:24:51 --> Final output sent to browser
DEBUG - 2015-02-04 14:24:51 --> Total execution time: 1.0251
DEBUG - 2015-02-04 14:32:08 --> Config Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:32:08 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:32:08 --> URI Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Router Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Output Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Security Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Input Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:32:08 --> Language Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Loader Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:32:08 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:32:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:32:08 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Session: Regenerate ID
DEBUG - 2015-02-04 14:32:08 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:32:08 --> Model Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Model Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Controller Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:32:08 --> Email Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:32:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:32:08 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:32:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:32:08 --> Model Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:32:08 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:32:08 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:32:08 --> Model Class Initialized
DEBUG - 2015-02-04 14:32:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:32:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:32:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:32:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:32:09 --> Final output sent to browser
DEBUG - 2015-02-04 14:32:09 --> Total execution time: 1.1161
DEBUG - 2015-02-04 14:35:38 --> Config Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:35:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:35:38 --> URI Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Router Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Output Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Security Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Input Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:35:38 --> Language Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Loader Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:35:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:35:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:35:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:35:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:35:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Controller Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:35:38 --> Email Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:35:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:35:38 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:35:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:35:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:35:38 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:35:38 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:35:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:35:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:35:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:35:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:35:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:35:39 --> Final output sent to browser
DEBUG - 2015-02-04 14:35:39 --> Total execution time: 0.9941
DEBUG - 2015-02-04 14:41:03 --> Config Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:41:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:41:03 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:41:03 --> URI Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Router Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Output Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Security Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Input Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:41:03 --> Language Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Loader Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:41:03 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:41:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:41:03 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Session: Regenerate ID
DEBUG - 2015-02-04 14:41:03 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:41:03 --> Model Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Model Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Controller Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:41:03 --> Email Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:41:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:41:03 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:41:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:41:03 --> Model Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:41:03 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:41:03 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:41:03 --> Model Class Initialized
DEBUG - 2015-02-04 14:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:41:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-04 14:41:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:41:04 --> Final output sent to browser
DEBUG - 2015-02-04 14:41:04 --> Total execution time: 1.0231
DEBUG - 2015-02-04 14:41:20 --> Config Class Initialized
DEBUG - 2015-02-04 14:41:20 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:41:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:41:20 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:41:20 --> URI Class Initialized
DEBUG - 2015-02-04 14:41:20 --> Router Class Initialized
DEBUG - 2015-02-04 14:41:20 --> Output Class Initialized
DEBUG - 2015-02-04 14:41:20 --> Security Class Initialized
DEBUG - 2015-02-04 14:41:20 --> Input Class Initialized
DEBUG - 2015-02-04 14:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:41:20 --> Language Class Initialized
ERROR - 2015-02-04 14:41:20 --> 404 Page Not Found: admin/Files/index
DEBUG - 2015-02-04 14:41:32 --> Config Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:41:32 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:41:32 --> URI Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Router Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Output Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Security Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Input Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:41:32 --> Language Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Loader Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:41:32 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:41:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:41:32 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:41:32 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:41:32 --> Model Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Model Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Controller Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:41:32 --> Email Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:41:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:41:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:41:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:41:32 --> Model Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:41:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:41:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:41:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Config Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:42:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:42:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:42:31 --> URI Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Router Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Output Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Security Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Input Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:42:31 --> Language Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Loader Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:42:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:42:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:42:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:42:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:42:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Controller Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:42:31 --> Email Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:42:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:42:31 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:42:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:42:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:42:31 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:42:31 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:42:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:42:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:42:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:42:31 --> Severity: Error --> Call to undefined method Entity\Files::getFile() D:\phutx\project\ups\myblog\application\views\admin\file\index.php 32
DEBUG - 2015-02-04 14:49:38 --> Config Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:49:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:49:38 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:49:38 --> URI Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Router Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Output Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Security Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Input Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:49:38 --> Language Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Loader Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:49:38 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:49:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:49:38 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Session: Regenerate ID
DEBUG - 2015-02-04 14:49:38 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:49:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Controller Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:49:38 --> Email Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:49:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:49:38 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:49:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:49:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:49:38 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:49:38 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:49:38 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\system\core\Exceptions.php:272) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-04 14:49:38 --> Severity: Error --> Call to undefined method Entity\Files::getArtices() D:\phutx\project\ups\myblog\application\views\admin\file\index.php 39
DEBUG - 2015-02-04 14:49:56 --> Config Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:49:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:49:56 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:49:56 --> URI Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Router Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Output Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Security Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Input Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:49:56 --> Language Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Loader Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:49:56 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:49:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:49:56 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:49:56 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Controller Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:49:56 --> Email Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:49:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:49:56 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:49:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:49:56 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:49:56 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-04 14:49:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:49:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:49:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\system\core\Exceptions.php:272) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-04 14:49:57 --> Severity: Error --> Call to undefined method Proxies\__CG__\Entity\Articles::toArray() D:\phutx\project\ups\myblog\application\models\Entity\Files.php 252
DEBUG - 2015-02-04 14:51:31 --> Config Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:51:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:51:31 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:51:31 --> URI Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Router Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Output Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Security Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Input Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:51:31 --> Language Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Loader Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:51:31 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:51:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:51:31 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:51:31 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:51:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Controller Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:51:31 --> Email Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:51:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:51:31 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:51:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:51:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:51:31 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:51:31 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:51:31 --> Model Class Initialized
DEBUG - 2015-02-04 14:51:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:51:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Notice --> Undefined index: file_id D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\UnitOfWork.php 2539
ERROR - 2015-02-04 14:51:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\system\core\Exceptions.php:272) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-04 14:51:31 --> Severity: Error --> Call to undefined method Proxies\__CG__\Entity\Articles::toArray() D:\phutx\project\ups\myblog\application\models\Entity\Files.php 252
DEBUG - 2015-02-04 14:52:12 --> Config Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:52:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:52:12 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:52:12 --> URI Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Router Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Output Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Security Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Input Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:52:12 --> Language Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Loader Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:52:12 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:52:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:52:12 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:52:12 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:52:12 --> Model Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Model Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Controller Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:52:12 --> Email Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:52:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:52:12 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:52:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:52:12 --> Model Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:52:12 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:52:12 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:52:12 --> Model Class Initialized
DEBUG - 2015-02-04 14:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:52:12 --> Severity: Error --> Call to undefined method Entity\Articles::toArray() D:\phutx\project\ups\myblog\application\models\Entity\Files.php 249
DEBUG - 2015-02-04 14:53:00 --> Config Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:53:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:53:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:53:00 --> URI Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Router Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Output Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Security Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Input Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:53:00 --> Language Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Loader Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:53:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:53:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:53:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:53:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:53:00 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Controller Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:53:00 --> Email Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:53:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:53:00 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:53:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:53:00 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:53:00 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:53:00 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:53:00 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:53:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:53:01 --> Severity: Error --> Call to undefined method Entity\Articles::toArray() D:\phutx\project\ups\myblog\application\models\Entity\Files.php 249
DEBUG - 2015-02-04 14:53:21 --> Config Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:53:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:53:21 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:53:21 --> URI Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Router Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Output Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Security Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Input Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:53:21 --> Language Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Loader Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:53:21 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:53:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:53:21 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:53:21 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:53:21 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Controller Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:53:21 --> Email Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:53:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:53:21 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:53:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:53:21 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:53:21 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:53:21 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:53:21 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:53:22 --> Severity: Error --> Call to undefined method Entity\Files::getSlugName() D:\phutx\project\ups\myblog\application\views\admin\file\index.php 41
DEBUG - 2015-02-04 14:53:43 --> Config Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:53:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:53:43 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:53:43 --> URI Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Router Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Output Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Security Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Input Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:53:43 --> Language Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Loader Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:53:43 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:53:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:53:43 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:53:43 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:53:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Controller Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:53:43 --> Email Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:53:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:53:43 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:53:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:53:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:53:43 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:53:43 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:53:43 --> Model Class Initialized
DEBUG - 2015-02-04 14:53:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:53:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:53:44 --> Severity: Error --> Call to a member function getTitle() on a non-object D:\phutx\project\ups\myblog\application\views\admin\file\index.php 39
DEBUG - 2015-02-04 14:54:13 --> Config Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:54:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:54:13 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:54:13 --> URI Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Router Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Output Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Security Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Input Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:54:13 --> Language Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Loader Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:54:13 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:54:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:54:13 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:54:13 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:54:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Controller Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:54:13 --> Email Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:54:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:54:13 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:54:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:54:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:54:13 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:54:13 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:54:13 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:54:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 14:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:54:14 --> Final output sent to browser
DEBUG - 2015-02-04 14:54:14 --> Total execution time: 0.7791
DEBUG - 2015-02-04 14:54:35 --> Config Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:54:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:54:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:54:35 --> URI Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Router Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Output Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Security Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Input Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:54:35 --> Language Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Loader Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:54:35 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:54:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:54:35 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:54:35 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:54:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Controller Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:54:35 --> Email Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:54:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:54:35 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:54:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:54:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:54:35 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:54:35 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:54:35 --> Model Class Initialized
DEBUG - 2015-02-04 14:54:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:54:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 14:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:54:36 --> Final output sent to browser
DEBUG - 2015-02-04 14:54:36 --> Total execution time: 0.7891
DEBUG - 2015-02-04 14:55:00 --> Config Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:55:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:55:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:55:00 --> URI Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Router Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Output Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Security Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Input Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:55:00 --> Language Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Loader Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:55:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:55:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:55:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:55:00 --> Session: Regenerate ID
DEBUG - 2015-02-04 14:55:00 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:55:01 --> Model Class Initialized
DEBUG - 2015-02-04 14:55:01 --> Model Class Initialized
DEBUG - 2015-02-04 14:55:01 --> Controller Class Initialized
DEBUG - 2015-02-04 14:55:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:55:01 --> Email Class Initialized
DEBUG - 2015-02-04 14:55:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:55:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:55:01 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:55:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:55:01 --> Model Class Initialized
DEBUG - 2015-02-04 14:55:01 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:55:01 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:55:01 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:55:01 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:55:01 --> Model Class Initialized
ERROR - 2015-02-04 14:55:01 --> Severity: Error --> Call to undefined method File_model::getBySlugName() D:\phutx\project\ups\myblog\application\models\File_model.php 22
DEBUG - 2015-02-04 14:55:33 --> Config Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:55:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:55:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:55:33 --> URI Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Router Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Output Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Security Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Input Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:55:33 --> Language Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Loader Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:55:33 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:55:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:55:33 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:55:33 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:55:33 --> Model Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Model Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Controller Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:55:33 --> Email Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:55:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:55:33 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:55:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:55:33 --> Model Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:55:33 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:55:33 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:55:33 --> Model Class Initialized
ERROR - 2015-02-04 14:55:33 --> Severity: Error --> Call to undefined method File_model::getBySlugName() D:\phutx\project\ups\myblog\application\models\File_model.php 22
DEBUG - 2015-02-04 14:56:10 --> Config Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:56:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:56:10 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:56:10 --> URI Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Router Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Output Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Security Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Input Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:56:10 --> Language Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Loader Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:56:10 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:56:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:56:10 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:56:10 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:56:10 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Controller Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:56:10 --> Email Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:56:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:56:10 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:56:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:56:10 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:56:10 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:56:10 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:56:10 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Config Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:56:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:56:11 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:56:11 --> URI Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Router Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Output Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Security Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Input Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:56:11 --> Language Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Loader Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:56:11 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:56:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:56:11 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:56:11 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:56:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Controller Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:56:11 --> Email Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:56:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:56:11 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:56:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:56:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:56:11 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:56:11 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:56:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:56:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:56:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 14:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:56:12 --> Final output sent to browser
DEBUG - 2015-02-04 14:56:12 --> Total execution time: 0.7721
DEBUG - 2015-02-04 14:58:00 --> Config Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:58:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:58:00 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:58:00 --> URI Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Router Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Output Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Security Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Input Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:58:00 --> Language Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Loader Class Initialized
DEBUG - 2015-02-04 14:58:00 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:58:00 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:58:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:58:00 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:58:01 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:58:01 --> Model Class Initialized
DEBUG - 2015-02-04 14:58:01 --> Model Class Initialized
DEBUG - 2015-02-04 14:58:01 --> Controller Class Initialized
DEBUG - 2015-02-04 14:58:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:58:01 --> Email Class Initialized
DEBUG - 2015-02-04 14:58:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:58:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:58:01 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:58:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:58:01 --> Model Class Initialized
DEBUG - 2015-02-04 14:58:01 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:58:01 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:58:01 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:58:01 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:58:01 --> Model Class Initialized
DEBUG - 2015-02-04 14:58:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:58:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 14:58:01 --> Severity: Error --> Call to undefined method File_model::getBySlugName() D:\phutx\project\ups\myblog\application\controllers\admin\Files.php 31
DEBUG - 2015-02-04 14:59:11 --> Config Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Hooks Class Initialized
DEBUG - 2015-02-04 14:59:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 14:59:11 --> Utf8 Class Initialized
DEBUG - 2015-02-04 14:59:11 --> URI Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Router Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Output Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Security Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Input Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 14:59:11 --> Language Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Loader Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Helper loaded: url_helper
DEBUG - 2015-02-04 14:59:11 --> Helper loaded: link_helper
DEBUG - 2015-02-04 14:59:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 14:59:11 --> CI_Session Class Initialized
DEBUG - 2015-02-04 14:59:11 --> CI_Session routines successfully run
DEBUG - 2015-02-04 14:59:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Controller Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 14:59:11 --> Email Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 14:59:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 14:59:11 --> Helper loaded: language_helper
DEBUG - 2015-02-04 14:59:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 14:59:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Database Driver Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Helper loaded: date_helper
DEBUG - 2015-02-04 14:59:11 --> Helper loaded: form_helper
DEBUG - 2015-02-04 14:59:11 --> Form Validation Class Initialized
DEBUG - 2015-02-04 14:59:11 --> Model Class Initialized
DEBUG - 2015-02-04 14:59:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 14:59:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 14:59:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 14:59:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 14:59:12 --> Final output sent to browser
DEBUG - 2015-02-04 14:59:12 --> Total execution time: 0.8001
DEBUG - 2015-02-04 15:00:07 --> Config Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:00:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:00:07 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:00:07 --> URI Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Router Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Output Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Security Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Input Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:00:07 --> Language Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Loader Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:00:07 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:00:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:00:07 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Session: Regenerate ID
DEBUG - 2015-02-04 15:00:07 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:00:07 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Controller Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:00:07 --> Email Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:00:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:00:07 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:00:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:00:07 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:00:07 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:00:07 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:00:07 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Config Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:00:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:00:08 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:00:08 --> URI Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Router Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Output Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Security Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Input Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:00:08 --> Language Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Loader Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:00:08 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:00:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:00:08 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:00:08 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:00:08 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Controller Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:00:08 --> Email Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:00:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:00:08 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:00:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:00:08 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:00:08 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:00:08 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:00:08 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:00:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:00:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 15:00:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:00:08 --> Final output sent to browser
DEBUG - 2015-02-04 15:00:08 --> Total execution time: 0.8081
DEBUG - 2015-02-04 15:00:44 --> Config Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:00:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:00:44 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:00:44 --> URI Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Router Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Output Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Security Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Input Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:00:44 --> Language Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Loader Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:00:44 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:00:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:00:44 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:00:44 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:00:44 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Controller Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:00:44 --> Email Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:00:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:00:44 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:00:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:00:44 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:00:44 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:00:44 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:00:44 --> Model Class Initialized
DEBUG - 2015-02-04 15:00:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:00:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:00:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 15:00:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:00:45 --> Final output sent to browser
DEBUG - 2015-02-04 15:00:45 --> Total execution time: 0.8201
DEBUG - 2015-02-04 15:01:04 --> Config Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:01:04 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:01:04 --> URI Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Router Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Output Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Security Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Input Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:01:04 --> Language Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Loader Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:01:04 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:01:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:01:04 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:01:04 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Controller Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:01:04 --> Email Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:01:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:01:04 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:01:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:01:04 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:01:04 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:01:04 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Config Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:01:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:01:05 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:01:05 --> URI Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Router Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Output Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Security Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Input Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:01:05 --> Language Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Loader Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:01:05 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:01:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:01:05 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:01:05 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:01:05 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Controller Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:01:05 --> Email Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:01:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:01:05 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:01:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:01:05 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:01:05 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:01:05 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:01:05 --> Model Class Initialized
DEBUG - 2015-02-04 15:01:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:01:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:01:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 15:01:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:01:06 --> Final output sent to browser
DEBUG - 2015-02-04 15:01:06 --> Total execution time: 0.7481
DEBUG - 2015-02-04 15:08:28 --> Config Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:08:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:08:28 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:08:28 --> URI Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Router Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Output Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Security Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Input Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:08:28 --> Language Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Loader Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:08:28 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:08:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:08:28 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Session: Regenerate ID
DEBUG - 2015-02-04 15:08:28 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:08:28 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Controller Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:08:28 --> Email Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:08:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:08:28 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:08:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:08:28 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:08:28 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:08:28 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:08:28 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:08:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 15:08:28 --> Severity: Error --> Call to undefined method File_model::getBySlugName() D:\phutx\project\ups\myblog\application\controllers\admin\Files.php 31
DEBUG - 2015-02-04 15:08:44 --> Config Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:08:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:08:44 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:08:44 --> URI Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Router Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Output Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Security Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Input Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:08:44 --> Language Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Loader Class Initialized
DEBUG - 2015-02-04 15:08:44 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:08:44 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:08:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:08:45 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:08:45 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:45 --> Controller Class Initialized
DEBUG - 2015-02-04 15:08:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:08:45 --> Email Class Initialized
DEBUG - 2015-02-04 15:08:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:08:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:08:45 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:08:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:45 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:08:45 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:08:45 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:08:45 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:08:45 --> Model Class Initialized
DEBUG - 2015-02-04 15:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 15:08:45 --> Severity: Error --> Call to undefined method File_model::getBySlugName() D:\phutx\project\ups\myblog\application\controllers\admin\Files.php 31
DEBUG - 2015-02-04 15:09:25 --> Config Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:09:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:09:25 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:09:25 --> URI Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Router Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Output Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Security Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Input Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:09:25 --> Language Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Loader Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:09:25 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:09:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:09:25 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:09:25 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:09:25 --> Model Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Model Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Controller Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:09:25 --> Email Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:09:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:09:25 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:09:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:09:25 --> Model Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:09:25 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:09:25 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:09:25 --> Model Class Initialized
DEBUG - 2015-02-04 15:09:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:09:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 15:09:25 --> Severity: Notice --> Undefined variable: action D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 3
ERROR - 2015-02-04 15:09:25 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 6
ERROR - 2015-02-04 15:09:25 --> Severity: Error --> Call to a member function getTitle() on a non-object D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 6
DEBUG - 2015-02-04 15:11:09 --> Config Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:11:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:11:09 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:11:09 --> URI Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Router Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Output Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Security Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Input Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:11:09 --> Language Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Loader Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:11:09 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:11:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:11:09 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:11:09 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:11:09 --> Model Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Model Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Controller Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:11:09 --> Email Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:11:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:11:09 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:11:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:11:09 --> Model Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:11:09 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:11:09 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:11:09 --> Model Class Initialized
DEBUG - 2015-02-04 15:11:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:11:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 15:11:09 --> Severity: Notice --> Undefined variable: action D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 3
ERROR - 2015-02-04 15:11:09 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 6
ERROR - 2015-02-04 15:11:09 --> Severity: Error --> Call to a member function getTitle() on a non-object D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 6
DEBUG - 2015-02-04 15:12:55 --> Config Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:12:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:12:55 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:12:55 --> URI Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Router Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Output Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Security Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Input Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:12:55 --> Language Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Loader Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:12:55 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:12:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:12:55 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:12:55 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:12:55 --> Model Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Model Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Controller Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:12:55 --> Email Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:12:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:12:55 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:12:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:12:55 --> Model Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:12:55 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:12:55 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:12:55 --> Model Class Initialized
DEBUG - 2015-02-04 15:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-04 15:12:55 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 6
ERROR - 2015-02-04 15:12:55 --> Severity: Error --> Call to a member function getTitle() on a non-object D:\phutx\project\ups\myblog\application\views\admin\file\edit.php 6
DEBUG - 2015-02-04 15:13:32 --> Config Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:13:32 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:13:32 --> URI Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Router Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Output Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Security Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Input Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:13:32 --> Language Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Loader Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:13:32 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:13:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:13:32 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Session: Regenerate ID
DEBUG - 2015-02-04 15:13:32 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:13:32 --> Model Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Model Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Controller Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:13:32 --> Email Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:13:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:13:32 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:13:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:13:32 --> Model Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:13:32 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:13:32 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:13:32 --> Model Class Initialized
DEBUG - 2015-02-04 15:13:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:13:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/edit.php
DEBUG - 2015-02-04 15:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:13:33 --> Final output sent to browser
DEBUG - 2015-02-04 15:13:33 --> Total execution time: 0.7121
DEBUG - 2015-02-04 15:14:33 --> Config Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:14:33 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:14:33 --> URI Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Router Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Output Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Security Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Input Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:14:33 --> Language Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Loader Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:14:33 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:14:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:14:33 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:14:33 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:14:33 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Controller Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:14:33 --> Email Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:14:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:14:33 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:14:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:14:33 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:14:33 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:14:33 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:14:33 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:14:34 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/edit.php
DEBUG - 2015-02-04 15:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:14:34 --> Final output sent to browser
DEBUG - 2015-02-04 15:14:34 --> Total execution time: 0.7221
DEBUG - 2015-02-04 15:14:39 --> Config Class Initialized
DEBUG - 2015-02-04 15:14:39 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:14:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:14:39 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:14:39 --> URI Class Initialized
DEBUG - 2015-02-04 15:14:39 --> Router Class Initialized
DEBUG - 2015-02-04 15:14:39 --> Output Class Initialized
DEBUG - 2015-02-04 15:14:39 --> Security Class Initialized
DEBUG - 2015-02-04 15:14:39 --> Input Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:14:40 --> Language Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Loader Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:14:40 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:14:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:14:40 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:14:40 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:14:40 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Controller Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:14:40 --> Email Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:14:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:14:40 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:14:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:14:40 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:14:40 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:14:40 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:14:40 --> Model Class Initialized
DEBUG - 2015-02-04 15:14:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:14:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:14:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/edit.php
DEBUG - 2015-02-04 15:14:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:14:40 --> Final output sent to browser
DEBUG - 2015-02-04 15:14:40 --> Total execution time: 0.7211
DEBUG - 2015-02-04 15:17:35 --> Config Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:17:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:17:35 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:17:35 --> URI Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Router Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Output Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Security Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Input Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:17:35 --> Language Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Loader Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:17:35 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:17:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:17:35 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:17:35 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Controller Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:17:35 --> Email Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:17:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:17:35 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:17:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:17:35 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:17:35 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/edit.php
DEBUG - 2015-02-04 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:17:36 --> Final output sent to browser
DEBUG - 2015-02-04 15:17:36 --> Total execution time: 0.7511
DEBUG - 2015-02-04 15:17:41 --> Config Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:17:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:17:41 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:17:41 --> URI Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Router Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Output Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Security Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Input Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:17:41 --> Language Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Loader Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:17:41 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:17:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:17:41 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:17:41 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:17:41 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Controller Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:17:41 --> Email Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:17:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:17:41 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:17:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:17:41 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:17:41 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:17:41 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:17:41 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 15:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 15:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 15:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 15:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 15:17:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 15:17:42 --> Final output sent to browser
DEBUG - 2015-02-04 15:17:42 --> Total execution time: 1.0431
DEBUG - 2015-02-04 15:17:48 --> Config Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:17:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:17:48 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:17:48 --> URI Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Router Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Output Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Security Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Input Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:17:48 --> Language Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Loader Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:17:48 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:17:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:17:48 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:17:48 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:17:48 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Controller Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:17:48 --> Email Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:17:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:17:48 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:17:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:17:48 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:17:48 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:17:48 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:17:48 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:17:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-04 15:17:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:17:49 --> Final output sent to browser
DEBUG - 2015-02-04 15:17:49 --> Total execution time: 0.8411
DEBUG - 2015-02-04 15:17:52 --> Config Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:17:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:17:52 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:17:52 --> URI Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Router Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Output Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Security Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Input Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:17:52 --> Language Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Loader Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:17:52 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:17:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:17:52 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:17:52 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:17:52 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Controller Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:17:52 --> Email Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:17:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:17:52 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:17:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:17:52 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:17:52 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:17:52 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:17:52 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-04 15:17:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-04 15:17:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/edit.php
DEBUG - 2015-02-04 15:17:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-04 15:17:53 --> Final output sent to browser
DEBUG - 2015-02-04 15:17:53 --> Total execution time: 0.7791
DEBUG - 2015-02-04 15:17:54 --> Config Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Hooks Class Initialized
DEBUG - 2015-02-04 15:17:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-04 15:17:54 --> Utf8 Class Initialized
DEBUG - 2015-02-04 15:17:54 --> URI Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Router Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Output Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Security Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Input Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-04 15:17:54 --> Language Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Loader Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Helper loaded: url_helper
DEBUG - 2015-02-04 15:17:54 --> Helper loaded: link_helper
DEBUG - 2015-02-04 15:17:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-04 15:17:54 --> CI_Session Class Initialized
DEBUG - 2015-02-04 15:17:54 --> CI_Session routines successfully run
DEBUG - 2015-02-04 15:17:54 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Controller Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-04 15:17:54 --> Email Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-04 15:17:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-04 15:17:54 --> Helper loaded: language_helper
DEBUG - 2015-02-04 15:17:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-04 15:17:54 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Database Driver Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Helper loaded: date_helper
DEBUG - 2015-02-04 15:17:54 --> Helper loaded: form_helper
DEBUG - 2015-02-04 15:17:54 --> Form Validation Class Initialized
DEBUG - 2015-02-04 15:17:54 --> Model Class Initialized
DEBUG - 2015-02-04 15:17:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-04 15:17:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-04 15:17:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-04 15:17:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-04 15:17:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-04 15:17:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-04 15:17:55 --> Final output sent to browser
DEBUG - 2015-02-04 15:17:55 --> Total execution time: 0.8341
