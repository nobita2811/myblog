<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-03 00:00:52 --> Config Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 00:00:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 00:00:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 00:00:52 --> URI Class Initialized
DEBUG - 2015-02-03 00:00:52 --> No URI present. Default controller set.
DEBUG - 2015-02-03 00:00:52 --> Router Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Output Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Security Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Input Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 00:00:52 --> Language Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Loader Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 00:00:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 00:00:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 00:00:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Session: Regenerate ID
DEBUG - 2015-02-03 00:00:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 00:00:52 --> Model Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Model Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Controller Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 00:00:52 --> Email Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 00:00:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 00:00:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 00:00:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 00:00:52 --> Model Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Helper loaded: date_helper
DEBUG - 2015-02-03 00:00:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 00:00:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Model Class Initialized
DEBUG - 2015-02-03 00:00:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 00:00:52 --> Pagination Class Initialized
DEBUG - 2015-02-03 00:00:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 00:00:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 00:00:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 00:00:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 00:00:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 00:00:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 00:00:52 --> Final output sent to browser
DEBUG - 2015-02-03 00:00:52 --> Total execution time: 0.6350
DEBUG - 2015-02-03 00:15:53 --> Config Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Hooks Class Initialized
DEBUG - 2015-02-03 00:15:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 00:15:53 --> Utf8 Class Initialized
DEBUG - 2015-02-03 00:15:53 --> URI Class Initialized
DEBUG - 2015-02-03 00:15:53 --> No URI present. Default controller set.
DEBUG - 2015-02-03 00:15:53 --> Router Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Output Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Security Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Input Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 00:15:53 --> Language Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Loader Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Helper loaded: url_helper
DEBUG - 2015-02-03 00:15:53 --> Helper loaded: link_helper
DEBUG - 2015-02-03 00:15:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 00:15:53 --> CI_Session Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Session: Regenerate ID
DEBUG - 2015-02-03 00:15:53 --> CI_Session routines successfully run
DEBUG - 2015-02-03 00:15:53 --> Model Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Model Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Controller Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 00:15:53 --> Email Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 00:15:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 00:15:53 --> Helper loaded: language_helper
DEBUG - 2015-02-03 00:15:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 00:15:53 --> Model Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Database Driver Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Helper loaded: date_helper
DEBUG - 2015-02-03 00:15:53 --> Helper loaded: form_helper
DEBUG - 2015-02-03 00:15:53 --> Form Validation Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Model Class Initialized
DEBUG - 2015-02-03 00:15:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 00:15:53 --> Pagination Class Initialized
DEBUG - 2015-02-03 00:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 00:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 00:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 00:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 00:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 00:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 00:15:54 --> Final output sent to browser
DEBUG - 2015-02-03 00:15:54 --> Total execution time: 0.6291
DEBUG - 2015-02-03 00:30:54 --> Config Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Hooks Class Initialized
DEBUG - 2015-02-03 00:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 00:30:54 --> Utf8 Class Initialized
DEBUG - 2015-02-03 00:30:54 --> URI Class Initialized
DEBUG - 2015-02-03 00:30:54 --> No URI present. Default controller set.
DEBUG - 2015-02-03 00:30:54 --> Router Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Output Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Security Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Input Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 00:30:54 --> Language Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Loader Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Helper loaded: url_helper
DEBUG - 2015-02-03 00:30:54 --> Helper loaded: link_helper
DEBUG - 2015-02-03 00:30:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 00:30:54 --> CI_Session Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Session: Regenerate ID
DEBUG - 2015-02-03 00:30:54 --> CI_Session routines successfully run
DEBUG - 2015-02-03 00:30:54 --> Model Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Model Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Controller Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 00:30:54 --> Email Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 00:30:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 00:30:54 --> Helper loaded: language_helper
DEBUG - 2015-02-03 00:30:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 00:30:54 --> Model Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Database Driver Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Helper loaded: date_helper
DEBUG - 2015-02-03 00:30:54 --> Helper loaded: form_helper
DEBUG - 2015-02-03 00:30:54 --> Form Validation Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Model Class Initialized
DEBUG - 2015-02-03 00:30:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 00:30:54 --> Pagination Class Initialized
DEBUG - 2015-02-03 00:30:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 00:30:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 00:30:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 00:30:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 00:30:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 00:30:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 00:30:55 --> Final output sent to browser
DEBUG - 2015-02-03 00:30:55 --> Total execution time: 0.6461
DEBUG - 2015-02-03 00:45:55 --> Config Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 00:45:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 00:45:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 00:45:55 --> URI Class Initialized
DEBUG - 2015-02-03 00:45:55 --> No URI present. Default controller set.
DEBUG - 2015-02-03 00:45:55 --> Router Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Output Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Security Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Input Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 00:45:55 --> Language Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Loader Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 00:45:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 00:45:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 00:45:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Session: Regenerate ID
DEBUG - 2015-02-03 00:45:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 00:45:55 --> Model Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Model Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Controller Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 00:45:55 --> Email Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 00:45:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 00:45:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 00:45:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 00:45:55 --> Model Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 00:45:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 00:45:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Model Class Initialized
DEBUG - 2015-02-03 00:45:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 00:45:55 --> Pagination Class Initialized
DEBUG - 2015-02-03 00:45:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 00:45:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 00:45:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 00:45:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 00:45:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 00:45:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 00:45:56 --> Final output sent to browser
DEBUG - 2015-02-03 00:45:56 --> Total execution time: 0.6431
DEBUG - 2015-02-03 01:00:56 --> Config Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Hooks Class Initialized
DEBUG - 2015-02-03 01:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 01:00:56 --> Utf8 Class Initialized
DEBUG - 2015-02-03 01:00:56 --> URI Class Initialized
DEBUG - 2015-02-03 01:00:56 --> No URI present. Default controller set.
DEBUG - 2015-02-03 01:00:56 --> Router Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Output Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Security Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Input Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 01:00:56 --> Language Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Loader Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Helper loaded: url_helper
DEBUG - 2015-02-03 01:00:56 --> Helper loaded: link_helper
DEBUG - 2015-02-03 01:00:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 01:00:56 --> CI_Session Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Session: Regenerate ID
DEBUG - 2015-02-03 01:00:56 --> CI_Session routines successfully run
DEBUG - 2015-02-03 01:00:56 --> Model Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Model Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Controller Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 01:00:56 --> Email Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 01:00:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 01:00:56 --> Helper loaded: language_helper
DEBUG - 2015-02-03 01:00:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 01:00:56 --> Model Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Database Driver Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Helper loaded: date_helper
DEBUG - 2015-02-03 01:00:56 --> Helper loaded: form_helper
DEBUG - 2015-02-03 01:00:56 --> Form Validation Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Model Class Initialized
DEBUG - 2015-02-03 01:00:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 01:00:56 --> Pagination Class Initialized
DEBUG - 2015-02-03 01:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 01:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 01:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 01:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 01:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 01:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 01:00:57 --> Final output sent to browser
DEBUG - 2015-02-03 01:00:57 --> Total execution time: 0.6490
DEBUG - 2015-02-03 01:16:00 --> Config Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Hooks Class Initialized
DEBUG - 2015-02-03 01:16:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 01:16:00 --> Utf8 Class Initialized
DEBUG - 2015-02-03 01:16:00 --> URI Class Initialized
DEBUG - 2015-02-03 01:16:00 --> No URI present. Default controller set.
DEBUG - 2015-02-03 01:16:00 --> Router Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Output Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Security Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Input Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 01:16:00 --> Language Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Loader Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 01:16:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 01:16:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 01:16:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Session: Regenerate ID
DEBUG - 2015-02-03 01:16:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 01:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Controller Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 01:16:00 --> Email Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 01:16:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 01:16:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 01:16:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 01:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Database Driver Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Helper loaded: date_helper
DEBUG - 2015-02-03 01:16:00 --> Helper loaded: form_helper
DEBUG - 2015-02-03 01:16:00 --> Form Validation Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 01:16:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 01:16:00 --> Pagination Class Initialized
DEBUG - 2015-02-03 01:16:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 01:16:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 01:16:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 01:16:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 01:16:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 01:16:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 01:16:01 --> Final output sent to browser
DEBUG - 2015-02-03 01:16:01 --> Total execution time: 0.6591
DEBUG - 2015-02-03 01:31:02 --> Config Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Hooks Class Initialized
DEBUG - 2015-02-03 01:31:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 01:31:02 --> Utf8 Class Initialized
DEBUG - 2015-02-03 01:31:02 --> URI Class Initialized
DEBUG - 2015-02-03 01:31:02 --> No URI present. Default controller set.
DEBUG - 2015-02-03 01:31:02 --> Router Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Output Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Security Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Input Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 01:31:02 --> Language Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Loader Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Helper loaded: url_helper
DEBUG - 2015-02-03 01:31:02 --> Helper loaded: link_helper
DEBUG - 2015-02-03 01:31:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 01:31:02 --> CI_Session Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Session: Regenerate ID
DEBUG - 2015-02-03 01:31:02 --> CI_Session routines successfully run
DEBUG - 2015-02-03 01:31:02 --> Model Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Model Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Controller Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 01:31:02 --> Email Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 01:31:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 01:31:02 --> Helper loaded: language_helper
DEBUG - 2015-02-03 01:31:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 01:31:02 --> Model Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Database Driver Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Helper loaded: date_helper
DEBUG - 2015-02-03 01:31:02 --> Helper loaded: form_helper
DEBUG - 2015-02-03 01:31:02 --> Form Validation Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Model Class Initialized
DEBUG - 2015-02-03 01:31:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 01:31:02 --> Pagination Class Initialized
DEBUG - 2015-02-03 01:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 01:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 01:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 01:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 01:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 01:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 01:31:02 --> Final output sent to browser
DEBUG - 2015-02-03 01:31:02 --> Total execution time: 0.6531
DEBUG - 2015-02-03 01:46:03 --> Config Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Hooks Class Initialized
DEBUG - 2015-02-03 01:46:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 01:46:03 --> Utf8 Class Initialized
DEBUG - 2015-02-03 01:46:03 --> URI Class Initialized
DEBUG - 2015-02-03 01:46:03 --> No URI present. Default controller set.
DEBUG - 2015-02-03 01:46:03 --> Router Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Output Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Security Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Input Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 01:46:03 --> Language Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Loader Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Helper loaded: url_helper
DEBUG - 2015-02-03 01:46:03 --> Helper loaded: link_helper
DEBUG - 2015-02-03 01:46:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 01:46:03 --> CI_Session Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Session: Regenerate ID
DEBUG - 2015-02-03 01:46:03 --> CI_Session routines successfully run
DEBUG - 2015-02-03 01:46:03 --> Model Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Model Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Controller Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 01:46:03 --> Email Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 01:46:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 01:46:03 --> Helper loaded: language_helper
DEBUG - 2015-02-03 01:46:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 01:46:03 --> Model Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Database Driver Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Helper loaded: date_helper
DEBUG - 2015-02-03 01:46:03 --> Helper loaded: form_helper
DEBUG - 2015-02-03 01:46:03 --> Form Validation Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Model Class Initialized
DEBUG - 2015-02-03 01:46:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 01:46:03 --> Pagination Class Initialized
DEBUG - 2015-02-03 01:46:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 01:46:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 01:46:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 01:46:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 01:46:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 01:46:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 01:46:03 --> Final output sent to browser
DEBUG - 2015-02-03 01:46:03 --> Total execution time: 0.6371
DEBUG - 2015-02-03 02:01:04 --> Config Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Hooks Class Initialized
DEBUG - 2015-02-03 02:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 02:01:04 --> Utf8 Class Initialized
DEBUG - 2015-02-03 02:01:04 --> URI Class Initialized
DEBUG - 2015-02-03 02:01:04 --> No URI present. Default controller set.
DEBUG - 2015-02-03 02:01:04 --> Router Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Output Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Security Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Input Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 02:01:04 --> Language Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Loader Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Helper loaded: url_helper
DEBUG - 2015-02-03 02:01:04 --> Helper loaded: link_helper
DEBUG - 2015-02-03 02:01:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 02:01:04 --> CI_Session Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Session: Regenerate ID
DEBUG - 2015-02-03 02:01:04 --> CI_Session routines successfully run
DEBUG - 2015-02-03 02:01:04 --> Model Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Model Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Controller Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 02:01:04 --> Email Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 02:01:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 02:01:04 --> Helper loaded: language_helper
DEBUG - 2015-02-03 02:01:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 02:01:04 --> Model Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Database Driver Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Helper loaded: date_helper
DEBUG - 2015-02-03 02:01:04 --> Helper loaded: form_helper
DEBUG - 2015-02-03 02:01:04 --> Form Validation Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Model Class Initialized
DEBUG - 2015-02-03 02:01:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 02:01:04 --> Pagination Class Initialized
DEBUG - 2015-02-03 02:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 02:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 02:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 02:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 02:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 02:01:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 02:01:04 --> Final output sent to browser
DEBUG - 2015-02-03 02:01:04 --> Total execution time: 0.6351
DEBUG - 2015-02-03 02:16:05 --> Config Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Hooks Class Initialized
DEBUG - 2015-02-03 02:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 02:16:05 --> Utf8 Class Initialized
DEBUG - 2015-02-03 02:16:05 --> URI Class Initialized
DEBUG - 2015-02-03 02:16:05 --> No URI present. Default controller set.
DEBUG - 2015-02-03 02:16:05 --> Router Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Output Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Security Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Input Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 02:16:05 --> Language Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Loader Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Helper loaded: url_helper
DEBUG - 2015-02-03 02:16:05 --> Helper loaded: link_helper
DEBUG - 2015-02-03 02:16:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 02:16:05 --> CI_Session Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Session: Regenerate ID
DEBUG - 2015-02-03 02:16:05 --> CI_Session routines successfully run
DEBUG - 2015-02-03 02:16:05 --> Model Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Model Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Controller Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 02:16:05 --> Email Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 02:16:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 02:16:05 --> Helper loaded: language_helper
DEBUG - 2015-02-03 02:16:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 02:16:05 --> Model Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Database Driver Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Helper loaded: date_helper
DEBUG - 2015-02-03 02:16:05 --> Helper loaded: form_helper
DEBUG - 2015-02-03 02:16:05 --> Form Validation Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Model Class Initialized
DEBUG - 2015-02-03 02:16:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 02:16:05 --> Pagination Class Initialized
DEBUG - 2015-02-03 02:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 02:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 02:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 02:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 02:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 02:16:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 02:16:05 --> Final output sent to browser
DEBUG - 2015-02-03 02:16:05 --> Total execution time: 0.6361
DEBUG - 2015-02-03 02:31:06 --> Config Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Hooks Class Initialized
DEBUG - 2015-02-03 02:31:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 02:31:06 --> Utf8 Class Initialized
DEBUG - 2015-02-03 02:31:06 --> URI Class Initialized
DEBUG - 2015-02-03 02:31:06 --> No URI present. Default controller set.
DEBUG - 2015-02-03 02:31:06 --> Router Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Output Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Security Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Input Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 02:31:06 --> Language Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Loader Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Helper loaded: url_helper
DEBUG - 2015-02-03 02:31:06 --> Helper loaded: link_helper
DEBUG - 2015-02-03 02:31:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 02:31:06 --> CI_Session Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Session: Regenerate ID
DEBUG - 2015-02-03 02:31:06 --> CI_Session routines successfully run
DEBUG - 2015-02-03 02:31:06 --> Model Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Model Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Controller Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 02:31:06 --> Email Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 02:31:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 02:31:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 02:31:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 02:31:06 --> Model Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 02:31:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 02:31:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Model Class Initialized
DEBUG - 2015-02-03 02:31:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 02:31:06 --> Pagination Class Initialized
DEBUG - 2015-02-03 02:31:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 02:31:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 02:31:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 02:31:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 02:31:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 02:31:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 02:31:07 --> Final output sent to browser
DEBUG - 2015-02-03 02:31:07 --> Total execution time: 0.6531
DEBUG - 2015-02-03 02:46:07 --> Config Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Hooks Class Initialized
DEBUG - 2015-02-03 02:46:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 02:46:07 --> Utf8 Class Initialized
DEBUG - 2015-02-03 02:46:07 --> URI Class Initialized
DEBUG - 2015-02-03 02:46:07 --> No URI present. Default controller set.
DEBUG - 2015-02-03 02:46:07 --> Router Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Output Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Security Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Input Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 02:46:07 --> Language Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Loader Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Helper loaded: url_helper
DEBUG - 2015-02-03 02:46:07 --> Helper loaded: link_helper
DEBUG - 2015-02-03 02:46:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 02:46:07 --> CI_Session Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Session: Regenerate ID
DEBUG - 2015-02-03 02:46:07 --> CI_Session routines successfully run
DEBUG - 2015-02-03 02:46:07 --> Model Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Model Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Controller Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 02:46:07 --> Email Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 02:46:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 02:46:07 --> Helper loaded: language_helper
DEBUG - 2015-02-03 02:46:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 02:46:07 --> Model Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Database Driver Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Helper loaded: date_helper
DEBUG - 2015-02-03 02:46:07 --> Helper loaded: form_helper
DEBUG - 2015-02-03 02:46:07 --> Form Validation Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Model Class Initialized
DEBUG - 2015-02-03 02:46:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 02:46:07 --> Pagination Class Initialized
DEBUG - 2015-02-03 02:46:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 02:46:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 02:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 02:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 02:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 02:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 02:46:08 --> Final output sent to browser
DEBUG - 2015-02-03 02:46:08 --> Total execution time: 0.6851
DEBUG - 2015-02-03 03:01:08 --> Config Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 03:01:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 03:01:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 03:01:08 --> URI Class Initialized
DEBUG - 2015-02-03 03:01:08 --> No URI present. Default controller set.
DEBUG - 2015-02-03 03:01:08 --> Router Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Output Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Security Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Input Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 03:01:08 --> Language Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Loader Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 03:01:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 03:01:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 03:01:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Session: Regenerate ID
DEBUG - 2015-02-03 03:01:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 03:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Controller Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 03:01:08 --> Email Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 03:01:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 03:01:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 03:01:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 03:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 03:01:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 03:01:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 03:01:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 03:01:08 --> Pagination Class Initialized
DEBUG - 2015-02-03 03:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 03:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 03:01:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 03:01:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 03:01:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 03:01:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 03:01:09 --> Final output sent to browser
DEBUG - 2015-02-03 03:01:09 --> Total execution time: 0.6451
DEBUG - 2015-02-03 03:16:09 --> Config Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Hooks Class Initialized
DEBUG - 2015-02-03 03:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 03:16:09 --> Utf8 Class Initialized
DEBUG - 2015-02-03 03:16:09 --> URI Class Initialized
DEBUG - 2015-02-03 03:16:09 --> No URI present. Default controller set.
DEBUG - 2015-02-03 03:16:09 --> Router Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Output Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Security Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Input Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 03:16:09 --> Language Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Loader Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Helper loaded: url_helper
DEBUG - 2015-02-03 03:16:09 --> Helper loaded: link_helper
DEBUG - 2015-02-03 03:16:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 03:16:09 --> CI_Session Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Session: Regenerate ID
DEBUG - 2015-02-03 03:16:09 --> CI_Session routines successfully run
DEBUG - 2015-02-03 03:16:09 --> Model Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Model Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Controller Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 03:16:09 --> Email Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 03:16:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 03:16:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 03:16:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 03:16:09 --> Model Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 03:16:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 03:16:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Model Class Initialized
DEBUG - 2015-02-03 03:16:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 03:16:09 --> Pagination Class Initialized
DEBUG - 2015-02-03 03:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 03:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 03:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 03:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 03:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 03:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 03:16:10 --> Final output sent to browser
DEBUG - 2015-02-03 03:16:10 --> Total execution time: 0.6340
DEBUG - 2015-02-03 03:31:10 --> Config Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Hooks Class Initialized
DEBUG - 2015-02-03 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 03:31:10 --> Utf8 Class Initialized
DEBUG - 2015-02-03 03:31:10 --> URI Class Initialized
DEBUG - 2015-02-03 03:31:10 --> No URI present. Default controller set.
DEBUG - 2015-02-03 03:31:10 --> Router Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Output Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Security Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Input Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 03:31:10 --> Language Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Loader Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Helper loaded: url_helper
DEBUG - 2015-02-03 03:31:10 --> Helper loaded: link_helper
DEBUG - 2015-02-03 03:31:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 03:31:10 --> CI_Session Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Session: Regenerate ID
DEBUG - 2015-02-03 03:31:10 --> CI_Session routines successfully run
DEBUG - 2015-02-03 03:31:10 --> Model Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Model Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Controller Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 03:31:10 --> Email Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 03:31:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 03:31:10 --> Helper loaded: language_helper
DEBUG - 2015-02-03 03:31:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 03:31:10 --> Model Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Database Driver Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Helper loaded: date_helper
DEBUG - 2015-02-03 03:31:10 --> Helper loaded: form_helper
DEBUG - 2015-02-03 03:31:10 --> Form Validation Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Model Class Initialized
DEBUG - 2015-02-03 03:31:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 03:31:10 --> Pagination Class Initialized
DEBUG - 2015-02-03 03:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 03:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 03:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 03:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 03:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 03:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 03:31:11 --> Final output sent to browser
DEBUG - 2015-02-03 03:31:11 --> Total execution time: 0.6401
DEBUG - 2015-02-03 03:46:11 --> Config Class Initialized
DEBUG - 2015-02-03 03:46:11 --> Hooks Class Initialized
DEBUG - 2015-02-03 03:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 03:46:11 --> Utf8 Class Initialized
DEBUG - 2015-02-03 03:46:11 --> URI Class Initialized
DEBUG - 2015-02-03 03:46:11 --> No URI present. Default controller set.
DEBUG - 2015-02-03 03:46:11 --> Router Class Initialized
DEBUG - 2015-02-03 03:46:11 --> Output Class Initialized
DEBUG - 2015-02-03 03:46:11 --> Security Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Input Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 03:46:12 --> Language Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Loader Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 03:46:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 03:46:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 03:46:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Session: Regenerate ID
DEBUG - 2015-02-03 03:46:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 03:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Controller Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 03:46:12 --> Email Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 03:46:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 03:46:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 03:46:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 03:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 03:46:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 03:46:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 03:46:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 03:46:12 --> Pagination Class Initialized
DEBUG - 2015-02-03 03:46:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 03:46:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 03:46:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 03:46:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 03:46:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 03:46:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 03:46:12 --> Final output sent to browser
DEBUG - 2015-02-03 03:46:12 --> Total execution time: 0.6451
DEBUG - 2015-02-03 04:01:13 --> Config Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Hooks Class Initialized
DEBUG - 2015-02-03 04:01:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 04:01:13 --> Utf8 Class Initialized
DEBUG - 2015-02-03 04:01:13 --> URI Class Initialized
DEBUG - 2015-02-03 04:01:13 --> No URI present. Default controller set.
DEBUG - 2015-02-03 04:01:13 --> Router Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Output Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Security Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Input Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 04:01:13 --> Language Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Loader Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Helper loaded: url_helper
DEBUG - 2015-02-03 04:01:13 --> Helper loaded: link_helper
DEBUG - 2015-02-03 04:01:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 04:01:13 --> CI_Session Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Session: Regenerate ID
DEBUG - 2015-02-03 04:01:13 --> CI_Session routines successfully run
DEBUG - 2015-02-03 04:01:13 --> Model Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Model Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Controller Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 04:01:13 --> Email Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 04:01:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 04:01:13 --> Helper loaded: language_helper
DEBUG - 2015-02-03 04:01:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 04:01:13 --> Model Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Database Driver Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Helper loaded: date_helper
DEBUG - 2015-02-03 04:01:13 --> Helper loaded: form_helper
DEBUG - 2015-02-03 04:01:13 --> Form Validation Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Model Class Initialized
DEBUG - 2015-02-03 04:01:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 04:01:13 --> Pagination Class Initialized
DEBUG - 2015-02-03 04:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 04:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 04:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 04:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 04:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 04:01:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 04:01:13 --> Final output sent to browser
DEBUG - 2015-02-03 04:01:13 --> Total execution time: 0.6351
DEBUG - 2015-02-03 04:16:14 --> Config Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Hooks Class Initialized
DEBUG - 2015-02-03 04:16:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 04:16:14 --> Utf8 Class Initialized
DEBUG - 2015-02-03 04:16:14 --> URI Class Initialized
DEBUG - 2015-02-03 04:16:14 --> No URI present. Default controller set.
DEBUG - 2015-02-03 04:16:14 --> Router Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Output Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Security Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Input Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 04:16:14 --> Language Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Loader Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Helper loaded: url_helper
DEBUG - 2015-02-03 04:16:14 --> Helper loaded: link_helper
DEBUG - 2015-02-03 04:16:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 04:16:14 --> CI_Session Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Session: Regenerate ID
DEBUG - 2015-02-03 04:16:14 --> CI_Session routines successfully run
DEBUG - 2015-02-03 04:16:14 --> Model Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Model Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Controller Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 04:16:14 --> Email Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 04:16:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 04:16:14 --> Helper loaded: language_helper
DEBUG - 2015-02-03 04:16:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 04:16:14 --> Model Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Database Driver Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Helper loaded: date_helper
DEBUG - 2015-02-03 04:16:14 --> Helper loaded: form_helper
DEBUG - 2015-02-03 04:16:14 --> Form Validation Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Model Class Initialized
DEBUG - 2015-02-03 04:16:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 04:16:14 --> Pagination Class Initialized
DEBUG - 2015-02-03 04:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 04:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 04:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 04:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 04:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 04:16:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 04:16:14 --> Final output sent to browser
DEBUG - 2015-02-03 04:16:14 --> Total execution time: 0.6351
DEBUG - 2015-02-03 04:31:15 --> Config Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Hooks Class Initialized
DEBUG - 2015-02-03 04:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 04:31:15 --> Utf8 Class Initialized
DEBUG - 2015-02-03 04:31:15 --> URI Class Initialized
DEBUG - 2015-02-03 04:31:15 --> No URI present. Default controller set.
DEBUG - 2015-02-03 04:31:15 --> Router Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Output Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Security Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Input Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 04:31:15 --> Language Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Loader Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Helper loaded: url_helper
DEBUG - 2015-02-03 04:31:15 --> Helper loaded: link_helper
DEBUG - 2015-02-03 04:31:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 04:31:15 --> CI_Session Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Session: Regenerate ID
DEBUG - 2015-02-03 04:31:15 --> CI_Session routines successfully run
DEBUG - 2015-02-03 04:31:15 --> Model Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Model Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Controller Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 04:31:15 --> Email Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 04:31:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 04:31:15 --> Helper loaded: language_helper
DEBUG - 2015-02-03 04:31:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 04:31:15 --> Model Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Database Driver Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Helper loaded: date_helper
DEBUG - 2015-02-03 04:31:15 --> Helper loaded: form_helper
DEBUG - 2015-02-03 04:31:15 --> Form Validation Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Model Class Initialized
DEBUG - 2015-02-03 04:31:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 04:31:15 --> Pagination Class Initialized
DEBUG - 2015-02-03 04:31:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 04:31:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 04:31:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 04:31:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 04:31:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 04:31:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 04:31:15 --> Final output sent to browser
DEBUG - 2015-02-03 04:31:15 --> Total execution time: 0.6560
DEBUG - 2015-02-03 04:46:16 --> Config Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Hooks Class Initialized
DEBUG - 2015-02-03 04:46:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 04:46:16 --> Utf8 Class Initialized
DEBUG - 2015-02-03 04:46:16 --> URI Class Initialized
DEBUG - 2015-02-03 04:46:16 --> No URI present. Default controller set.
DEBUG - 2015-02-03 04:46:16 --> Router Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Output Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Security Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Input Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 04:46:16 --> Language Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Loader Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Helper loaded: url_helper
DEBUG - 2015-02-03 04:46:16 --> Helper loaded: link_helper
DEBUG - 2015-02-03 04:46:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 04:46:16 --> CI_Session Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Session: Regenerate ID
DEBUG - 2015-02-03 04:46:16 --> CI_Session routines successfully run
DEBUG - 2015-02-03 04:46:16 --> Model Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Model Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Controller Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 04:46:16 --> Email Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 04:46:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 04:46:16 --> Helper loaded: language_helper
DEBUG - 2015-02-03 04:46:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 04:46:16 --> Model Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Database Driver Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Helper loaded: date_helper
DEBUG - 2015-02-03 04:46:16 --> Helper loaded: form_helper
DEBUG - 2015-02-03 04:46:16 --> Form Validation Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Model Class Initialized
DEBUG - 2015-02-03 04:46:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 04:46:16 --> Pagination Class Initialized
DEBUG - 2015-02-03 04:46:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 04:46:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 04:46:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 04:46:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 04:46:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 04:46:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 04:46:16 --> Final output sent to browser
DEBUG - 2015-02-03 04:46:16 --> Total execution time: 0.6421
DEBUG - 2015-02-03 05:01:17 --> Config Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Hooks Class Initialized
DEBUG - 2015-02-03 05:01:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 05:01:17 --> Utf8 Class Initialized
DEBUG - 2015-02-03 05:01:17 --> URI Class Initialized
DEBUG - 2015-02-03 05:01:17 --> No URI present. Default controller set.
DEBUG - 2015-02-03 05:01:17 --> Router Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Output Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Security Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Input Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 05:01:17 --> Language Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Loader Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Helper loaded: url_helper
DEBUG - 2015-02-03 05:01:17 --> Helper loaded: link_helper
DEBUG - 2015-02-03 05:01:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 05:01:17 --> CI_Session Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Session: Regenerate ID
DEBUG - 2015-02-03 05:01:17 --> CI_Session routines successfully run
DEBUG - 2015-02-03 05:01:17 --> Model Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Model Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Controller Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 05:01:17 --> Email Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 05:01:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 05:01:17 --> Helper loaded: language_helper
DEBUG - 2015-02-03 05:01:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 05:01:17 --> Model Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Database Driver Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Helper loaded: date_helper
DEBUG - 2015-02-03 05:01:17 --> Helper loaded: form_helper
DEBUG - 2015-02-03 05:01:17 --> Form Validation Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Model Class Initialized
DEBUG - 2015-02-03 05:01:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 05:01:17 --> Pagination Class Initialized
DEBUG - 2015-02-03 05:01:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 05:01:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 05:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 05:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 05:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 05:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 05:01:18 --> Final output sent to browser
DEBUG - 2015-02-03 05:01:18 --> Total execution time: 0.6471
DEBUG - 2015-02-03 05:16:18 --> Config Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Hooks Class Initialized
DEBUG - 2015-02-03 05:16:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 05:16:18 --> Utf8 Class Initialized
DEBUG - 2015-02-03 05:16:18 --> URI Class Initialized
DEBUG - 2015-02-03 05:16:18 --> No URI present. Default controller set.
DEBUG - 2015-02-03 05:16:18 --> Router Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Output Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Security Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Input Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 05:16:18 --> Language Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Loader Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Helper loaded: url_helper
DEBUG - 2015-02-03 05:16:18 --> Helper loaded: link_helper
DEBUG - 2015-02-03 05:16:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 05:16:18 --> CI_Session Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Session: Regenerate ID
DEBUG - 2015-02-03 05:16:18 --> CI_Session routines successfully run
DEBUG - 2015-02-03 05:16:18 --> Model Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Model Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Controller Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 05:16:18 --> Email Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 05:16:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 05:16:18 --> Helper loaded: language_helper
DEBUG - 2015-02-03 05:16:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 05:16:18 --> Model Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Database Driver Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Helper loaded: date_helper
DEBUG - 2015-02-03 05:16:18 --> Helper loaded: form_helper
DEBUG - 2015-02-03 05:16:18 --> Form Validation Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Model Class Initialized
DEBUG - 2015-02-03 05:16:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 05:16:18 --> Pagination Class Initialized
DEBUG - 2015-02-03 05:16:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 05:16:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 05:16:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 05:16:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 05:16:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 05:16:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 05:16:19 --> Final output sent to browser
DEBUG - 2015-02-03 05:16:19 --> Total execution time: 0.6401
DEBUG - 2015-02-03 05:31:19 --> Config Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Hooks Class Initialized
DEBUG - 2015-02-03 05:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 05:31:19 --> Utf8 Class Initialized
DEBUG - 2015-02-03 05:31:19 --> URI Class Initialized
DEBUG - 2015-02-03 05:31:19 --> No URI present. Default controller set.
DEBUG - 2015-02-03 05:31:19 --> Router Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Output Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Security Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Input Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 05:31:19 --> Language Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Loader Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Helper loaded: url_helper
DEBUG - 2015-02-03 05:31:19 --> Helper loaded: link_helper
DEBUG - 2015-02-03 05:31:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 05:31:19 --> CI_Session Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Session: Regenerate ID
DEBUG - 2015-02-03 05:31:19 --> CI_Session routines successfully run
DEBUG - 2015-02-03 05:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Controller Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 05:31:19 --> Email Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 05:31:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 05:31:19 --> Helper loaded: language_helper
DEBUG - 2015-02-03 05:31:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 05:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Database Driver Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Helper loaded: date_helper
DEBUG - 2015-02-03 05:31:19 --> Helper loaded: form_helper
DEBUG - 2015-02-03 05:31:19 --> Form Validation Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 05:31:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 05:31:19 --> Pagination Class Initialized
DEBUG - 2015-02-03 05:31:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 05:31:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 05:31:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 05:31:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 05:31:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 05:31:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 05:31:20 --> Final output sent to browser
DEBUG - 2015-02-03 05:31:20 --> Total execution time: 0.6370
DEBUG - 2015-02-03 05:46:20 --> Config Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Hooks Class Initialized
DEBUG - 2015-02-03 05:46:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 05:46:20 --> Utf8 Class Initialized
DEBUG - 2015-02-03 05:46:20 --> URI Class Initialized
DEBUG - 2015-02-03 05:46:20 --> No URI present. Default controller set.
DEBUG - 2015-02-03 05:46:20 --> Router Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Output Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Security Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Input Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 05:46:20 --> Language Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Loader Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Helper loaded: url_helper
DEBUG - 2015-02-03 05:46:20 --> Helper loaded: link_helper
DEBUG - 2015-02-03 05:46:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 05:46:20 --> CI_Session Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Session: Regenerate ID
DEBUG - 2015-02-03 05:46:20 --> CI_Session routines successfully run
DEBUG - 2015-02-03 05:46:20 --> Model Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Model Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Controller Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 05:46:20 --> Email Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 05:46:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 05:46:20 --> Helper loaded: language_helper
DEBUG - 2015-02-03 05:46:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 05:46:20 --> Model Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Database Driver Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Helper loaded: date_helper
DEBUG - 2015-02-03 05:46:20 --> Helper loaded: form_helper
DEBUG - 2015-02-03 05:46:20 --> Form Validation Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Model Class Initialized
DEBUG - 2015-02-03 05:46:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 05:46:20 --> Pagination Class Initialized
DEBUG - 2015-02-03 05:46:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 05:46:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 05:46:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 05:46:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 05:46:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 05:46:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 05:46:21 --> Final output sent to browser
DEBUG - 2015-02-03 05:46:21 --> Total execution time: 0.6551
DEBUG - 2015-02-03 06:01:21 --> Config Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Hooks Class Initialized
DEBUG - 2015-02-03 06:01:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 06:01:21 --> Utf8 Class Initialized
DEBUG - 2015-02-03 06:01:21 --> URI Class Initialized
DEBUG - 2015-02-03 06:01:21 --> No URI present. Default controller set.
DEBUG - 2015-02-03 06:01:21 --> Router Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Output Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Security Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Input Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 06:01:21 --> Language Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Loader Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Helper loaded: url_helper
DEBUG - 2015-02-03 06:01:21 --> Helper loaded: link_helper
DEBUG - 2015-02-03 06:01:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 06:01:21 --> CI_Session Class Initialized
DEBUG - 2015-02-03 06:01:21 --> Session: Regenerate ID
DEBUG - 2015-02-03 06:01:21 --> CI_Session routines successfully run
DEBUG - 2015-02-03 06:01:22 --> Model Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Model Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Controller Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 06:01:22 --> Email Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 06:01:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 06:01:22 --> Helper loaded: language_helper
DEBUG - 2015-02-03 06:01:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 06:01:22 --> Model Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Database Driver Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Helper loaded: date_helper
DEBUG - 2015-02-03 06:01:22 --> Helper loaded: form_helper
DEBUG - 2015-02-03 06:01:22 --> Form Validation Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Model Class Initialized
DEBUG - 2015-02-03 06:01:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 06:01:22 --> Pagination Class Initialized
DEBUG - 2015-02-03 06:01:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 06:01:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 06:01:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 06:01:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 06:01:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 06:01:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 06:01:22 --> Final output sent to browser
DEBUG - 2015-02-03 06:01:22 --> Total execution time: 0.6191
DEBUG - 2015-02-03 06:16:23 --> Config Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 06:16:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 06:16:23 --> URI Class Initialized
DEBUG - 2015-02-03 06:16:23 --> No URI present. Default controller set.
DEBUG - 2015-02-03 06:16:23 --> Router Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Output Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Security Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Input Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 06:16:23 --> Language Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Loader Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 06:16:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 06:16:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 06:16:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Session: Regenerate ID
DEBUG - 2015-02-03 06:16:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 06:16:23 --> Model Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Model Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Controller Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 06:16:23 --> Email Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 06:16:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 06:16:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 06:16:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 06:16:23 --> Model Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 06:16:23 --> Helper loaded: form_helper
DEBUG - 2015-02-03 06:16:23 --> Form Validation Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Model Class Initialized
DEBUG - 2015-02-03 06:16:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 06:16:23 --> Pagination Class Initialized
DEBUG - 2015-02-03 06:16:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 06:16:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 06:16:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 06:16:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 06:16:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 06:16:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 06:16:23 --> Final output sent to browser
DEBUG - 2015-02-03 06:16:23 --> Total execution time: 0.6451
DEBUG - 2015-02-03 06:31:24 --> Config Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Hooks Class Initialized
DEBUG - 2015-02-03 06:31:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 06:31:24 --> Utf8 Class Initialized
DEBUG - 2015-02-03 06:31:24 --> URI Class Initialized
DEBUG - 2015-02-03 06:31:24 --> No URI present. Default controller set.
DEBUG - 2015-02-03 06:31:24 --> Router Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Output Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Security Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Input Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 06:31:24 --> Language Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Loader Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Helper loaded: url_helper
DEBUG - 2015-02-03 06:31:24 --> Helper loaded: link_helper
DEBUG - 2015-02-03 06:31:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 06:31:24 --> CI_Session Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Session: Regenerate ID
DEBUG - 2015-02-03 06:31:24 --> CI_Session routines successfully run
DEBUG - 2015-02-03 06:31:24 --> Model Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Model Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Controller Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 06:31:24 --> Email Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 06:31:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 06:31:24 --> Helper loaded: language_helper
DEBUG - 2015-02-03 06:31:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 06:31:24 --> Model Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Database Driver Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Helper loaded: date_helper
DEBUG - 2015-02-03 06:31:24 --> Helper loaded: form_helper
DEBUG - 2015-02-03 06:31:24 --> Form Validation Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Model Class Initialized
DEBUG - 2015-02-03 06:31:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 06:31:24 --> Pagination Class Initialized
DEBUG - 2015-02-03 06:31:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 06:31:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 06:31:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 06:31:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 06:31:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 06:31:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 06:31:24 --> Final output sent to browser
DEBUG - 2015-02-03 06:31:24 --> Total execution time: 0.6431
DEBUG - 2015-02-03 06:46:25 --> Config Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Hooks Class Initialized
DEBUG - 2015-02-03 06:46:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 06:46:25 --> Utf8 Class Initialized
DEBUG - 2015-02-03 06:46:25 --> URI Class Initialized
DEBUG - 2015-02-03 06:46:25 --> No URI present. Default controller set.
DEBUG - 2015-02-03 06:46:25 --> Router Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Output Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Security Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Input Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 06:46:25 --> Language Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Loader Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Helper loaded: url_helper
DEBUG - 2015-02-03 06:46:25 --> Helper loaded: link_helper
DEBUG - 2015-02-03 06:46:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 06:46:25 --> CI_Session Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Session: Regenerate ID
DEBUG - 2015-02-03 06:46:25 --> CI_Session routines successfully run
DEBUG - 2015-02-03 06:46:25 --> Model Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Model Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Controller Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 06:46:25 --> Email Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 06:46:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 06:46:25 --> Helper loaded: language_helper
DEBUG - 2015-02-03 06:46:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 06:46:25 --> Model Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Database Driver Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Helper loaded: date_helper
DEBUG - 2015-02-03 06:46:25 --> Helper loaded: form_helper
DEBUG - 2015-02-03 06:46:25 --> Form Validation Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Model Class Initialized
DEBUG - 2015-02-03 06:46:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 06:46:25 --> Pagination Class Initialized
DEBUG - 2015-02-03 06:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 06:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 06:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 06:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 06:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 06:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 06:46:25 --> Final output sent to browser
DEBUG - 2015-02-03 06:46:25 --> Total execution time: 0.6351
DEBUG - 2015-02-03 07:01:26 --> Config Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Hooks Class Initialized
DEBUG - 2015-02-03 07:01:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 07:01:26 --> Utf8 Class Initialized
DEBUG - 2015-02-03 07:01:26 --> URI Class Initialized
DEBUG - 2015-02-03 07:01:26 --> No URI present. Default controller set.
DEBUG - 2015-02-03 07:01:26 --> Router Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Output Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Security Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Input Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 07:01:26 --> Language Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Loader Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Helper loaded: url_helper
DEBUG - 2015-02-03 07:01:26 --> Helper loaded: link_helper
DEBUG - 2015-02-03 07:01:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 07:01:26 --> CI_Session Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Session: Regenerate ID
DEBUG - 2015-02-03 07:01:26 --> CI_Session routines successfully run
DEBUG - 2015-02-03 07:01:26 --> Model Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Model Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Controller Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 07:01:26 --> Email Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 07:01:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 07:01:26 --> Helper loaded: language_helper
DEBUG - 2015-02-03 07:01:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 07:01:26 --> Model Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Database Driver Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Helper loaded: date_helper
DEBUG - 2015-02-03 07:01:26 --> Helper loaded: form_helper
DEBUG - 2015-02-03 07:01:26 --> Form Validation Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Model Class Initialized
DEBUG - 2015-02-03 07:01:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 07:01:26 --> Pagination Class Initialized
DEBUG - 2015-02-03 07:01:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 07:01:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 07:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 07:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 07:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 07:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 07:01:27 --> Final output sent to browser
DEBUG - 2015-02-03 07:01:27 --> Total execution time: 0.6391
DEBUG - 2015-02-03 07:16:27 --> Config Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Hooks Class Initialized
DEBUG - 2015-02-03 07:16:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 07:16:27 --> Utf8 Class Initialized
DEBUG - 2015-02-03 07:16:27 --> URI Class Initialized
DEBUG - 2015-02-03 07:16:27 --> No URI present. Default controller set.
DEBUG - 2015-02-03 07:16:27 --> Router Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Output Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Security Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Input Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 07:16:27 --> Language Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Loader Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Helper loaded: url_helper
DEBUG - 2015-02-03 07:16:27 --> Helper loaded: link_helper
DEBUG - 2015-02-03 07:16:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 07:16:27 --> CI_Session Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Session: Regenerate ID
DEBUG - 2015-02-03 07:16:27 --> CI_Session routines successfully run
DEBUG - 2015-02-03 07:16:27 --> Model Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Model Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Controller Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 07:16:27 --> Email Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 07:16:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 07:16:27 --> Helper loaded: language_helper
DEBUG - 2015-02-03 07:16:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 07:16:27 --> Model Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Database Driver Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Helper loaded: date_helper
DEBUG - 2015-02-03 07:16:27 --> Helper loaded: form_helper
DEBUG - 2015-02-03 07:16:27 --> Form Validation Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Model Class Initialized
DEBUG - 2015-02-03 07:16:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 07:16:27 --> Pagination Class Initialized
DEBUG - 2015-02-03 07:16:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 07:16:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 07:16:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 07:16:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 07:16:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 07:16:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 07:16:28 --> Final output sent to browser
DEBUG - 2015-02-03 07:16:28 --> Total execution time: 0.6431
DEBUG - 2015-02-03 07:31:28 --> Config Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 07:31:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 07:31:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 07:31:28 --> URI Class Initialized
DEBUG - 2015-02-03 07:31:28 --> No URI present. Default controller set.
DEBUG - 2015-02-03 07:31:28 --> Router Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Output Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Security Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Input Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 07:31:28 --> Language Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Loader Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 07:31:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 07:31:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 07:31:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Session: Regenerate ID
DEBUG - 2015-02-03 07:31:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 07:31:28 --> Model Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Model Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Controller Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 07:31:28 --> Email Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 07:31:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 07:31:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 07:31:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 07:31:28 --> Model Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 07:31:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 07:31:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Model Class Initialized
DEBUG - 2015-02-03 07:31:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 07:31:28 --> Pagination Class Initialized
DEBUG - 2015-02-03 07:31:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 07:31:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 07:31:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 07:31:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 07:31:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 07:31:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 07:31:29 --> Final output sent to browser
DEBUG - 2015-02-03 07:31:29 --> Total execution time: 0.6411
DEBUG - 2015-02-03 07:46:29 --> Config Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Hooks Class Initialized
DEBUG - 2015-02-03 07:46:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 07:46:29 --> Utf8 Class Initialized
DEBUG - 2015-02-03 07:46:29 --> URI Class Initialized
DEBUG - 2015-02-03 07:46:29 --> No URI present. Default controller set.
DEBUG - 2015-02-03 07:46:29 --> Router Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Output Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Security Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Input Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 07:46:29 --> Language Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Loader Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Helper loaded: url_helper
DEBUG - 2015-02-03 07:46:29 --> Helper loaded: link_helper
DEBUG - 2015-02-03 07:46:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 07:46:29 --> CI_Session Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Session: Regenerate ID
DEBUG - 2015-02-03 07:46:29 --> CI_Session routines successfully run
DEBUG - 2015-02-03 07:46:29 --> Model Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Model Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Controller Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 07:46:29 --> Email Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 07:46:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 07:46:29 --> Helper loaded: language_helper
DEBUG - 2015-02-03 07:46:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 07:46:29 --> Model Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Database Driver Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Helper loaded: date_helper
DEBUG - 2015-02-03 07:46:29 --> Helper loaded: form_helper
DEBUG - 2015-02-03 07:46:29 --> Form Validation Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Model Class Initialized
DEBUG - 2015-02-03 07:46:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 07:46:29 --> Pagination Class Initialized
DEBUG - 2015-02-03 07:46:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 07:46:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 07:46:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 07:46:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 07:46:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 07:46:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 07:46:30 --> Final output sent to browser
DEBUG - 2015-02-03 07:46:30 --> Total execution time: 0.6448
DEBUG - 2015-02-03 08:01:30 --> Config Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:01:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:01:30 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:01:30 --> URI Class Initialized
DEBUG - 2015-02-03 08:01:30 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:01:30 --> Router Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Output Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Security Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Input Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:01:30 --> Language Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Loader Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:01:30 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:01:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:01:30 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Session: Regenerate ID
DEBUG - 2015-02-03 08:01:30 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:01:30 --> Model Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Model Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Controller Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:01:30 --> Email Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:01:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:01:30 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:01:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:01:30 --> Model Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:01:30 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:01:30 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Model Class Initialized
DEBUG - 2015-02-03 08:01:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:01:30 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:01:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:01:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:01:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:01:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:01:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:01:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:01:31 --> Final output sent to browser
DEBUG - 2015-02-03 08:01:31 --> Total execution time: 0.6390
DEBUG - 2015-02-03 08:16:13 --> Config Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:16:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:16:13 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:16:13 --> URI Class Initialized
DEBUG - 2015-02-03 08:16:13 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:16:13 --> Router Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Output Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Security Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Input Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:16:13 --> Language Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Loader Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:16:13 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:16:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:16:13 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Session: Regenerate ID
DEBUG - 2015-02-03 08:16:13 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:16:13 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Controller Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:16:13 --> Email Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:16:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:16:13 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:16:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:16:13 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:16:13 --> Helper loaded: date_helper
ERROR - 2015-02-03 08:16:13 --> Severity: Error --> Call to undefined function get_user_group() D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 251
DEBUG - 2015-02-03 08:16:20 --> Config Class Initialized
DEBUG - 2015-02-03 08:16:20 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:16:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:16:20 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:16:20 --> URI Class Initialized
DEBUG - 2015-02-03 08:16:20 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:16:20 --> Router Class Initialized
DEBUG - 2015-02-03 08:16:20 --> Output Class Initialized
DEBUG - 2015-02-03 08:16:20 --> Security Class Initialized
DEBUG - 2015-02-03 08:16:20 --> Input Class Initialized
DEBUG - 2015-02-03 08:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:16:20 --> Language Class Initialized
DEBUG - 2015-02-03 08:16:20 --> Loader Class Initialized
DEBUG - 2015-02-03 08:16:20 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:16:20 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:16:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:16:20 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:16:20 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:16:21 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Controller Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:16:21 --> Email Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:16:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:16:21 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:16:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:16:21 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Helper loaded: date_helper
ERROR - 2015-02-03 08:16:21 --> Severity: Notice --> Undefined variable: user_id D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 251
DEBUG - 2015-02-03 08:16:21 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:16:21 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:16:21 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:16:21 --> Final output sent to browser
DEBUG - 2015-02-03 08:16:21 --> Total execution time: 0.9131
DEBUG - 2015-02-03 08:16:31 --> Config Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:16:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:16:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:16:31 --> URI Class Initialized
DEBUG - 2015-02-03 08:16:31 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:16:31 --> Router Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Output Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Security Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Input Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:16:31 --> Language Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Loader Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:16:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:16:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:16:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:16:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:16:31 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Controller Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:16:31 --> Email Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:16:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:16:31 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:16:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:16:31 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:16:31 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:16:32 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:16:32 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:16:32 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:32 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:16:32 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:16:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:16:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:16:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:16:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:16:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:16:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:16:32 --> Final output sent to browser
DEBUG - 2015-02-03 08:16:32 --> Total execution time: 0.7901
DEBUG - 2015-02-03 08:16:47 --> Config Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:16:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:16:47 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:16:47 --> URI Class Initialized
DEBUG - 2015-02-03 08:16:47 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:16:47 --> Router Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Output Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Security Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Input Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:16:47 --> Language Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Loader Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:16:47 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:16:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:16:47 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:16:47 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:16:47 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Controller Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:16:47 --> Email Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:16:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:16:47 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:16:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:16:47 --> Model Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:16:47 --> Helper loaded: date_helper
ERROR - 2015-02-03 08:16:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php:1742) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-03 08:16:48 --> Severity: Error --> Call to undefined method CI_DB_mysql_driver::leftJoin() D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 1742
DEBUG - 2015-02-03 08:17:33 --> Config Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:17:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:17:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:17:33 --> URI Class Initialized
DEBUG - 2015-02-03 08:17:33 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:17:33 --> Router Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Output Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Security Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Input Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:17:33 --> Language Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Loader Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:17:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:17:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:17:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:17:33 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:17:33 --> Model Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Model Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Controller Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:17:33 --> Email Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:17:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:17:33 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:17:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:17:33 --> Model Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:17:33 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:17:33 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Model Class Initialized
DEBUG - 2015-02-03 08:17:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:17:33 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:17:33 --> Final output sent to browser
DEBUG - 2015-02-03 08:17:33 --> Total execution time: 0.7261
DEBUG - 2015-02-03 08:18:16 --> Config Class Initialized
DEBUG - 2015-02-03 08:18:16 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:18:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:18:16 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:18:16 --> URI Class Initialized
DEBUG - 2015-02-03 08:18:16 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:18:16 --> Router Class Initialized
DEBUG - 2015-02-03 08:18:16 --> Output Class Initialized
DEBUG - 2015-02-03 08:18:16 --> Security Class Initialized
DEBUG - 2015-02-03 08:18:16 --> Input Class Initialized
DEBUG - 2015-02-03 08:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:18:16 --> Language Class Initialized
DEBUG - 2015-02-03 08:18:16 --> Loader Class Initialized
DEBUG - 2015-02-03 08:18:16 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:18:16 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:18:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:18:17 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:18:17 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:18:17 --> Model Class Initialized
DEBUG - 2015-02-03 08:18:17 --> Model Class Initialized
DEBUG - 2015-02-03 08:18:17 --> Controller Class Initialized
DEBUG - 2015-02-03 08:18:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:18:17 --> Email Class Initialized
DEBUG - 2015-02-03 08:18:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:18:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:18:17 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:18:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:18:17 --> Model Class Initialized
DEBUG - 2015-02-03 08:18:17 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:18:17 --> Helper loaded: date_helper
ERROR - 2015-02-03 08:18:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php:252) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-03 08:18:17 --> Severity: Error --> Call to undefined method CI_DB_mysql_driver::get_last_query() D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 252
DEBUG - 2015-02-03 08:18:52 --> Config Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:18:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:18:52 --> URI Class Initialized
DEBUG - 2015-02-03 08:18:52 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:18:52 --> Router Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Output Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Security Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Input Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:18:52 --> Language Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Loader Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:18:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:18:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:18:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:18:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:18:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:18:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:18:53 --> Controller Class Initialized
DEBUG - 2015-02-03 08:18:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:18:53 --> Email Class Initialized
DEBUG - 2015-02-03 08:18:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:18:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:18:53 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:18:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:18:53 --> Model Class Initialized
DEBUG - 2015-02-03 08:18:53 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:18:53 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:18:53 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:18:53 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:18:53 --> Model Class Initialized
DEBUG - 2015-02-03 08:18:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:18:53 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:18:53 --> Final output sent to browser
DEBUG - 2015-02-03 08:18:53 --> Total execution time: 0.7951
DEBUG - 2015-02-03 08:20:29 --> Config Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:20:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:20:29 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:20:29 --> URI Class Initialized
DEBUG - 2015-02-03 08:20:29 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:20:29 --> Router Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Output Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Security Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Input Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:20:29 --> Language Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Loader Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:20:29 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:20:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:20:29 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:20:29 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:20:29 --> Model Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Model Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Controller Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:20:29 --> Email Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:20:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:20:29 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:20:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:20:29 --> Model Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:20:29 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:20:29 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Model Class Initialized
DEBUG - 2015-02-03 08:20:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:20:29 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:20:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:20:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:20:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:20:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:20:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:20:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:20:30 --> Final output sent to browser
DEBUG - 2015-02-03 08:20:30 --> Total execution time: 0.6941
DEBUG - 2015-02-03 08:21:16 --> Config Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:21:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:21:16 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:21:16 --> URI Class Initialized
DEBUG - 2015-02-03 08:21:16 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:21:16 --> Router Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Output Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Security Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Input Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:21:16 --> Language Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Loader Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:21:16 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:21:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:21:16 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Session: Regenerate ID
DEBUG - 2015-02-03 08:21:16 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:21:16 --> Model Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Model Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Controller Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:21:16 --> Email Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:21:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:21:16 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:21:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:21:16 --> Model Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:21:16 --> Helper loaded: date_helper
ERROR - 2015-02-03 08:21:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php:1746) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-03 08:21:16 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::rows() D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 1746
DEBUG - 2015-02-03 08:22:01 --> Config Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:22:01 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:22:01 --> URI Class Initialized
DEBUG - 2015-02-03 08:22:01 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:22:01 --> Router Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Output Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Security Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Input Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:22:01 --> Language Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Loader Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:22:01 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:22:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:22:01 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:22:01 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:22:01 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Controller Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:22:01 --> Email Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:22:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:22:01 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:22:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:22:01 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:22:01 --> Helper loaded: date_helper
ERROR - 2015-02-03 08:22:01 --> Query error: No tables used - Invalid query: SELECT *
DEBUG - 2015-02-03 08:22:01 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-03 08:22:35 --> Config Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:22:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:22:35 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:22:35 --> URI Class Initialized
DEBUG - 2015-02-03 08:22:35 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:22:35 --> Router Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Output Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Security Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Input Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:22:35 --> Language Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Loader Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:22:35 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:22:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:22:35 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:22:35 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:22:35 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Controller Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:22:35 --> Email Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:22:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:22:35 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:22:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:22:35 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:22:35 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:22:35 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:22:35 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:22:36 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:22:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:22:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:22:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:22:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:22:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:22:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:22:36 --> Final output sent to browser
DEBUG - 2015-02-03 08:22:36 --> Total execution time: 0.7311
DEBUG - 2015-02-03 08:22:52 --> Config Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:22:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:22:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:22:52 --> URI Class Initialized
DEBUG - 2015-02-03 08:22:52 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:22:52 --> Router Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Output Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Security Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Input Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:22:52 --> Language Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Loader Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:22:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:22:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:22:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:22:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:22:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Controller Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:22:52 --> Email Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:22:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:22:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:22:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:22:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:22:52 --> Helper loaded: date_helper
ERROR - 2015-02-03 08:22:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php:1746) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-03 08:22:52 --> Severity: Error --> Call to undefined method CI_DB_mysql_result::row_data() D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 1746
DEBUG - 2015-02-03 08:22:55 --> Config Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:22:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:22:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:22:55 --> URI Class Initialized
DEBUG - 2015-02-03 08:22:55 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:22:55 --> Router Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Output Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Security Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Input Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:22:55 --> Language Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Loader Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:22:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:22:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:22:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:22:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:22:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Controller Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:22:55 --> Email Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:22:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:22:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:22:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:22:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:22:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:22:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:22:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:22:55 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:22:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:22:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:22:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:22:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:22:56 --> Final output sent to browser
DEBUG - 2015-02-03 08:22:56 --> Total execution time: 0.8211
DEBUG - 2015-02-03 08:23:00 --> Config Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:23:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:23:00 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:23:00 --> URI Class Initialized
DEBUG - 2015-02-03 08:23:00 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:23:00 --> Router Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Output Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Security Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Input Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:23:00 --> Language Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Loader Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:23:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:23:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:23:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:23:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:23:00 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Controller Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:23:00 --> Email Class Initialized
DEBUG - 2015-02-03 08:23:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:23:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:23:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:23:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:23:01 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:01 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:23:01 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:23:01 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:23:01 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:23:01 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:23:01 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:23:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:23:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:23:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:23:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:23:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:23:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:23:01 --> Final output sent to browser
DEBUG - 2015-02-03 08:23:01 --> Total execution time: 0.7861
DEBUG - 2015-02-03 08:23:15 --> Config Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:23:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:23:15 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:23:15 --> URI Class Initialized
DEBUG - 2015-02-03 08:23:15 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:23:15 --> Router Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Output Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Security Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Input Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:23:15 --> Language Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Loader Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:23:15 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:23:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:23:15 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:23:15 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:23:15 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Controller Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:23:15 --> Email Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:23:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:23:15 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:23:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:23:15 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:23:15 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:23:15 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:23:15 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:23:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:23:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:23:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:23:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:23:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:23:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:23:15 --> Final output sent to browser
DEBUG - 2015-02-03 08:23:15 --> Total execution time: 0.7981
DEBUG - 2015-02-03 08:23:52 --> Config Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:23:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:23:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:23:52 --> URI Class Initialized
DEBUG - 2015-02-03 08:23:52 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:23:52 --> Router Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Output Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Security Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Input Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:23:52 --> Language Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Loader Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:23:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:23:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:23:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:23:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:23:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Controller Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:23:52 --> Email Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:23:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:23:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:23:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:23:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:23:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:23:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:23:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:23:52 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:23:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:23:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:23:53 --> Final output sent to browser
DEBUG - 2015-02-03 08:23:53 --> Total execution time: 0.7131
DEBUG - 2015-02-03 08:24:19 --> Config Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:24:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:24:19 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:24:19 --> URI Class Initialized
DEBUG - 2015-02-03 08:24:19 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:24:19 --> Router Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Output Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Security Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Input Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:24:19 --> Language Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Loader Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:24:19 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:24:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:24:19 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:24:19 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:24:19 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Controller Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:24:19 --> Email Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:24:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:24:19 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:24:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:24:19 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:24:19 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:24:19 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:24:19 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:24:20 --> Final output sent to browser
DEBUG - 2015-02-03 08:24:20 --> Total execution time: 0.7071
DEBUG - 2015-02-03 08:24:41 --> Config Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:24:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:24:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:24:41 --> URI Class Initialized
DEBUG - 2015-02-03 08:24:41 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:24:41 --> Router Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Output Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Security Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Input Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:24:41 --> Language Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Loader Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:24:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:24:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:24:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:24:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:24:41 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Controller Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:24:41 --> Email Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:24:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:24:41 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:24:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:24:41 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:24:41 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:24:41 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:24:41 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:24:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:24:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:24:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:24:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:24:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:24:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:24:42 --> Final output sent to browser
DEBUG - 2015-02-03 08:24:42 --> Total execution time: 0.6661
DEBUG - 2015-02-03 08:24:43 --> Config Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:24:43 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:24:43 --> URI Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Router Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Output Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Security Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Input Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:24:43 --> Language Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Loader Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:24:43 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:24:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:24:43 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:24:43 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:24:43 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Controller Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:24:43 --> Email Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:24:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:24:43 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:24:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:24:43 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:24:43 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:24:43 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:24:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 08:24:43 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 08:24:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 08:24:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:24:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:24:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-03 08:24:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:24:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:24:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:24:44 --> Final output sent to browser
DEBUG - 2015-02-03 08:24:44 --> Total execution time: 0.2520
DEBUG - 2015-02-03 08:24:55 --> Config Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:24:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:24:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:24:55 --> URI Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Router Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Output Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Security Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Input Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:24:55 --> Language Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Loader Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:24:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:24:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:24:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Controller Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:24:55 --> Email Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:24:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:24:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:24:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 08:24:55 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 08:24:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 08:24:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 08:24:55 --> Config Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:24:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:24:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:24:55 --> URI Class Initialized
DEBUG - 2015-02-03 08:24:55 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:24:55 --> Router Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Output Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Security Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Input Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:24:55 --> Language Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Loader Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:24:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:24:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:24:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Controller Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:24:55 --> Email Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:24:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:24:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:24:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:24:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:24:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:24:55 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:24:56 --> Final output sent to browser
DEBUG - 2015-02-03 08:24:56 --> Total execution time: 0.6931
DEBUG - 2015-02-03 08:25:42 --> Config Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:25:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:25:42 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:25:42 --> URI Class Initialized
DEBUG - 2015-02-03 08:25:42 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:25:42 --> Router Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Output Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Security Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Input Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:25:42 --> Language Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Loader Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:25:42 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:25:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:25:42 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:25:42 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:25:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Controller Class Initialized
DEBUG - 2015-02-03 08:25:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:25:43 --> Email Class Initialized
DEBUG - 2015-02-03 08:25:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:25:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:25:43 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:25:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:25:43 --> Model Class Initialized
DEBUG - 2015-02-03 08:25:43 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:25:43 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:25:43 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:25:43 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:25:43 --> Model Class Initialized
DEBUG - 2015-02-03 08:25:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:25:43 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:25:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:25:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:25:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:25:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:25:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:25:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:25:43 --> Final output sent to browser
DEBUG - 2015-02-03 08:25:43 --> Total execution time: 0.6681
DEBUG - 2015-02-03 08:27:37 --> Config Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:27:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:27:37 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:27:37 --> URI Class Initialized
DEBUG - 2015-02-03 08:27:37 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:27:37 --> Router Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Output Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Security Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Input Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:27:37 --> Language Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Loader Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:27:37 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:27:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:27:37 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Session: Regenerate ID
DEBUG - 2015-02-03 08:27:37 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:27:37 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Controller Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:27:37 --> Email Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:27:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:27:37 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:27:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:37 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:27:37 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:27:37 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:27:37 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:27:38 --> Final output sent to browser
DEBUG - 2015-02-03 08:27:38 --> Total execution time: 0.6941
DEBUG - 2015-02-03 08:27:42 --> Config Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:27:42 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:27:42 --> URI Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Router Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Output Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Security Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Input Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:27:42 --> Language Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Loader Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:27:42 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:27:42 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:27:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Controller Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:27:42 --> Email Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:27:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:27:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 08:27:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 08:27:42 --> Session: Creating new session (ca8dec2d8e60c2f3c27d88f2e6919f69)
DEBUG - 2015-02-03 08:27:42 --> Config Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:27:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:27:42 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:27:42 --> URI Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Router Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Output Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Security Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Input Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:27:42 --> Language Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Loader Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:27:42 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:27:42 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:27:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Controller Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:27:42 --> Email Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:27:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:42 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:27:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:27:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:27:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 08:27:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 08:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-03 08:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:27:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:27:42 --> Final output sent to browser
DEBUG - 2015-02-03 08:27:42 --> Total execution time: 0.1990
DEBUG - 2015-02-03 08:27:51 --> Config Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:27:51 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:27:51 --> URI Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Router Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Output Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Security Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Input Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:27:51 --> Language Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Loader Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:27:51 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:27:51 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:27:51 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Controller Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:27:51 --> Email Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:27:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:51 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:27:51 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 08:27:51 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:51 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 08:27:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 08:27:51 --> Config Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:27:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:27:51 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:27:51 --> URI Class Initialized
DEBUG - 2015-02-03 08:27:51 --> No URI present. Default controller set.
DEBUG - 2015-02-03 08:27:51 --> Router Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Output Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Security Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Input Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:27:51 --> Language Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Loader Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:27:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:27:51 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:27:51 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:27:51 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:51 --> Controller Class Initialized
DEBUG - 2015-02-03 08:27:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:27:52 --> Email Class Initialized
DEBUG - 2015-02-03 08:27:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:27:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:27:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:27:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:27:52 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:27:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:27:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:27:52 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 08:27:52 --> Pagination Class Initialized
DEBUG - 2015-02-03 08:27:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 08:27:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 08:27:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 08:27:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 08:27:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 08:27:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 08:27:52 --> Final output sent to browser
DEBUG - 2015-02-03 08:27:52 --> Total execution time: 0.6931
DEBUG - 2015-02-03 08:27:55 --> Config Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:27:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:27:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:27:55 --> URI Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Router Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Output Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Security Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Input Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:27:55 --> Language Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Loader Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:27:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:27:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:27:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:27:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:27:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Controller Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:27:55 --> Email Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:27:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:27:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:27:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:27:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:27:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:27:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:27:55 --> Model Class Initialized
DEBUG - 2015-02-03 08:27:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 08:27:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 08:27:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 08:27:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 08:27:55 --> Final output sent to browser
DEBUG - 2015-02-03 08:27:55 --> Total execution time: 0.5381
DEBUG - 2015-02-03 08:42:56 --> Config Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:42:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:42:56 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:42:56 --> URI Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Router Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Output Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Security Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Input Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:42:56 --> Language Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Loader Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:42:56 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:42:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:42:56 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Session: Regenerate ID
DEBUG - 2015-02-03 08:42:56 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:42:56 --> Model Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Model Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Controller Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:42:56 --> Email Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:42:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:42:56 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:42:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:42:56 --> Model Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:42:56 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:42:56 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:42:56 --> Model Class Initialized
DEBUG - 2015-02-03 08:42:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 08:42:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 08:42:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 08:42:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 08:42:56 --> Final output sent to browser
DEBUG - 2015-02-03 08:42:56 --> Total execution time: 0.3730
DEBUG - 2015-02-03 08:57:57 --> Config Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Hooks Class Initialized
DEBUG - 2015-02-03 08:57:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 08:57:57 --> Utf8 Class Initialized
DEBUG - 2015-02-03 08:57:57 --> URI Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Router Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Output Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Security Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Input Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 08:57:57 --> Language Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Loader Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Helper loaded: url_helper
DEBUG - 2015-02-03 08:57:57 --> Helper loaded: link_helper
DEBUG - 2015-02-03 08:57:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 08:57:57 --> CI_Session Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Session: Regenerate ID
DEBUG - 2015-02-03 08:57:57 --> CI_Session routines successfully run
DEBUG - 2015-02-03 08:57:57 --> Model Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Model Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Controller Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 08:57:57 --> Email Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 08:57:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 08:57:57 --> Helper loaded: language_helper
DEBUG - 2015-02-03 08:57:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 08:57:57 --> Model Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Database Driver Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Helper loaded: date_helper
DEBUG - 2015-02-03 08:57:57 --> Helper loaded: form_helper
DEBUG - 2015-02-03 08:57:57 --> Form Validation Class Initialized
DEBUG - 2015-02-03 08:57:57 --> Model Class Initialized
DEBUG - 2015-02-03 08:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 08:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 08:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 08:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 08:57:57 --> Final output sent to browser
DEBUG - 2015-02-03 08:57:57 --> Total execution time: 0.2810
DEBUG - 2015-02-03 09:12:58 --> Config Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Hooks Class Initialized
DEBUG - 2015-02-03 09:12:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 09:12:58 --> Utf8 Class Initialized
DEBUG - 2015-02-03 09:12:58 --> URI Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Router Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Output Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Security Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Input Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 09:12:58 --> Language Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Loader Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Helper loaded: url_helper
DEBUG - 2015-02-03 09:12:58 --> Helper loaded: link_helper
DEBUG - 2015-02-03 09:12:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 09:12:58 --> CI_Session Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Session: Regenerate ID
DEBUG - 2015-02-03 09:12:58 --> CI_Session routines successfully run
DEBUG - 2015-02-03 09:12:58 --> Model Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Model Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Controller Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 09:12:58 --> Email Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 09:12:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 09:12:58 --> Helper loaded: language_helper
DEBUG - 2015-02-03 09:12:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 09:12:58 --> Model Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Database Driver Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Helper loaded: date_helper
DEBUG - 2015-02-03 09:12:58 --> Helper loaded: form_helper
DEBUG - 2015-02-03 09:12:58 --> Form Validation Class Initialized
DEBUG - 2015-02-03 09:12:58 --> Model Class Initialized
DEBUG - 2015-02-03 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 09:12:58 --> Final output sent to browser
DEBUG - 2015-02-03 09:12:58 --> Total execution time: 0.2970
DEBUG - 2015-02-03 09:28:08 --> Config Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 09:28:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 09:28:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 09:28:08 --> URI Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Router Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Output Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Security Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Input Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 09:28:08 --> Language Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Loader Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 09:28:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 09:28:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 09:28:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Session: Regenerate ID
DEBUG - 2015-02-03 09:28:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 09:28:08 --> Model Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Model Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Controller Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 09:28:08 --> Email Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 09:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 09:28:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 09:28:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 09:28:08 --> Model Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 09:28:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 09:28:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 09:28:08 --> Model Class Initialized
DEBUG - 2015-02-03 09:28:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 09:28:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 09:28:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 09:28:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 09:28:08 --> Final output sent to browser
DEBUG - 2015-02-03 09:28:08 --> Total execution time: 0.3080
DEBUG - 2015-02-03 09:43:09 --> Config Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Hooks Class Initialized
DEBUG - 2015-02-03 09:43:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 09:43:09 --> Utf8 Class Initialized
DEBUG - 2015-02-03 09:43:09 --> URI Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Router Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Output Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Security Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Input Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 09:43:09 --> Language Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Loader Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Helper loaded: url_helper
DEBUG - 2015-02-03 09:43:09 --> Helper loaded: link_helper
DEBUG - 2015-02-03 09:43:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 09:43:09 --> CI_Session Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Session: Regenerate ID
DEBUG - 2015-02-03 09:43:09 --> CI_Session routines successfully run
DEBUG - 2015-02-03 09:43:09 --> Model Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Model Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Controller Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 09:43:09 --> Email Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 09:43:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 09:43:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 09:43:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 09:43:09 --> Model Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 09:43:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 09:43:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 09:43:09 --> Model Class Initialized
DEBUG - 2015-02-03 09:43:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 09:43:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 09:43:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 09:43:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 09:43:09 --> Final output sent to browser
DEBUG - 2015-02-03 09:43:09 --> Total execution time: 0.3850
DEBUG - 2015-02-03 09:58:11 --> Config Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Hooks Class Initialized
DEBUG - 2015-02-03 09:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 09:58:11 --> Utf8 Class Initialized
DEBUG - 2015-02-03 09:58:11 --> URI Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Router Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Output Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Security Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Input Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 09:58:11 --> Language Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Loader Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Helper loaded: url_helper
DEBUG - 2015-02-03 09:58:11 --> Helper loaded: link_helper
DEBUG - 2015-02-03 09:58:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 09:58:11 --> CI_Session Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Session: Regenerate ID
DEBUG - 2015-02-03 09:58:11 --> CI_Session routines successfully run
DEBUG - 2015-02-03 09:58:11 --> Model Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Model Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Controller Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 09:58:11 --> Email Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 09:58:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 09:58:11 --> Helper loaded: language_helper
DEBUG - 2015-02-03 09:58:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 09:58:11 --> Model Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Database Driver Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Helper loaded: date_helper
DEBUG - 2015-02-03 09:58:11 --> Helper loaded: form_helper
DEBUG - 2015-02-03 09:58:11 --> Form Validation Class Initialized
DEBUG - 2015-02-03 09:58:11 --> Model Class Initialized
DEBUG - 2015-02-03 09:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 09:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 09:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 09:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 09:58:11 --> Final output sent to browser
DEBUG - 2015-02-03 09:58:11 --> Total execution time: 0.3210
DEBUG - 2015-02-03 10:13:13 --> Config Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Hooks Class Initialized
DEBUG - 2015-02-03 10:13:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 10:13:13 --> Utf8 Class Initialized
DEBUG - 2015-02-03 10:13:13 --> URI Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Router Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Output Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Security Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Input Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 10:13:13 --> Language Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Loader Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Helper loaded: url_helper
DEBUG - 2015-02-03 10:13:13 --> Helper loaded: link_helper
DEBUG - 2015-02-03 10:13:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 10:13:13 --> CI_Session Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Session: Regenerate ID
DEBUG - 2015-02-03 10:13:13 --> CI_Session routines successfully run
DEBUG - 2015-02-03 10:13:13 --> Model Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Model Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Controller Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 10:13:13 --> Email Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 10:13:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 10:13:13 --> Helper loaded: language_helper
DEBUG - 2015-02-03 10:13:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 10:13:13 --> Model Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Database Driver Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Helper loaded: date_helper
DEBUG - 2015-02-03 10:13:13 --> Helper loaded: form_helper
DEBUG - 2015-02-03 10:13:13 --> Form Validation Class Initialized
DEBUG - 2015-02-03 10:13:13 --> Model Class Initialized
DEBUG - 2015-02-03 10:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 10:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 10:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 10:13:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 10:13:13 --> Final output sent to browser
DEBUG - 2015-02-03 10:13:13 --> Total execution time: 0.2920
DEBUG - 2015-02-03 10:28:15 --> Config Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Hooks Class Initialized
DEBUG - 2015-02-03 10:28:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 10:28:15 --> Utf8 Class Initialized
DEBUG - 2015-02-03 10:28:15 --> URI Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Router Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Output Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Security Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Input Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 10:28:15 --> Language Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Loader Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Helper loaded: url_helper
DEBUG - 2015-02-03 10:28:15 --> Helper loaded: link_helper
DEBUG - 2015-02-03 10:28:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 10:28:15 --> CI_Session Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Session: Regenerate ID
DEBUG - 2015-02-03 10:28:15 --> CI_Session routines successfully run
DEBUG - 2015-02-03 10:28:15 --> Model Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Model Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Controller Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 10:28:15 --> Email Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 10:28:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 10:28:15 --> Helper loaded: language_helper
DEBUG - 2015-02-03 10:28:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 10:28:15 --> Model Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Database Driver Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Helper loaded: date_helper
DEBUG - 2015-02-03 10:28:15 --> Helper loaded: form_helper
DEBUG - 2015-02-03 10:28:15 --> Form Validation Class Initialized
DEBUG - 2015-02-03 10:28:15 --> Model Class Initialized
DEBUG - 2015-02-03 10:28:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 10:28:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 10:28:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 10:28:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 10:28:15 --> Final output sent to browser
DEBUG - 2015-02-03 10:28:15 --> Total execution time: 0.2930
DEBUG - 2015-02-03 10:43:16 --> Config Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Hooks Class Initialized
DEBUG - 2015-02-03 10:43:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 10:43:16 --> Utf8 Class Initialized
DEBUG - 2015-02-03 10:43:16 --> URI Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Router Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Output Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Security Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Input Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 10:43:16 --> Language Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Loader Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Helper loaded: url_helper
DEBUG - 2015-02-03 10:43:16 --> Helper loaded: link_helper
DEBUG - 2015-02-03 10:43:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 10:43:16 --> CI_Session Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Session: Regenerate ID
DEBUG - 2015-02-03 10:43:16 --> CI_Session routines successfully run
DEBUG - 2015-02-03 10:43:16 --> Model Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Model Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Controller Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 10:43:16 --> Email Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 10:43:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 10:43:16 --> Helper loaded: language_helper
DEBUG - 2015-02-03 10:43:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 10:43:16 --> Model Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Database Driver Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Helper loaded: date_helper
DEBUG - 2015-02-03 10:43:16 --> Helper loaded: form_helper
DEBUG - 2015-02-03 10:43:16 --> Form Validation Class Initialized
DEBUG - 2015-02-03 10:43:16 --> Model Class Initialized
DEBUG - 2015-02-03 10:43:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 10:43:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 10:43:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 10:43:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 10:43:16 --> Final output sent to browser
DEBUG - 2015-02-03 10:43:16 --> Total execution time: 0.3690
DEBUG - 2015-02-03 10:58:17 --> Config Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Hooks Class Initialized
DEBUG - 2015-02-03 10:58:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 10:58:17 --> Utf8 Class Initialized
DEBUG - 2015-02-03 10:58:17 --> URI Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Router Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Output Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Security Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Input Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 10:58:17 --> Language Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Loader Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Helper loaded: url_helper
DEBUG - 2015-02-03 10:58:17 --> Helper loaded: link_helper
DEBUG - 2015-02-03 10:58:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 10:58:17 --> CI_Session Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Session: Regenerate ID
DEBUG - 2015-02-03 10:58:17 --> CI_Session routines successfully run
DEBUG - 2015-02-03 10:58:17 --> Model Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Model Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Controller Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 10:58:17 --> Email Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 10:58:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 10:58:17 --> Helper loaded: language_helper
DEBUG - 2015-02-03 10:58:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 10:58:17 --> Model Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Database Driver Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Helper loaded: date_helper
DEBUG - 2015-02-03 10:58:17 --> Helper loaded: form_helper
DEBUG - 2015-02-03 10:58:17 --> Form Validation Class Initialized
DEBUG - 2015-02-03 10:58:17 --> Model Class Initialized
DEBUG - 2015-02-03 10:58:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 10:58:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 10:58:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 10:58:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 10:58:17 --> Final output sent to browser
DEBUG - 2015-02-03 10:58:17 --> Total execution time: 0.2940
DEBUG - 2015-02-03 11:13:18 --> Config Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Hooks Class Initialized
DEBUG - 2015-02-03 11:13:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 11:13:18 --> Utf8 Class Initialized
DEBUG - 2015-02-03 11:13:18 --> URI Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Router Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Output Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Security Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Input Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 11:13:18 --> Language Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Loader Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Helper loaded: url_helper
DEBUG - 2015-02-03 11:13:18 --> Helper loaded: link_helper
DEBUG - 2015-02-03 11:13:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 11:13:18 --> CI_Session Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Session: Regenerate ID
DEBUG - 2015-02-03 11:13:18 --> CI_Session routines successfully run
DEBUG - 2015-02-03 11:13:18 --> Model Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Model Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Controller Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 11:13:18 --> Email Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 11:13:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 11:13:18 --> Helper loaded: language_helper
DEBUG - 2015-02-03 11:13:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 11:13:18 --> Model Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Database Driver Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Helper loaded: date_helper
DEBUG - 2015-02-03 11:13:18 --> Helper loaded: form_helper
DEBUG - 2015-02-03 11:13:18 --> Form Validation Class Initialized
DEBUG - 2015-02-03 11:13:18 --> Model Class Initialized
DEBUG - 2015-02-03 11:13:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 11:13:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 11:13:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 11:13:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 11:13:18 --> Final output sent to browser
DEBUG - 2015-02-03 11:13:18 --> Total execution time: 0.3190
DEBUG - 2015-02-03 11:28:28 --> Config Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 11:28:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 11:28:28 --> URI Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Router Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Output Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Security Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Input Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 11:28:28 --> Language Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Loader Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 11:28:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 11:28:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 11:28:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Session: Regenerate ID
DEBUG - 2015-02-03 11:28:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 11:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Controller Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 11:28:28 --> Email Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 11:28:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 11:28:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 11:28:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 11:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 11:28:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 11:28:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 11:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 11:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 11:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 11:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 11:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 11:28:28 --> Final output sent to browser
DEBUG - 2015-02-03 11:28:28 --> Total execution time: 0.2960
DEBUG - 2015-02-03 11:43:29 --> Config Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Hooks Class Initialized
DEBUG - 2015-02-03 11:43:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 11:43:29 --> Utf8 Class Initialized
DEBUG - 2015-02-03 11:43:29 --> URI Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Router Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Output Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Security Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Input Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 11:43:29 --> Language Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Loader Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Helper loaded: url_helper
DEBUG - 2015-02-03 11:43:29 --> Helper loaded: link_helper
DEBUG - 2015-02-03 11:43:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 11:43:29 --> CI_Session Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Session: Regenerate ID
DEBUG - 2015-02-03 11:43:29 --> CI_Session routines successfully run
DEBUG - 2015-02-03 11:43:29 --> Model Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Model Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Controller Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 11:43:29 --> Email Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 11:43:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 11:43:29 --> Helper loaded: language_helper
DEBUG - 2015-02-03 11:43:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 11:43:29 --> Model Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Database Driver Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Helper loaded: date_helper
DEBUG - 2015-02-03 11:43:29 --> Helper loaded: form_helper
DEBUG - 2015-02-03 11:43:29 --> Form Validation Class Initialized
DEBUG - 2015-02-03 11:43:29 --> Model Class Initialized
DEBUG - 2015-02-03 11:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 11:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 11:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 11:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 11:43:29 --> Final output sent to browser
DEBUG - 2015-02-03 11:43:29 --> Total execution time: 0.2850
DEBUG - 2015-02-03 11:58:30 --> Config Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Hooks Class Initialized
DEBUG - 2015-02-03 11:58:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 11:58:30 --> Utf8 Class Initialized
DEBUG - 2015-02-03 11:58:30 --> URI Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Router Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Output Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Security Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Input Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 11:58:30 --> Language Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Loader Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Helper loaded: url_helper
DEBUG - 2015-02-03 11:58:30 --> Helper loaded: link_helper
DEBUG - 2015-02-03 11:58:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 11:58:30 --> CI_Session Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Session: Regenerate ID
DEBUG - 2015-02-03 11:58:30 --> CI_Session routines successfully run
DEBUG - 2015-02-03 11:58:30 --> Model Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Model Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Controller Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 11:58:30 --> Email Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 11:58:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 11:58:30 --> Helper loaded: language_helper
DEBUG - 2015-02-03 11:58:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 11:58:30 --> Model Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Database Driver Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Helper loaded: date_helper
DEBUG - 2015-02-03 11:58:30 --> Helper loaded: form_helper
DEBUG - 2015-02-03 11:58:30 --> Form Validation Class Initialized
DEBUG - 2015-02-03 11:58:30 --> Model Class Initialized
DEBUG - 2015-02-03 11:58:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 11:58:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 11:58:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 11:58:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 11:58:30 --> Final output sent to browser
DEBUG - 2015-02-03 11:58:30 --> Total execution time: 0.3040
DEBUG - 2015-02-03 12:13:31 --> Config Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 12:13:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 12:13:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 12:13:31 --> URI Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Router Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Output Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Security Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Input Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 12:13:31 --> Language Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Loader Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 12:13:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 12:13:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 12:13:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Session: Regenerate ID
DEBUG - 2015-02-03 12:13:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 12:13:31 --> Model Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Model Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Controller Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 12:13:31 --> Email Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 12:13:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 12:13:31 --> Helper loaded: language_helper
DEBUG - 2015-02-03 12:13:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 12:13:31 --> Model Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Database Driver Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Helper loaded: date_helper
DEBUG - 2015-02-03 12:13:31 --> Helper loaded: form_helper
DEBUG - 2015-02-03 12:13:31 --> Form Validation Class Initialized
DEBUG - 2015-02-03 12:13:31 --> Model Class Initialized
DEBUG - 2015-02-03 12:13:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 12:13:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 12:13:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 12:13:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 12:13:31 --> Final output sent to browser
DEBUG - 2015-02-03 12:13:31 --> Total execution time: 0.3300
DEBUG - 2015-02-03 12:28:40 --> Config Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Hooks Class Initialized
DEBUG - 2015-02-03 12:28:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 12:28:40 --> Utf8 Class Initialized
DEBUG - 2015-02-03 12:28:40 --> URI Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Router Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Output Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Security Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Input Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 12:28:40 --> Language Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Loader Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Helper loaded: url_helper
DEBUG - 2015-02-03 12:28:40 --> Helper loaded: link_helper
DEBUG - 2015-02-03 12:28:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 12:28:40 --> CI_Session Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Session: Regenerate ID
DEBUG - 2015-02-03 12:28:40 --> CI_Session routines successfully run
DEBUG - 2015-02-03 12:28:40 --> Model Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Model Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Controller Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 12:28:40 --> Email Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 12:28:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 12:28:40 --> Helper loaded: language_helper
DEBUG - 2015-02-03 12:28:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 12:28:40 --> Model Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Database Driver Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Helper loaded: date_helper
DEBUG - 2015-02-03 12:28:40 --> Helper loaded: form_helper
DEBUG - 2015-02-03 12:28:40 --> Form Validation Class Initialized
DEBUG - 2015-02-03 12:28:40 --> Model Class Initialized
DEBUG - 2015-02-03 12:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 12:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 12:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 12:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 12:28:41 --> Final output sent to browser
DEBUG - 2015-02-03 12:28:41 --> Total execution time: 0.2960
DEBUG - 2015-02-03 12:43:41 --> Config Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 12:43:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 12:43:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 12:43:41 --> URI Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Router Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Output Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Security Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Input Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 12:43:41 --> Language Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Loader Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 12:43:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 12:43:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 12:43:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Session: Regenerate ID
DEBUG - 2015-02-03 12:43:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 12:43:41 --> Model Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Model Class Initialized
DEBUG - 2015-02-03 12:43:41 --> Controller Class Initialized
DEBUG - 2015-02-03 12:43:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 12:43:42 --> Email Class Initialized
DEBUG - 2015-02-03 12:43:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 12:43:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 12:43:42 --> Helper loaded: language_helper
DEBUG - 2015-02-03 12:43:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 12:43:42 --> Model Class Initialized
DEBUG - 2015-02-03 12:43:42 --> Database Driver Class Initialized
DEBUG - 2015-02-03 12:43:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 12:43:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 12:43:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 12:43:42 --> Model Class Initialized
DEBUG - 2015-02-03 12:43:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 12:43:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 12:43:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 12:43:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 12:43:42 --> Final output sent to browser
DEBUG - 2015-02-03 12:43:42 --> Total execution time: 0.3070
DEBUG - 2015-02-03 12:58:45 --> Config Class Initialized
DEBUG - 2015-02-03 12:58:45 --> Hooks Class Initialized
DEBUG - 2015-02-03 12:58:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 12:58:46 --> Utf8 Class Initialized
DEBUG - 2015-02-03 12:58:46 --> URI Class Initialized
DEBUG - 2015-02-03 12:58:46 --> Router Class Initialized
DEBUG - 2015-02-03 12:58:46 --> Output Class Initialized
DEBUG - 2015-02-03 12:58:46 --> Security Class Initialized
DEBUG - 2015-02-03 12:58:46 --> Input Class Initialized
DEBUG - 2015-02-03 12:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 12:58:46 --> Language Class Initialized
DEBUG - 2015-02-03 12:58:46 --> Loader Class Initialized
DEBUG - 2015-02-03 12:58:46 --> Helper loaded: url_helper
DEBUG - 2015-02-03 12:58:46 --> Helper loaded: link_helper
DEBUG - 2015-02-03 12:58:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 12:58:46 --> CI_Session Class Initialized
ERROR - 2015-02-03 12:58:46 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-03 12:58:46 --> Session: Creating new session (1d7dbf91989c8a9596178a3bad9fbd2d)
DEBUG - 2015-02-03 12:58:46 --> CI_Session routines successfully run
DEBUG - 2015-02-03 12:58:48 --> Model Class Initialized
DEBUG - 2015-02-03 12:58:48 --> Model Class Initialized
DEBUG - 2015-02-03 12:58:48 --> Controller Class Initialized
DEBUG - 2015-02-03 12:58:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 12:58:48 --> Email Class Initialized
DEBUG - 2015-02-03 12:58:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 12:58:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 12:58:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 12:58:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 12:58:48 --> Model Class Initialized
DEBUG - 2015-02-03 12:58:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 12:58:49 --> Helper loaded: date_helper
DEBUG - 2015-02-03 12:58:49 --> Helper loaded: form_helper
DEBUG - 2015-02-03 12:58:49 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Config Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:02:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:02:23 --> URI Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Router Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Output Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Security Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Input Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:02:23 --> Language Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Loader Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:02:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:02:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:02:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:02:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:02:23 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Controller Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:02:23 --> Email Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:02:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:02:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:02:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:23 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:02:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:02:23 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:02:23 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Config Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:02:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:02:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:02:28 --> URI Class Initialized
DEBUG - 2015-02-03 13:02:28 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:02:28 --> Router Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Output Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Security Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Input Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:02:28 --> Language Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Loader Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:02:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:02:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:02:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:02:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:02:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Controller Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:02:28 --> Email Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:02:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:02:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:02:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:02:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:02:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:02:28 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:02:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:02:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:02:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:02:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:02:31 --> Final output sent to browser
DEBUG - 2015-02-03 13:02:31 --> Total execution time: 2.5983
DEBUG - 2015-02-03 13:02:38 --> Config Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:02:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:02:38 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:02:38 --> URI Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Router Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Output Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Security Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Input Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:02:38 --> Language Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Loader Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:02:38 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:02:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:02:38 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:02:38 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:02:38 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Controller Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:02:38 --> Email Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:02:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:02:38 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:02:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:38 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:02:38 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:02:38 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:02:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:02:38 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:38 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 13:02:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:02:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:02:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-03 13:02:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:02:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:02:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:02:38 --> Final output sent to browser
DEBUG - 2015-02-03 13:02:38 --> Total execution time: 0.2130
DEBUG - 2015-02-03 13:02:48 --> Config Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:02:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:02:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:02:48 --> URI Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Router Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Output Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Security Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Input Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:02:48 --> Language Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Loader Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:02:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:02:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:02:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Controller Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:02:48 --> Email Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:02:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:02:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:02:48 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 13:02:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 13:02:48 --> Config Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:02:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:02:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:02:48 --> URI Class Initialized
DEBUG - 2015-02-03 13:02:48 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:02:48 --> Router Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Output Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Security Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Input Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:02:48 --> Language Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Loader Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:02:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:02:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:02:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Controller Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:02:48 --> Email Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:02:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:02:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:02:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:02:48 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:02:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:02:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:02:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:02:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:02:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:02:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:02:49 --> Final output sent to browser
DEBUG - 2015-02-03 13:02:49 --> Total execution time: 0.6551
DEBUG - 2015-02-03 13:02:57 --> Config Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:02:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:02:58 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:02:58 --> URI Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Router Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Output Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Security Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Input Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:02:58 --> Language Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Loader Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:02:58 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:02:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:02:58 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:02:58 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:02:58 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Controller Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:02:58 --> Email Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:02:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:02:58 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:02:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:02:58 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:02:58 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:02:58 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:02:58 --> Model Class Initialized
DEBUG - 2015-02-03 13:02:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:02:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:02:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 13:02:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:02:58 --> Final output sent to browser
DEBUG - 2015-02-03 13:02:58 --> Total execution time: 1.5212
DEBUG - 2015-02-03 13:03:23 --> Config Class Initialized
DEBUG - 2015-02-03 13:03:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:03:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:03:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Config Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:05:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:05:05 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:05:05 --> URI Class Initialized
DEBUG - 2015-02-03 13:05:05 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:05:05 --> Router Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Output Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Security Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Input Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:05:05 --> Language Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Loader Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:05:05 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:05:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:05:05 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Session: Regenerate ID
DEBUG - 2015-02-03 13:05:05 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:05:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Controller Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:05:05 --> Email Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:05:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:05:05 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:05:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:05:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:05:05 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:05:05 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:05:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:05:05 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:05:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:05:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:05:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:05:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:05:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:05:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:05:05 --> Final output sent to browser
DEBUG - 2015-02-03 13:05:05 --> Total execution time: 0.6841
DEBUG - 2015-02-03 13:05:13 --> Config Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:05:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:05:13 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:05:13 --> URI Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Router Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Output Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Security Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Input Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:05:13 --> Language Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Loader Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:05:13 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:05:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:05:13 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:05:13 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:05:13 --> Model Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Model Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Controller Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:05:13 --> Email Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:05:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:05:13 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:05:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:05:13 --> Model Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:05:13 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:05:13 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:05:13 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:05:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:05:14 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:05:14 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:05:14 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:05:14 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:05:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:05:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:05:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:05:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:05:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:05:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:05:14 --> Final output sent to browser
DEBUG - 2015-02-03 13:05:14 --> Total execution time: 0.2580
DEBUG - 2015-02-03 13:06:23 --> Config Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:06:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:06:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:06:23 --> URI Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Router Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Output Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Security Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Input Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:06:23 --> Language Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Loader Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:06:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:06:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:06:23 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Controller Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:06:23 --> Email Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:06:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:06:23 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:06:23 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:06:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:06:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:06:23 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:06:23 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:06:23 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:06:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:06:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:06:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:06:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:06:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:06:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:06:23 --> Final output sent to browser
DEBUG - 2015-02-03 13:06:23 --> Total execution time: 0.2400
DEBUG - 2015-02-03 13:06:32 --> Config Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:06:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:06:32 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:06:32 --> URI Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Router Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Output Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Security Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Input Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:06:32 --> Language Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Loader Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:06:32 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:06:32 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:06:32 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Controller Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:06:32 --> Email Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:06:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:06:32 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:06:32 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:06:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:06:32 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:06:32 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:06:32 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:06:32 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:06:32 --> Final output sent to browser
DEBUG - 2015-02-03 13:06:32 --> Total execution time: 0.2660
DEBUG - 2015-02-03 13:06:41 --> Config Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:06:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:06:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:06:41 --> URI Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Router Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Output Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Security Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Input Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:06:41 --> Language Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Loader Class Initialized
DEBUG - 2015-02-03 13:06:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:06:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:06:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:06:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:06:42 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:06:42 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:42 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:42 --> Controller Class Initialized
DEBUG - 2015-02-03 13:06:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:06:42 --> Email Class Initialized
DEBUG - 2015-02-03 13:06:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:06:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:06:42 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:06:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:06:42 --> Model Class Initialized
DEBUG - 2015-02-03 13:06:42 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:06:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:06:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:06:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:06:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:06:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:06:42 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:06:42 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:06:42 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:06:42 --> Final output sent to browser
DEBUG - 2015-02-03 13:06:42 --> Total execution time: 0.2420
DEBUG - 2015-02-03 13:07:28 --> Config Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:07:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:07:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:07:28 --> URI Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Router Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Output Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Security Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Input Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:07:28 --> Language Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Loader Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:07:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:07:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:07:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Controller Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:07:28 --> Email Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:07:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:07:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:07:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:07:28 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:07:28 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:07:28 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:07:28 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:07:28 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:07:28 --> Final output sent to browser
DEBUG - 2015-02-03 13:07:28 --> Total execution time: 0.2470
DEBUG - 2015-02-03 13:08:50 --> Config Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:08:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:08:50 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:08:50 --> URI Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Router Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Output Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Security Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Input Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:08:50 --> Language Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Loader Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:08:50 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:08:50 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:08:50 --> Model Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Model Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Controller Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:08:50 --> Email Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:08:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:08:50 --> Model Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:08:50 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:08:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:08:50 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:08:50 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:08:50 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:08:50 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:08:50 --> Final output sent to browser
DEBUG - 2015-02-03 13:08:50 --> Total execution time: 0.2240
DEBUG - 2015-02-03 13:09:08 --> Config Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:09:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:09:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:09:08 --> URI Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Router Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Output Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Security Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Input Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:09:08 --> Language Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Loader Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:09:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:09:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:09:08 --> Model Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Model Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Controller Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:09:08 --> Email Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:09:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:09:08 --> Model Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:09:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:09:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:09:08 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:09:08 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:09:08 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:09:08 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:09:08 --> Final output sent to browser
DEBUG - 2015-02-03 13:09:08 --> Total execution time: 0.2690
DEBUG - 2015-02-03 13:09:41 --> Config Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:09:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:09:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:09:41 --> URI Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Router Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Output Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Security Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Input Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:09:41 --> Language Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Loader Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:09:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:09:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:09:41 --> Model Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Model Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Controller Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:09:41 --> Email Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:09:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:09:41 --> Model Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:09:41 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:09:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:09:41 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:09:41 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:09:41 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:09:41 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:09:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:09:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:09:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:09:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:09:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:09:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:09:41 --> Final output sent to browser
DEBUG - 2015-02-03 13:09:41 --> Total execution time: 0.2420
DEBUG - 2015-02-03 13:10:10 --> Config Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:10:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:10:10 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:10:10 --> URI Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Router Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Output Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Security Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Input Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:10:10 --> Language Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Loader Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:10:10 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:10:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:10:10 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Session: Regenerate ID
DEBUG - 2015-02-03 13:10:10 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:10:10 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Controller Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:10:10 --> Email Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:10:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:10:10 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:10:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:10 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:10:10 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:10:10 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:10:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:10:10 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:10 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:10:10 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:10:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 13:10:11 --> Config Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:10:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:10:11 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:10:11 --> URI Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Router Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Output Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Security Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Input Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:10:11 --> Language Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Loader Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:10:11 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:10:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:10:11 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:10:11 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:10:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Controller Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:10:11 --> Email Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:10:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:10:11 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:10:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:10:11 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:10:11 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:10:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:10:11 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:11 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 13:10:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:10:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:10:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-03 13:10:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:10:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:10:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:10:11 --> Final output sent to browser
DEBUG - 2015-02-03 13:10:11 --> Total execution time: 0.2860
DEBUG - 2015-02-03 13:10:49 --> Config Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:10:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:10:49 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:10:49 --> URI Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Router Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Output Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Security Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Input Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:10:49 --> Language Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Loader Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:10:49 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:10:49 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:10:49 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Controller Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:10:49 --> Email Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:10:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:49 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:10:49 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:10:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:10:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:49 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:10:49 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:10:49 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:10:49 --> Final output sent to browser
DEBUG - 2015-02-03 13:10:49 --> Total execution time: 0.2320
DEBUG - 2015-02-03 13:10:53 --> Config Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:10:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:10:53 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:10:53 --> URI Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Router Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Output Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Security Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Input Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:10:53 --> Language Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Loader Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:10:53 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:10:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:10:53 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:10:53 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:10:53 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Controller Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:10:53 --> Email Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:10:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:10:53 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:10:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:53 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:10:53 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:10:53 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:10:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:10:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:53 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:10:53 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:10:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 13:10:54 --> Config Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:10:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:10:54 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:10:54 --> URI Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Router Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Output Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Security Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Input Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:10:54 --> Language Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Loader Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:10:54 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:10:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:10:54 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:10:54 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:10:54 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Controller Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:10:54 --> Email Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:10:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:10:54 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:10:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:54 --> Model Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:10:54 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:10:54 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:10:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:10:54 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:10:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-03 13:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/index.php
DEBUG - 2015-02-03 13:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:10:54 --> Final output sent to browser
DEBUG - 2015-02-03 13:10:54 --> Total execution time: 0.2180
DEBUG - 2015-02-03 13:11:08 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:08 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:08 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:08 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:08 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:08 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:08 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:08 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:08 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:08 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:11:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:11:08 --> Final output sent to browser
DEBUG - 2015-02-03 13:11:08 --> Total execution time: 0.2390
DEBUG - 2015-02-03 13:11:10 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:10 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:10 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:10 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:10 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:10 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:10 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:10 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:10 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:10 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:10 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:10 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:10 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:10 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:10 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:10 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 13:11:11 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:11 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:11 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:11 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:11 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:11 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:11 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:11 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:11 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:11 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:11 --> Severity: Warning --> Missing argument 1 for Auth::edit_user() D:\phutx\project\ups\myblog\application\controllers\auth.php 511
ERROR - 2015-02-03 13:11:11 --> Severity: Notice --> Undefined variable: id D:\phutx\project\ups\myblog\application\controllers\auth.php 520
ERROR - 2015-02-03 13:11:11 --> Severity: Notice --> Undefined variable: id D:\phutx\project\ups\myblog\application\controllers\auth.php 522
ERROR - 2015-02-03 13:11:11 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:11 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:11:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:11:11 --> Final output sent to browser
DEBUG - 2015-02-03 13:11:11 --> Total execution time: 0.2340
DEBUG - 2015-02-03 13:11:22 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:22 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:22 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:22 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:22 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:22 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:22 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:22 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:22 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:22 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:22 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:22 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:22 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:22 --> Severity: Warning --> Missing argument 1 for Auth::edit_user() D:\phutx\project\ups\myblog\application\controllers\auth.php 511
ERROR - 2015-02-03 13:11:22 --> Severity: Notice --> Undefined variable: id D:\phutx\project\ups\myblog\application\controllers\auth.php 520
ERROR - 2015-02-03 13:11:22 --> Severity: Notice --> Undefined variable: id D:\phutx\project\ups\myblog\application\controllers\auth.php 522
ERROR - 2015-02-03 13:11:22 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:22 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:11:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:11:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:11:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:11:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:11:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:11:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:11:22 --> Final output sent to browser
DEBUG - 2015-02-03 13:11:22 --> Total execution time: 0.2890
DEBUG - 2015-02-03 13:11:24 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:24 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:24 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:24 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:24 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:24 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:24 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:24 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:24 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:24 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:24 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:24 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:24 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:24 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:11:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:11:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:11:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:11:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:11:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:11:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:11:24 --> Final output sent to browser
DEBUG - 2015-02-03 13:11:24 --> Total execution time: 0.2220
DEBUG - 2015-02-03 13:11:26 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:26 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:26 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:26 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:26 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:26 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:26 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:26 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:26 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:26 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:26 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:26 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:26 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:26 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:26 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:26 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:26 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 13:11:27 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:27 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:27 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:27 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:27 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:27 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:27 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:27 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:27 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:27 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:27 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:27 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:27 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:27 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:11:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:11:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:11:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:11:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:11:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:11:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:11:27 --> Final output sent to browser
DEBUG - 2015-02-03 13:11:27 --> Total execution time: 0.2220
DEBUG - 2015-02-03 13:11:31 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:31 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:31 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:31 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:31 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:31 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:31 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:31 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:31 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:31 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:31 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-03 13:11:31 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:31 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:31 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:31 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:31 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:31 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:31 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 13:11:31 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:31 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 13:11:31 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 13:11:31 --> Helper loaded: string_helper
DEBUG - 2015-02-03 13:11:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:11:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:11:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 13:11:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:11:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:11:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:11:31 --> Final output sent to browser
DEBUG - 2015-02-03 13:11:31 --> Total execution time: 0.2150
DEBUG - 2015-02-03 13:11:57 --> Config Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:11:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:11:57 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:11:57 --> URI Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Router Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Output Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Security Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Input Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:11:57 --> Language Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Loader Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:11:57 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:11:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:11:57 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:11:57 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:11:57 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Controller Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:11:57 --> Email Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:11:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:11:57 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:11:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:11:57 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:11:57 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:11:57 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:11:57 --> Model Class Initialized
DEBUG - 2015-02-03 13:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 13:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:11:57 --> Final output sent to browser
DEBUG - 2015-02-03 13:11:57 --> Total execution time: 0.3140
DEBUG - 2015-02-03 13:12:06 --> Config Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:12:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:12:06 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:12:06 --> URI Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Router Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Output Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Security Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Input Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:12:06 --> Language Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Loader Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:12:06 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:12:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:12:06 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:12:06 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:12:06 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Controller Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:12:06 --> Email Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:12:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:12:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:12:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:12:06 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:12:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:12:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:12:06 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:12:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:12:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:12:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:12:07 --> Final output sent to browser
DEBUG - 2015-02-03 13:12:07 --> Total execution time: 0.3130
DEBUG - 2015-02-03 13:12:28 --> Config Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:12:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:12:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:12:28 --> URI Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Router Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Output Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Security Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Input Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:12:28 --> Language Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Loader Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:12:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:12:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:12:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:12:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:12:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Controller Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:12:28 --> Email Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:12:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:12:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:12:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:12:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:12:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:12:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:12:28 --> Model Class Initialized
DEBUG - 2015-02-03 13:12:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:12:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:12:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:12:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:12:28 --> Final output sent to browser
DEBUG - 2015-02-03 13:12:28 --> Total execution time: 0.3000
DEBUG - 2015-02-03 13:13:26 --> Config Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:13:26 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:13:26 --> URI Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Router Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Output Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Security Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Input Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:13:26 --> Language Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Loader Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:13:26 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:13:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:13:26 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:13:26 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:13:26 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Controller Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:13:26 --> Email Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:13:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:13:26 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:13:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:13:26 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:13:26 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:13:26 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:13:26 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:13:26 --> Final output sent to browser
DEBUG - 2015-02-03 13:13:26 --> Total execution time: 0.2970
DEBUG - 2015-02-03 13:13:34 --> Config Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:13:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:13:34 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:13:34 --> URI Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Router Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Output Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Security Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Input Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:13:34 --> Language Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Loader Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:13:34 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:13:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:13:34 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:13:34 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:13:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Controller Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:13:34 --> Email Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:13:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:13:34 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:13:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:13:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:13:34 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:13:34 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:13:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:13:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:13:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:13:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:13:34 --> Final output sent to browser
DEBUG - 2015-02-03 13:13:34 --> Total execution time: 0.2940
DEBUG - 2015-02-03 13:13:45 --> Config Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:13:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:13:45 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:13:45 --> URI Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Router Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Output Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Security Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Input Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:13:45 --> Language Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Loader Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:13:45 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:13:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:13:45 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:13:45 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:13:45 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Controller Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:13:45 --> Email Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:13:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:13:45 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:13:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:13:45 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:13:45 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:13:45 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:13:45 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:13:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:13:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:13:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:13:45 --> Final output sent to browser
DEBUG - 2015-02-03 13:13:45 --> Total execution time: 0.2970
DEBUG - 2015-02-03 13:13:59 --> Config Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:13:59 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:13:59 --> URI Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Router Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Output Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Security Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Input Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:13:59 --> Language Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Loader Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:13:59 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:13:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:13:59 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:13:59 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Controller Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:13:59 --> Email Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:13:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:13:59 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:13:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:13:59 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:13:59 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-03 13:13:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:13:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:13:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:13:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:13:59 --> Final output sent to browser
DEBUG - 2015-02-03 13:13:59 --> Total execution time: 0.2890
DEBUG - 2015-02-03 13:14:05 --> Config Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:14:05 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:14:05 --> URI Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Router Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Output Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Security Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Input Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:14:05 --> Language Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Loader Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:14:05 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:14:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:14:05 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:14:05 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:14:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Controller Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:14:05 --> Email Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:14:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:14:05 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:14:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:14:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:14:05 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:14:05 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:14:05 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:14:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:14:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:14:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:14:05 --> Final output sent to browser
DEBUG - 2015-02-03 13:14:05 --> Total execution time: 0.2940
DEBUG - 2015-02-03 13:14:09 --> Config Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:14:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:14:09 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:14:09 --> URI Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Router Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Output Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Security Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Input Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:14:09 --> Language Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Loader Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:14:09 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:14:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:14:09 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:14:09 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Controller Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:14:09 --> Email Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:14:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:14:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:14:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:14:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:14:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:14:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:14:10 --> Final output sent to browser
DEBUG - 2015-02-03 13:14:10 --> Total execution time: 0.2840
DEBUG - 2015-02-03 13:14:13 --> Config Class Initialized
DEBUG - 2015-02-03 13:14:13 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:14:13 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:14:14 --> URI Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Router Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Output Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Security Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Input Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:14:14 --> Language Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Loader Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:14:14 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:14:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:14:14 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:14:14 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:14:14 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Controller Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:14:14 --> Email Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:14:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:14:14 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:14:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:14:14 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:14:14 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:14:14 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:14:14 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 13:14:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 13:14:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-03 13:14:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 13:14:14 --> Final output sent to browser
DEBUG - 2015-02-03 13:14:14 --> Total execution time: 0.4400
DEBUG - 2015-02-03 13:14:20 --> Config Class Initialized
DEBUG - 2015-02-03 13:14:20 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:14:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:14:20 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:14:20 --> URI Class Initialized
DEBUG - 2015-02-03 13:14:20 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:14:20 --> Router Class Initialized
DEBUG - 2015-02-03 13:14:20 --> Output Class Initialized
DEBUG - 2015-02-03 13:14:20 --> Security Class Initialized
DEBUG - 2015-02-03 13:14:20 --> Input Class Initialized
DEBUG - 2015-02-03 13:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:14:20 --> Language Class Initialized
DEBUG - 2015-02-03 13:14:20 --> Loader Class Initialized
DEBUG - 2015-02-03 13:14:20 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:14:20 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:14:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:14:20 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:14:20 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:14:21 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Controller Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:14:21 --> Email Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:14:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:14:21 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:14:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:14:21 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:14:21 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:14:21 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Model Class Initialized
DEBUG - 2015-02-03 13:14:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:14:21 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:14:21 --> Final output sent to browser
DEBUG - 2015-02-03 13:14:21 --> Total execution time: 0.6641
DEBUG - 2015-02-03 13:15:34 --> Config Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:15:34 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:15:34 --> URI Class Initialized
DEBUG - 2015-02-03 13:15:34 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:15:34 --> Router Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Output Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Security Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Input Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:15:34 --> Language Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Loader Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:15:34 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:15:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:15:34 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Session: Regenerate ID
DEBUG - 2015-02-03 13:15:34 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:15:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Controller Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:15:34 --> Email Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:15:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:15:34 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:15:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:15:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:15:34 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:15:34 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:15:34 --> Pagination Class Initialized
ERROR - 2015-02-03 13:15:34 --> Severity: Error --> Call to undefined method CI_Config::config() D:\phutx\project\ups\myblog\application\controllers\Welcome.php 47
DEBUG - 2015-02-03 13:15:43 --> Config Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:15:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:15:43 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:15:43 --> URI Class Initialized
DEBUG - 2015-02-03 13:15:43 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:15:43 --> Router Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Output Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Security Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Input Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:15:43 --> Language Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Loader Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:15:43 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:15:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:15:43 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:15:43 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:15:43 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Controller Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:15:43 --> Email Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:15:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:15:43 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:15:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:15:43 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:15:43 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:15:43 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Model Class Initialized
DEBUG - 2015-02-03 13:15:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:15:43 --> Pagination Class Initialized
ERROR - 2015-02-03 13:15:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\vendor\tracy\tracy\src\Tracy\Dumper.php:73) D:\phutx\project\ups\myblog\system\core\Common.php 566
ERROR - 2015-02-03 13:15:43 --> Severity: Error --> Call to undefined method CI_Config::config() D:\phutx\project\ups\myblog\application\controllers\Welcome.php 48
DEBUG - 2015-02-03 13:16:03 --> Config Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:16:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:16:03 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:16:03 --> URI Class Initialized
DEBUG - 2015-02-03 13:16:03 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:16:03 --> Router Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Output Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Security Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Input Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:16:03 --> Language Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Loader Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:16:03 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:16:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:16:03 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:16:03 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:16:03 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Controller Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:16:03 --> Email Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:16:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:16:03 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:16:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:16:03 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:16:03 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:16:03 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:16:03 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:16:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:16:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:16:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:16:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:16:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:16:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:16:04 --> Final output sent to browser
DEBUG - 2015-02-03 13:16:04 --> Total execution time: 0.8071
DEBUG - 2015-02-03 13:16:10 --> Config Class Initialized
DEBUG - 2015-02-03 13:16:10 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:16:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:16:10 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:16:10 --> URI Class Initialized
DEBUG - 2015-02-03 13:16:10 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:16:10 --> Router Class Initialized
DEBUG - 2015-02-03 13:16:10 --> Output Class Initialized
DEBUG - 2015-02-03 13:16:10 --> Security Class Initialized
DEBUG - 2015-02-03 13:16:10 --> Input Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:16:11 --> Language Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Loader Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:16:11 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:16:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:16:11 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:16:11 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:16:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Controller Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:16:11 --> Email Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:16:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:16:11 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:16:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:16:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:16:11 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:16:11 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:16:11 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:16:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:16:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:16:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:16:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:16:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:16:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:16:11 --> Final output sent to browser
DEBUG - 2015-02-03 13:16:11 --> Total execution time: 0.7511
DEBUG - 2015-02-03 13:16:48 --> Config Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:16:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:16:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:16:48 --> URI Class Initialized
DEBUG - 2015-02-03 13:16:48 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:16:48 --> Router Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Output Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Security Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Input Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:16:48 --> Language Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Loader Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:16:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:16:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:16:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:16:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:16:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Controller Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:16:48 --> Email Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:16:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:16:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:16:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:16:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:16:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:16:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Model Class Initialized
DEBUG - 2015-02-03 13:16:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:16:48 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:16:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:16:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:16:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:16:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:16:49 --> Final output sent to browser
DEBUG - 2015-02-03 13:16:49 --> Total execution time: 0.6741
DEBUG - 2015-02-03 13:31:49 --> Config Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:31:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:31:49 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:31:49 --> URI Class Initialized
DEBUG - 2015-02-03 13:31:49 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:31:49 --> Router Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Output Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Security Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Input Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:31:49 --> Language Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Loader Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:31:49 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:31:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:31:49 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Session: Regenerate ID
DEBUG - 2015-02-03 13:31:49 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:31:49 --> Model Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Model Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Controller Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:31:49 --> Email Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:31:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:31:49 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:31:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:31:49 --> Model Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:31:49 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:31:49 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Model Class Initialized
DEBUG - 2015-02-03 13:31:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:31:49 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:31:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:31:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:31:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:31:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:31:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:31:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:31:50 --> Final output sent to browser
DEBUG - 2015-02-03 13:31:50 --> Total execution time: 0.6751
DEBUG - 2015-02-03 13:46:50 --> Config Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Hooks Class Initialized
DEBUG - 2015-02-03 13:46:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 13:46:50 --> Utf8 Class Initialized
DEBUG - 2015-02-03 13:46:50 --> URI Class Initialized
DEBUG - 2015-02-03 13:46:50 --> No URI present. Default controller set.
DEBUG - 2015-02-03 13:46:50 --> Router Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Output Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Security Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Input Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 13:46:50 --> Language Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Loader Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Helper loaded: url_helper
DEBUG - 2015-02-03 13:46:50 --> Helper loaded: link_helper
DEBUG - 2015-02-03 13:46:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 13:46:50 --> CI_Session Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Session: Regenerate ID
DEBUG - 2015-02-03 13:46:50 --> CI_Session routines successfully run
DEBUG - 2015-02-03 13:46:50 --> Model Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Model Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Controller Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 13:46:50 --> Email Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 13:46:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 13:46:50 --> Helper loaded: language_helper
DEBUG - 2015-02-03 13:46:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 13:46:50 --> Model Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Database Driver Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Helper loaded: date_helper
DEBUG - 2015-02-03 13:46:50 --> Helper loaded: form_helper
DEBUG - 2015-02-03 13:46:50 --> Form Validation Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Model Class Initialized
DEBUG - 2015-02-03 13:46:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 13:46:50 --> Pagination Class Initialized
DEBUG - 2015-02-03 13:46:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 13:46:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 13:46:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 13:46:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 13:46:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 13:46:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 13:46:51 --> Final output sent to browser
DEBUG - 2015-02-03 13:46:51 --> Total execution time: 0.6781
DEBUG - 2015-02-03 14:01:52 --> Config Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 14:01:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 14:01:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 14:01:52 --> URI Class Initialized
DEBUG - 2015-02-03 14:01:52 --> No URI present. Default controller set.
DEBUG - 2015-02-03 14:01:52 --> Router Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Output Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Security Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Input Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 14:01:52 --> Language Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Loader Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 14:01:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 14:01:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 14:01:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Session: Regenerate ID
DEBUG - 2015-02-03 14:01:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 14:01:52 --> Model Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Model Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Controller Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 14:01:52 --> Email Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 14:01:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 14:01:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 14:01:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 14:01:52 --> Model Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Helper loaded: date_helper
DEBUG - 2015-02-03 14:01:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 14:01:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Model Class Initialized
DEBUG - 2015-02-03 14:01:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 14:01:52 --> Pagination Class Initialized
DEBUG - 2015-02-03 14:01:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 14:01:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 14:01:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 14:01:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 14:01:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 14:01:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 14:01:53 --> Final output sent to browser
DEBUG - 2015-02-03 14:01:53 --> Total execution time: 0.6701
DEBUG - 2015-02-03 14:16:53 --> Config Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Hooks Class Initialized
DEBUG - 2015-02-03 14:16:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 14:16:53 --> Utf8 Class Initialized
DEBUG - 2015-02-03 14:16:53 --> URI Class Initialized
DEBUG - 2015-02-03 14:16:53 --> No URI present. Default controller set.
DEBUG - 2015-02-03 14:16:53 --> Router Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Output Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Security Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Input Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 14:16:53 --> Language Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Loader Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Helper loaded: url_helper
DEBUG - 2015-02-03 14:16:53 --> Helper loaded: link_helper
DEBUG - 2015-02-03 14:16:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 14:16:53 --> CI_Session Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Session: Regenerate ID
DEBUG - 2015-02-03 14:16:53 --> CI_Session routines successfully run
DEBUG - 2015-02-03 14:16:53 --> Model Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Model Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Controller Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 14:16:53 --> Email Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 14:16:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 14:16:53 --> Helper loaded: language_helper
DEBUG - 2015-02-03 14:16:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 14:16:53 --> Model Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Database Driver Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Helper loaded: date_helper
DEBUG - 2015-02-03 14:16:53 --> Helper loaded: form_helper
DEBUG - 2015-02-03 14:16:53 --> Form Validation Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Model Class Initialized
DEBUG - 2015-02-03 14:16:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 14:16:53 --> Pagination Class Initialized
DEBUG - 2015-02-03 14:16:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 14:16:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 14:16:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 14:16:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 14:16:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 14:16:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 14:16:54 --> Final output sent to browser
DEBUG - 2015-02-03 14:16:54 --> Total execution time: 0.6821
DEBUG - 2015-02-03 14:31:55 --> Config Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 14:31:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 14:31:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 14:31:55 --> URI Class Initialized
DEBUG - 2015-02-03 14:31:55 --> No URI present. Default controller set.
DEBUG - 2015-02-03 14:31:55 --> Router Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Output Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Security Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Input Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 14:31:55 --> Language Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Loader Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 14:31:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 14:31:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 14:31:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Session: Regenerate ID
DEBUG - 2015-02-03 14:31:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 14:31:55 --> Model Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Model Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Controller Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 14:31:55 --> Email Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 14:31:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 14:31:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 14:31:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 14:31:55 --> Model Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 14:31:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 14:31:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Model Class Initialized
DEBUG - 2015-02-03 14:31:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 14:31:55 --> Pagination Class Initialized
DEBUG - 2015-02-03 14:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 14:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 14:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 14:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 14:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 14:31:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 14:31:56 --> Final output sent to browser
DEBUG - 2015-02-03 14:31:56 --> Total execution time: 0.6441
DEBUG - 2015-02-03 14:46:57 --> Config Class Initialized
DEBUG - 2015-02-03 14:46:57 --> Hooks Class Initialized
DEBUG - 2015-02-03 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 14:46:57 --> Utf8 Class Initialized
DEBUG - 2015-02-03 14:46:57 --> URI Class Initialized
DEBUG - 2015-02-03 14:46:57 --> No URI present. Default controller set.
DEBUG - 2015-02-03 14:46:57 --> Router Class Initialized
DEBUG - 2015-02-03 14:46:57 --> Output Class Initialized
DEBUG - 2015-02-03 14:46:57 --> Security Class Initialized
DEBUG - 2015-02-03 14:46:57 --> Input Class Initialized
DEBUG - 2015-02-03 14:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 14:46:57 --> Language Class Initialized
DEBUG - 2015-02-03 14:46:57 --> Loader Class Initialized
DEBUG - 2015-02-03 14:46:57 --> Helper loaded: url_helper
DEBUG - 2015-02-03 14:46:57 --> Helper loaded: link_helper
DEBUG - 2015-02-03 14:46:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 14:46:58 --> CI_Session Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Session: Regenerate ID
DEBUG - 2015-02-03 14:46:58 --> CI_Session routines successfully run
DEBUG - 2015-02-03 14:46:58 --> Model Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Model Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Controller Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 14:46:58 --> Email Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 14:46:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 14:46:58 --> Helper loaded: language_helper
DEBUG - 2015-02-03 14:46:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 14:46:58 --> Model Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Database Driver Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Helper loaded: date_helper
DEBUG - 2015-02-03 14:46:58 --> Helper loaded: form_helper
DEBUG - 2015-02-03 14:46:58 --> Form Validation Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Model Class Initialized
DEBUG - 2015-02-03 14:46:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 14:46:58 --> Pagination Class Initialized
DEBUG - 2015-02-03 14:46:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 14:46:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 14:46:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 14:46:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 14:46:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 14:46:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 14:46:58 --> Final output sent to browser
DEBUG - 2015-02-03 14:46:58 --> Total execution time: 0.6591
DEBUG - 2015-02-03 15:02:00 --> Config Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Hooks Class Initialized
DEBUG - 2015-02-03 15:02:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 15:02:00 --> Utf8 Class Initialized
DEBUG - 2015-02-03 15:02:00 --> URI Class Initialized
DEBUG - 2015-02-03 15:02:00 --> No URI present. Default controller set.
DEBUG - 2015-02-03 15:02:00 --> Router Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Output Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Security Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Input Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 15:02:00 --> Language Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Loader Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 15:02:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 15:02:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 15:02:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Session: Regenerate ID
DEBUG - 2015-02-03 15:02:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 15:02:00 --> Model Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Model Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Controller Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 15:02:00 --> Email Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 15:02:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 15:02:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 15:02:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 15:02:00 --> Model Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Database Driver Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Helper loaded: date_helper
DEBUG - 2015-02-03 15:02:00 --> Helper loaded: form_helper
DEBUG - 2015-02-03 15:02:00 --> Form Validation Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Model Class Initialized
DEBUG - 2015-02-03 15:02:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 15:02:00 --> Pagination Class Initialized
DEBUG - 2015-02-03 15:02:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 15:02:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 15:02:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 15:02:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 15:02:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 15:02:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 15:02:00 --> Final output sent to browser
DEBUG - 2015-02-03 15:02:00 --> Total execution time: 0.6581
DEBUG - 2015-02-03 15:17:02 --> Config Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Hooks Class Initialized
DEBUG - 2015-02-03 15:17:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 15:17:02 --> Utf8 Class Initialized
DEBUG - 2015-02-03 15:17:02 --> URI Class Initialized
DEBUG - 2015-02-03 15:17:02 --> No URI present. Default controller set.
DEBUG - 2015-02-03 15:17:02 --> Router Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Output Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Security Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Input Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 15:17:02 --> Language Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Loader Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Helper loaded: url_helper
DEBUG - 2015-02-03 15:17:02 --> Helper loaded: link_helper
DEBUG - 2015-02-03 15:17:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 15:17:02 --> CI_Session Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Session: Regenerate ID
DEBUG - 2015-02-03 15:17:02 --> CI_Session routines successfully run
DEBUG - 2015-02-03 15:17:02 --> Model Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Model Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Controller Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 15:17:02 --> Email Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 15:17:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 15:17:02 --> Helper loaded: language_helper
DEBUG - 2015-02-03 15:17:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 15:17:02 --> Model Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Database Driver Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Helper loaded: date_helper
DEBUG - 2015-02-03 15:17:02 --> Helper loaded: form_helper
DEBUG - 2015-02-03 15:17:02 --> Form Validation Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Model Class Initialized
DEBUG - 2015-02-03 15:17:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 15:17:02 --> Pagination Class Initialized
DEBUG - 2015-02-03 15:17:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 15:17:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 15:17:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 15:17:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 15:17:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 15:17:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 15:17:02 --> Final output sent to browser
DEBUG - 2015-02-03 15:17:02 --> Total execution time: 0.6751
DEBUG - 2015-02-03 15:32:04 --> Config Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Hooks Class Initialized
DEBUG - 2015-02-03 15:32:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 15:32:04 --> Utf8 Class Initialized
DEBUG - 2015-02-03 15:32:04 --> URI Class Initialized
DEBUG - 2015-02-03 15:32:04 --> No URI present. Default controller set.
DEBUG - 2015-02-03 15:32:04 --> Router Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Output Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Security Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Input Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 15:32:04 --> Language Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Loader Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Helper loaded: url_helper
DEBUG - 2015-02-03 15:32:04 --> Helper loaded: link_helper
DEBUG - 2015-02-03 15:32:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 15:32:04 --> CI_Session Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Session: Regenerate ID
DEBUG - 2015-02-03 15:32:04 --> CI_Session routines successfully run
DEBUG - 2015-02-03 15:32:04 --> Model Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Model Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Controller Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 15:32:04 --> Email Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 15:32:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 15:32:04 --> Helper loaded: language_helper
DEBUG - 2015-02-03 15:32:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 15:32:04 --> Model Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Database Driver Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Helper loaded: date_helper
DEBUG - 2015-02-03 15:32:04 --> Helper loaded: form_helper
DEBUG - 2015-02-03 15:32:04 --> Form Validation Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Model Class Initialized
DEBUG - 2015-02-03 15:32:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 15:32:04 --> Pagination Class Initialized
DEBUG - 2015-02-03 15:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 15:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 15:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 15:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 15:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 15:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 15:32:04 --> Final output sent to browser
DEBUG - 2015-02-03 15:32:04 --> Total execution time: 0.6781
DEBUG - 2015-02-03 15:47:06 --> Config Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Hooks Class Initialized
DEBUG - 2015-02-03 15:47:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 15:47:06 --> Utf8 Class Initialized
DEBUG - 2015-02-03 15:47:06 --> URI Class Initialized
DEBUG - 2015-02-03 15:47:06 --> No URI present. Default controller set.
DEBUG - 2015-02-03 15:47:06 --> Router Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Output Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Security Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Input Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 15:47:06 --> Language Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Loader Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Helper loaded: url_helper
DEBUG - 2015-02-03 15:47:06 --> Helper loaded: link_helper
DEBUG - 2015-02-03 15:47:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 15:47:06 --> CI_Session Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Session: Regenerate ID
DEBUG - 2015-02-03 15:47:06 --> CI_Session routines successfully run
DEBUG - 2015-02-03 15:47:06 --> Model Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Model Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Controller Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 15:47:06 --> Email Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 15:47:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 15:47:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 15:47:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 15:47:06 --> Model Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 15:47:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 15:47:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Model Class Initialized
DEBUG - 2015-02-03 15:47:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 15:47:06 --> Pagination Class Initialized
DEBUG - 2015-02-03 15:47:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 15:47:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 15:47:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 15:47:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 15:47:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 15:47:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 15:47:07 --> Final output sent to browser
DEBUG - 2015-02-03 15:47:07 --> Total execution time: 0.6621
DEBUG - 2015-02-03 16:02:08 --> Config Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:02:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:02:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:02:08 --> URI Class Initialized
DEBUG - 2015-02-03 16:02:08 --> No URI present. Default controller set.
DEBUG - 2015-02-03 16:02:08 --> Router Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Output Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Security Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Input Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:02:08 --> Language Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Loader Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:02:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:02:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:02:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:02:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:02:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Controller Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:02:08 --> Email Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:02:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:02:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:02:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:02:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:02:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:02:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:02:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 16:02:08 --> Pagination Class Initialized
DEBUG - 2015-02-03 16:02:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:02:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:02:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 16:02:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:02:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:02:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:02:09 --> Final output sent to browser
DEBUG - 2015-02-03 16:02:09 --> Total execution time: 1.2691
DEBUG - 2015-02-03 16:09:50 --> Config Class Initialized
DEBUG - 2015-02-03 16:09:50 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:09:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:09:50 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:09:50 --> URI Class Initialized
DEBUG - 2015-02-03 16:09:50 --> Router Class Initialized
DEBUG - 2015-02-03 16:09:50 --> Output Class Initialized
DEBUG - 2015-02-03 16:09:50 --> Security Class Initialized
DEBUG - 2015-02-03 16:09:50 --> Input Class Initialized
DEBUG - 2015-02-03 16:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:09:50 --> Language Class Initialized
ERROR - 2015-02-03 16:09:50 --> 404 Page Not Found: Article/day-la-bai-viet-moi
DEBUG - 2015-02-03 16:09:59 --> Config Class Initialized
DEBUG - 2015-02-03 16:09:59 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:09:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:09:59 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:10:00 --> URI Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Router Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Output Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Security Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Input Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:10:00 --> Language Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Loader Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:10:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:10:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:10:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:10:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:10:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Controller Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:10:00 --> Email Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:10:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:10:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:10:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:10:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:10:00 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:10:00 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:10:00 --> Model Class Initialized
ERROR - 2015-02-03 16:10:00 --> Severity: Notice --> Undefined property: article::$article_model D:\phutx\project\ups\myblog\application\controllers\article.php 9
ERROR - 2015-02-03 16:10:00 --> Severity: Error --> Call to a member function getBySlugName() on a non-object D:\phutx\project\ups\myblog\application\controllers\article.php 9
DEBUG - 2015-02-03 16:10:06 --> Config Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:10:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:10:06 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:10:06 --> URI Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Router Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Output Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Security Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Input Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:10:06 --> Language Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Loader Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:10:06 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:10:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:10:06 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:10:06 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:10:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Controller Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:10:06 --> Email Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:10:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:10:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:10:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:10:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:10:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:10:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:10:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:10:07 --> Final output sent to browser
DEBUG - 2015-02-03 16:10:07 --> Total execution time: 0.6791
DEBUG - 2015-02-03 16:11:42 --> Config Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:11:42 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:11:42 --> URI Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Router Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Output Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Security Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Input Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:11:42 --> Language Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Loader Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:11:42 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:11:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:11:42 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:11:42 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:11:42 --> Model Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Model Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Controller Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:11:42 --> Email Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:11:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:11:42 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:11:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:11:42 --> Model Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:11:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:11:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:11:42 --> Model Class Initialized
DEBUG - 2015-02-03 16:11:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:11:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:11:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:11:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:11:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:11:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:11:43 --> Final output sent to browser
DEBUG - 2015-02-03 16:11:43 --> Total execution time: 0.7281
DEBUG - 2015-02-03 16:12:13 --> Config Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:12:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:12:13 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:12:13 --> URI Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Router Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Output Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Security Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Input Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:12:13 --> Language Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Loader Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:12:13 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:12:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:12:13 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:12:13 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:12:13 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Controller Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:12:13 --> Email Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:12:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:12:13 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:12:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:12:13 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:12:13 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:12:13 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:12:13 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:12:14 --> Final output sent to browser
DEBUG - 2015-02-03 16:12:14 --> Total execution time: 0.6291
DEBUG - 2015-02-03 16:12:15 --> Config Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:12:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:12:15 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:12:15 --> URI Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Router Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Output Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Security Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Input Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:12:15 --> Language Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Loader Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:12:15 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:12:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:12:15 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:12:15 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:12:15 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Controller Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:12:15 --> Email Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:12:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:12:15 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:12:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:12:15 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:12:15 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:12:15 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:12:15 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:12:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:12:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:12:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:12:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:12:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:12:16 --> Final output sent to browser
DEBUG - 2015-02-03 16:12:16 --> Total execution time: 0.8271
DEBUG - 2015-02-03 16:12:37 --> Config Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:12:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:12:37 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:12:37 --> URI Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Router Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Output Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Security Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Input Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:12:37 --> Language Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Loader Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:12:37 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:12:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:12:37 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:12:37 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:12:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Controller Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:12:37 --> Email Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:12:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:12:37 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:12:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:12:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:12:37 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:12:37 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:12:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:12:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:12:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:12:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:12:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:12:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:12:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:12:38 --> Final output sent to browser
DEBUG - 2015-02-03 16:12:38 --> Total execution time: 0.6951
DEBUG - 2015-02-03 16:13:00 --> Config Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:13:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:13:00 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:13:00 --> URI Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Router Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Output Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Security Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Input Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:13:00 --> Language Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Loader Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:13:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:13:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:13:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:13:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:13:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Controller Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:13:00 --> Email Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:13:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:13:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:13:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:13:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:13:00 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:13:00 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:13:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:13:01 --> Final output sent to browser
DEBUG - 2015-02-03 16:13:01 --> Total execution time: 0.6221
DEBUG - 2015-02-03 16:13:23 --> Config Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:13:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:13:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:13:23 --> URI Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Router Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Output Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Security Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Input Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:13:23 --> Language Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Loader Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:13:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:13:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:13:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:13:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:13:23 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Controller Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:13:23 --> Email Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:13:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:13:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:13:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:13:23 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:13:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:13:24 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:13:24 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:13:24 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:13:24 --> Final output sent to browser
DEBUG - 2015-02-03 16:13:24 --> Total execution time: 0.7111
DEBUG - 2015-02-03 16:13:52 --> Config Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:13:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:13:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:13:52 --> URI Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Router Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Output Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Security Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Input Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:13:52 --> Language Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Loader Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:13:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:13:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:13:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:13:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:13:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Controller Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:13:52 --> Email Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:13:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:13:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:13:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:13:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:13:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:13:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:13:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:13:52 --> Final output sent to browser
DEBUG - 2015-02-03 16:13:52 --> Total execution time: 0.6211
DEBUG - 2015-02-03 16:14:48 --> Config Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:14:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:14:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:14:48 --> URI Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Router Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Output Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Security Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Input Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:14:48 --> Language Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Loader Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:14:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:14:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:14:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:14:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:14:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Controller Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:14:48 --> Email Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:14:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:14:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:14:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:14:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:14:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:14:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:14:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:14:48 --> Final output sent to browser
DEBUG - 2015-02-03 16:14:48 --> Total execution time: 0.6451
DEBUG - 2015-02-03 16:15:07 --> Config Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:15:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:15:07 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:15:07 --> URI Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Router Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Output Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Security Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Input Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:15:07 --> Language Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Loader Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:15:07 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:15:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:15:07 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:15:07 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:15:07 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Controller Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:15:07 --> Email Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:15:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:15:07 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:15:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:15:07 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:15:07 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:15:07 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:15:07 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:15:07 --> Final output sent to browser
DEBUG - 2015-02-03 16:15:07 --> Total execution time: 0.6231
DEBUG - 2015-02-03 16:15:17 --> Config Class Initialized
DEBUG - 2015-02-03 16:15:17 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:15:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:15:18 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:15:18 --> URI Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Router Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Output Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Security Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Input Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:15:18 --> Language Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Loader Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:15:18 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:15:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:15:18 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:15:18 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Controller Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:15:18 --> Email Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:15:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:15:18 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:15:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:15:18 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:15:18 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:15:18 --> Final output sent to browser
DEBUG - 2015-02-03 16:15:18 --> Total execution time: 0.7191
DEBUG - 2015-02-03 16:15:33 --> Config Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:15:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:15:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:15:33 --> URI Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Router Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Output Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Security Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Input Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:15:33 --> Language Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Loader Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:15:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:15:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:15:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:15:33 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:15:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Controller Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:15:33 --> Email Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:15:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:15:33 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:15:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:15:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:15:33 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:15:33 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:15:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:15:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:15:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:15:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:15:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:15:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:15:33 --> Final output sent to browser
DEBUG - 2015-02-03 16:15:33 --> Total execution time: 0.6311
DEBUG - 2015-02-03 16:15:45 --> Config Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:15:45 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:15:45 --> URI Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Router Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Output Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Security Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Input Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:15:45 --> Language Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Loader Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:15:45 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:15:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:15:45 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:15:45 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:15:45 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Controller Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:15:45 --> Email Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:15:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:15:45 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:15:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:15:45 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:15:45 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:15:45 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:15:45 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:15:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:15:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:15:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:15:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:15:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:15:46 --> Final output sent to browser
DEBUG - 2015-02-03 16:15:46 --> Total execution time: 0.6451
DEBUG - 2015-02-03 16:15:52 --> Config Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:15:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:15:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:15:52 --> URI Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Router Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Output Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Security Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Input Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:15:52 --> Language Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Loader Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:15:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:15:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:15:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:15:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:15:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Controller Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:15:52 --> Email Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:15:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:15:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:15:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:15:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:15:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:15:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:15:52 --> Model Class Initialized
DEBUG - 2015-02-03 16:15:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:15:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:15:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:15:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:15:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:15:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:15:52 --> Final output sent to browser
DEBUG - 2015-02-03 16:15:52 --> Total execution time: 0.6341
DEBUG - 2015-02-03 16:16:00 --> Config Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:16:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:16:00 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:16:00 --> URI Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Router Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Output Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Security Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Input Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:16:00 --> Language Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Loader Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:16:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:16:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:16:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:16:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Controller Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:16:00 --> Email Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:16:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:16:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:16:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:16:00 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:16:00 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:16:00 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:16:00 --> Final output sent to browser
DEBUG - 2015-02-03 16:16:00 --> Total execution time: 0.6191
DEBUG - 2015-02-03 16:16:12 --> Config Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:16:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:16:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:16:12 --> URI Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Router Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Output Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Security Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Input Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:16:12 --> Language Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Loader Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:16:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:16:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:16:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:16:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:16:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Controller Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:16:12 --> Email Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:16:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:16:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:16:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:16:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:16:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:16:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:16:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:16:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:16:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:16:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:16:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:16:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:16:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:16:12 --> Final output sent to browser
DEBUG - 2015-02-03 16:16:12 --> Total execution time: 0.6241
DEBUG - 2015-02-03 16:20:33 --> Config Class Initialized
DEBUG - 2015-02-03 16:20:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:20:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:20:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:20:33 --> URI Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Router Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Output Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Security Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Input Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:20:34 --> Language Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Loader Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:20:34 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:20:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:20:34 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:20:34 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:20:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Controller Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:20:34 --> Email Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:20:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:20:34 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:20:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:20:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:20:34 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:20:34 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:20:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:20:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:20:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:20:35 --> Final output sent to browser
DEBUG - 2015-02-03 16:20:35 --> Total execution time: 1.0491
DEBUG - 2015-02-03 16:21:08 --> Config Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:21:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:21:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:21:08 --> URI Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Router Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Output Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Security Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Input Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:21:08 --> Language Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Loader Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:21:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:21:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:21:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:21:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:21:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Controller Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:21:08 --> Email Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:21:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:21:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:21:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:21:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:21:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:21:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:21:08 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:21:09 --> Final output sent to browser
DEBUG - 2015-02-03 16:21:09 --> Total execution time: 1.1311
DEBUG - 2015-02-03 16:21:55 --> Config Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:21:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:21:55 --> URI Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Router Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Output Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Security Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Input Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:21:55 --> Language Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Loader Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:21:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:21:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:21:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:21:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:21:55 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Controller Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:21:55 --> Email Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:21:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:21:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:21:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:21:55 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:21:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:21:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:21:55 --> Model Class Initialized
DEBUG - 2015-02-03 16:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:21:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:21:56 --> Final output sent to browser
DEBUG - 2015-02-03 16:21:56 --> Total execution time: 0.9281
DEBUG - 2015-02-03 16:23:17 --> Config Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:23:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:23:17 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:23:17 --> URI Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Router Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Output Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Security Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Input Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:23:17 --> Language Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Loader Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:23:17 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:23:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:23:17 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:23:17 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:23:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Controller Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:23:17 --> Email Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:23:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:23:17 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:23:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:23:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:23:17 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:23:17 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:23:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:23:18 --> Severity: Notice --> Undefined property: Entity\ArticleCategories::$getCategory D:\phutx\project\ups\myblog\application\views\article\index.php 5
ERROR - 2015-02-03 16:23:18 --> Severity: Error --> Call to a member function getName() on a non-object D:\phutx\project\ups\myblog\application\views\article\index.php 5
DEBUG - 2015-02-03 16:23:29 --> Config Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:23:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:23:29 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:23:29 --> URI Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Router Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Output Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Security Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Input Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:23:29 --> Language Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Loader Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:23:29 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:23:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:23:29 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:23:29 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:23:29 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Controller Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:23:29 --> Email Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:23:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:23:29 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:23:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:23:29 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:23:29 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:23:29 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:23:29 --> Model Class Initialized
DEBUG - 2015-02-03 16:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:23:30 --> Final output sent to browser
DEBUG - 2015-02-03 16:23:30 --> Total execution time: 0.8791
DEBUG - 2015-02-03 16:25:37 --> Config Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:25:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:25:37 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:25:37 --> URI Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Router Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Output Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Security Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Input Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:25:37 --> Language Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Loader Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:25:37 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:25:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:25:37 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:25:37 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:25:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Controller Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:25:37 --> Email Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:25:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:25:37 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:25:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:25:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:25:37 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:25:37 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:25:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:25:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:25:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:25:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:25:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:25:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:25:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:25:37 --> Final output sent to browser
DEBUG - 2015-02-03 16:25:37 --> Total execution time: 0.8471
DEBUG - 2015-02-03 16:27:11 --> Config Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:27:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:27:11 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:27:11 --> URI Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Router Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Output Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Security Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Input Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:27:11 --> Language Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Loader Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:27:11 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:27:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:27:11 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:27:11 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:27:11 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Controller Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:27:11 --> Email Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:27:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:27:11 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:27:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:27:11 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:27:11 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:27:11 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:27:11 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:27:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:27:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:27:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:27:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:27:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:27:12 --> Final output sent to browser
DEBUG - 2015-02-03 16:27:12 --> Total execution time: 0.8501
DEBUG - 2015-02-03 16:27:30 --> Config Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:27:30 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:27:30 --> URI Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Router Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Output Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Security Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Input Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:27:30 --> Language Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Loader Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:27:30 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:27:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:27:30 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:27:30 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:27:30 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Controller Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:27:30 --> Email Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:27:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:27:30 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:27:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:27:30 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:27:30 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:27:30 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:27:30 --> Model Class Initialized
DEBUG - 2015-02-03 16:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:27:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:27:31 --> Final output sent to browser
DEBUG - 2015-02-03 16:27:31 --> Total execution time: 0.8481
DEBUG - 2015-02-03 16:28:28 --> Config Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:28:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:28:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:28:28 --> URI Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Router Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Output Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Security Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Input Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:28:28 --> Language Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Loader Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:28:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:28:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:28:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:28:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Controller Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:28:28 --> Email Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:28:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:28:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:28:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:28:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:28:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:28:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:28:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:28:29 --> Final output sent to browser
DEBUG - 2015-02-03 16:28:29 --> Total execution time: 0.7701
DEBUG - 2015-02-03 16:28:41 --> Config Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:28:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:28:41 --> URI Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Router Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Output Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Security Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Input Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:28:41 --> Language Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Loader Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:28:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:28:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:28:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:28:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:28:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Controller Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:28:41 --> Email Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:28:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:28:41 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:28:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:28:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:28:41 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:28:41 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:28:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:28:41 --> Final output sent to browser
DEBUG - 2015-02-03 16:28:41 --> Total execution time: 0.7801
DEBUG - 2015-02-03 16:29:05 --> Config Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:29:05 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:29:05 --> URI Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Router Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Output Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Security Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Input Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:29:05 --> Language Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Loader Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:29:05 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:29:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:29:05 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:29:05 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:29:05 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Controller Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:29:05 --> Email Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:29:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:29:05 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:29:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:29:05 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:29:05 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:29:05 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:29:05 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:29:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:29:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:29:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:29:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:29:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:29:05 --> Final output sent to browser
DEBUG - 2015-02-03 16:29:05 --> Total execution time: 0.8411
DEBUG - 2015-02-03 16:29:37 --> Config Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:29:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:29:37 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:29:37 --> URI Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Router Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Output Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Security Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Input Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:29:37 --> Language Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Loader Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:29:37 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:29:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:29:37 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:29:37 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:29:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Controller Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:29:37 --> Email Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:29:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:29:37 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:29:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:29:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:29:37 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:29:37 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:29:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:29:38 --> Final output sent to browser
DEBUG - 2015-02-03 16:29:38 --> Total execution time: 0.8521
DEBUG - 2015-02-03 16:30:02 --> Config Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:30:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:30:02 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:30:02 --> URI Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Router Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Output Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Security Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Input Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:30:02 --> Language Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Loader Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:30:02 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:30:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:30:02 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:30:02 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:30:02 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Controller Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:30:02 --> Email Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:30:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:30:02 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:30:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:30:02 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:30:02 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:30:02 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:30:02 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:30:03 --> Final output sent to browser
DEBUG - 2015-02-03 16:30:03 --> Total execution time: 0.7661
DEBUG - 2015-02-03 16:30:20 --> Config Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:30:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:30:20 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:30:20 --> URI Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Router Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Output Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Security Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Input Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:30:20 --> Language Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Loader Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:30:20 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:30:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:30:20 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:30:20 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:30:20 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Controller Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:30:20 --> Email Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:30:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:30:20 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:30:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:30:20 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:30:20 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:30:20 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:30:20 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:30:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:30:21 --> Final output sent to browser
DEBUG - 2015-02-03 16:30:21 --> Total execution time: 0.7671
DEBUG - 2015-02-03 16:30:37 --> Config Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:30:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:30:37 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:30:37 --> URI Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Router Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Output Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Security Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Input Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:30:37 --> Language Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Loader Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:30:37 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:30:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:30:37 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:30:37 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:30:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Controller Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:30:37 --> Email Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:30:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:30:37 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:30:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:30:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:30:37 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:30:37 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:30:37 --> Model Class Initialized
DEBUG - 2015-02-03 16:30:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:30:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:30:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:30:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:30:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:30:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:30:38 --> Final output sent to browser
DEBUG - 2015-02-03 16:30:38 --> Total execution time: 0.8051
DEBUG - 2015-02-03 16:31:33 --> Config Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:31:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:31:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:31:33 --> URI Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Router Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Output Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Security Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Input Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:31:33 --> Language Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Loader Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:31:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:31:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:31:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:31:33 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:31:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Controller Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:31:33 --> Email Class Initialized
DEBUG - 2015-02-03 16:31:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:31:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:31:33 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:31:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:31:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:31:34 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:31:34 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:31:34 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:31:34 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:31:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:31:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:31:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:31:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:31:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:31:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:31:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:31:34 --> Final output sent to browser
DEBUG - 2015-02-03 16:31:34 --> Total execution time: 0.8121
DEBUG - 2015-02-03 16:32:12 --> Config Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:32:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:32:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:32:12 --> URI Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Router Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Output Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Security Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Input Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:32:12 --> Language Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Loader Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:32:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:32:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:32:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:32:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:32:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Controller Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:32:12 --> Email Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:32:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:32:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:32:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:32:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:32:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:32:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:32:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:32:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:32:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:32:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:32:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:32:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:32:13 --> Final output sent to browser
DEBUG - 2015-02-03 16:32:13 --> Total execution time: 0.8011
DEBUG - 2015-02-03 16:32:25 --> Config Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:32:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:32:25 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:32:25 --> URI Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Router Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Output Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Security Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Input Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:32:25 --> Language Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Loader Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:32:25 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:32:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:32:25 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:32:25 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:32:25 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Controller Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:32:25 --> Email Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:32:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:32:25 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:32:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:32:25 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:32:25 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:32:25 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:32:25 --> Model Class Initialized
DEBUG - 2015-02-03 16:32:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:32:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:32:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:32:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:32:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:32:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:32:26 --> Final output sent to browser
DEBUG - 2015-02-03 16:32:26 --> Total execution time: 0.8971
DEBUG - 2015-02-03 16:33:58 --> Config Class Initialized
DEBUG - 2015-02-03 16:33:58 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:33:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:33:58 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:33:59 --> URI Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Router Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Output Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Security Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Input Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:33:59 --> Language Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Loader Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:33:59 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:33:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:33:59 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:33:59 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:33:59 --> Model Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Model Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Controller Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:33:59 --> Email Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:33:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:33:59 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:33:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:33:59 --> Model Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:33:59 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:33:59 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:33:59 --> Model Class Initialized
DEBUG - 2015-02-03 16:33:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:33:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:33:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:33:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:33:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:33:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:33:59 --> Final output sent to browser
DEBUG - 2015-02-03 16:33:59 --> Total execution time: 0.7761
DEBUG - 2015-02-03 16:34:27 --> Config Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:34:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:34:27 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:34:27 --> URI Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Router Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Output Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Security Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Input Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:34:27 --> Language Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Loader Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:34:27 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:34:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:34:27 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:34:27 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:34:27 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Controller Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:34:27 --> Email Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:34:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:34:27 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:34:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:34:27 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:34:27 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:34:27 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:34:27 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:34:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:34:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:34:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:34:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:34:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:34:28 --> Final output sent to browser
DEBUG - 2015-02-03 16:34:28 --> Total execution time: 0.8251
DEBUG - 2015-02-03 16:34:33 --> Config Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:34:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:34:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:34:33 --> URI Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Router Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Output Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Security Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Input Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:34:33 --> Language Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Loader Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:34:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:34:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:34:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:34:33 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:34:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Controller Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:34:33 --> Email Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:34:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:34:33 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:34:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:34:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:34:33 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:34:33 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:34:33 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:34:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:34:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:34:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:34:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:34:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:34:34 --> Final output sent to browser
DEBUG - 2015-02-03 16:34:34 --> Total execution time: 0.8611
DEBUG - 2015-02-03 16:34:41 --> Config Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:34:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:34:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:34:41 --> URI Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Router Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Output Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Security Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Input Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:34:41 --> Language Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Loader Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:34:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:34:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:34:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:34:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:34:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Controller Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:34:41 --> Email Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:34:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:34:41 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:34:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:34:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:34:41 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:34:41 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:34:41 --> Model Class Initialized
DEBUG - 2015-02-03 16:34:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:34:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:34:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:34:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:34:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:34:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:34:42 --> Final output sent to browser
DEBUG - 2015-02-03 16:34:42 --> Total execution time: 0.8181
DEBUG - 2015-02-03 16:35:04 --> Config Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:35:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:35:04 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:35:04 --> URI Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Router Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Output Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Security Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Input Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:35:04 --> Language Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Loader Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:35:04 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:35:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:35:04 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:35:04 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:35:04 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Controller Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:35:04 --> Email Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:35:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:35:04 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:35:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:35:04 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:35:04 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:35:04 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:35:04 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:35:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:35:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:35:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:35:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:35:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:35:05 --> Final output sent to browser
DEBUG - 2015-02-03 16:35:05 --> Total execution time: 0.8731
DEBUG - 2015-02-03 16:35:31 --> Config Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:35:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:35:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:35:31 --> URI Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Router Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Output Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Security Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Input Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:35:31 --> Language Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Loader Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:35:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:35:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:35:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:35:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:35:31 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Controller Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:35:31 --> Email Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:35:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:35:31 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:35:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:35:31 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:35:31 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:35:31 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:35:31 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:35:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:35:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:35:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:35:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:35:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:35:31 --> Final output sent to browser
DEBUG - 2015-02-03 16:35:31 --> Total execution time: 0.7841
DEBUG - 2015-02-03 16:35:46 --> Config Class Initialized
DEBUG - 2015-02-03 16:35:46 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:35:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:35:46 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:35:46 --> URI Class Initialized
DEBUG - 2015-02-03 16:35:46 --> Router Class Initialized
DEBUG - 2015-02-03 16:35:46 --> Output Class Initialized
DEBUG - 2015-02-03 16:35:46 --> Security Class Initialized
DEBUG - 2015-02-03 16:35:46 --> Input Class Initialized
DEBUG - 2015-02-03 16:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:35:46 --> Language Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Loader Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:35:47 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:35:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:35:47 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:35:47 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:35:47 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Controller Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:35:47 --> Email Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:35:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:35:47 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:35:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:35:47 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:35:47 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:35:47 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:35:47 --> Model Class Initialized
DEBUG - 2015-02-03 16:35:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:35:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:35:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:35:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:35:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:35:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:35:47 --> Final output sent to browser
DEBUG - 2015-02-03 16:35:47 --> Total execution time: 0.8231
DEBUG - 2015-02-03 16:36:14 --> Config Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:36:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:36:14 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:36:14 --> URI Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Router Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Output Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Security Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Input Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:36:14 --> Language Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Loader Class Initialized
DEBUG - 2015-02-03 16:36:14 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:36:14 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:36:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:36:14 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:36:14 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:36:14 --> Model Class Initialized
DEBUG - 2015-02-03 16:36:15 --> Model Class Initialized
DEBUG - 2015-02-03 16:36:15 --> Controller Class Initialized
DEBUG - 2015-02-03 16:36:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:36:15 --> Email Class Initialized
DEBUG - 2015-02-03 16:36:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:36:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:36:15 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:36:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:36:15 --> Model Class Initialized
DEBUG - 2015-02-03 16:36:15 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:36:15 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:36:15 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:36:15 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:36:15 --> Model Class Initialized
DEBUG - 2015-02-03 16:36:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:36:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:36:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:36:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:36:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:36:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:36:15 --> Final output sent to browser
DEBUG - 2015-02-03 16:36:15 --> Total execution time: 0.7981
DEBUG - 2015-02-03 16:39:06 --> Config Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:39:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:39:06 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:39:06 --> URI Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Router Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Output Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Security Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Input Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:39:06 --> Language Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Loader Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:39:06 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:39:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:39:06 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:39:06 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:39:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Controller Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:39:06 --> Email Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:39:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:39:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:39:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:39:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:39:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:39:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:39:06 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:39:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:39:07 --> Severity: error --> Exception: An exception occurred while executing 'SELECT t0.id AS id1, t0.username AS username2, t0.password AS password3, t0.email AS email4, t0.full_name AS full_name5, t0.work AS work6, t0.age AS age7, t0.gender AS gender8, t0.created AS created9, t0.modified AS modified10, t0.role_id AS role_id11 FROM users t0 WHERE t0.id = ?' with params ["1"]:

SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.work' in 'field list' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-03 16:39:24 --> Config Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:39:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:39:24 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:39:24 --> URI Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Router Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Output Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Security Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Input Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:39:24 --> Language Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Loader Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:39:24 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:39:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:39:24 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:39:24 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:39:24 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Controller Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:39:24 --> Email Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:39:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:39:24 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:39:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:39:24 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:39:24 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:39:24 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:39:24 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:39:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:39:25 --> Severity: Parsing Error --> syntax error, unexpected '?>' D:\phutx\project\ups\myblog\application\views\article\index.php 17
DEBUG - 2015-02-03 16:39:32 --> Config Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:39:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:39:32 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:39:32 --> URI Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Router Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Output Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Security Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Input Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:39:32 --> Language Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Loader Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:39:32 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:39:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:39:32 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:39:32 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:39:32 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Controller Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:39:32 --> Email Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:39:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:39:32 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:39:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:39:32 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:39:32 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:39:32 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:39:32 --> Model Class Initialized
DEBUG - 2015-02-03 16:39:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:39:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:39:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:39:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:39:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:39:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:39:33 --> Final output sent to browser
DEBUG - 2015-02-03 16:39:33 --> Total execution time: 0.8931
DEBUG - 2015-02-03 16:40:17 --> Config Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:40:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:40:17 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:40:17 --> URI Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Router Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Output Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Security Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Input Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:40:17 --> Language Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Loader Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:40:17 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:40:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:40:17 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:40:17 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:40:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Controller Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:40:17 --> Email Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:40:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:40:17 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:40:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:40:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:40:17 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:40:17 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:40:17 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:40:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:40:18 --> Final output sent to browser
DEBUG - 2015-02-03 16:40:18 --> Total execution time: 0.8871
DEBUG - 2015-02-03 16:40:51 --> Config Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:40:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:40:51 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:40:51 --> URI Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Router Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Output Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Security Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Input Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:40:51 --> Language Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Loader Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:40:51 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:40:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:40:51 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:40:51 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:40:51 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Controller Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:40:51 --> Email Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:40:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:40:51 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:40:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:40:51 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:40:51 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:40:51 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:40:51 --> Model Class Initialized
DEBUG - 2015-02-03 16:40:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:40:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:40:52 --> Severity: error --> Exception: An exception occurred while executing 'SELECT t0.id AS id1, t0.username AS username2, t0.password AS password3, t0.email AS email4, t0.full_name AS full_name5, t0.work AS work6, t0.age AS age7, t0.gender AS gender8, t0.created AS created9, t0.modified AS modified10, t0.role_id AS role_id11 FROM users t0 WHERE t0.id = ?' with params ["1"]:

SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.work' in 'field list' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-03 16:41:12 --> Config Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:41:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:41:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:41:12 --> URI Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Router Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Output Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Security Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Input Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:41:12 --> Language Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Loader Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:41:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:41:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:41:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:41:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:41:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Controller Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:41:12 --> Email Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:41:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:41:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:41:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:41:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:41:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:41:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:41:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:41:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:41:13 --> Severity: Error --> Call to undefined method Entity\Articles::getUsers() D:\phutx\project\ups\myblog\application\views\article\index.php 17
DEBUG - 2015-02-03 16:41:38 --> Config Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:41:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:41:38 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:41:38 --> URI Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Router Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Output Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Security Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Input Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:41:38 --> Language Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Loader Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:41:38 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:41:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:41:38 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:41:38 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:41:38 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Controller Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:41:38 --> Email Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:41:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:41:38 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:41:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:41:38 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:41:38 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:41:38 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:41:38 --> Model Class Initialized
DEBUG - 2015-02-03 16:41:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:41:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:41:39 --> Severity: error --> Exception: An exception occurred while executing 'SELECT t0.id AS id1, t0.username AS username2, t0.password AS password3, t0.email AS email4, t0.full_name AS full_name5, t0.work AS work6, t0.age AS age7, t0.gender AS gender8, t0.created AS created9, t0.modified AS modified10, t0.role_id AS role_id11 FROM users t0 WHERE t0.id = ?' with params ["1"]:

SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.work' in 'field list' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-03 16:42:28 --> Config Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:42:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:42:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:42:28 --> URI Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Router Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Output Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Security Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Input Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:42:28 --> Language Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Loader Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:42:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:42:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:42:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:42:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:42:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Controller Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:42:28 --> Email Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:42:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:42:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:42:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:42:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:42:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:42:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:42:28 --> Model Class Initialized
DEBUG - 2015-02-03 16:42:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:42:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:42:29 --> Severity: error --> Exception: An exception occurred while executing 'SELECT t0.id AS id1, t0.username AS username2, t0.password AS password3, t0.email AS email4, t0.full_name AS full_name5, t0.company AS company6, t0.age AS age7, t0.gender AS gender8, t0.created AS created9, t0.modified AS modified10, t0.role_id AS role_id11 FROM users t0 WHERE t0.id = ?' with params ["1"]:

SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.created' in 'field list' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-03 16:44:48 --> Config Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:44:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:44:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:44:48 --> URI Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Router Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Output Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Security Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Input Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:44:48 --> Language Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Loader Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:44:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:44:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:44:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:44:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:44:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Controller Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:44:48 --> Email Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:44:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:44:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:44:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:44:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:44:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:44:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:44:48 --> Model Class Initialized
DEBUG - 2015-02-03 16:44:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:44:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:44:48 --> Severity: error --> Exception: An exception occurred while executing 'SELECT t0.id AS id1, t0.username AS username2, t0.password AS password3, t0.email AS email4, t0.full_name AS full_name5, t0.company AS company6, t0.age AS age7, t0.gender AS gender8, t0.created_on AS created_on9, t0.modified AS modified10, t0.role_id AS role_id11 FROM users t0 WHERE t0.id = ?' with params ["1"]:

SQLSTATE[42S22]: Column not found: 1054 Unknown column 't0.modified' in 'field list' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-03 16:45:34 --> Config Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:45:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:45:34 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:45:34 --> URI Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Router Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Output Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Security Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Input Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:45:34 --> Language Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Loader Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:45:34 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:45:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:45:34 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:45:34 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:45:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Controller Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:45:34 --> Email Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:45:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:45:34 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:45:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:45:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:45:34 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:45:34 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:45:34 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:45:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:45:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:45:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:45:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:45:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:45:35 --> Final output sent to browser
DEBUG - 2015-02-03 16:45:35 --> Total execution time: 0.7601
DEBUG - 2015-02-03 16:45:53 --> Config Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:45:53 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:45:53 --> URI Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Router Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Output Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Security Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Input Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:45:53 --> Language Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Loader Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:45:53 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:45:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:45:53 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:45:53 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Controller Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:45:53 --> Email Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:45:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:45:53 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:45:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:45:53 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:45:53 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 16:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:45:54 --> Final output sent to browser
DEBUG - 2015-02-03 16:45:54 --> Total execution time: 0.7741
DEBUG - 2015-02-03 16:46:12 --> Config Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:46:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:46:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:46:12 --> URI Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Router Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Output Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Security Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Input Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:46:12 --> Language Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Loader Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:46:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:46:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:46:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:46:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Controller Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:46:12 --> Email Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:46:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:46:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:46:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:46:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:46:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:46:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:46:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:46:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:46:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:46:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:46:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:46:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:46:13 --> Final output sent to browser
DEBUG - 2015-02-03 16:46:13 --> Total execution time: 0.7931
DEBUG - 2015-02-03 16:58:12 --> Config Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:58:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:58:12 --> URI Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Router Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Output Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Security Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Input Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:58:12 --> Language Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Loader Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:58:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:58:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:58:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Session: Regenerate ID
DEBUG - 2015-02-03 16:58:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:58:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Controller Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:58:12 --> Email Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:58:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:58:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:58:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:58:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:58:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:58:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:58:12 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 16:58:13 --> Severity: Notice --> Undefined variable: tags D:\phutx\project\ups\myblog\application\views\article\index.php 3
DEBUG - 2015-02-03 16:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:58:13 --> Final output sent to browser
DEBUG - 2015-02-03 16:58:13 --> Total execution time: 0.9961
DEBUG - 2015-02-03 16:58:35 --> Config Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:58:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:58:35 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:58:35 --> URI Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Router Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Output Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Security Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Input Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:58:35 --> Language Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Loader Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:58:35 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:58:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:58:35 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:58:35 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:58:35 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Controller Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:58:35 --> Email Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:58:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:58:35 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:58:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:58:35 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:58:35 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:58:35 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:58:35 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:58:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:58:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:58:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:58:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:58:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:58:36 --> Final output sent to browser
DEBUG - 2015-02-03 16:58:36 --> Total execution time: 0.8851
DEBUG - 2015-02-03 16:58:54 --> Config Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:58:54 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:58:54 --> URI Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Router Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Output Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Security Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Input Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:58:54 --> Language Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Loader Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:58:54 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:58:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:58:54 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:58:54 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Controller Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:58:54 --> Email Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:58:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:58:54 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:58:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:58:54 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:58:54 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-03 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:58:55 --> Final output sent to browser
DEBUG - 2015-02-03 16:58:55 --> Total execution time: 0.9421
DEBUG - 2015-02-03 16:59:22 --> Config Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Hooks Class Initialized
DEBUG - 2015-02-03 16:59:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 16:59:22 --> Utf8 Class Initialized
DEBUG - 2015-02-03 16:59:22 --> URI Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Router Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Output Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Security Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Input Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 16:59:22 --> Language Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Loader Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Helper loaded: url_helper
DEBUG - 2015-02-03 16:59:22 --> Helper loaded: link_helper
DEBUG - 2015-02-03 16:59:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 16:59:22 --> CI_Session Class Initialized
DEBUG - 2015-02-03 16:59:22 --> CI_Session routines successfully run
DEBUG - 2015-02-03 16:59:22 --> Model Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Model Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Controller Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 16:59:22 --> Email Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 16:59:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 16:59:22 --> Helper loaded: language_helper
DEBUG - 2015-02-03 16:59:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 16:59:22 --> Model Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Database Driver Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Helper loaded: date_helper
DEBUG - 2015-02-03 16:59:22 --> Helper loaded: form_helper
DEBUG - 2015-02-03 16:59:22 --> Form Validation Class Initialized
DEBUG - 2015-02-03 16:59:22 --> Model Class Initialized
DEBUG - 2015-02-03 16:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 16:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 16:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 16:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 16:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 16:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 16:59:23 --> Final output sent to browser
DEBUG - 2015-02-03 16:59:23 --> Total execution time: 0.8331
DEBUG - 2015-02-03 17:00:25 --> Config Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:00:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:00:25 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:00:25 --> URI Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Router Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Output Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Security Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Input Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:00:25 --> Language Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Loader Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:00:25 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:00:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:00:25 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:00:25 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:00:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Controller Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:00:25 --> Email Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:00:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:00:25 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:00:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:00:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:00:25 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:00:25 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:00:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:00:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:00:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:00:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:00:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:00:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:00:26 --> Final output sent to browser
DEBUG - 2015-02-03 17:00:26 --> Total execution time: 0.8291
DEBUG - 2015-02-03 17:00:49 --> Config Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:00:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:00:49 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:00:49 --> URI Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Router Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Output Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Security Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Input Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:00:49 --> Language Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Loader Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:00:49 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:00:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:00:49 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:00:49 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:00:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Controller Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:00:49 --> Email Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:00:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:00:49 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:00:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:00:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:00:49 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:00:49 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:00:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:00:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:00:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:00:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:00:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:00:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:00:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:00:50 --> Final output sent to browser
DEBUG - 2015-02-03 17:00:50 --> Total execution time: 0.8081
DEBUG - 2015-02-03 17:01:08 --> Config Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:01:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:01:08 --> URI Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Router Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Output Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Security Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Input Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:01:08 --> Language Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Loader Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:01:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:01:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:01:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:01:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Controller Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:01:08 --> Email Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:01:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:01:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:01:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:01:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:01:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:01:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:01:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:01:08 --> Final output sent to browser
DEBUG - 2015-02-03 17:01:08 --> Total execution time: 0.8401
DEBUG - 2015-02-03 17:01:37 --> Config Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:01:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:01:37 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:01:37 --> URI Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Router Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Output Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Security Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Input Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:01:37 --> Language Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Loader Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:01:37 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:01:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:01:37 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:01:37 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:01:37 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Controller Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:01:37 --> Email Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:01:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:01:37 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:01:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:01:37 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:01:37 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:01:37 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:01:37 --> Model Class Initialized
DEBUG - 2015-02-03 17:01:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:01:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 17:01:37 --> Severity: Error --> Call to undefined method Entity\Articles::getView() D:\phutx\project\ups\myblog\application\views\article\index.php 43
DEBUG - 2015-02-03 17:02:16 --> Config Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:02:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:02:16 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:02:16 --> URI Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Router Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Output Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Security Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Input Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:02:16 --> Language Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Loader Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:02:16 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:02:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:02:16 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:02:16 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:02:16 --> Model Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Model Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Controller Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:02:16 --> Email Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:02:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:02:16 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:02:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:02:16 --> Model Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:02:16 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:02:16 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:02:16 --> Model Class Initialized
DEBUG - 2015-02-03 17:02:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:02:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:02:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:02:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:02:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:02:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:02:17 --> Final output sent to browser
DEBUG - 2015-02-03 17:02:17 --> Total execution time: 0.8771
DEBUG - 2015-02-03 17:03:30 --> Config Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:03:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:03:30 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:03:30 --> URI Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Router Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Output Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Security Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Input Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:03:30 --> Language Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Loader Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:03:30 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:03:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:03:30 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:03:30 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:03:30 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Controller Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:03:30 --> Email Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:03:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:03:30 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:03:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:03:30 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:03:30 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:03:30 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:03:30 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:03:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:03:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:03:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:03:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:03:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:03:31 --> Final output sent to browser
DEBUG - 2015-02-03 17:03:31 --> Total execution time: 0.8791
DEBUG - 2015-02-03 17:03:31 --> Config Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:03:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:03:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:03:31 --> URI Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Router Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Output Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Security Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Input Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:03:31 --> Language Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Loader Class Initialized
DEBUG - 2015-02-03 17:03:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:03:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:03:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:03:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:03:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:03:32 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:32 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:32 --> Controller Class Initialized
DEBUG - 2015-02-03 17:03:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:03:32 --> Email Class Initialized
DEBUG - 2015-02-03 17:03:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:03:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:03:32 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:03:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:03:32 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:32 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:03:32 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:03:32 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:03:32 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:03:32 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:03:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:03:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:03:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:03:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:03:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:03:32 --> Final output sent to browser
DEBUG - 2015-02-03 17:03:32 --> Total execution time: 0.9351
DEBUG - 2015-02-03 17:03:33 --> Config Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:03:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:03:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:03:33 --> URI Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Router Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Output Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Security Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Input Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:03:33 --> Language Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Loader Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:03:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:03:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:03:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:03:33 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:03:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Controller Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:03:33 --> Email Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:03:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:03:33 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:03:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:03:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:03:33 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:03:33 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:03:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:03:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:03:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:03:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:03:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:03:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:03:34 --> Final output sent to browser
DEBUG - 2015-02-03 17:03:34 --> Total execution time: 0.9171
DEBUG - 2015-02-03 17:03:49 --> Config Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:03:49 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:03:49 --> URI Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Router Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Output Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Security Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Input Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:03:49 --> Language Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Loader Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:03:49 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:03:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:03:49 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:03:49 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:03:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Controller Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:03:49 --> Email Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:03:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:03:49 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:03:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:03:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:03:49 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:03:49 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:03:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:03:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:03:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:03:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:03:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:03:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:03:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:03:49 --> Final output sent to browser
DEBUG - 2015-02-03 17:03:49 --> Total execution time: 0.8611
DEBUG - 2015-02-03 17:05:03 --> Config Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:05:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:05:03 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:05:03 --> URI Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Router Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Output Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Security Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Input Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:05:03 --> Language Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Loader Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:05:03 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:05:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:05:03 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:05:03 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:05:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Controller Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:05:03 --> Email Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:05:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:05:03 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:05:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:05:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:05:03 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:05:03 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:05:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:05:04 --> Final output sent to browser
DEBUG - 2015-02-03 17:05:04 --> Total execution time: 0.8701
DEBUG - 2015-02-03 17:05:57 --> Config Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:05:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:05:57 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:05:57 --> URI Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Router Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Output Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Security Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Input Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:05:57 --> Language Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Loader Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:05:57 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:05:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:05:57 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:05:57 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:05:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Controller Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:05:57 --> Email Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:05:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:05:57 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:05:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:05:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:05:57 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:05:57 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:05:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:05:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:05:58 --> Final output sent to browser
DEBUG - 2015-02-03 17:05:58 --> Total execution time: 0.9171
DEBUG - 2015-02-03 17:06:03 --> Config Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:06:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:06:03 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:06:03 --> URI Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Router Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Output Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Security Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Input Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:06:03 --> Language Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Loader Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:06:03 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:06:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:06:03 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:06:03 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:06:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Controller Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:06:03 --> Email Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:06:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:06:03 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:06:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:06:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:06:03 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:06:03 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:06:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:06:04 --> Final output sent to browser
DEBUG - 2015-02-03 17:06:04 --> Total execution time: 0.9201
DEBUG - 2015-02-03 17:06:20 --> Config Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:06:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:06:20 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:06:20 --> URI Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Router Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Output Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Security Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Input Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:06:20 --> Language Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Loader Class Initialized
DEBUG - 2015-02-03 17:06:20 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:06:20 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:06:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:06:20 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:06:20 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:06:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:21 --> Controller Class Initialized
DEBUG - 2015-02-03 17:06:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:06:21 --> Email Class Initialized
DEBUG - 2015-02-03 17:06:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:06:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:06:21 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:06:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:06:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:21 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:06:21 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:06:21 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:06:21 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:06:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:06:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:06:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:06:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:06:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:06:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:06:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:06:21 --> Final output sent to browser
DEBUG - 2015-02-03 17:06:21 --> Total execution time: 0.8601
DEBUG - 2015-02-03 17:07:39 --> Config Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:07:39 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:07:39 --> URI Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Router Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Output Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Security Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Input Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:07:39 --> Language Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Loader Class Initialized
DEBUG - 2015-02-03 17:07:39 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:07:39 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:07:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:07:39 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:07:39 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:07:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:07:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:07:40 --> Controller Class Initialized
DEBUG - 2015-02-03 17:07:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:07:40 --> Email Class Initialized
DEBUG - 2015-02-03 17:07:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:07:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:07:40 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:07:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:07:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:07:40 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:07:40 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:07:40 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:07:40 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:07:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:07:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:07:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:07:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:07:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:07:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:07:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:07:40 --> Final output sent to browser
DEBUG - 2015-02-03 17:07:40 --> Total execution time: 0.8591
DEBUG - 2015-02-03 17:08:04 --> Config Class Initialized
DEBUG - 2015-02-03 17:08:04 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:08:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:08:04 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:08:04 --> URI Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Router Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Output Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Security Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Input Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:08:05 --> Language Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Loader Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:08:05 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:08:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:08:05 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:08:05 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Controller Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:08:05 --> Email Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:08:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:08:05 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:08:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:08:05 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:08:05 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:08:05 --> Final output sent to browser
DEBUG - 2015-02-03 17:08:05 --> Total execution time: 0.9641
DEBUG - 2015-02-03 17:08:28 --> Config Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:08:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:08:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:08:28 --> URI Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Router Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Output Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Security Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Input Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:08:28 --> Language Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Loader Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:08:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:08:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:08:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:08:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:08:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Controller Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:08:28 --> Email Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:08:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:08:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:08:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:08:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:08:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:08:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:08:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:08:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:08:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:08:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:08:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:08:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:08:29 --> Final output sent to browser
DEBUG - 2015-02-03 17:08:29 --> Total execution time: 0.8541
DEBUG - 2015-02-03 17:08:45 --> Config Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:08:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:08:45 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:08:45 --> URI Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Router Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Output Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Security Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Input Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:08:45 --> Language Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Loader Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:08:45 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:08:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:08:45 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:08:45 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:08:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Controller Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:08:45 --> Email Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:08:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:08:45 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:08:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:08:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:08:45 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:08:45 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:08:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:08:46 --> Final output sent to browser
DEBUG - 2015-02-03 17:08:46 --> Total execution time: 0.8601
DEBUG - 2015-02-03 17:08:53 --> Config Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:08:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:08:53 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:08:53 --> URI Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Router Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Output Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Security Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Input Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:08:53 --> Language Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Loader Class Initialized
DEBUG - 2015-02-03 17:08:53 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:08:53 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:08:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:08:53 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:08:53 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:08:54 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:54 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:54 --> Controller Class Initialized
DEBUG - 2015-02-03 17:08:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:08:54 --> Email Class Initialized
DEBUG - 2015-02-03 17:08:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:08:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:08:54 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:08:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:08:54 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:54 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:08:54 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:08:54 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:08:54 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:08:54 --> Model Class Initialized
DEBUG - 2015-02-03 17:08:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:08:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:08:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:08:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:08:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:08:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:08:54 --> Final output sent to browser
DEBUG - 2015-02-03 17:08:54 --> Total execution time: 0.9071
DEBUG - 2015-02-03 17:09:58 --> Config Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:09:58 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:09:58 --> URI Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Router Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Output Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Security Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Input Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:09:58 --> Language Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Loader Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:09:58 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:09:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:09:58 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:09:58 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:09:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Controller Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:09:58 --> Email Class Initialized
DEBUG - 2015-02-03 17:09:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:09:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:09:58 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:09:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:09:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:09:59 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:09:59 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:09:59 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:09:59 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:09:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:09:59 --> Final output sent to browser
DEBUG - 2015-02-03 17:09:59 --> Total execution time: 0.8931
DEBUG - 2015-02-03 17:10:12 --> Config Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:10:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:10:12 --> URI Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Router Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Output Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Security Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Input Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:10:12 --> Language Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Loader Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:10:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:10:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:10:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:10:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:10:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Controller Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:10:12 --> Email Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:10:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:10:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:10:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:10:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:10:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:10:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:10:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:10:13 --> Final output sent to browser
DEBUG - 2015-02-03 17:10:13 --> Total execution time: 0.8581
DEBUG - 2015-02-03 17:10:48 --> Config Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:10:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:10:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:10:48 --> URI Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Router Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Output Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Security Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Input Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:10:48 --> Language Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Loader Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:10:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:10:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:10:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:10:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:10:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Controller Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:10:48 --> Email Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:10:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:10:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:10:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:10:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:10:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:10:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:10:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:10:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:10:49 --> Final output sent to browser
DEBUG - 2015-02-03 17:10:49 --> Total execution time: 0.8941
DEBUG - 2015-02-03 17:10:57 --> Config Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:10:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:10:57 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:10:57 --> URI Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Router Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Output Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Security Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Input Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:10:57 --> Language Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Loader Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:10:57 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:10:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:10:57 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:10:57 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:10:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Controller Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:10:57 --> Email Class Initialized
DEBUG - 2015-02-03 17:10:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:10:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:10:57 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:10:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:10:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:58 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:10:58 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:10:58 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:10:58 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:10:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:10:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:10:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:10:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:10:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:10:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:10:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:10:58 --> Final output sent to browser
DEBUG - 2015-02-03 17:10:58 --> Total execution time: 0.9571
DEBUG - 2015-02-03 17:11:39 --> Config Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:11:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:11:39 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:11:39 --> URI Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Router Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Output Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Security Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Input Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:11:39 --> Language Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Loader Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:11:39 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:11:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:11:39 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:11:39 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:11:39 --> Model Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Model Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Controller Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:11:39 --> Email Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:11:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:11:39 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:11:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:11:39 --> Model Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:11:39 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:11:39 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:11:39 --> Model Class Initialized
DEBUG - 2015-02-03 17:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:11:39 --> Final output sent to browser
DEBUG - 2015-02-03 17:11:39 --> Total execution time: 0.8821
DEBUG - 2015-02-03 17:12:03 --> Config Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:12:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:12:03 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:12:03 --> URI Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Router Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Output Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Security Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Input Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:12:03 --> Language Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Loader Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:12:03 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:12:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:12:03 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:12:03 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:12:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Controller Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:12:03 --> Email Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:12:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:12:03 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:12:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:12:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:12:03 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:12:03 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:12:03 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:12:04 --> Final output sent to browser
DEBUG - 2015-02-03 17:12:04 --> Total execution time: 0.9151
DEBUG - 2015-02-03 17:12:23 --> Config Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:12:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:12:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:12:23 --> URI Class Initialized
DEBUG - 2015-02-03 17:12:23 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:12:23 --> Router Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Output Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Security Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Input Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:12:23 --> Language Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Loader Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:12:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:12:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:12:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:12:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:12:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Controller Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:12:23 --> Email Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:12:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:12:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:12:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:12:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:12:23 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:12:23 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:12:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:12:23 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:12:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:12:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:12:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:12:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:12:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:12:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:12:24 --> Final output sent to browser
DEBUG - 2015-02-03 17:12:24 --> Total execution time: 0.7191
DEBUG - 2015-02-03 17:14:09 --> Config Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:14:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:14:09 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:14:09 --> URI Class Initialized
DEBUG - 2015-02-03 17:14:09 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:14:09 --> Router Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Output Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Security Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Input Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:14:09 --> Language Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Loader Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:14:09 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:14:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:14:09 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:14:09 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Controller Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:14:09 --> Email Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:14:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:14:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:14:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:14:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:14:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:14:09 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:14:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:14:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:14:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:14:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:14:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:14:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:14:10 --> Final output sent to browser
DEBUG - 2015-02-03 17:14:10 --> Total execution time: 0.6541
DEBUG - 2015-02-03 17:14:20 --> Config Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:14:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:14:20 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:14:20 --> URI Class Initialized
DEBUG - 2015-02-03 17:14:20 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:14:20 --> Router Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Output Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Security Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Input Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:14:20 --> Language Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Loader Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:14:20 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:14:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:14:20 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:14:20 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:14:20 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Controller Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:14:20 --> Email Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:14:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:14:20 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:14:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:14:20 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:14:20 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:14:20 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:14:20 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:14:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:14:21 --> Final output sent to browser
DEBUG - 2015-02-03 17:14:21 --> Total execution time: 0.6661
DEBUG - 2015-02-03 17:14:58 --> Config Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:14:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:14:58 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:14:58 --> URI Class Initialized
DEBUG - 2015-02-03 17:14:58 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:14:58 --> Router Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Output Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Security Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Input Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:14:58 --> Language Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Loader Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:14:58 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:14:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:14:58 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:14:58 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:14:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Controller Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:14:58 --> Email Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:14:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:14:58 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:14:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:14:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:14:58 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:14:58 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Model Class Initialized
DEBUG - 2015-02-03 17:14:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:14:58 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:14:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:14:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:14:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:14:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:14:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:14:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:14:59 --> Final output sent to browser
DEBUG - 2015-02-03 17:14:59 --> Total execution time: 0.6591
DEBUG - 2015-02-03 17:15:18 --> Config Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:15:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:15:18 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:15:18 --> URI Class Initialized
DEBUG - 2015-02-03 17:15:18 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:15:18 --> Router Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Output Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Security Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Input Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:15:18 --> Language Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Loader Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:15:18 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:15:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:15:18 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:15:18 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Controller Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:15:18 --> Email Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:15:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:15:18 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:15:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:15:18 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:15:18 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:15:18 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:15:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:15:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:15:19 --> Final output sent to browser
DEBUG - 2015-02-03 17:15:19 --> Total execution time: 0.6501
DEBUG - 2015-02-03 17:15:26 --> Config Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:15:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:15:26 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:15:26 --> URI Class Initialized
DEBUG - 2015-02-03 17:15:26 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:15:26 --> Router Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Output Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Security Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Input Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:15:26 --> Language Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Loader Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:15:26 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:15:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:15:26 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:15:26 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:15:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Controller Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:15:26 --> Email Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:15:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:15:26 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:15:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:15:26 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:15:26 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:15:26 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:15:26 --> Final output sent to browser
DEBUG - 2015-02-03 17:15:26 --> Total execution time: 0.6601
DEBUG - 2015-02-03 17:15:31 --> Config Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:15:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:15:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:15:31 --> URI Class Initialized
DEBUG - 2015-02-03 17:15:31 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:15:31 --> Router Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Output Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Security Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Input Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:15:31 --> Language Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Loader Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:15:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:15:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:15:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:15:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:15:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Controller Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:15:31 --> Email Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:15:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:15:31 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:15:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:15:31 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:15:31 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:15:31 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:15:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:15:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:15:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:15:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:15:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:15:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:15:31 --> Final output sent to browser
DEBUG - 2015-02-03 17:15:31 --> Total execution time: 0.6741
DEBUG - 2015-02-03 17:15:34 --> Config Class Initialized
DEBUG - 2015-02-03 17:15:34 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:15:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:15:34 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:15:34 --> URI Class Initialized
DEBUG - 2015-02-03 17:15:34 --> Router Class Initialized
DEBUG - 2015-02-03 17:15:34 --> Output Class Initialized
DEBUG - 2015-02-03 17:15:34 --> Security Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Input Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:15:35 --> Language Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Loader Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:15:35 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:15:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:15:35 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:15:35 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:15:35 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Controller Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:15:35 --> Email Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:15:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:15:35 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:15:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:35 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:15:35 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:15:35 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:15:35 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:15:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:15:35 --> Final output sent to browser
DEBUG - 2015-02-03 17:15:35 --> Total execution time: 0.9431
DEBUG - 2015-02-03 17:15:42 --> Config Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:15:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:15:42 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:15:42 --> URI Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Router Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Output Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Security Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Input Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:15:42 --> Language Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Loader Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:15:42 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:15:42 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:15:42 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Controller Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:15:42 --> Email Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:15:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:42 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:15:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:15:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 17:15:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:42 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 17:15:42 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 17:15:42 --> Helper loaded: string_helper
DEBUG - 2015-02-03 17:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 17:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:15:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:15:42 --> Final output sent to browser
DEBUG - 2015-02-03 17:15:42 --> Total execution time: 0.2750
DEBUG - 2015-02-03 17:15:44 --> Config Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:15:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:15:44 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:15:44 --> URI Class Initialized
DEBUG - 2015-02-03 17:15:44 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:15:44 --> Router Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Output Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Security Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Input Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:15:44 --> Language Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Loader Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:15:44 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:15:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:15:44 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:15:44 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:15:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Controller Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:15:44 --> Email Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:15:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:15:44 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:15:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:15:44 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:15:44 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:15:44 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:15:44 --> Final output sent to browser
DEBUG - 2015-02-03 17:15:44 --> Total execution time: 0.7031
DEBUG - 2015-02-03 17:15:59 --> Config Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:15:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:15:59 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:15:59 --> URI Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Router Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Output Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Security Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Input Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:15:59 --> Language Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Loader Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:15:59 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:15:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:15:59 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:15:59 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:15:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Controller Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:15:59 --> Email Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:15:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:15:59 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:15:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:15:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:15:59 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:15:59 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:15:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:15:59 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:16:00 --> Final output sent to browser
DEBUG - 2015-02-03 17:16:00 --> Total execution time: 0.6911
DEBUG - 2015-02-03 17:16:44 --> Config Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:16:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:16:44 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:16:44 --> URI Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Router Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Output Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Security Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Input Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:16:44 --> Language Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Loader Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:16:44 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:16:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:16:44 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:16:44 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:16:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Controller Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:16:44 --> Email Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:16:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:16:44 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:16:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:16:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:16:44 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:16:44 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:16:44 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:16:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:16:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:16:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:16:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:16:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:16:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:16:44 --> Final output sent to browser
DEBUG - 2015-02-03 17:16:44 --> Total execution time: 0.7911
DEBUG - 2015-02-03 17:16:47 --> Config Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:16:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:16:47 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:16:47 --> URI Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Router Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Output Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Security Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Input Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:16:47 --> Language Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Loader Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:16:47 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:16:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:16:47 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:16:47 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:16:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Controller Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:16:47 --> Email Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:16:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:16:47 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:16:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:16:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:16:47 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:16:47 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:16:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-03 17:16:48 --> Severity: Notice --> Undefined variable: categories D:\phutx\project\ups\myblog\application\views\article\index.php 10
ERROR - 2015-02-03 17:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\application\views\article\index.php 10
ERROR - 2015-02-03 17:16:48 --> Severity: Notice --> Undefined variable: categories D:\phutx\project\ups\myblog\application\views\article\index.php 31
ERROR - 2015-02-03 17:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\application\views\article\index.php 31
ERROR - 2015-02-03 17:16:48 --> Severity: Notice --> Undefined variable: tags D:\phutx\project\ups\myblog\application\views\article\index.php 36
ERROR - 2015-02-03 17:16:48 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\application\views\article\index.php 36
DEBUG - 2015-02-03 17:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:16:48 --> Final output sent to browser
DEBUG - 2015-02-03 17:16:48 --> Total execution time: 0.7831
DEBUG - 2015-02-03 17:17:24 --> Config Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:17:24 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:17:24 --> URI Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Router Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Output Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Security Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Input Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:17:24 --> Language Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Loader Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:17:24 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:17:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:17:24 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:17:24 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:17:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Controller Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:17:24 --> Email Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:17:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:17:24 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:17:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:17:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:17:24 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:17:24 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:17:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:17:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:17:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:17:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:17:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:17:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:17:25 --> Final output sent to browser
DEBUG - 2015-02-03 17:17:25 --> Total execution time: 0.7791
DEBUG - 2015-02-03 17:17:31 --> Config Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:17:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:17:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:17:31 --> URI Class Initialized
DEBUG - 2015-02-03 17:17:31 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:17:31 --> Router Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Output Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Security Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Input Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:17:31 --> Language Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Loader Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:17:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:17:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:17:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:17:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:17:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Controller Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:17:31 --> Email Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:17:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:17:31 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:17:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:17:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:17:31 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:17:31 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:17:31 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:17:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:17:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:17:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:17:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:17:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:17:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:17:32 --> Final output sent to browser
DEBUG - 2015-02-03 17:17:32 --> Total execution time: 0.6571
DEBUG - 2015-02-03 17:17:34 --> Config Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:17:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:17:34 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:17:34 --> URI Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Router Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Output Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Security Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Input Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:17:34 --> Language Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Loader Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:17:34 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:17:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:17:34 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:17:34 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:17:34 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Controller Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:17:34 --> Email Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:17:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:17:34 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:17:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:17:34 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:17:34 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:17:34 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:17:34 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:17:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:17:35 --> Final output sent to browser
DEBUG - 2015-02-03 17:17:35 --> Total execution time: 0.8751
DEBUG - 2015-02-03 17:17:56 --> Config Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:17:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:17:56 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:17:56 --> URI Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Router Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Output Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Security Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Input Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:17:56 --> Language Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Loader Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:17:56 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:17:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:17:56 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:17:56 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:17:56 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Controller Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:17:56 --> Email Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:17:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:17:56 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:17:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:17:56 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:17:56 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:17:56 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:17:56 --> Model Class Initialized
DEBUG - 2015-02-03 17:17:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:17:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:17:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:17:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:17:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:17:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:17:57 --> Final output sent to browser
DEBUG - 2015-02-03 17:17:57 --> Total execution time: 0.8881
DEBUG - 2015-02-03 17:18:10 --> Config Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:18:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:18:10 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:18:10 --> URI Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Router Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Output Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Security Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Input Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:18:10 --> Language Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Loader Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:18:10 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:18:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:18:10 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:18:10 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:18:10 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Controller Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:18:10 --> Email Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:18:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:18:10 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:18:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:18:10 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:18:10 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:18:10 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:18:10 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:18:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:18:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:18:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:18:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:18:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:18:11 --> Final output sent to browser
DEBUG - 2015-02-03 17:18:11 --> Total execution time: 0.8791
DEBUG - 2015-02-03 17:18:24 --> Config Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:18:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:18:24 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:18:24 --> URI Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Router Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Output Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Security Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Input Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:18:24 --> Language Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Loader Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:18:24 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:18:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:18:24 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:18:24 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:18:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Controller Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:18:24 --> Email Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:18:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:18:24 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:18:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:18:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:18:24 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:18:24 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:18:24 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:18:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:18:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-03 17:18:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:18:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:18:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:18:25 --> Final output sent to browser
DEBUG - 2015-02-03 17:18:25 --> Total execution time: 0.8931
DEBUG - 2015-02-03 17:18:42 --> Config Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:18:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:18:42 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:18:42 --> URI Class Initialized
DEBUG - 2015-02-03 17:18:42 --> No URI present. Default controller set.
DEBUG - 2015-02-03 17:18:42 --> Router Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Output Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Security Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Input Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:18:42 --> Language Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Loader Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:18:42 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:18:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:18:42 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:18:42 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:18:42 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Controller Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:18:42 --> Email Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:18:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:18:42 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:18:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:18:42 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:18:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:18:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-03 17:18:42 --> Pagination Class Initialized
DEBUG - 2015-02-03 17:18:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:18:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:18:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-03 17:18:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:18:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:18:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:18:42 --> Final output sent to browser
DEBUG - 2015-02-03 17:18:42 --> Total execution time: 0.6841
DEBUG - 2015-02-03 17:18:48 --> Config Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:18:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:18:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:18:48 --> URI Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Router Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Output Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Security Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Input Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:18:48 --> Language Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Loader Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:18:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:18:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:18:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Controller Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:18:48 --> Email Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:18:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:18:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:18:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:18:48 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-03 17:18:48 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-03 17:18:48 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-03 17:18:48 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-03 17:18:48 --> Helper loaded: string_helper
DEBUG - 2015-02-03 17:18:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-03 17:18:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-03 17:18:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-03 17:18:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-03 17:18:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-03 17:18:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-03 17:18:48 --> Final output sent to browser
DEBUG - 2015-02-03 17:18:48 --> Total execution time: 0.2840
DEBUG - 2015-02-03 17:18:49 --> Config Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:18:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:18:49 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:18:49 --> URI Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Router Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Output Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Security Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Input Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:18:49 --> Language Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Loader Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:18:49 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:18:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:18:49 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:18:49 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:18:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Controller Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:18:49 --> Email Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:18:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:18:49 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:18:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:18:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:18:49 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:18:49 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:18:49 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:18:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:18:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 17:18:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:18:49 --> Final output sent to browser
DEBUG - 2015-02-03 17:18:49 --> Total execution time: 0.3550
DEBUG - 2015-02-03 17:18:52 --> Config Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:18:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:18:52 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:18:52 --> URI Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Router Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Output Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Security Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Input Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:18:52 --> Language Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Loader Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:18:52 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:18:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:18:52 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:18:52 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:18:52 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Controller Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:18:52 --> Email Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:18:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:18:52 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:18:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:18:52 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:18:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:18:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:18:52 --> Model Class Initialized
DEBUG - 2015-02-03 17:18:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:18:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-03 17:18:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:18:53 --> Final output sent to browser
DEBUG - 2015-02-03 17:18:53 --> Total execution time: 0.6441
DEBUG - 2015-02-03 17:19:12 --> Config Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:19:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:19:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:19:12 --> URI Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Router Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Output Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Security Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Input Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:19:12 --> Language Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Loader Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:19:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:19:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:19:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:19:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:19:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Controller Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:19:12 --> Email Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:19:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:19:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:19:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:19:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:19:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:19:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:19:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:19:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:19:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-03 17:19:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:19:12 --> Final output sent to browser
DEBUG - 2015-02-03 17:19:12 --> Total execution time: 0.3390
DEBUG - 2015-02-03 17:19:17 --> Config Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:19:17 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:19:17 --> URI Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Router Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Output Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Security Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Input Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:19:17 --> Language Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Loader Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:19:17 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:19:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:19:17 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:19:17 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:19:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Controller Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:19:17 --> Email Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:19:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:19:17 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:19:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:19:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:19:17 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:19:17 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:19:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:19:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:19:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-03 17:19:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:19:17 --> Final output sent to browser
DEBUG - 2015-02-03 17:19:17 --> Total execution time: 0.6291
DEBUG - 2015-02-03 17:19:19 --> Config Class Initialized
DEBUG - 2015-02-03 17:19:19 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:19:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:19:19 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Config Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:19:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:19:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:19:23 --> URI Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Router Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Output Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Security Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Input Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:19:23 --> Language Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Loader Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:19:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:19:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:19:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:19:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:19:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Controller Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:19:23 --> Email Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:19:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:19:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:19:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:19:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:19:23 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:19:23 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:19:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:19:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:19:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-03 17:19:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:19:23 --> Final output sent to browser
DEBUG - 2015-02-03 17:19:23 --> Total execution time: 0.6451
DEBUG - 2015-02-03 17:19:26 --> Config Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:19:26 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:19:26 --> URI Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Router Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Output Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Security Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Input Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:19:26 --> Language Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Loader Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:19:26 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:19:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:19:26 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:19:26 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:19:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Controller Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:19:26 --> Email Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:19:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:19:26 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:19:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:19:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:19:26 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:19:26 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:19:26 --> Model Class Initialized
DEBUG - 2015-02-03 17:19:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:19:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:19:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:19:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:19:26 --> Final output sent to browser
DEBUG - 2015-02-03 17:19:26 --> Total execution time: 0.1930
DEBUG - 2015-02-03 17:25:17 --> Config Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:25:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:25:17 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:25:17 --> URI Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Router Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Output Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Security Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Input Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:25:17 --> Language Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Loader Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:25:17 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:25:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:25:17 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:25:17 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:25:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Controller Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:25:17 --> Email Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:25:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:25:17 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:25:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:25:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:25:17 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:25:17 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:25:17 --> Model Class Initialized
DEBUG - 2015-02-03 17:25:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:25:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:25:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:25:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:25:17 --> Final output sent to browser
DEBUG - 2015-02-03 17:25:17 --> Total execution time: 0.2870
DEBUG - 2015-02-03 17:26:07 --> Config Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:26:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:26:07 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:26:07 --> URI Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Router Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Output Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Security Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Input Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:26:07 --> Language Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Loader Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:26:07 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:26:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:26:07 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:26:07 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:26:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Controller Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:26:07 --> Email Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:26:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:26:07 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:26:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:26:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:26:07 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:26:07 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:26:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:26:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:26:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:26:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:26:07 --> Final output sent to browser
DEBUG - 2015-02-03 17:26:07 --> Total execution time: 0.2010
DEBUG - 2015-02-03 17:26:47 --> Config Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:26:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:26:47 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:26:47 --> URI Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Router Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Output Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Security Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Input Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:26:47 --> Language Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Loader Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:26:47 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:26:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:26:47 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:26:47 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:26:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Controller Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:26:47 --> Email Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:26:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:26:47 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:26:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:26:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:26:47 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:26:47 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:26:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:26:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:26:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:26:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:26:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:26:47 --> Final output sent to browser
DEBUG - 2015-02-03 17:26:47 --> Total execution time: 0.2190
DEBUG - 2015-02-03 17:27:45 --> Config Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:27:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:27:45 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:27:45 --> URI Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Router Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Output Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Security Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Input Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:27:45 --> Language Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Loader Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:27:45 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:27:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:27:45 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:27:45 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:27:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Controller Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:27:45 --> Email Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:27:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:27:45 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:27:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:27:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:27:45 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:27:45 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:27:45 --> Model Class Initialized
DEBUG - 2015-02-03 17:27:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:27:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:27:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:27:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:27:45 --> Final output sent to browser
DEBUG - 2015-02-03 17:27:45 --> Total execution time: 0.2790
DEBUG - 2015-02-03 17:30:48 --> Config Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:30:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:30:48 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:30:48 --> URI Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Router Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Output Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Security Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Input Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:30:48 --> Language Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Loader Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:30:48 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:30:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:30:48 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:30:48 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:30:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Controller Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:30:48 --> Email Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:30:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:30:48 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:30:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:30:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:30:48 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:30:48 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:30:48 --> Model Class Initialized
DEBUG - 2015-02-03 17:30:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:30:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:30:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:30:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:30:59 --> Config Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:30:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:30:59 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:30:59 --> URI Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Router Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Output Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Security Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Input Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:30:59 --> Language Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Loader Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:30:59 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:30:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:30:59 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:30:59 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:30:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Controller Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:30:59 --> Email Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:30:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:30:59 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:30:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:30:59 --> Model Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:30:59 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:30:59 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:30:59 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:31:00 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:31:09 --> Config Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:31:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:31:09 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:31:09 --> URI Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Router Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Output Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Security Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Input Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:31:09 --> Language Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Loader Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:31:09 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:31:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:31:09 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:31:09 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:31:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Controller Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:31:09 --> Email Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:31:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:31:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:31:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:31:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:31:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:31:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:31:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:31:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:31:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:31:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:31:19 --> Config Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:31:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:31:19 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:31:19 --> URI Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Router Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Output Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Security Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Input Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:31:19 --> Language Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Loader Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:31:19 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:31:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:31:19 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:31:19 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Controller Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:31:19 --> Email Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:31:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:31:19 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:31:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:31:19 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:31:19 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:31:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:31:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:31:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:31:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:31:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:31:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:31:19 --> Final output sent to browser
DEBUG - 2015-02-03 17:31:19 --> Total execution time: 0.2480
DEBUG - 2015-02-03 17:32:33 --> Config Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:32:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:32:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:32:33 --> URI Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Router Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Output Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Security Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Input Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:32:33 --> Language Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Loader Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:32:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:32:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:32:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:32:33 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:32:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Controller Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:32:33 --> Email Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:32:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:32:33 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:32:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:32:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:32:33 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:32:33 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:32:33 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:32:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:32:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:32:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:32:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:32:33 --> Final output sent to browser
DEBUG - 2015-02-03 17:32:33 --> Total execution time: 0.2130
DEBUG - 2015-02-03 17:32:40 --> Config Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:32:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:32:40 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:32:40 --> URI Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Router Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Output Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Security Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Input Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:32:40 --> Language Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Loader Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:32:40 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:32:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:32:40 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:32:40 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:32:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Controller Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:32:40 --> Email Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:32:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:32:40 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:32:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:32:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:32:40 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:32:40 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:32:40 --> Model Class Initialized
DEBUG - 2015-02-03 17:32:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:32:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:32:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:32:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:32:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:32:40 --> Final output sent to browser
DEBUG - 2015-02-03 17:32:40 --> Total execution time: 0.2070
DEBUG - 2015-02-03 17:33:09 --> Config Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:33:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:33:09 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:33:09 --> URI Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Router Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Output Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Security Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Input Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:33:09 --> Language Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Loader Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:33:09 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:33:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:33:09 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:33:09 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:33:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Controller Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:33:09 --> Email Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:33:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:33:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:33:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:33:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:33:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:33:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:33:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:33:10 --> Model Class Initialized
DEBUG - 2015-02-03 17:33:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:33:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:33:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:33:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:33:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:33:10 --> Final output sent to browser
DEBUG - 2015-02-03 17:33:10 --> Total execution time: 0.2070
DEBUG - 2015-02-03 17:35:12 --> Config Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:35:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:35:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:35:12 --> URI Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Router Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Output Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Security Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Input Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:35:12 --> Language Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Loader Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:35:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:35:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:35:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:35:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:35:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Controller Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:35:12 --> Email Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:35:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:35:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:35:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:35:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:35:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:35:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:35:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:35:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:35:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:35:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:35:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:35:12 --> Final output sent to browser
DEBUG - 2015-02-03 17:35:12 --> Total execution time: 0.2198
DEBUG - 2015-02-03 17:35:22 --> Config Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:35:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:35:22 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:35:22 --> URI Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Router Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Output Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Security Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Input Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:35:22 --> Language Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Loader Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:35:22 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:35:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:35:22 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:35:22 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:35:22 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Controller Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:35:22 --> Email Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:35:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:35:22 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:35:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:35:22 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:35:22 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:35:22 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:35:22 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:35:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:35:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:35:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:35:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:35:22 --> Final output sent to browser
DEBUG - 2015-02-03 17:35:22 --> Total execution time: 0.2238
DEBUG - 2015-02-03 17:35:35 --> Config Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:35:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:35:35 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:35:35 --> URI Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Router Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Output Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Security Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Input Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:35:35 --> Language Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Loader Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:35:35 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:35:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:35:35 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:35:35 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:35:35 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Controller Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:35:35 --> Email Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:35:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:35:35 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:35:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:35:35 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:35:35 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:35:35 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:35:35 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:35:36 --> Model Class Initialized
DEBUG - 2015-02-03 17:35:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:35:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:35:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:35:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:35:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:35:36 --> Final output sent to browser
DEBUG - 2015-02-03 17:35:36 --> Total execution time: 0.2048
DEBUG - 2015-02-03 17:36:47 --> Config Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:36:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:36:47 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:36:47 --> URI Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Router Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Output Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Security Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Input Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:36:47 --> Language Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Loader Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:36:47 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:36:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:36:47 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:36:47 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Controller Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:36:47 --> Email Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:36:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:36:47 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:36:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:36:47 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:36:47 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-03 17:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:36:47 --> Final output sent to browser
DEBUG - 2015-02-03 17:36:47 --> Total execution time: 0.2278
DEBUG - 2015-02-03 17:37:08 --> Config Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:37:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:37:08 --> URI Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Router Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Output Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Security Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Input Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:37:08 --> Language Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Loader Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:37:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:37:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:37:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:37:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:37:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Controller Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:37:08 --> Email Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:37:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:37:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:37:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:37:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:37:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:37:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:37:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:37:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:37:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:37:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:37:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:37:08 --> Final output sent to browser
DEBUG - 2015-02-03 17:37:08 --> Total execution time: 0.1928
DEBUG - 2015-02-03 17:37:43 --> Config Class Initialized
DEBUG - 2015-02-03 17:37:43 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:37:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:37:44 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:37:44 --> URI Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Router Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Output Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Security Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Input Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:37:44 --> Language Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Loader Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:37:44 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:37:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:37:44 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:37:44 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:37:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Controller Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:37:44 --> Email Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:37:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:37:44 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:37:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:37:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:37:44 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:37:44 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:37:44 --> Model Class Initialized
DEBUG - 2015-02-03 17:37:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:37:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:37:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:37:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:37:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:37:44 --> Final output sent to browser
DEBUG - 2015-02-03 17:37:44 --> Total execution time: 0.2168
DEBUG - 2015-02-03 17:38:21 --> Config Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:38:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:38:21 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:38:21 --> URI Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Router Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Output Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Security Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Input Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:38:21 --> Language Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Loader Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:38:21 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:38:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:38:21 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:38:21 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:38:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Controller Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:38:21 --> Email Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:38:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:38:21 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:38:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:38:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:38:21 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:38:21 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:38:21 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:38:21 --> Final output sent to browser
DEBUG - 2015-02-03 17:38:21 --> Total execution time: 0.2318
DEBUG - 2015-02-03 17:38:28 --> Config Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:38:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:38:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:38:28 --> URI Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Router Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Output Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Security Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Input Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:38:28 --> Language Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Loader Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:38:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:38:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:38:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:38:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:38:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Controller Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:38:28 --> Email Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:38:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:38:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:38:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:38:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:38:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:38:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:38:28 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:38:28 --> Final output sent to browser
DEBUG - 2015-02-03 17:38:28 --> Total execution time: 0.2058
DEBUG - 2015-02-03 17:38:50 --> Config Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:38:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:38:50 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:38:50 --> URI Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Router Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Output Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Security Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Input Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:38:50 --> Language Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Loader Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:38:50 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:38:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:38:50 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:38:50 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Controller Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:38:50 --> Email Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:38:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:38:50 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:38:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:38:50 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:38:50 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:38:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:38:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:38:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:38:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:38:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:38:50 --> Final output sent to browser
DEBUG - 2015-02-03 17:38:50 --> Total execution time: 0.1990
DEBUG - 2015-02-03 17:39:00 --> Config Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:39:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:39:00 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:39:00 --> URI Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Router Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Output Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Security Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Input Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:39:00 --> Language Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Loader Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:39:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:39:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:39:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:39:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Controller Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:39:00 --> Email Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:39:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:39:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:39:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:39:00 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:39:00 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:39:00 --> Final output sent to browser
DEBUG - 2015-02-03 17:39:00 --> Total execution time: 0.2360
DEBUG - 2015-02-03 17:39:19 --> Config Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:39:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:39:19 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:39:19 --> URI Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Router Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Output Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Security Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Input Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:39:19 --> Language Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Loader Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:39:19 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:39:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:39:19 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:39:19 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:39:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Controller Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:39:19 --> Email Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:39:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:39:19 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:39:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:39:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:39:19 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:39:19 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:39:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:39:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:39:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:39:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:39:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:39:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:39:19 --> Final output sent to browser
DEBUG - 2015-02-03 17:39:19 --> Total execution time: 0.1930
DEBUG - 2015-02-03 17:40:08 --> Config Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:40:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:40:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:40:08 --> URI Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Router Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Output Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Security Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Input Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:40:08 --> Language Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Loader Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:40:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:40:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:40:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:40:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:40:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Controller Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:40:08 --> Email Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:40:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:40:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:40:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:40:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:40:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:40:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:40:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:40:08 --> Final output sent to browser
DEBUG - 2015-02-03 17:40:08 --> Total execution time: 0.2150
DEBUG - 2015-02-03 17:41:41 --> Config Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:41:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:41:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:41:41 --> URI Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Router Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Output Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Security Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Input Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:41:41 --> Language Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Loader Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:41:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:41:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:41:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:41:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:41:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Controller Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:41:41 --> Email Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:41:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:41:41 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:41:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:41:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:41:41 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:41:41 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:41:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:41:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:41:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:41:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:41:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:41:41 --> Final output sent to browser
DEBUG - 2015-02-03 17:41:41 --> Total execution time: 0.2010
DEBUG - 2015-02-03 17:41:57 --> Config Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:41:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:41:57 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:41:57 --> URI Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Router Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Output Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Security Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Input Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:41:57 --> Language Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Loader Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:41:57 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:41:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:41:57 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:41:57 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:41:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Controller Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:41:57 --> Email Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:41:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:41:57 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:41:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:41:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:41:57 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:41:57 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:41:57 --> Model Class Initialized
DEBUG - 2015-02-03 17:41:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:41:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:41:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:41:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:41:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:41:57 --> Final output sent to browser
DEBUG - 2015-02-03 17:41:57 --> Total execution time: 0.2250
DEBUG - 2015-02-03 17:42:07 --> Config Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:42:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:42:07 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:42:07 --> URI Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Router Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Output Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Security Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Input Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:42:07 --> Language Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Loader Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:42:07 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:42:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:42:07 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:42:07 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:42:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Controller Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:42:07 --> Email Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:42:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:42:07 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:42:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:42:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:42:07 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:42:07 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:42:07 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:42:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:42:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:42:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:42:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:42:07 --> Final output sent to browser
DEBUG - 2015-02-03 17:42:07 --> Total execution time: 0.2010
DEBUG - 2015-02-03 17:42:27 --> Config Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:42:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:42:27 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:42:27 --> URI Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Router Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Output Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Security Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Input Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:42:27 --> Language Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Loader Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:42:27 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:42:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:42:27 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:42:27 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:42:27 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Controller Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:42:27 --> Email Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:42:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:42:27 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:42:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:42:27 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:42:27 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:42:27 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:42:27 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:42:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:42:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:42:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:42:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:42:27 --> Final output sent to browser
DEBUG - 2015-02-03 17:42:27 --> Total execution time: 0.1990
DEBUG - 2015-02-03 17:42:46 --> Config Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:42:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:42:46 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:42:46 --> URI Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Router Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Output Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Security Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Input Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:42:46 --> Language Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Loader Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:42:46 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:42:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:42:46 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:42:46 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Controller Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:42:46 --> Email Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:42:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:42:46 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:42:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:42:46 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:42:46 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-03 17:42:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:42:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:42:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:42:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:42:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:42:46 --> Final output sent to browser
DEBUG - 2015-02-03 17:42:46 --> Total execution time: 0.2270
DEBUG - 2015-02-03 17:43:08 --> Config Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:43:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:43:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:43:08 --> URI Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Router Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Output Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Security Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Input Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:43:08 --> Language Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Loader Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:43:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:43:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:43:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:43:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:43:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Controller Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:43:08 --> Email Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:43:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:43:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:43:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:43:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:43:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:43:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:43:08 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:43:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:43:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:43:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:43:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:43:08 --> Final output sent to browser
DEBUG - 2015-02-03 17:43:08 --> Total execution time: 0.2150
DEBUG - 2015-02-03 17:43:25 --> Config Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:43:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:43:25 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:43:25 --> URI Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Router Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Output Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Security Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Input Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:43:25 --> Language Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Loader Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:43:25 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:43:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:43:25 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:43:25 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:43:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Controller Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:43:25 --> Email Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:43:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:43:25 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:43:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:43:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:43:25 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:43:25 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:43:25 --> Model Class Initialized
DEBUG - 2015-02-03 17:43:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:43:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:43:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:43:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:43:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:43:25 --> Final output sent to browser
DEBUG - 2015-02-03 17:43:25 --> Total execution time: 0.2150
DEBUG - 2015-02-03 17:45:53 --> Config Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:45:53 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:45:53 --> URI Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Router Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Output Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Security Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Input Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:45:53 --> Language Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Loader Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:45:53 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:45:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:45:53 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:45:53 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Controller Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:45:53 --> Email Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:45:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:45:53 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:45:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:45:53 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:45:53 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:45:53 --> Model Class Initialized
DEBUG - 2015-02-03 17:45:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:45:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:45:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:45:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:45:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:45:53 --> Final output sent to browser
DEBUG - 2015-02-03 17:45:53 --> Total execution time: 0.2290
DEBUG - 2015-02-03 17:48:12 --> Config Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:48:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:48:12 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:48:12 --> URI Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Router Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Output Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Security Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Input Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:48:12 --> Language Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Loader Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:48:12 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:48:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:48:12 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:48:12 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:48:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Controller Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:48:12 --> Email Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:48:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:48:12 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:48:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:48:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:48:12 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:48:12 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:48:12 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:48:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:48:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:48:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:48:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:48:12 --> Final output sent to browser
DEBUG - 2015-02-03 17:48:12 --> Total execution time: 0.2400
DEBUG - 2015-02-03 17:48:51 --> Config Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:48:51 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:48:51 --> URI Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Router Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Output Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Security Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Input Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:48:51 --> Language Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Loader Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:48:51 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:48:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:48:51 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:48:51 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:48:51 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Controller Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:48:51 --> Email Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:48:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:48:51 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:48:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:48:51 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:48:51 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:48:52 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:48:52 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:48:52 --> Model Class Initialized
DEBUG - 2015-02-03 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:48:52 --> Final output sent to browser
DEBUG - 2015-02-03 17:48:52 --> Total execution time: 0.1900
DEBUG - 2015-02-03 17:50:22 --> Config Class Initialized
DEBUG - 2015-02-03 17:50:22 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:50:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:50:22 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:50:22 --> URI Class Initialized
DEBUG - 2015-02-03 17:50:22 --> Router Class Initialized
DEBUG - 2015-02-03 17:50:22 --> Output Class Initialized
DEBUG - 2015-02-03 17:50:22 --> Security Class Initialized
DEBUG - 2015-02-03 17:50:22 --> Input Class Initialized
DEBUG - 2015-02-03 17:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:50:23 --> Language Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Loader Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:50:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:50:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:50:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:50:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:50:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Controller Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:50:23 --> Email Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:50:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:50:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:50:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:50:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:50:23 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:50:23 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:50:23 --> Final output sent to browser
DEBUG - 2015-02-03 17:50:23 --> Total execution time: 0.2280
DEBUG - 2015-02-03 17:50:23 --> Config Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:50:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:50:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:50:23 --> URI Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Router Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Output Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Security Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Input Class Initialized
DEBUG - 2015-02-03 17:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:50:23 --> Language Class Initialized
ERROR - 2015-02-03 17:50:23 --> 404 Page Not Found: admin/Articles/assets
DEBUG - 2015-02-03 17:50:50 --> Config Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:50:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:50:50 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:50:50 --> URI Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Router Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Output Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Security Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Input Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:50:50 --> Language Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Loader Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:50:50 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:50:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:50:50 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:50:50 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:50:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Controller Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:50:50 --> Email Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:50:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:50:50 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:50:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:50:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:50:50 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:50:50 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:50:50 --> Model Class Initialized
DEBUG - 2015-02-03 17:50:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:50:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:50:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:50:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:50:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:50:50 --> Final output sent to browser
DEBUG - 2015-02-03 17:50:50 --> Total execution time: 0.2070
DEBUG - 2015-02-03 17:54:19 --> Config Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:54:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:54:19 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:54:19 --> URI Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Router Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Output Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Security Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Input Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:54:19 --> Language Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Loader Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:54:19 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:54:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:54:19 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Session: Regenerate ID
DEBUG - 2015-02-03 17:54:19 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:54:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Controller Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:54:19 --> Email Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:54:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:54:19 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:54:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:54:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:54:19 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:54:19 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:54:19 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:54:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:54:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:54:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:54:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:54:19 --> Final output sent to browser
DEBUG - 2015-02-03 17:54:19 --> Total execution time: 0.2670
DEBUG - 2015-02-03 17:54:55 --> Config Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:54:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:54:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:54:55 --> URI Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Router Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Output Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Security Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Input Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:54:55 --> Language Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Loader Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:54:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:54:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:54:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:54:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:54:55 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Controller Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:54:55 --> Email Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:54:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:54:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:54:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:54:55 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:54:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:54:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:54:55 --> Model Class Initialized
DEBUG - 2015-02-03 17:54:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:54:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:54:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:54:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:54:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:54:55 --> Final output sent to browser
DEBUG - 2015-02-03 17:54:55 --> Total execution time: 0.2240
DEBUG - 2015-02-03 17:57:02 --> Config Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:57:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:57:02 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:57:02 --> URI Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Router Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Output Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Security Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Input Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:57:02 --> Language Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Loader Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:57:02 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:57:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:57:02 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:57:02 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:57:02 --> Model Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Model Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Controller Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:57:02 --> Email Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:57:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:57:02 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:57:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:57:02 --> Model Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:57:02 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:57:02 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:57:02 --> Model Class Initialized
DEBUG - 2015-02-03 17:57:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:57:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:57:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:57:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:57:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:57:02 --> Final output sent to browser
DEBUG - 2015-02-03 17:57:02 --> Total execution time: 0.2080
DEBUG - 2015-02-03 17:58:41 --> Config Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:58:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:58:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:58:41 --> URI Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Router Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Output Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Security Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Input Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:58:41 --> Language Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Loader Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:58:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:58:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:58:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:58:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:58:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Controller Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:58:41 --> Email Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:58:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:58:41 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:58:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:58:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:58:41 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:58:41 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:58:41 --> Model Class Initialized
DEBUG - 2015-02-03 17:58:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:58:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:58:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:58:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:58:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:58:41 --> Final output sent to browser
DEBUG - 2015-02-03 17:58:41 --> Total execution time: 0.2120
DEBUG - 2015-02-03 17:59:09 --> Config Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Hooks Class Initialized
DEBUG - 2015-02-03 17:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 17:59:09 --> Utf8 Class Initialized
DEBUG - 2015-02-03 17:59:09 --> URI Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Router Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Output Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Security Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Input Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 17:59:09 --> Language Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Loader Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Helper loaded: url_helper
DEBUG - 2015-02-03 17:59:09 --> Helper loaded: link_helper
DEBUG - 2015-02-03 17:59:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 17:59:09 --> CI_Session Class Initialized
DEBUG - 2015-02-03 17:59:09 --> CI_Session routines successfully run
DEBUG - 2015-02-03 17:59:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Controller Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 17:59:09 --> Email Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 17:59:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 17:59:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 17:59:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 17:59:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 17:59:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 17:59:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 17:59:09 --> Model Class Initialized
DEBUG - 2015-02-03 17:59:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 17:59:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 17:59:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 17:59:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 17:59:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 17:59:09 --> Final output sent to browser
DEBUG - 2015-02-03 17:59:09 --> Total execution time: 0.2800
DEBUG - 2015-02-03 18:01:05 --> Config Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:01:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:01:05 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:01:05 --> URI Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Router Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Output Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Security Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Input Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:01:05 --> Language Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Loader Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:01:05 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:01:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:01:05 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:01:05 --> Session: Regenerate ID
DEBUG - 2015-02-03 18:01:05 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:01:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:01:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:01:06 --> Controller Class Initialized
DEBUG - 2015-02-03 18:01:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:01:06 --> Email Class Initialized
DEBUG - 2015-02-03 18:01:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:01:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:01:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:01:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:01:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:01:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:01:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:01:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:01:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:01:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:01:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:01:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:01:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:01:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:01:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:01:06 --> Final output sent to browser
DEBUG - 2015-02-03 18:01:06 --> Total execution time: 0.2040
DEBUG - 2015-02-03 18:01:07 --> Config Class Initialized
DEBUG - 2015-02-03 18:01:07 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:01:07 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:01:07 --> URI Class Initialized
DEBUG - 2015-02-03 18:01:07 --> Router Class Initialized
DEBUG - 2015-02-03 18:01:07 --> Output Class Initialized
DEBUG - 2015-02-03 18:01:07 --> Security Class Initialized
DEBUG - 2015-02-03 18:01:07 --> Input Class Initialized
DEBUG - 2015-02-03 18:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:01:07 --> Language Class Initialized
ERROR - 2015-02-03 18:01:07 --> 404 Page Not Found: Resources/css
DEBUG - 2015-02-03 18:02:18 --> Config Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:02:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:02:18 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:02:18 --> URI Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Router Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Output Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Security Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Input Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:02:18 --> Language Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Loader Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:02:18 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:02:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:02:18 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:02:18 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Controller Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:02:18 --> Email Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:02:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:02:18 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:02:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:02:18 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:02:18 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:02:18 --> Final output sent to browser
DEBUG - 2015-02-03 18:02:18 --> Total execution time: 0.2630
DEBUG - 2015-02-03 18:02:27 --> Config Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:02:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:02:27 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:02:27 --> URI Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Router Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Output Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Security Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Input Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:02:27 --> Language Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Loader Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:02:27 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:02:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:02:27 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:02:27 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:02:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Controller Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:02:27 --> Email Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:02:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:02:27 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:02:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:02:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:02:27 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:02:27 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:02:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:02:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:02:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:02:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:02:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:02:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:02:27 --> Final output sent to browser
DEBUG - 2015-02-03 18:02:27 --> Total execution time: 0.2540
DEBUG - 2015-02-03 18:05:08 --> Config Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:05:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:05:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:05:08 --> URI Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Router Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Output Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Security Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Input Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:05:08 --> Language Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Loader Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:05:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:05:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:05:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:05:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:05:08 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Controller Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:05:08 --> Email Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:05:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:05:08 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:05:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:05:08 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:05:08 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:05:08 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:05:08 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:05:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:05:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:05:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:05:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:05:09 --> Final output sent to browser
DEBUG - 2015-02-03 18:05:09 --> Total execution time: 0.9611
DEBUG - 2015-02-03 18:05:44 --> Config Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:05:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:05:44 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:05:44 --> URI Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Router Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Output Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Security Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Input Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:05:44 --> Language Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Loader Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:05:44 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:05:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:05:44 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:05:44 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:05:44 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Controller Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:05:44 --> Email Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:05:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:05:44 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:05:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:05:44 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:05:44 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:05:44 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:05:44 --> Model Class Initialized
DEBUG - 2015-02-03 18:05:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:05:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:05:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:05:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:05:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:05:44 --> Final output sent to browser
DEBUG - 2015-02-03 18:05:44 --> Total execution time: 0.3150
DEBUG - 2015-02-03 18:06:27 --> Config Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:06:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:06:27 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:06:27 --> URI Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Router Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Output Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Security Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Input Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:06:27 --> Language Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Loader Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:06:27 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:06:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:06:27 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Session: Regenerate ID
DEBUG - 2015-02-03 18:06:27 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:06:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Controller Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:06:27 --> Email Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:06:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:06:27 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:06:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:06:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:06:27 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:06:27 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:06:27 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:06:27 --> Final output sent to browser
DEBUG - 2015-02-03 18:06:27 --> Total execution time: 0.3500
DEBUG - 2015-02-03 18:06:33 --> Config Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:06:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:06:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:06:33 --> URI Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Router Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Output Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Security Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Input Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:06:33 --> Language Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Loader Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:06:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:06:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:06:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:06:33 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Controller Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:06:33 --> Email Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:06:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:06:33 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:06:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:06:33 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:06:33 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-03 18:06:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:06:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:06:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:06:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:06:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:06:33 --> Final output sent to browser
DEBUG - 2015-02-03 18:06:33 --> Total execution time: 0.3060
DEBUG - 2015-02-03 18:09:11 --> Config Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:09:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:09:11 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:09:11 --> URI Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Router Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Output Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Security Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Input Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:09:11 --> Language Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Loader Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:09:11 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:09:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:09:11 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:09:11 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:09:11 --> Model Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Model Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Controller Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:09:11 --> Email Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:09:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:09:11 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:09:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:09:11 --> Model Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:09:11 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:09:11 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:09:11 --> Model Class Initialized
DEBUG - 2015-02-03 18:09:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:09:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:09:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:09:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:09:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:09:12 --> Final output sent to browser
DEBUG - 2015-02-03 18:09:12 --> Total execution time: 0.4470
DEBUG - 2015-02-03 18:10:04 --> Config Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:10:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:10:04 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:10:04 --> URI Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Router Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Output Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Security Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Input Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:10:04 --> Language Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Loader Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:10:04 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:10:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:10:04 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:10:04 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:10:04 --> Model Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Model Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Controller Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:10:04 --> Email Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:10:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:10:04 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:10:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:10:04 --> Model Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:10:04 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:10:04 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:10:04 --> Model Class Initialized
DEBUG - 2015-02-03 18:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:12:49 --> Config Class Initialized
DEBUG - 2015-02-03 18:12:49 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:12:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:12:49 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:12:49 --> URI Class Initialized
DEBUG - 2015-02-03 18:12:49 --> Router Class Initialized
DEBUG - 2015-02-03 18:12:49 --> Output Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Security Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Input Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:12:50 --> Language Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Loader Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:12:50 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:12:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:12:50 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Session: Regenerate ID
DEBUG - 2015-02-03 18:12:50 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:12:50 --> Model Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Model Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Controller Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:12:50 --> Email Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:12:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:12:50 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:12:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:12:50 --> Model Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:12:50 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:12:50 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:12:50 --> Model Class Initialized
DEBUG - 2015-02-03 18:12:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:12:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:12:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:12:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:12:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:12:50 --> Final output sent to browser
DEBUG - 2015-02-03 18:12:50 --> Total execution time: 0.3590
DEBUG - 2015-02-03 18:13:06 --> Config Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:13:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:13:06 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:13:06 --> URI Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Router Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Output Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Security Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Input Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:13:06 --> Language Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Loader Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:13:06 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:13:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:13:06 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:13:06 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:13:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Controller Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:13:06 --> Email Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:13:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:13:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:13:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:13:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:13:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:13:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:13:06 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:13:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:13:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:13:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:13:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:13:06 --> Final output sent to browser
DEBUG - 2015-02-03 18:13:06 --> Total execution time: 0.3470
DEBUG - 2015-02-03 18:13:23 --> Config Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:13:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:13:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:13:23 --> URI Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Router Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Output Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Security Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Input Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:13:23 --> Language Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Loader Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:13:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:13:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:13:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:13:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:13:23 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Controller Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:13:23 --> Email Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:13:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:13:23 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:13:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:13:23 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:13:23 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:13:23 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:13:23 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:13:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:13:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:13:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:13:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:13:23 --> Final output sent to browser
DEBUG - 2015-02-03 18:13:23 --> Total execution time: 0.3930
DEBUG - 2015-02-03 18:13:51 --> Config Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:13:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:13:51 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:13:51 --> URI Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Router Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Output Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Security Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Input Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:13:51 --> Language Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Loader Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:13:51 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:13:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:13:51 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:13:51 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:13:51 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Controller Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:13:51 --> Email Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:13:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:13:51 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:13:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:13:51 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:13:51 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:13:51 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:13:51 --> Model Class Initialized
DEBUG - 2015-02-03 18:13:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:13:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:13:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:13:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:13:52 --> Final output sent to browser
DEBUG - 2015-02-03 18:13:52 --> Total execution time: 0.5261
DEBUG - 2015-02-03 18:28:53 --> Config Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:28:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:28:53 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:28:53 --> URI Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Router Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Output Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Security Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Input Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:28:53 --> Language Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Loader Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:28:53 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:28:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:28:53 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Session: Regenerate ID
DEBUG - 2015-02-03 18:28:53 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:28:53 --> Model Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Model Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Controller Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:28:53 --> Email Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:28:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:28:53 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:28:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:28:53 --> Model Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:28:53 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:28:53 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:28:53 --> Model Class Initialized
DEBUG - 2015-02-03 18:28:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:28:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:28:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:28:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:28:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:28:54 --> Final output sent to browser
DEBUG - 2015-02-03 18:28:54 --> Total execution time: 0.4360
DEBUG - 2015-02-03 18:43:55 --> Config Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:43:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:43:55 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:43:55 --> URI Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Router Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Output Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Security Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Input Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:43:55 --> Language Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Loader Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:43:55 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:43:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:43:55 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Session: Regenerate ID
DEBUG - 2015-02-03 18:43:55 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:43:55 --> Model Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Model Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Controller Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:43:55 --> Email Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:43:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:43:55 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:43:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:43:55 --> Model Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:43:55 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:43:55 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:43:55 --> Model Class Initialized
DEBUG - 2015-02-03 18:43:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:43:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:43:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:43:56 --> Final output sent to browser
DEBUG - 2015-02-03 18:43:56 --> Total execution time: 0.3750
DEBUG - 2015-02-03 18:58:57 --> Config Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Hooks Class Initialized
DEBUG - 2015-02-03 18:58:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 18:58:57 --> Utf8 Class Initialized
DEBUG - 2015-02-03 18:58:57 --> URI Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Router Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Output Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Security Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Input Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 18:58:57 --> Language Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Loader Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Helper loaded: url_helper
DEBUG - 2015-02-03 18:58:57 --> Helper loaded: link_helper
DEBUG - 2015-02-03 18:58:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 18:58:57 --> CI_Session Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Session: Regenerate ID
DEBUG - 2015-02-03 18:58:57 --> CI_Session routines successfully run
DEBUG - 2015-02-03 18:58:57 --> Model Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Model Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Controller Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 18:58:57 --> Email Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 18:58:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 18:58:57 --> Helper loaded: language_helper
DEBUG - 2015-02-03 18:58:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 18:58:57 --> Model Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Database Driver Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Helper loaded: date_helper
DEBUG - 2015-02-03 18:58:57 --> Helper loaded: form_helper
DEBUG - 2015-02-03 18:58:57 --> Form Validation Class Initialized
DEBUG - 2015-02-03 18:58:57 --> Model Class Initialized
DEBUG - 2015-02-03 18:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 18:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 18:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 18:58:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 18:58:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 18:58:58 --> Final output sent to browser
DEBUG - 2015-02-03 18:58:58 --> Total execution time: 0.3720
DEBUG - 2015-02-03 19:14:00 --> Config Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Hooks Class Initialized
DEBUG - 2015-02-03 19:14:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 19:14:00 --> Utf8 Class Initialized
DEBUG - 2015-02-03 19:14:00 --> URI Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Router Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Output Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Security Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Input Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 19:14:00 --> Language Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Loader Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Helper loaded: url_helper
DEBUG - 2015-02-03 19:14:00 --> Helper loaded: link_helper
DEBUG - 2015-02-03 19:14:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 19:14:00 --> CI_Session Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Session: Regenerate ID
DEBUG - 2015-02-03 19:14:00 --> CI_Session routines successfully run
DEBUG - 2015-02-03 19:14:00 --> Model Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Model Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Controller Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 19:14:00 --> Email Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 19:14:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 19:14:00 --> Helper loaded: language_helper
DEBUG - 2015-02-03 19:14:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 19:14:00 --> Model Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Database Driver Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Helper loaded: date_helper
DEBUG - 2015-02-03 19:14:00 --> Helper loaded: form_helper
DEBUG - 2015-02-03 19:14:00 --> Form Validation Class Initialized
DEBUG - 2015-02-03 19:14:00 --> Model Class Initialized
DEBUG - 2015-02-03 19:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 19:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 19:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 19:14:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 19:14:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 19:14:01 --> Final output sent to browser
DEBUG - 2015-02-03 19:14:01 --> Total execution time: 0.3430
DEBUG - 2015-02-03 19:29:02 --> Config Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Hooks Class Initialized
DEBUG - 2015-02-03 19:29:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 19:29:02 --> Utf8 Class Initialized
DEBUG - 2015-02-03 19:29:02 --> URI Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Router Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Output Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Security Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Input Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 19:29:02 --> Language Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Loader Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Helper loaded: url_helper
DEBUG - 2015-02-03 19:29:02 --> Helper loaded: link_helper
DEBUG - 2015-02-03 19:29:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 19:29:02 --> CI_Session Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Session: Regenerate ID
DEBUG - 2015-02-03 19:29:02 --> CI_Session routines successfully run
DEBUG - 2015-02-03 19:29:02 --> Model Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Model Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Controller Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 19:29:02 --> Email Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 19:29:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 19:29:02 --> Helper loaded: language_helper
DEBUG - 2015-02-03 19:29:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 19:29:02 --> Model Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Database Driver Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Helper loaded: date_helper
DEBUG - 2015-02-03 19:29:02 --> Helper loaded: form_helper
DEBUG - 2015-02-03 19:29:02 --> Form Validation Class Initialized
DEBUG - 2015-02-03 19:29:02 --> Model Class Initialized
DEBUG - 2015-02-03 19:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 19:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 19:29:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 19:29:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 19:29:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 19:29:03 --> Final output sent to browser
DEBUG - 2015-02-03 19:29:03 --> Total execution time: 0.3390
DEBUG - 2015-02-03 19:44:04 --> Config Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Hooks Class Initialized
DEBUG - 2015-02-03 19:44:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 19:44:04 --> Utf8 Class Initialized
DEBUG - 2015-02-03 19:44:04 --> URI Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Router Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Output Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Security Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Input Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 19:44:04 --> Language Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Loader Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Helper loaded: url_helper
DEBUG - 2015-02-03 19:44:04 --> Helper loaded: link_helper
DEBUG - 2015-02-03 19:44:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 19:44:04 --> CI_Session Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Session: Regenerate ID
DEBUG - 2015-02-03 19:44:04 --> CI_Session routines successfully run
DEBUG - 2015-02-03 19:44:04 --> Model Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Model Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Controller Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 19:44:04 --> Email Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 19:44:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 19:44:04 --> Helper loaded: language_helper
DEBUG - 2015-02-03 19:44:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 19:44:04 --> Model Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Database Driver Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Helper loaded: date_helper
DEBUG - 2015-02-03 19:44:04 --> Helper loaded: form_helper
DEBUG - 2015-02-03 19:44:04 --> Form Validation Class Initialized
DEBUG - 2015-02-03 19:44:04 --> Model Class Initialized
DEBUG - 2015-02-03 19:44:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 19:44:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 19:44:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 19:44:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 19:44:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 19:44:05 --> Final output sent to browser
DEBUG - 2015-02-03 19:44:05 --> Total execution time: 0.3710
DEBUG - 2015-02-03 19:59:06 --> Config Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Hooks Class Initialized
DEBUG - 2015-02-03 19:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 19:59:06 --> Utf8 Class Initialized
DEBUG - 2015-02-03 19:59:06 --> URI Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Router Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Output Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Security Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Input Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 19:59:06 --> Language Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Loader Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Helper loaded: url_helper
DEBUG - 2015-02-03 19:59:06 --> Helper loaded: link_helper
DEBUG - 2015-02-03 19:59:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 19:59:06 --> CI_Session Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Session: Regenerate ID
DEBUG - 2015-02-03 19:59:06 --> CI_Session routines successfully run
DEBUG - 2015-02-03 19:59:06 --> Model Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Model Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Controller Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 19:59:06 --> Email Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 19:59:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 19:59:06 --> Helper loaded: language_helper
DEBUG - 2015-02-03 19:59:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 19:59:06 --> Model Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Database Driver Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Helper loaded: date_helper
DEBUG - 2015-02-03 19:59:06 --> Helper loaded: form_helper
DEBUG - 2015-02-03 19:59:06 --> Form Validation Class Initialized
DEBUG - 2015-02-03 19:59:06 --> Model Class Initialized
DEBUG - 2015-02-03 19:59:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 19:59:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 19:59:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 19:59:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 19:59:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 19:59:07 --> Final output sent to browser
DEBUG - 2015-02-03 19:59:07 --> Total execution time: 0.3680
DEBUG - 2015-02-03 20:14:08 --> Config Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Hooks Class Initialized
DEBUG - 2015-02-03 20:14:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 20:14:08 --> Utf8 Class Initialized
DEBUG - 2015-02-03 20:14:08 --> URI Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Router Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Output Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Security Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Input Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 20:14:08 --> Language Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Loader Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Helper loaded: url_helper
DEBUG - 2015-02-03 20:14:08 --> Helper loaded: link_helper
DEBUG - 2015-02-03 20:14:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 20:14:08 --> CI_Session Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Session: Regenerate ID
DEBUG - 2015-02-03 20:14:08 --> CI_Session routines successfully run
DEBUG - 2015-02-03 20:14:08 --> Model Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Model Class Initialized
DEBUG - 2015-02-03 20:14:08 --> Controller Class Initialized
DEBUG - 2015-02-03 20:14:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 20:14:09 --> Email Class Initialized
DEBUG - 2015-02-03 20:14:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 20:14:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 20:14:09 --> Helper loaded: language_helper
DEBUG - 2015-02-03 20:14:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 20:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 20:14:09 --> Database Driver Class Initialized
DEBUG - 2015-02-03 20:14:09 --> Helper loaded: date_helper
DEBUG - 2015-02-03 20:14:09 --> Helper loaded: form_helper
DEBUG - 2015-02-03 20:14:09 --> Form Validation Class Initialized
DEBUG - 2015-02-03 20:14:09 --> Model Class Initialized
DEBUG - 2015-02-03 20:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 20:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 20:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 20:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 20:14:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 20:14:09 --> Final output sent to browser
DEBUG - 2015-02-03 20:14:09 --> Total execution time: 0.3690
DEBUG - 2015-02-03 20:29:11 --> Config Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Hooks Class Initialized
DEBUG - 2015-02-03 20:29:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 20:29:11 --> Utf8 Class Initialized
DEBUG - 2015-02-03 20:29:11 --> URI Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Router Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Output Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Security Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Input Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 20:29:11 --> Language Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Loader Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Helper loaded: url_helper
DEBUG - 2015-02-03 20:29:11 --> Helper loaded: link_helper
DEBUG - 2015-02-03 20:29:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 20:29:11 --> CI_Session Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Session: Regenerate ID
DEBUG - 2015-02-03 20:29:11 --> CI_Session routines successfully run
DEBUG - 2015-02-03 20:29:11 --> Model Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Model Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Controller Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 20:29:11 --> Email Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 20:29:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 20:29:11 --> Helper loaded: language_helper
DEBUG - 2015-02-03 20:29:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 20:29:11 --> Model Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Database Driver Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Helper loaded: date_helper
DEBUG - 2015-02-03 20:29:11 --> Helper loaded: form_helper
DEBUG - 2015-02-03 20:29:11 --> Form Validation Class Initialized
DEBUG - 2015-02-03 20:29:11 --> Model Class Initialized
DEBUG - 2015-02-03 20:29:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 20:29:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 20:29:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 20:29:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 20:29:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 20:29:11 --> Final output sent to browser
DEBUG - 2015-02-03 20:29:11 --> Total execution time: 0.3700
DEBUG - 2015-02-03 20:44:13 --> Config Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Hooks Class Initialized
DEBUG - 2015-02-03 20:44:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 20:44:13 --> Utf8 Class Initialized
DEBUG - 2015-02-03 20:44:13 --> URI Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Router Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Output Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Security Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Input Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 20:44:13 --> Language Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Loader Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Helper loaded: url_helper
DEBUG - 2015-02-03 20:44:13 --> Helper loaded: link_helper
DEBUG - 2015-02-03 20:44:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 20:44:13 --> CI_Session Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Session: Regenerate ID
DEBUG - 2015-02-03 20:44:13 --> CI_Session routines successfully run
DEBUG - 2015-02-03 20:44:13 --> Model Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Model Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Controller Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 20:44:13 --> Email Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 20:44:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 20:44:13 --> Helper loaded: language_helper
DEBUG - 2015-02-03 20:44:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 20:44:13 --> Model Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Database Driver Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Helper loaded: date_helper
DEBUG - 2015-02-03 20:44:13 --> Helper loaded: form_helper
DEBUG - 2015-02-03 20:44:13 --> Form Validation Class Initialized
DEBUG - 2015-02-03 20:44:13 --> Model Class Initialized
DEBUG - 2015-02-03 20:44:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 20:44:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 20:44:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 20:44:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 20:44:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 20:44:13 --> Final output sent to browser
DEBUG - 2015-02-03 20:44:13 --> Total execution time: 0.3590
DEBUG - 2015-02-03 20:59:15 --> Config Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Hooks Class Initialized
DEBUG - 2015-02-03 20:59:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 20:59:15 --> Utf8 Class Initialized
DEBUG - 2015-02-03 20:59:15 --> URI Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Router Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Output Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Security Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Input Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 20:59:15 --> Language Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Loader Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Helper loaded: url_helper
DEBUG - 2015-02-03 20:59:15 --> Helper loaded: link_helper
DEBUG - 2015-02-03 20:59:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 20:59:15 --> CI_Session Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Session: Regenerate ID
DEBUG - 2015-02-03 20:59:15 --> CI_Session routines successfully run
DEBUG - 2015-02-03 20:59:15 --> Model Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Model Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Controller Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 20:59:15 --> Email Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 20:59:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 20:59:15 --> Helper loaded: language_helper
DEBUG - 2015-02-03 20:59:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 20:59:15 --> Model Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Database Driver Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Helper loaded: date_helper
DEBUG - 2015-02-03 20:59:15 --> Helper loaded: form_helper
DEBUG - 2015-02-03 20:59:15 --> Form Validation Class Initialized
DEBUG - 2015-02-03 20:59:15 --> Model Class Initialized
DEBUG - 2015-02-03 20:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 20:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 20:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 20:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 20:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 20:59:15 --> Final output sent to browser
DEBUG - 2015-02-03 20:59:15 --> Total execution time: 0.3690
DEBUG - 2015-02-03 21:14:18 --> Config Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Hooks Class Initialized
DEBUG - 2015-02-03 21:14:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 21:14:18 --> Utf8 Class Initialized
DEBUG - 2015-02-03 21:14:18 --> URI Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Router Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Output Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Security Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Input Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 21:14:18 --> Language Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Loader Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Helper loaded: url_helper
DEBUG - 2015-02-03 21:14:18 --> Helper loaded: link_helper
DEBUG - 2015-02-03 21:14:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 21:14:18 --> CI_Session Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Session: Regenerate ID
DEBUG - 2015-02-03 21:14:18 --> CI_Session routines successfully run
DEBUG - 2015-02-03 21:14:18 --> Model Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Model Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Controller Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 21:14:18 --> Email Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 21:14:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 21:14:18 --> Helper loaded: language_helper
DEBUG - 2015-02-03 21:14:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 21:14:18 --> Model Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Database Driver Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Helper loaded: date_helper
DEBUG - 2015-02-03 21:14:18 --> Helper loaded: form_helper
DEBUG - 2015-02-03 21:14:18 --> Form Validation Class Initialized
DEBUG - 2015-02-03 21:14:18 --> Model Class Initialized
DEBUG - 2015-02-03 21:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 21:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 21:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 21:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 21:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 21:14:18 --> Final output sent to browser
DEBUG - 2015-02-03 21:14:18 --> Total execution time: 0.3710
DEBUG - 2015-02-03 21:29:20 --> Config Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Hooks Class Initialized
DEBUG - 2015-02-03 21:29:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 21:29:20 --> Utf8 Class Initialized
DEBUG - 2015-02-03 21:29:20 --> URI Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Router Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Output Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Security Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Input Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 21:29:20 --> Language Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Loader Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Helper loaded: url_helper
DEBUG - 2015-02-03 21:29:20 --> Helper loaded: link_helper
DEBUG - 2015-02-03 21:29:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 21:29:20 --> CI_Session Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Session: Regenerate ID
DEBUG - 2015-02-03 21:29:20 --> CI_Session routines successfully run
DEBUG - 2015-02-03 21:29:20 --> Model Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Model Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Controller Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 21:29:20 --> Email Class Initialized
DEBUG - 2015-02-03 21:29:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 21:29:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 21:29:20 --> Helper loaded: language_helper
DEBUG - 2015-02-03 21:29:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 21:29:21 --> Model Class Initialized
DEBUG - 2015-02-03 21:29:21 --> Database Driver Class Initialized
DEBUG - 2015-02-03 21:29:21 --> Helper loaded: date_helper
DEBUG - 2015-02-03 21:29:21 --> Helper loaded: form_helper
DEBUG - 2015-02-03 21:29:21 --> Form Validation Class Initialized
DEBUG - 2015-02-03 21:29:21 --> Model Class Initialized
DEBUG - 2015-02-03 21:29:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 21:29:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 21:29:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 21:29:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 21:29:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 21:29:21 --> Final output sent to browser
DEBUG - 2015-02-03 21:29:21 --> Total execution time: 0.3800
DEBUG - 2015-02-03 21:44:23 --> Config Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Hooks Class Initialized
DEBUG - 2015-02-03 21:44:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 21:44:23 --> Utf8 Class Initialized
DEBUG - 2015-02-03 21:44:23 --> URI Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Router Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Output Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Security Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Input Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 21:44:23 --> Language Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Loader Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Helper loaded: url_helper
DEBUG - 2015-02-03 21:44:23 --> Helper loaded: link_helper
DEBUG - 2015-02-03 21:44:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 21:44:23 --> CI_Session Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Session: Regenerate ID
DEBUG - 2015-02-03 21:44:23 --> CI_Session routines successfully run
DEBUG - 2015-02-03 21:44:23 --> Model Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Model Class Initialized
DEBUG - 2015-02-03 21:44:23 --> Controller Class Initialized
DEBUG - 2015-02-03 21:44:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 21:44:24 --> Email Class Initialized
DEBUG - 2015-02-03 21:44:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 21:44:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 21:44:24 --> Helper loaded: language_helper
DEBUG - 2015-02-03 21:44:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 21:44:24 --> Model Class Initialized
DEBUG - 2015-02-03 21:44:24 --> Database Driver Class Initialized
DEBUG - 2015-02-03 21:44:24 --> Helper loaded: date_helper
DEBUG - 2015-02-03 21:44:24 --> Helper loaded: form_helper
DEBUG - 2015-02-03 21:44:24 --> Form Validation Class Initialized
DEBUG - 2015-02-03 21:44:24 --> Model Class Initialized
DEBUG - 2015-02-03 21:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 21:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 21:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 21:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 21:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 21:44:24 --> Final output sent to browser
DEBUG - 2015-02-03 21:44:24 --> Total execution time: 0.3670
DEBUG - 2015-02-03 21:59:26 --> Config Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Hooks Class Initialized
DEBUG - 2015-02-03 21:59:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 21:59:26 --> Utf8 Class Initialized
DEBUG - 2015-02-03 21:59:26 --> URI Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Router Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Output Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Security Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Input Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 21:59:26 --> Language Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Loader Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Helper loaded: url_helper
DEBUG - 2015-02-03 21:59:26 --> Helper loaded: link_helper
DEBUG - 2015-02-03 21:59:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 21:59:26 --> CI_Session Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Session: Regenerate ID
DEBUG - 2015-02-03 21:59:26 --> CI_Session routines successfully run
DEBUG - 2015-02-03 21:59:26 --> Model Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Model Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Controller Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 21:59:26 --> Email Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 21:59:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 21:59:26 --> Helper loaded: language_helper
DEBUG - 2015-02-03 21:59:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 21:59:26 --> Model Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Database Driver Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Helper loaded: date_helper
DEBUG - 2015-02-03 21:59:26 --> Helper loaded: form_helper
DEBUG - 2015-02-03 21:59:26 --> Form Validation Class Initialized
DEBUG - 2015-02-03 21:59:26 --> Model Class Initialized
DEBUG - 2015-02-03 21:59:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 21:59:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 21:59:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 21:59:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 21:59:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 21:59:26 --> Final output sent to browser
DEBUG - 2015-02-03 21:59:26 --> Total execution time: 0.3700
DEBUG - 2015-02-03 22:14:28 --> Config Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Hooks Class Initialized
DEBUG - 2015-02-03 22:14:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 22:14:28 --> Utf8 Class Initialized
DEBUG - 2015-02-03 22:14:28 --> URI Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Router Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Output Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Security Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Input Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 22:14:28 --> Language Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Loader Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Helper loaded: url_helper
DEBUG - 2015-02-03 22:14:28 --> Helper loaded: link_helper
DEBUG - 2015-02-03 22:14:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 22:14:28 --> CI_Session Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Session: Regenerate ID
DEBUG - 2015-02-03 22:14:28 --> CI_Session routines successfully run
DEBUG - 2015-02-03 22:14:28 --> Model Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Model Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Controller Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 22:14:28 --> Email Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 22:14:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 22:14:28 --> Helper loaded: language_helper
DEBUG - 2015-02-03 22:14:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 22:14:28 --> Model Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Database Driver Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Helper loaded: date_helper
DEBUG - 2015-02-03 22:14:28 --> Helper loaded: form_helper
DEBUG - 2015-02-03 22:14:28 --> Form Validation Class Initialized
DEBUG - 2015-02-03 22:14:28 --> Model Class Initialized
DEBUG - 2015-02-03 22:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 22:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 22:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 22:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 22:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 22:14:28 --> Final output sent to browser
DEBUG - 2015-02-03 22:14:28 --> Total execution time: 0.3599
DEBUG - 2015-02-03 22:29:29 --> Config Class Initialized
DEBUG - 2015-02-03 22:29:29 --> Hooks Class Initialized
DEBUG - 2015-02-03 22:29:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 22:29:29 --> Utf8 Class Initialized
DEBUG - 2015-02-03 22:29:29 --> URI Class Initialized
DEBUG - 2015-02-03 22:29:29 --> Router Class Initialized
DEBUG - 2015-02-03 22:29:29 --> Output Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Security Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Input Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 22:29:30 --> Language Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Loader Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Helper loaded: url_helper
DEBUG - 2015-02-03 22:29:30 --> Helper loaded: link_helper
DEBUG - 2015-02-03 22:29:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 22:29:30 --> CI_Session Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Session: Regenerate ID
DEBUG - 2015-02-03 22:29:30 --> CI_Session routines successfully run
DEBUG - 2015-02-03 22:29:30 --> Model Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Model Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Controller Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 22:29:30 --> Email Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 22:29:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 22:29:30 --> Helper loaded: language_helper
DEBUG - 2015-02-03 22:29:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 22:29:30 --> Model Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Database Driver Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Helper loaded: date_helper
DEBUG - 2015-02-03 22:29:30 --> Helper loaded: form_helper
DEBUG - 2015-02-03 22:29:30 --> Form Validation Class Initialized
DEBUG - 2015-02-03 22:29:30 --> Model Class Initialized
DEBUG - 2015-02-03 22:29:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 22:29:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 22:29:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 22:29:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 22:29:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 22:29:30 --> Final output sent to browser
DEBUG - 2015-02-03 22:29:30 --> Total execution time: 0.3410
DEBUG - 2015-02-03 22:44:31 --> Config Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Hooks Class Initialized
DEBUG - 2015-02-03 22:44:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 22:44:31 --> Utf8 Class Initialized
DEBUG - 2015-02-03 22:44:31 --> URI Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Router Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Output Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Security Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Input Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 22:44:31 --> Language Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Loader Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Helper loaded: url_helper
DEBUG - 2015-02-03 22:44:31 --> Helper loaded: link_helper
DEBUG - 2015-02-03 22:44:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 22:44:31 --> CI_Session Class Initialized
DEBUG - 2015-02-03 22:44:31 --> Session: Regenerate ID
DEBUG - 2015-02-03 22:44:31 --> CI_Session routines successfully run
DEBUG - 2015-02-03 22:44:32 --> Model Class Initialized
DEBUG - 2015-02-03 22:44:32 --> Model Class Initialized
DEBUG - 2015-02-03 22:44:32 --> Controller Class Initialized
DEBUG - 2015-02-03 22:44:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 22:44:32 --> Email Class Initialized
DEBUG - 2015-02-03 22:44:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 22:44:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 22:44:32 --> Helper loaded: language_helper
DEBUG - 2015-02-03 22:44:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 22:44:32 --> Model Class Initialized
DEBUG - 2015-02-03 22:44:32 --> Database Driver Class Initialized
DEBUG - 2015-02-03 22:44:32 --> Helper loaded: date_helper
DEBUG - 2015-02-03 22:44:32 --> Helper loaded: form_helper
DEBUG - 2015-02-03 22:44:32 --> Form Validation Class Initialized
DEBUG - 2015-02-03 22:44:32 --> Model Class Initialized
DEBUG - 2015-02-03 22:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 22:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 22:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 22:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 22:44:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 22:44:32 --> Final output sent to browser
DEBUG - 2015-02-03 22:44:32 --> Total execution time: 0.3580
DEBUG - 2015-02-03 22:59:33 --> Config Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Hooks Class Initialized
DEBUG - 2015-02-03 22:59:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 22:59:33 --> Utf8 Class Initialized
DEBUG - 2015-02-03 22:59:33 --> URI Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Router Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Output Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Security Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Input Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 22:59:33 --> Language Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Loader Class Initialized
DEBUG - 2015-02-03 22:59:33 --> Helper loaded: url_helper
DEBUG - 2015-02-03 22:59:33 --> Helper loaded: link_helper
DEBUG - 2015-02-03 22:59:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 22:59:33 --> CI_Session Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Session: Regenerate ID
DEBUG - 2015-02-03 22:59:34 --> CI_Session routines successfully run
DEBUG - 2015-02-03 22:59:34 --> Model Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Model Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Controller Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 22:59:34 --> Email Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 22:59:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 22:59:34 --> Helper loaded: language_helper
DEBUG - 2015-02-03 22:59:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 22:59:34 --> Model Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Database Driver Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Helper loaded: date_helper
DEBUG - 2015-02-03 22:59:34 --> Helper loaded: form_helper
DEBUG - 2015-02-03 22:59:34 --> Form Validation Class Initialized
DEBUG - 2015-02-03 22:59:34 --> Model Class Initialized
DEBUG - 2015-02-03 22:59:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 22:59:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 22:59:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 22:59:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 22:59:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 22:59:34 --> Final output sent to browser
DEBUG - 2015-02-03 22:59:34 --> Total execution time: 0.3590
DEBUG - 2015-02-03 23:14:36 --> Config Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Hooks Class Initialized
DEBUG - 2015-02-03 23:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 23:14:36 --> Utf8 Class Initialized
DEBUG - 2015-02-03 23:14:36 --> URI Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Router Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Output Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Security Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Input Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 23:14:36 --> Language Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Loader Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Helper loaded: url_helper
DEBUG - 2015-02-03 23:14:36 --> Helper loaded: link_helper
DEBUG - 2015-02-03 23:14:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 23:14:36 --> CI_Session Class Initialized
DEBUG - 2015-02-03 23:14:36 --> Session: Regenerate ID
DEBUG - 2015-02-03 23:14:36 --> CI_Session routines successfully run
DEBUG - 2015-02-03 23:14:37 --> Model Class Initialized
DEBUG - 2015-02-03 23:14:37 --> Model Class Initialized
DEBUG - 2015-02-03 23:14:37 --> Controller Class Initialized
DEBUG - 2015-02-03 23:14:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 23:14:37 --> Email Class Initialized
DEBUG - 2015-02-03 23:14:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 23:14:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 23:14:37 --> Helper loaded: language_helper
DEBUG - 2015-02-03 23:14:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 23:14:37 --> Model Class Initialized
DEBUG - 2015-02-03 23:14:37 --> Database Driver Class Initialized
DEBUG - 2015-02-03 23:14:37 --> Helper loaded: date_helper
DEBUG - 2015-02-03 23:14:37 --> Helper loaded: form_helper
DEBUG - 2015-02-03 23:14:37 --> Form Validation Class Initialized
DEBUG - 2015-02-03 23:14:37 --> Model Class Initialized
DEBUG - 2015-02-03 23:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 23:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 23:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 23:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 23:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 23:14:37 --> Final output sent to browser
DEBUG - 2015-02-03 23:14:37 --> Total execution time: 0.3650
DEBUG - 2015-02-03 23:29:38 --> Config Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Hooks Class Initialized
DEBUG - 2015-02-03 23:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 23:29:38 --> Utf8 Class Initialized
DEBUG - 2015-02-03 23:29:38 --> URI Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Router Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Output Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Security Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Input Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 23:29:38 --> Language Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Loader Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Helper loaded: url_helper
DEBUG - 2015-02-03 23:29:38 --> Helper loaded: link_helper
DEBUG - 2015-02-03 23:29:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 23:29:38 --> CI_Session Class Initialized
DEBUG - 2015-02-03 23:29:38 --> Session: Regenerate ID
DEBUG - 2015-02-03 23:29:38 --> CI_Session routines successfully run
DEBUG - 2015-02-03 23:29:39 --> Model Class Initialized
DEBUG - 2015-02-03 23:29:39 --> Model Class Initialized
DEBUG - 2015-02-03 23:29:39 --> Controller Class Initialized
DEBUG - 2015-02-03 23:29:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 23:29:39 --> Email Class Initialized
DEBUG - 2015-02-03 23:29:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 23:29:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 23:29:39 --> Helper loaded: language_helper
DEBUG - 2015-02-03 23:29:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 23:29:39 --> Model Class Initialized
DEBUG - 2015-02-03 23:29:39 --> Database Driver Class Initialized
DEBUG - 2015-02-03 23:29:39 --> Helper loaded: date_helper
DEBUG - 2015-02-03 23:29:39 --> Helper loaded: form_helper
DEBUG - 2015-02-03 23:29:39 --> Form Validation Class Initialized
DEBUG - 2015-02-03 23:29:39 --> Model Class Initialized
DEBUG - 2015-02-03 23:29:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 23:29:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 23:29:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 23:29:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 23:29:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 23:29:39 --> Final output sent to browser
DEBUG - 2015-02-03 23:29:39 --> Total execution time: 0.3690
DEBUG - 2015-02-03 23:44:41 --> Config Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Hooks Class Initialized
DEBUG - 2015-02-03 23:44:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 23:44:41 --> Utf8 Class Initialized
DEBUG - 2015-02-03 23:44:41 --> URI Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Router Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Output Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Security Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Input Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 23:44:41 --> Language Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Loader Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Helper loaded: url_helper
DEBUG - 2015-02-03 23:44:41 --> Helper loaded: link_helper
DEBUG - 2015-02-03 23:44:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 23:44:41 --> CI_Session Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Session: Regenerate ID
DEBUG - 2015-02-03 23:44:41 --> CI_Session routines successfully run
DEBUG - 2015-02-03 23:44:41 --> Model Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Model Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Controller Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 23:44:41 --> Email Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 23:44:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 23:44:41 --> Helper loaded: language_helper
DEBUG - 2015-02-03 23:44:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 23:44:41 --> Model Class Initialized
DEBUG - 2015-02-03 23:44:41 --> Database Driver Class Initialized
DEBUG - 2015-02-03 23:44:42 --> Helper loaded: date_helper
DEBUG - 2015-02-03 23:44:42 --> Helper loaded: form_helper
DEBUG - 2015-02-03 23:44:42 --> Form Validation Class Initialized
DEBUG - 2015-02-03 23:44:42 --> Model Class Initialized
DEBUG - 2015-02-03 23:44:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 23:44:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 23:44:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 23:44:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 23:44:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 23:44:42 --> Final output sent to browser
DEBUG - 2015-02-03 23:44:42 --> Total execution time: 0.3370
DEBUG - 2015-02-03 23:59:43 --> Config Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Hooks Class Initialized
DEBUG - 2015-02-03 23:59:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-03 23:59:43 --> Utf8 Class Initialized
DEBUG - 2015-02-03 23:59:43 --> URI Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Router Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Output Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Security Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Input Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-03 23:59:43 --> Language Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Loader Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Helper loaded: url_helper
DEBUG - 2015-02-03 23:59:43 --> Helper loaded: link_helper
DEBUG - 2015-02-03 23:59:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-03 23:59:43 --> CI_Session Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Session: Regenerate ID
DEBUG - 2015-02-03 23:59:43 --> CI_Session routines successfully run
DEBUG - 2015-02-03 23:59:43 --> Model Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Model Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Controller Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-03 23:59:43 --> Email Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-03 23:59:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-03 23:59:43 --> Helper loaded: language_helper
DEBUG - 2015-02-03 23:59:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-03 23:59:43 --> Model Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Database Driver Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Helper loaded: date_helper
DEBUG - 2015-02-03 23:59:43 --> Helper loaded: form_helper
DEBUG - 2015-02-03 23:59:43 --> Form Validation Class Initialized
DEBUG - 2015-02-03 23:59:43 --> Model Class Initialized
DEBUG - 2015-02-03 23:59:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-03 23:59:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-03 23:59:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-03 23:59:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-03 23:59:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-03 23:59:44 --> Final output sent to browser
DEBUG - 2015-02-03 23:59:44 --> Total execution time: 0.3440
