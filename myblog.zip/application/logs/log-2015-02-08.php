<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-08 04:01:03 --> Config Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Hooks Class Initialized
DEBUG - 2015-02-08 04:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 04:01:04 --> Utf8 Class Initialized
DEBUG - 2015-02-08 04:01:04 --> URI Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Router Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Output Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Security Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Input Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 04:01:04 --> Language Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Loader Class Initialized
DEBUG - 2015-02-08 04:01:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 04:01:04 --> Helper loaded: url_helper
DEBUG - 2015-02-08 04:01:04 --> Helper loaded: link_helper
DEBUG - 2015-02-08 04:01:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 04:01:05 --> CI_Session Class Initialized
DEBUG - 2015-02-08 04:01:05 --> A session cookie was not found.
DEBUG - 2015-02-08 04:01:05 --> Session: Creating new session (41b13099c1e7be2e1c0b06ad58639bd1)
DEBUG - 2015-02-08 04:01:05 --> CI_Session routines successfully run
DEBUG - 2015-02-08 04:01:08 --> Model Class Initialized
DEBUG - 2015-02-08 04:01:08 --> Model Class Initialized
DEBUG - 2015-02-08 04:01:08 --> Controller Class Initialized
DEBUG - 2015-02-08 04:01:08 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 04:01:08 --> Email Class Initialized
DEBUG - 2015-02-08 04:01:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 04:01:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 04:01:08 --> Helper loaded: language_helper
DEBUG - 2015-02-08 04:01:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 04:01:08 --> Model Class Initialized
DEBUG - 2015-02-08 04:01:09 --> Database Driver Class Initialized
DEBUG - 2015-02-08 04:01:12 --> Helper loaded: date_helper
DEBUG - 2015-02-08 04:01:13 --> Helper loaded: form_helper
DEBUG - 2015-02-08 04:01:13 --> Form Validation Class Initialized
DEBUG - 2015-02-08 04:01:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 04:01:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 04:01:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 04:01:13 --> Model Class Initialized
DEBUG - 2015-02-08 04:01:18 --> Model Class Initialized
DEBUG - 2015-02-08 04:01:19 --> Model Class Initialized
DEBUG - 2015-02-08 04:01:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 04:01:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 04:01:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-08 04:01:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 04:01:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 04:01:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 04:01:21 --> Final output sent to browser
DEBUG - 2015-02-08 04:01:21 --> Total execution time: 17.7980
DEBUG - 2015-02-08 04:16:29 --> Config Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Hooks Class Initialized
DEBUG - 2015-02-08 04:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 04:16:29 --> Utf8 Class Initialized
DEBUG - 2015-02-08 04:16:29 --> URI Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Router Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Output Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Security Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Input Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 04:16:29 --> Language Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Loader Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 04:16:29 --> Helper loaded: url_helper
DEBUG - 2015-02-08 04:16:29 --> Helper loaded: link_helper
DEBUG - 2015-02-08 04:16:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 04:16:29 --> CI_Session Class Initialized
DEBUG - 2015-02-08 04:16:29 --> Session: Regenerate ID
DEBUG - 2015-02-08 04:16:29 --> CI_Session routines successfully run
DEBUG - 2015-02-08 04:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Controller Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 04:16:30 --> Email Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 04:16:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 04:16:30 --> Helper loaded: language_helper
DEBUG - 2015-02-08 04:16:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 04:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Database Driver Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Helper loaded: date_helper
DEBUG - 2015-02-08 04:16:30 --> Helper loaded: form_helper
DEBUG - 2015-02-08 04:16:30 --> Form Validation Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 04:16:30 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 04:16:30 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 04:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 04:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 04:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 04:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 04:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-08 04:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 04:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 04:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 04:16:30 --> Final output sent to browser
DEBUG - 2015-02-08 04:16:30 --> Total execution time: 1.1341
DEBUG - 2015-02-08 04:31:33 --> Config Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Hooks Class Initialized
DEBUG - 2015-02-08 04:31:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 04:31:33 --> Utf8 Class Initialized
DEBUG - 2015-02-08 04:31:33 --> URI Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Router Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Output Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Security Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Input Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 04:31:33 --> Language Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Loader Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 04:31:33 --> Helper loaded: url_helper
DEBUG - 2015-02-08 04:31:33 --> Helper loaded: link_helper
DEBUG - 2015-02-08 04:31:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 04:31:33 --> CI_Session Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Session: Regenerate ID
DEBUG - 2015-02-08 04:31:33 --> CI_Session routines successfully run
DEBUG - 2015-02-08 04:31:33 --> Model Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Model Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Controller Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 04:31:33 --> Email Class Initialized
DEBUG - 2015-02-08 04:31:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 04:31:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 04:31:33 --> Helper loaded: language_helper
DEBUG - 2015-02-08 04:31:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 04:31:33 --> Model Class Initialized
DEBUG - 2015-02-08 04:31:34 --> Database Driver Class Initialized
DEBUG - 2015-02-08 04:31:34 --> Helper loaded: date_helper
DEBUG - 2015-02-08 04:31:34 --> Helper loaded: form_helper
DEBUG - 2015-02-08 04:31:34 --> Form Validation Class Initialized
DEBUG - 2015-02-08 04:31:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 04:31:34 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 04:31:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 04:31:34 --> Model Class Initialized
DEBUG - 2015-02-08 04:31:34 --> Model Class Initialized
DEBUG - 2015-02-08 04:31:34 --> Model Class Initialized
DEBUG - 2015-02-08 04:31:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 04:31:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 04:31:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-08 04:31:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 04:31:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 04:31:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 04:31:34 --> Final output sent to browser
DEBUG - 2015-02-08 04:31:34 --> Total execution time: 1.1501
DEBUG - 2015-02-08 04:46:36 --> Config Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Hooks Class Initialized
DEBUG - 2015-02-08 04:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 04:46:36 --> Utf8 Class Initialized
DEBUG - 2015-02-08 04:46:36 --> URI Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Router Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Output Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Security Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Input Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 04:46:36 --> Language Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Loader Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: url_helper
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: link_helper
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 04:46:36 --> CI_Session Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Session: Regenerate ID
DEBUG - 2015-02-08 04:46:36 --> CI_Session routines successfully run
DEBUG - 2015-02-08 04:46:36 --> Model Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Model Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Controller Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 04:46:36 --> Email Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: language_helper
DEBUG - 2015-02-08 04:46:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 04:46:36 --> Model Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Database Driver Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: date_helper
DEBUG - 2015-02-08 04:46:36 --> Helper loaded: form_helper
DEBUG - 2015-02-08 04:46:36 --> Form Validation Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 04:46:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 04:46:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 04:46:36 --> Model Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Model Class Initialized
DEBUG - 2015-02-08 04:46:36 --> Model Class Initialized
DEBUG - 2015-02-08 04:46:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 04:46:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 04:46:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-08 04:46:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 04:46:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 04:46:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 04:46:37 --> Final output sent to browser
DEBUG - 2015-02-08 04:46:37 --> Total execution time: 1.1741
DEBUG - 2015-02-08 04:55:43 --> Config Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Hooks Class Initialized
DEBUG - 2015-02-08 04:55:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 04:55:43 --> Utf8 Class Initialized
DEBUG - 2015-02-08 04:55:43 --> URI Class Initialized
DEBUG - 2015-02-08 04:55:43 --> No URI present. Default controller set.
DEBUG - 2015-02-08 04:55:43 --> Router Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Output Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Security Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Input Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 04:55:43 --> Language Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Loader Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: url_helper
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: link_helper
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 04:55:43 --> CI_Session Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Session: Regenerate ID
DEBUG - 2015-02-08 04:55:43 --> CI_Session routines successfully run
DEBUG - 2015-02-08 04:55:43 --> Model Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Model Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Controller Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 04:55:43 --> Email Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 04:55:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 04:55:43 --> Model Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 04:55:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 04:55:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 04:55:43 --> Email has already been instantiated as 'email'. Second attempt aborted.
DEBUG - 2015-02-08 04:55:49 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 04:55:49 --> Model Class Initialized
DEBUG - 2015-02-08 04:55:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 04:55:49 --> Pagination Class Initialized
DEBUG - 2015-02-08 04:55:50 --> Model Class Initialized
DEBUG - 2015-02-08 04:55:50 --> Model Class Initialized
DEBUG - 2015-02-08 04:55:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 04:55:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 04:55:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 04:55:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 04:55:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 04:55:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 04:55:52 --> Final output sent to browser
DEBUG - 2015-02-08 04:55:52 --> Total execution time: 9.2185
DEBUG - 2015-02-08 05:05:21 --> Config Class Initialized
DEBUG - 2015-02-08 05:05:21 --> Hooks Class Initialized
DEBUG - 2015-02-08 05:05:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 05:05:21 --> Utf8 Class Initialized
DEBUG - 2015-02-08 05:05:21 --> URI Class Initialized
DEBUG - 2015-02-08 05:05:21 --> No URI present. Default controller set.
DEBUG - 2015-02-08 05:05:21 --> Router Class Initialized
DEBUG - 2015-02-08 05:05:21 --> Output Class Initialized
DEBUG - 2015-02-08 05:05:21 --> Security Class Initialized
DEBUG - 2015-02-08 05:05:21 --> Input Class Initialized
DEBUG - 2015-02-08 05:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 05:05:21 --> Language Class Initialized
DEBUG - 2015-02-08 05:05:21 --> Loader Class Initialized
DEBUG - 2015-02-08 05:05:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 05:05:22 --> Helper loaded: url_helper
DEBUG - 2015-02-08 05:05:22 --> Helper loaded: link_helper
DEBUG - 2015-02-08 05:05:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 05:05:22 --> CI_Session Class Initialized
DEBUG - 2015-02-08 05:05:22 --> Session: Regenerate ID
DEBUG - 2015-02-08 05:05:22 --> CI_Session routines successfully run
DEBUG - 2015-02-08 05:05:23 --> Model Class Initialized
DEBUG - 2015-02-08 05:05:23 --> Model Class Initialized
DEBUG - 2015-02-08 05:05:23 --> Controller Class Initialized
DEBUG - 2015-02-08 05:05:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 05:05:23 --> Email Class Initialized
DEBUG - 2015-02-08 05:05:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 05:05:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 05:05:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 05:05:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 05:05:23 --> Model Class Initialized
DEBUG - 2015-02-08 05:05:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 05:05:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 05:05:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 05:05:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 05:05:23 --> Email has already been instantiated as 'email'. Second attempt aborted.
DEBUG - 2015-02-08 05:05:28 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 05:05:28 --> Model Class Initialized
DEBUG - 2015-02-08 05:05:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 05:05:28 --> Pagination Class Initialized
DEBUG - 2015-02-08 05:05:29 --> Model Class Initialized
DEBUG - 2015-02-08 05:05:29 --> Model Class Initialized
DEBUG - 2015-02-08 05:05:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 05:05:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 05:05:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 05:05:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 05:05:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 05:05:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 05:05:29 --> Final output sent to browser
DEBUG - 2015-02-08 05:05:29 --> Total execution time: 8.5755
DEBUG - 2015-02-08 05:07:40 --> Config Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Hooks Class Initialized
DEBUG - 2015-02-08 05:07:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 05:07:40 --> Utf8 Class Initialized
DEBUG - 2015-02-08 05:07:40 --> URI Class Initialized
DEBUG - 2015-02-08 05:07:40 --> No URI present. Default controller set.
DEBUG - 2015-02-08 05:07:40 --> Router Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Output Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Security Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Input Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 05:07:40 --> Language Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Loader Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: url_helper
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: link_helper
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 05:07:40 --> CI_Session Class Initialized
DEBUG - 2015-02-08 05:07:40 --> CI_Session routines successfully run
DEBUG - 2015-02-08 05:07:40 --> Model Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Model Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Controller Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 05:07:40 --> Email Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: language_helper
DEBUG - 2015-02-08 05:07:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 05:07:40 --> Model Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Database Driver Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: date_helper
DEBUG - 2015-02-08 05:07:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 05:07:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 05:07:40 --> Email has already been instantiated as 'email'. Second attempt aborted.
DEBUG - 2015-02-08 05:07:42 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 05:07:42 --> Model Class Initialized
DEBUG - 2015-02-08 05:07:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 05:07:42 --> Pagination Class Initialized
DEBUG - 2015-02-08 05:07:42 --> Model Class Initialized
DEBUG - 2015-02-08 05:07:42 --> Model Class Initialized
DEBUG - 2015-02-08 05:07:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 05:07:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 05:07:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 05:07:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 05:07:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 05:07:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 05:07:42 --> Final output sent to browser
DEBUG - 2015-02-08 05:07:42 --> Total execution time: 2.5801
DEBUG - 2015-02-08 05:10:59 --> Config Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Hooks Class Initialized
DEBUG - 2015-02-08 05:11:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 05:11:00 --> Utf8 Class Initialized
DEBUG - 2015-02-08 05:11:00 --> URI Class Initialized
DEBUG - 2015-02-08 05:11:00 --> No URI present. Default controller set.
DEBUG - 2015-02-08 05:11:00 --> Router Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Output Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Security Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Input Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 05:11:00 --> Language Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Loader Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 05:11:00 --> Helper loaded: url_helper
DEBUG - 2015-02-08 05:11:00 --> Helper loaded: link_helper
DEBUG - 2015-02-08 05:11:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 05:11:00 --> CI_Session Class Initialized
DEBUG - 2015-02-08 05:11:00 --> Session: Regenerate ID
DEBUG - 2015-02-08 05:11:00 --> CI_Session routines successfully run
DEBUG - 2015-02-08 05:11:01 --> Model Class Initialized
DEBUG - 2015-02-08 05:11:01 --> Model Class Initialized
DEBUG - 2015-02-08 05:11:01 --> Controller Class Initialized
DEBUG - 2015-02-08 05:11:01 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 05:11:01 --> Email Class Initialized
DEBUG - 2015-02-08 05:11:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 05:11:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 05:11:01 --> Helper loaded: language_helper
DEBUG - 2015-02-08 05:11:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 05:11:01 --> Model Class Initialized
DEBUG - 2015-02-08 05:11:01 --> Database Driver Class Initialized
DEBUG - 2015-02-08 05:11:01 --> Helper loaded: date_helper
DEBUG - 2015-02-08 05:11:01 --> Helper loaded: form_helper
DEBUG - 2015-02-08 05:11:01 --> Form Validation Class Initialized
DEBUG - 2015-02-08 05:11:01 --> Email has already been instantiated as 'email'. Second attempt aborted.
DEBUG - 2015-02-08 05:11:04 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 05:11:04 --> Model Class Initialized
DEBUG - 2015-02-08 05:11:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 05:11:04 --> Pagination Class Initialized
DEBUG - 2015-02-08 05:11:04 --> Model Class Initialized
DEBUG - 2015-02-08 05:11:05 --> Model Class Initialized
DEBUG - 2015-02-08 05:11:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 05:11:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 05:11:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 05:11:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 05:11:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 05:11:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 05:11:05 --> Final output sent to browser
DEBUG - 2015-02-08 05:11:05 --> Total execution time: 5.5523
DEBUG - 2015-02-08 05:13:32 --> Config Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Hooks Class Initialized
DEBUG - 2015-02-08 05:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 05:13:32 --> Utf8 Class Initialized
DEBUG - 2015-02-08 05:13:32 --> URI Class Initialized
DEBUG - 2015-02-08 05:13:32 --> No URI present. Default controller set.
DEBUG - 2015-02-08 05:13:32 --> Router Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Output Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Security Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Input Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 05:13:32 --> Language Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Loader Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: url_helper
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: link_helper
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 05:13:32 --> CI_Session Class Initialized
DEBUG - 2015-02-08 05:13:32 --> CI_Session routines successfully run
DEBUG - 2015-02-08 05:13:32 --> Model Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Model Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Controller Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 05:13:32 --> Email Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: language_helper
DEBUG - 2015-02-08 05:13:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 05:13:32 --> Model Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Database Driver Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: date_helper
DEBUG - 2015-02-08 05:13:32 --> Helper loaded: form_helper
DEBUG - 2015-02-08 05:13:32 --> Form Validation Class Initialized
DEBUG - 2015-02-08 05:13:32 --> Email has already been instantiated as 'email'. Second attempt aborted.
ERROR - 2015-02-08 05:13:38 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:13:38 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:13:38 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
DEBUG - 2015-02-08 05:13:38 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 05:14:42 --> Config Class Initialized
DEBUG - 2015-02-08 05:14:42 --> Hooks Class Initialized
DEBUG - 2015-02-08 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 05:14:42 --> Utf8 Class Initialized
DEBUG - 2015-02-08 05:14:42 --> URI Class Initialized
DEBUG - 2015-02-08 05:14:42 --> No URI present. Default controller set.
DEBUG - 2015-02-08 05:14:42 --> Router Class Initialized
DEBUG - 2015-02-08 05:14:42 --> Output Class Initialized
DEBUG - 2015-02-08 05:14:42 --> Security Class Initialized
DEBUG - 2015-02-08 05:14:42 --> Input Class Initialized
DEBUG - 2015-02-08 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 05:14:42 --> Language Class Initialized
DEBUG - 2015-02-08 05:14:42 --> Loader Class Initialized
DEBUG - 2015-02-08 05:14:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 05:14:42 --> Helper loaded: url_helper
DEBUG - 2015-02-08 05:14:42 --> Helper loaded: link_helper
DEBUG - 2015-02-08 05:14:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 05:14:42 --> CI_Session Class Initialized
DEBUG - 2015-02-08 05:14:42 --> CI_Session routines successfully run
DEBUG - 2015-02-08 05:14:43 --> Model Class Initialized
DEBUG - 2015-02-08 05:14:43 --> Model Class Initialized
DEBUG - 2015-02-08 05:14:43 --> Controller Class Initialized
DEBUG - 2015-02-08 05:14:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 05:14:43 --> Email Class Initialized
DEBUG - 2015-02-08 05:14:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 05:14:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 05:14:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 05:14:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 05:14:43 --> Model Class Initialized
DEBUG - 2015-02-08 05:14:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 05:14:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 05:14:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 05:14:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 05:14:43 --> Email has already been instantiated as 'email'. Second attempt aborted.
ERROR - 2015-02-08 05:14:44 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:14:44 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:14:44 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
DEBUG - 2015-02-08 05:14:44 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 05:15:01 --> Config Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Hooks Class Initialized
DEBUG - 2015-02-08 05:15:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 05:15:01 --> Utf8 Class Initialized
DEBUG - 2015-02-08 05:15:01 --> URI Class Initialized
DEBUG - 2015-02-08 05:15:01 --> No URI present. Default controller set.
DEBUG - 2015-02-08 05:15:01 --> Router Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Output Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Security Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Input Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 05:15:01 --> Language Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Loader Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: url_helper
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: link_helper
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 05:15:01 --> CI_Session Class Initialized
DEBUG - 2015-02-08 05:15:01 --> CI_Session routines successfully run
DEBUG - 2015-02-08 05:15:01 --> Model Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Model Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Controller Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 05:15:01 --> Email Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: language_helper
DEBUG - 2015-02-08 05:15:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 05:15:01 --> Model Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Database Driver Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: date_helper
DEBUG - 2015-02-08 05:15:01 --> Helper loaded: form_helper
DEBUG - 2015-02-08 05:15:01 --> Form Validation Class Initialized
DEBUG - 2015-02-08 05:15:01 --> Email has already been instantiated as 'email'. Second attempt aborted.
ERROR - 2015-02-08 05:15:02 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:15:02 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:15:02 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
DEBUG - 2015-02-08 05:15:02 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 05:16:06 --> Config Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Hooks Class Initialized
DEBUG - 2015-02-08 05:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 05:16:06 --> Utf8 Class Initialized
DEBUG - 2015-02-08 05:16:06 --> URI Class Initialized
DEBUG - 2015-02-08 05:16:06 --> No URI present. Default controller set.
DEBUG - 2015-02-08 05:16:06 --> Router Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Output Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Security Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Input Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 05:16:06 --> Language Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Loader Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 05:16:06 --> Helper loaded: url_helper
DEBUG - 2015-02-08 05:16:06 --> Helper loaded: link_helper
DEBUG - 2015-02-08 05:16:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 05:16:06 --> CI_Session Class Initialized
DEBUG - 2015-02-08 05:16:06 --> Session: Regenerate ID
DEBUG - 2015-02-08 05:16:06 --> CI_Session routines successfully run
DEBUG - 2015-02-08 05:16:07 --> Model Class Initialized
DEBUG - 2015-02-08 05:16:07 --> Model Class Initialized
DEBUG - 2015-02-08 05:16:07 --> Controller Class Initialized
DEBUG - 2015-02-08 05:16:07 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 05:16:07 --> Email Class Initialized
DEBUG - 2015-02-08 05:16:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 05:16:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 05:16:07 --> Helper loaded: language_helper
DEBUG - 2015-02-08 05:16:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 05:16:07 --> Model Class Initialized
DEBUG - 2015-02-08 05:16:07 --> Database Driver Class Initialized
DEBUG - 2015-02-08 05:16:07 --> Helper loaded: date_helper
DEBUG - 2015-02-08 05:16:07 --> Helper loaded: form_helper
DEBUG - 2015-02-08 05:16:07 --> Form Validation Class Initialized
DEBUG - 2015-02-08 05:16:07 --> Email has already been instantiated as 'email'. Second attempt aborted.
ERROR - 2015-02-08 05:16:08 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:16:08 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
ERROR - 2015-02-08 05:16:08 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\xampp\htdocs\myblog\system\libraries\Email.php 1949
DEBUG - 2015-02-08 05:16:08 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-02-08 06:52:16 --> Config Class Initialized
DEBUG - 2015-02-08 06:52:17 --> Hooks Class Initialized
DEBUG - 2015-02-08 06:52:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 06:52:17 --> Utf8 Class Initialized
DEBUG - 2015-02-08 06:52:17 --> URI Class Initialized
DEBUG - 2015-02-08 06:52:18 --> No URI present. Default controller set.
DEBUG - 2015-02-08 06:52:18 --> Router Class Initialized
DEBUG - 2015-02-08 06:52:18 --> Output Class Initialized
DEBUG - 2015-02-08 06:52:18 --> Security Class Initialized
DEBUG - 2015-02-08 06:52:18 --> Input Class Initialized
DEBUG - 2015-02-08 06:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 06:52:18 --> Language Class Initialized
DEBUG - 2015-02-08 06:52:19 --> Loader Class Initialized
DEBUG - 2015-02-08 06:52:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 06:52:19 --> Helper loaded: url_helper
DEBUG - 2015-02-08 06:52:19 --> Helper loaded: link_helper
DEBUG - 2015-02-08 06:52:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 06:52:19 --> CI_Session Class Initialized
DEBUG - 2015-02-08 06:52:19 --> Session: Regenerate ID
DEBUG - 2015-02-08 06:52:19 --> CI_Session routines successfully run
DEBUG - 2015-02-08 06:52:21 --> Model Class Initialized
DEBUG - 2015-02-08 06:52:21 --> Model Class Initialized
DEBUG - 2015-02-08 06:52:21 --> Controller Class Initialized
DEBUG - 2015-02-08 06:52:21 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 06:52:21 --> Email Class Initialized
DEBUG - 2015-02-08 06:52:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 06:52:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 06:52:21 --> Helper loaded: language_helper
DEBUG - 2015-02-08 06:52:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 06:52:22 --> Model Class Initialized
DEBUG - 2015-02-08 06:52:22 --> Database Driver Class Initialized
DEBUG - 2015-02-08 06:52:24 --> Helper loaded: date_helper
DEBUG - 2015-02-08 06:52:24 --> Helper loaded: form_helper
DEBUG - 2015-02-08 06:52:24 --> Form Validation Class Initialized
DEBUG - 2015-02-08 06:52:24 --> Model Class Initialized
DEBUG - 2015-02-08 06:52:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 06:52:24 --> Pagination Class Initialized
ERROR - 2015-02-08 06:52:25 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 06:55:40 --> Config Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Hooks Class Initialized
DEBUG - 2015-02-08 06:55:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 06:55:40 --> Utf8 Class Initialized
DEBUG - 2015-02-08 06:55:40 --> URI Class Initialized
DEBUG - 2015-02-08 06:55:40 --> No URI present. Default controller set.
DEBUG - 2015-02-08 06:55:40 --> Router Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Output Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Security Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Input Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 06:55:40 --> Language Class Initialized
ERROR - 2015-02-08 06:55:40 --> Severity: Warning --> The use statement with non-compound name 'PHPMailer' has no effect C:\xampp\htdocs\myblog\application\controllers\Welcome.php 41
DEBUG - 2015-02-08 06:55:40 --> Loader Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: url_helper
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: link_helper
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 06:55:40 --> CI_Session Class Initialized
DEBUG - 2015-02-08 06:55:40 --> CI_Session routines successfully run
DEBUG - 2015-02-08 06:55:40 --> Model Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Model Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Controller Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 06:55:40 --> Email Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: language_helper
DEBUG - 2015-02-08 06:55:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 06:55:40 --> Model Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Database Driver Class Initialized
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: date_helper
DEBUG - 2015-02-08 06:55:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 06:55:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 06:55:41 --> Model Class Initialized
DEBUG - 2015-02-08 06:55:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 06:55:41 --> Pagination Class Initialized
ERROR - 2015-02-08 06:55:41 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 06:56:04 --> Config Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Hooks Class Initialized
DEBUG - 2015-02-08 06:56:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 06:56:04 --> Utf8 Class Initialized
DEBUG - 2015-02-08 06:56:04 --> URI Class Initialized
DEBUG - 2015-02-08 06:56:04 --> No URI present. Default controller set.
DEBUG - 2015-02-08 06:56:04 --> Router Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Output Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Security Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Input Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 06:56:04 --> Language Class Initialized
ERROR - 2015-02-08 06:56:04 --> Severity: Warning --> The use statement with non-compound name 'PHPMailer' has no effect C:\xampp\htdocs\myblog\application\controllers\Welcome.php 41
DEBUG - 2015-02-08 06:56:04 --> Loader Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: url_helper
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: link_helper
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 06:56:04 --> CI_Session Class Initialized
DEBUG - 2015-02-08 06:56:04 --> CI_Session routines successfully run
DEBUG - 2015-02-08 06:56:04 --> Model Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Model Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Controller Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 06:56:04 --> Email Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: language_helper
DEBUG - 2015-02-08 06:56:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 06:56:04 --> Model Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Database Driver Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: date_helper
DEBUG - 2015-02-08 06:56:04 --> Helper loaded: form_helper
DEBUG - 2015-02-08 06:56:04 --> Form Validation Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Model Class Initialized
DEBUG - 2015-02-08 06:56:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 06:56:04 --> Pagination Class Initialized
ERROR - 2015-02-08 06:56:04 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 06:59:04 --> Config Class Initialized
DEBUG - 2015-02-08 06:59:04 --> Hooks Class Initialized
DEBUG - 2015-02-08 06:59:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 06:59:04 --> Utf8 Class Initialized
DEBUG - 2015-02-08 06:59:04 --> URI Class Initialized
DEBUG - 2015-02-08 06:59:04 --> No URI present. Default controller set.
DEBUG - 2015-02-08 06:59:04 --> Router Class Initialized
DEBUG - 2015-02-08 06:59:04 --> Output Class Initialized
DEBUG - 2015-02-08 06:59:04 --> Security Class Initialized
DEBUG - 2015-02-08 06:59:04 --> Input Class Initialized
DEBUG - 2015-02-08 06:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 06:59:04 --> Language Class Initialized
ERROR - 2015-02-08 06:59:04 --> Severity: Warning --> The use statement with non-compound name 'PHPMailer' has no effect C:\xampp\htdocs\myblog\application\controllers\Welcome.php 41
DEBUG - 2015-02-08 06:59:04 --> Loader Class Initialized
DEBUG - 2015-02-08 06:59:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 06:59:04 --> Helper loaded: url_helper
DEBUG - 2015-02-08 06:59:04 --> Helper loaded: link_helper
DEBUG - 2015-02-08 06:59:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 06:59:04 --> CI_Session Class Initialized
DEBUG - 2015-02-08 06:59:04 --> Session: Regenerate ID
DEBUG - 2015-02-08 06:59:04 --> CI_Session routines successfully run
DEBUG - 2015-02-08 06:59:05 --> Model Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Model Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Controller Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 06:59:05 --> Email Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 06:59:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 06:59:05 --> Helper loaded: language_helper
DEBUG - 2015-02-08 06:59:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 06:59:05 --> Model Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Database Driver Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Helper loaded: date_helper
DEBUG - 2015-02-08 06:59:05 --> Helper loaded: form_helper
DEBUG - 2015-02-08 06:59:05 --> Form Validation Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Model Class Initialized
DEBUG - 2015-02-08 06:59:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 06:59:05 --> Pagination Class Initialized
ERROR - 2015-02-08 06:59:05 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:05:32 --> Config Class Initialized
DEBUG - 2015-02-08 07:05:32 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:05:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:05:32 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:05:32 --> URI Class Initialized
DEBUG - 2015-02-08 07:05:32 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:05:32 --> Router Class Initialized
DEBUG - 2015-02-08 07:05:32 --> Output Class Initialized
DEBUG - 2015-02-08 07:05:32 --> Security Class Initialized
DEBUG - 2015-02-08 07:05:32 --> Input Class Initialized
DEBUG - 2015-02-08 07:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:05:32 --> Language Class Initialized
ERROR - 2015-02-08 07:05:32 --> Severity: Warning --> require_once(C:\xampp\htdocs\myblog): failed to open stream: Permission denied C:\xampp\htdocs\myblog\application\controllers\Welcome.php 41
ERROR - 2015-02-08 07:05:32 --> Severity: Compile Error --> require_once(): Failed opening required '' (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\myblog\application\controllers\Welcome.php 41
DEBUG - 2015-02-08 07:05:39 --> Config Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:05:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:05:39 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:05:39 --> URI Class Initialized
DEBUG - 2015-02-08 07:05:39 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:05:39 --> Router Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Output Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Security Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Input Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:05:39 --> Language Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Loader Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:05:39 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:05:39 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:05:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Controller Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:05:39 --> Email Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:05:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:05:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:05:39 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:05:39 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:05:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:05:39 --> Pagination Class Initialized
ERROR - 2015-02-08 07:05:40 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:06:26 --> Config Class Initialized
DEBUG - 2015-02-08 07:06:26 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:06:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:06:26 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:06:26 --> URI Class Initialized
DEBUG - 2015-02-08 07:06:26 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:06:26 --> Router Class Initialized
DEBUG - 2015-02-08 07:06:26 --> Output Class Initialized
DEBUG - 2015-02-08 07:06:26 --> Security Class Initialized
DEBUG - 2015-02-08 07:06:26 --> Input Class Initialized
DEBUG - 2015-02-08 07:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:06:26 --> Language Class Initialized
DEBUG - 2015-02-08 07:06:26 --> Loader Class Initialized
DEBUG - 2015-02-08 07:06:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:06:26 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:06:26 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:06:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:06:26 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:06:26 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:06:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Controller Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:06:27 --> Email Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:06:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:06:27 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:06:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:06:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:06:27 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:06:27 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:06:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:06:27 --> Pagination Class Initialized
ERROR - 2015-02-08 07:06:27 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:08:17 --> Config Class Initialized
DEBUG - 2015-02-08 07:08:17 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:08:17 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:08:17 --> URI Class Initialized
DEBUG - 2015-02-08 07:08:17 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:08:17 --> Router Class Initialized
DEBUG - 2015-02-08 07:08:17 --> Output Class Initialized
DEBUG - 2015-02-08 07:08:17 --> Security Class Initialized
DEBUG - 2015-02-08 07:08:17 --> Input Class Initialized
DEBUG - 2015-02-08 07:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:08:17 --> Language Class Initialized
DEBUG - 2015-02-08 07:08:17 --> Loader Class Initialized
DEBUG - 2015-02-08 07:08:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:08:17 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:08:17 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:08:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:08:17 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:08:17 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:08:18 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Controller Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:08:18 --> Email Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:08:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:08:18 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:08:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:08:18 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:08:18 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:08:18 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:08:18 --> Pagination Class Initialized
ERROR - 2015-02-08 07:08:18 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:08:20 --> Config Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:08:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:08:20 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:08:20 --> URI Class Initialized
DEBUG - 2015-02-08 07:08:20 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:08:20 --> Router Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Output Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Security Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Input Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:08:20 --> Language Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Loader Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:08:20 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:08:20 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:08:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Controller Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:08:20 --> Email Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:08:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:08:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:08:20 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:08:20 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:08:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:08:21 --> Pagination Class Initialized
ERROR - 2015-02-08 07:08:21 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:08:29 --> Config Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:08:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:08:29 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:08:29 --> URI Class Initialized
DEBUG - 2015-02-08 07:08:29 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:08:29 --> Router Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Output Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Security Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Input Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:08:29 --> Language Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Loader Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:08:29 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:08:29 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:08:29 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Controller Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:08:29 --> Email Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:08:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:08:29 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:08:29 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:08:29 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:08:29 --> Pagination Class Initialized
ERROR - 2015-02-08 07:08:29 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:08:37 --> Config Class Initialized
DEBUG - 2015-02-08 07:08:37 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:08:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:08:38 --> URI Class Initialized
DEBUG - 2015-02-08 07:08:38 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:08:38 --> Router Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Output Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Security Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Input Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:08:38 --> Language Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Loader Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:08:38 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:08:38 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:08:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Controller Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:08:38 --> Email Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:08:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:08:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:08:38 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:08:38 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:08:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:08:38 --> Pagination Class Initialized
ERROR - 2015-02-08 07:08:38 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:10:05 --> Config Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:10:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:10:05 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:10:05 --> URI Class Initialized
DEBUG - 2015-02-08 07:10:05 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:10:05 --> Router Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Output Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Security Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Input Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:10:05 --> Language Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Loader Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:10:05 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:10:05 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:10:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:10:05 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:10:05 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:10:05 --> Model Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Model Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Controller Class Initialized
DEBUG - 2015-02-08 07:10:05 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:10:06 --> Email Class Initialized
DEBUG - 2015-02-08 07:10:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:10:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:10:06 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:10:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:10:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:10:06 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:10:06 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:10:06 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:10:06 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:10:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:10:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:10:06 --> Pagination Class Initialized
ERROR - 2015-02-08 07:10:06 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:11:58 --> Config Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:11:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:11:58 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:11:58 --> URI Class Initialized
DEBUG - 2015-02-08 07:11:58 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:11:58 --> Router Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Output Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Security Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Input Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:11:58 --> Language Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Loader Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:11:58 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:11:58 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:11:58 --> Model Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Model Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Controller Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:11:58 --> Email Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:11:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:11:58 --> Model Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:11:58 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:11:58 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Model Class Initialized
DEBUG - 2015-02-08 07:11:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:11:58 --> Pagination Class Initialized
ERROR - 2015-02-08 07:11:58 --> Severity: error --> Exception: [Semantical Error] line 0, col 32 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:13:10 --> Config Class Initialized
DEBUG - 2015-02-08 07:13:10 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:13:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:13:10 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:13:10 --> URI Class Initialized
DEBUG - 2015-02-08 07:13:10 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:13:10 --> Router Class Initialized
DEBUG - 2015-02-08 07:13:10 --> Output Class Initialized
DEBUG - 2015-02-08 07:13:10 --> Security Class Initialized
DEBUG - 2015-02-08 07:13:10 --> Input Class Initialized
DEBUG - 2015-02-08 07:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:13:10 --> Language Class Initialized
DEBUG - 2015-02-08 07:13:10 --> Loader Class Initialized
DEBUG - 2015-02-08 07:13:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:13:10 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:13:10 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:13:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:13:10 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:13:10 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:13:11 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Controller Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:13:11 --> Email Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:13:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:13:11 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:13:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:13:11 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:13:11 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:13:11 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:13:11 --> Pagination Class Initialized
ERROR - 2015-02-08 07:13:11 --> Severity: error --> Exception: [Semantical Error] line 0, col 32 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:13:32 --> Config Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:13:32 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:13:32 --> URI Class Initialized
DEBUG - 2015-02-08 07:13:32 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:13:32 --> Router Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Output Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Security Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Input Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:13:32 --> Language Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Loader Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:13:32 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:13:32 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:13:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:13:32 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:13:32 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:13:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:33 --> Controller Class Initialized
DEBUG - 2015-02-08 07:13:33 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:13:33 --> Email Class Initialized
DEBUG - 2015-02-08 07:13:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:13:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:13:33 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:13:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:13:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:33 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:13:33 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:13:33 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:13:33 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:13:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:13:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:13:33 --> Pagination Class Initialized
ERROR - 2015-02-08 07:13:33 --> Severity: error --> Exception: [Semantical Error] line 0, col 32 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:14:02 --> Config Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:14:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:14:02 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:14:02 --> URI Class Initialized
DEBUG - 2015-02-08 07:14:02 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:14:02 --> Router Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Output Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Security Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Input Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:14:02 --> Language Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Loader Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:14:02 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:14:02 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Controller Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:14:02 --> Email Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:14:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:14:02 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:14:02 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:14:02 --> Pagination Class Initialized
ERROR - 2015-02-08 07:14:03 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:14:36 --> Config Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:14:36 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:14:36 --> URI Class Initialized
DEBUG - 2015-02-08 07:14:36 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:14:36 --> Router Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Output Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Security Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Input Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:14:36 --> Language Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Loader Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:14:36 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:14:36 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:14:36 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Controller Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:14:36 --> Email Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:14:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:14:36 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:14:36 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:14:36 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:14:36 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Config Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:14:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:14:41 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:14:41 --> URI Class Initialized
DEBUG - 2015-02-08 07:14:41 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:14:41 --> Router Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Output Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Security Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Input Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:14:41 --> Language Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Loader Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:14:41 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:14:41 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:14:41 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Controller Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:14:41 --> Email Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:14:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:14:41 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:14:41 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:14:41 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Model Class Initialized
DEBUG - 2015-02-08 07:14:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:14:41 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Config Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:15:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:15:08 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:15:08 --> URI Class Initialized
DEBUG - 2015-02-08 07:15:08 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:15:08 --> Router Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Output Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Security Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Input Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:15:08 --> Language Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Loader Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:15:08 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:15:08 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:15:08 --> Model Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Model Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Controller Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:15:08 --> Email Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:15:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:15:08 --> Model Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:15:08 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:15:08 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Model Class Initialized
DEBUG - 2015-02-08 07:15:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:15:08 --> Pagination Class Initialized
ERROR - 2015-02-08 07:15:08 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:16:38 --> Config Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:16:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:16:38 --> URI Class Initialized
DEBUG - 2015-02-08 07:16:38 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:16:38 --> Router Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Output Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Security Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Input Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:16:38 --> Language Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Loader Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:16:38 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:16:38 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:16:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Controller Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:16:38 --> Email Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:16:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:16:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:16:38 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:16:38 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:16:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:16:38 --> Pagination Class Initialized
ERROR - 2015-02-08 07:16:38 --> Severity: error --> Exception: [Semantical Error] line 0, col 32 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:19:46 --> Config Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:19:46 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:19:46 --> URI Class Initialized
DEBUG - 2015-02-08 07:19:46 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:19:46 --> Router Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Output Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Security Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Input Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:19:46 --> Language Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Loader Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:19:46 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:19:46 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:19:46 --> Model Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Model Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Controller Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:19:46 --> Email Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:19:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:19:46 --> Model Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:19:46 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:19:46 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Model Class Initialized
DEBUG - 2015-02-08 07:19:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:19:46 --> Pagination Class Initialized
ERROR - 2015-02-08 07:19:46 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:21:33 --> Config Class Initialized
DEBUG - 2015-02-08 07:21:33 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:21:33 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:21:33 --> URI Class Initialized
DEBUG - 2015-02-08 07:21:33 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:21:33 --> Router Class Initialized
DEBUG - 2015-02-08 07:21:33 --> Output Class Initialized
DEBUG - 2015-02-08 07:21:33 --> Security Class Initialized
DEBUG - 2015-02-08 07:21:33 --> Input Class Initialized
DEBUG - 2015-02-08 07:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:21:33 --> Language Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Loader Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:21:34 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:21:34 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:21:34 --> Model Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Model Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Controller Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:21:34 --> Email Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:21:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:21:34 --> Model Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:21:34 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:21:34 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Model Class Initialized
DEBUG - 2015-02-08 07:21:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:21:34 --> Pagination Class Initialized
ERROR - 2015-02-08 07:21:34 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:24:06 --> Config Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:24:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:24:06 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:24:06 --> URI Class Initialized
DEBUG - 2015-02-08 07:24:06 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:24:06 --> Router Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Output Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Security Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Input Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:24:06 --> Language Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Loader Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:24:06 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:24:06 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:24:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Controller Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:24:06 --> Email Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:24:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:24:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:24:06 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:24:06 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:24:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:24:06 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Config Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:32:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:32:25 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:32:25 --> URI Class Initialized
DEBUG - 2015-02-08 07:32:25 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:32:25 --> Router Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Output Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Security Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Input Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:32:25 --> Language Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Loader Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:32:25 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:32:25 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:32:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:32:25 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:32:25 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:32:25 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:05 --> Config Class Initialized
DEBUG - 2015-02-08 07:35:05 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:35:05 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:35:05 --> URI Class Initialized
DEBUG - 2015-02-08 07:35:05 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:35:05 --> Router Class Initialized
DEBUG - 2015-02-08 07:35:05 --> Output Class Initialized
DEBUG - 2015-02-08 07:35:05 --> Security Class Initialized
DEBUG - 2015-02-08 07:35:05 --> Input Class Initialized
DEBUG - 2015-02-08 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:35:05 --> Language Class Initialized
DEBUG - 2015-02-08 07:35:05 --> Loader Class Initialized
DEBUG - 2015-02-08 07:35:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:35:05 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:35:05 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:35:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:35:05 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:35:05 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:20 --> Config Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:35:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:35:20 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:35:20 --> URI Class Initialized
DEBUG - 2015-02-08 07:35:20 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:35:20 --> Router Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Output Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Security Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Input Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:35:20 --> Language Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Loader Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:35:20 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:35:20 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Controller Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:35:20 --> Email Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:35:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:35:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:35:20 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:35:20 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:35:20 --> Pagination Class Initialized
ERROR - 2015-02-08 07:35:21 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:35:22 --> Config Class Initialized
DEBUG - 2015-02-08 07:35:22 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:35:22 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:35:22 --> URI Class Initialized
DEBUG - 2015-02-08 07:35:22 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:35:22 --> Router Class Initialized
DEBUG - 2015-02-08 07:35:22 --> Output Class Initialized
DEBUG - 2015-02-08 07:35:22 --> Security Class Initialized
DEBUG - 2015-02-08 07:35:22 --> Input Class Initialized
DEBUG - 2015-02-08 07:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:35:22 --> Language Class Initialized
DEBUG - 2015-02-08 07:35:22 --> Loader Class Initialized
DEBUG - 2015-02-08 07:35:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:35:22 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:35:22 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:35:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:35:22 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:35:22 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Controller Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:35:23 --> Email Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:35:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:35:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:35:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:35:23 --> Pagination Class Initialized
ERROR - 2015-02-08 07:35:23 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:35:23 --> Config Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:35:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:35:23 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:35:23 --> URI Class Initialized
DEBUG - 2015-02-08 07:35:23 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:35:23 --> Router Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Output Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Security Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Input Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:35:23 --> Language Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Loader Class Initialized
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:35:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:35:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:35:24 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:24 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Controller Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:35:24 --> Email Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:35:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:35:24 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:35:24 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:35:24 --> Pagination Class Initialized
ERROR - 2015-02-08 07:35:24 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:35:24 --> Config Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:35:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:35:24 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:35:24 --> URI Class Initialized
DEBUG - 2015-02-08 07:35:24 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:35:24 --> Router Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Output Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Security Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Input Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:35:24 --> Language Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Loader Class Initialized
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:35:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:35:24 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:35:24 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:25 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Controller Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:35:25 --> Email Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:35:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:35:25 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:35:25 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:35:25 --> Pagination Class Initialized
ERROR - 2015-02-08 07:35:25 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:35:25 --> Config Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:35:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:35:25 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:35:25 --> URI Class Initialized
DEBUG - 2015-02-08 07:35:25 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:35:25 --> Router Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Output Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Security Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Input Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:35:25 --> Language Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Loader Class Initialized
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:35:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:35:25 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:35:25 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:26 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Controller Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:35:26 --> Email Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:35:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:35:26 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:35:26 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:35:26 --> Pagination Class Initialized
ERROR - 2015-02-08 07:35:26 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:35:26 --> Config Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:35:26 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:35:26 --> URI Class Initialized
DEBUG - 2015-02-08 07:35:26 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:35:26 --> Router Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Output Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Security Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Input Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:35:26 --> Language Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Loader Class Initialized
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:35:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:35:26 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:35:26 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:35:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Controller Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:35:27 --> Email Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:35:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:35:27 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:35:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:35:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:35:27 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:35:27 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:35:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:35:27 --> Pagination Class Initialized
ERROR - 2015-02-08 07:35:27 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:36:20 --> Config Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:36:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:36:20 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:36:20 --> URI Class Initialized
DEBUG - 2015-02-08 07:36:20 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:36:20 --> Router Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Output Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Security Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Input Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:36:20 --> Language Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Loader Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:36:20 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:36:20 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:36:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:36:20 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:36:20 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:36:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Controller Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:36:20 --> Email Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:36:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:36:20 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:36:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:36:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:36:20 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:36:21 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:36:21 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:36:21 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:36:21 --> Pagination Class Initialized
ERROR - 2015-02-08 07:36:21 --> Severity: error --> Exception: [Semantical Error] line 0, col 24 near 'Entity\Articles': Error: Class 'Entity\Articles' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-08 07:36:33 --> Config Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:36:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:36:33 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:36:33 --> URI Class Initialized
DEBUG - 2015-02-08 07:36:33 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:36:33 --> Router Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Output Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Security Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Input Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:36:33 --> Language Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Loader Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:36:33 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:36:33 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:36:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Controller Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:36:33 --> Email Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:36:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:36:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:36:33 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:36:33 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:36:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:36:33 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Config Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:37:52 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:37:52 --> URI Class Initialized
DEBUG - 2015-02-08 07:37:52 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:37:52 --> Router Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Output Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Security Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Input Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:37:52 --> Language Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Loader Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:37:52 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:37:52 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:37:52 --> Model Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Model Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Controller Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:37:52 --> Email Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:37:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:37:52 --> Model Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:37:52 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:37:52 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Model Class Initialized
DEBUG - 2015-02-08 07:37:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:37:52 --> Pagination Class Initialized
ERROR - 2015-02-08 07:37:52 --> Severity: error --> Exception: Class 'Entity\Articles' does not exist C:\xampp\htdocs\myblog\vendor\doctrine\common\lib\Doctrine\Common\Persistence\Mapping\MappingException.php 96
DEBUG - 2015-02-08 07:39:13 --> Config Class Initialized
DEBUG - 2015-02-08 07:39:13 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:39:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:39:13 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:39:13 --> URI Class Initialized
DEBUG - 2015-02-08 07:39:13 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:39:13 --> Router Class Initialized
DEBUG - 2015-02-08 07:39:13 --> Output Class Initialized
DEBUG - 2015-02-08 07:39:13 --> Security Class Initialized
DEBUG - 2015-02-08 07:39:13 --> Input Class Initialized
DEBUG - 2015-02-08 07:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:39:13 --> Language Class Initialized
DEBUG - 2015-02-08 07:39:13 --> Loader Class Initialized
DEBUG - 2015-02-08 07:39:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:39:13 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:39:13 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:39:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:39:13 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:39:13 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:39:14 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Controller Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:39:14 --> Email Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:39:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:39:14 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:39:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:39:14 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:39:14 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:39:14 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:39:14 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:39:26 --> Config Class Initialized
DEBUG - 2015-02-08 07:39:26 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:39:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:39:26 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:39:26 --> URI Class Initialized
DEBUG - 2015-02-08 07:39:27 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:39:27 --> Router Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Output Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Security Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Input Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:39:27 --> Language Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Loader Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:39:27 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:39:27 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:39:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Controller Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:39:27 --> Email Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:39:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:39:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:39:27 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:39:27 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:39:27 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:39:27 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:28 --> Model Class Initialized
DEBUG - 2015-02-08 07:39:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:39:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:39:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:39:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-08 07:39:28 --> Severity: Error --> Call to undefined method Article_model::getLastArticleViewed() C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 114
DEBUG - 2015-02-08 07:41:43 --> Config Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:41:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:41:43 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:41:43 --> URI Class Initialized
DEBUG - 2015-02-08 07:41:43 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:41:43 --> Router Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Output Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Security Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Input Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:41:43 --> Language Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Loader Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:41:43 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:41:43 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:41:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:41:43 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:41:43 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:41:43 --> Model Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Model Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Controller Class Initialized
DEBUG - 2015-02-08 07:41:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:41:44 --> Email Class Initialized
DEBUG - 2015-02-08 07:41:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:41:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:41:44 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:41:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:41:44 --> Model Class Initialized
DEBUG - 2015-02-08 07:41:44 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:41:44 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:41:44 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:41:44 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:41:44 --> Model Class Initialized
DEBUG - 2015-02-08 07:41:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:41:44 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:41:44 --> Model Class Initialized
DEBUG - 2015-02-08 07:41:44 --> Model Class Initialized
DEBUG - 2015-02-08 07:41:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:41:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:41:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:41:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-08 07:41:44 --> Severity: Error --> Call to a member function getCreated() on array C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 117
DEBUG - 2015-02-08 07:42:23 --> Config Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:42:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:42:23 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:42:23 --> URI Class Initialized
DEBUG - 2015-02-08 07:42:23 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:42:23 --> Router Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Output Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Security Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Input Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:42:23 --> Language Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Loader Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:42:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:42:23 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:42:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Controller Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:42:23 --> Email Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:42:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:42:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:42:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:42:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:42:23 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:42:23 --> Model Class Initialized
DEBUG - 2015-02-08 07:42:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:42:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:42:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:42:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:42:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:42:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:42:23 --> Final output sent to browser
DEBUG - 2015-02-08 07:42:23 --> Total execution time: 0.6870
DEBUG - 2015-02-08 07:43:46 --> Config Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:43:46 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:43:46 --> URI Class Initialized
DEBUG - 2015-02-08 07:43:46 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:43:46 --> Router Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Output Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Security Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Input Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:43:46 --> Language Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Loader Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:43:46 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:43:46 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:43:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:43:46 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:43:46 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:43:46 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:43:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Controller Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:43:47 --> Email Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:43:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:43:47 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:43:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:43:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:43:47 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:43:47 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:43:47 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:43:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:43:47 --> Final output sent to browser
DEBUG - 2015-02-08 07:43:47 --> Total execution time: 0.9861
DEBUG - 2015-02-08 07:45:09 --> Config Class Initialized
DEBUG - 2015-02-08 07:45:09 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:45:09 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:45:09 --> URI Class Initialized
DEBUG - 2015-02-08 07:45:09 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:45:09 --> Router Class Initialized
DEBUG - 2015-02-08 07:45:09 --> Output Class Initialized
DEBUG - 2015-02-08 07:45:09 --> Security Class Initialized
DEBUG - 2015-02-08 07:45:09 --> Input Class Initialized
DEBUG - 2015-02-08 07:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:45:09 --> Language Class Initialized
DEBUG - 2015-02-08 07:45:09 --> Loader Class Initialized
DEBUG - 2015-02-08 07:45:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:45:09 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:45:09 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:45:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:45:09 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:45:09 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Controller Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:45:10 --> Email Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:45:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:45:10 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:45:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:45:10 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:45:10 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:45:10 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-08 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-08 07:45:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:45:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:45:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:45:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:45:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:45:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:45:10 --> Final output sent to browser
DEBUG - 2015-02-08 07:45:10 --> Total execution time: 1.2651
DEBUG - 2015-02-08 07:46:28 --> Config Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:46:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:46:28 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:46:28 --> URI Class Initialized
DEBUG - 2015-02-08 07:46:28 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:46:28 --> Router Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Output Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Security Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Input Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:46:28 --> Language Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Loader Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:46:28 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:46:28 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:46:28 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Controller Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:46:28 --> Email Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:46:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:46:28 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:46:28 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:46:28 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:46:28 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:28 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:46:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:46:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:46:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:46:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:46:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:46:28 --> Final output sent to browser
DEBUG - 2015-02-08 07:46:28 --> Total execution time: 0.7310
DEBUG - 2015-02-08 07:46:47 --> Config Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:46:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:46:47 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:46:47 --> URI Class Initialized
DEBUG - 2015-02-08 07:46:47 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:46:47 --> Router Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Output Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Security Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Input Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:46:47 --> Language Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Loader Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:46:47 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:46:47 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:46:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Controller Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:46:47 --> Email Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:46:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:46:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:46:47 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:46:47 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:46:47 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:46:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:48 --> Model Class Initialized
DEBUG - 2015-02-08 07:46:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:46:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:46:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:46:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:46:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:46:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:46:48 --> Final output sent to browser
DEBUG - 2015-02-08 07:46:48 --> Total execution time: 0.9111
DEBUG - 2015-02-08 07:47:39 --> Config Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:47:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:47:39 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:47:39 --> URI Class Initialized
DEBUG - 2015-02-08 07:47:39 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:47:39 --> Router Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Output Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Security Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Input Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:47:39 --> Language Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Loader Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:47:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:47:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:47:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:47:39 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:47:39 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:47:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Controller Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:47:39 --> Email Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:47:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:47:39 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:47:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:47:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:47:39 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:47:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:47:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:47:40 --> Model Class Initialized
DEBUG - 2015-02-08 07:47:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:47:40 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:47:40 --> Model Class Initialized
DEBUG - 2015-02-08 07:47:40 --> Model Class Initialized
DEBUG - 2015-02-08 07:47:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:47:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:47:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:47:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:47:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:47:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:47:40 --> Final output sent to browser
DEBUG - 2015-02-08 07:47:40 --> Total execution time: 0.9621
DEBUG - 2015-02-08 07:48:55 --> Config Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:48:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:48:55 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:48:55 --> URI Class Initialized
DEBUG - 2015-02-08 07:48:55 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:48:55 --> Router Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Output Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Security Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Input Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:48:55 --> Language Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Loader Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:48:55 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:48:55 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:48:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:48:55 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:48:55 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:48:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Controller Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:48:55 --> Email Class Initialized
DEBUG - 2015-02-08 07:48:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:48:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:48:55 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:48:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:48:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:48:56 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:48:56 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:48:56 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:48:56 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:48:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:48:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:48:56 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:48:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:48:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:48:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:48:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:48:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:48:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:48:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:48:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:48:56 --> Final output sent to browser
DEBUG - 2015-02-08 07:48:56 --> Total execution time: 0.9671
DEBUG - 2015-02-08 07:49:19 --> Config Class Initialized
DEBUG - 2015-02-08 07:49:19 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:49:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:49:19 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:49:19 --> URI Class Initialized
DEBUG - 2015-02-08 07:49:19 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:49:19 --> Router Class Initialized
DEBUG - 2015-02-08 07:49:19 --> Output Class Initialized
DEBUG - 2015-02-08 07:49:19 --> Security Class Initialized
DEBUG - 2015-02-08 07:49:19 --> Input Class Initialized
DEBUG - 2015-02-08 07:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:49:19 --> Language Class Initialized
DEBUG - 2015-02-08 07:49:19 --> Loader Class Initialized
DEBUG - 2015-02-08 07:49:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:49:19 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:49:19 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:49:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:49:19 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:49:19 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:49:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Controller Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:49:20 --> Email Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:49:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:49:20 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:49:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:49:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:49:20 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:49:20 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:49:20 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:20 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:49:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:49:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:49:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:49:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:49:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:49:20 --> Final output sent to browser
DEBUG - 2015-02-08 07:49:20 --> Total execution time: 0.8120
DEBUG - 2015-02-08 07:49:37 --> Config Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:49:37 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:49:37 --> URI Class Initialized
DEBUG - 2015-02-08 07:49:37 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:49:37 --> Router Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Output Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Security Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Input Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:49:37 --> Language Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Loader Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:49:37 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:49:37 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:49:37 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Controller Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:49:37 --> Email Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:49:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:49:37 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:49:37 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:49:37 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:49:37 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:49:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:38 --> Model Class Initialized
DEBUG - 2015-02-08 07:49:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:49:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:49:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:49:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:49:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:49:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:49:38 --> Final output sent to browser
DEBUG - 2015-02-08 07:49:38 --> Total execution time: 1.1731
DEBUG - 2015-02-08 07:52:38 --> Config Class Initialized
DEBUG - 2015-02-08 07:52:38 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:52:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:52:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:52:38 --> URI Class Initialized
DEBUG - 2015-02-08 07:52:38 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:52:38 --> Router Class Initialized
DEBUG - 2015-02-08 07:52:38 --> Output Class Initialized
DEBUG - 2015-02-08 07:52:38 --> Security Class Initialized
DEBUG - 2015-02-08 07:52:38 --> Input Class Initialized
DEBUG - 2015-02-08 07:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:52:38 --> Language Class Initialized
DEBUG - 2015-02-08 07:52:39 --> Loader Class Initialized
DEBUG - 2015-02-08 07:52:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:52:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:52:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:52:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:52:39 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:52:39 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:52:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:52:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:52:39 --> Controller Class Initialized
DEBUG - 2015-02-08 07:52:39 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:52:39 --> Email Class Initialized
DEBUG - 2015-02-08 07:52:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:52:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:52:39 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:52:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:52:39 --> Model Class Initialized
DEBUG - 2015-02-08 07:52:39 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:52:40 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:52:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:52:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:52:40 --> Model Class Initialized
DEBUG - 2015-02-08 07:52:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:52:40 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:52:40 --> Model Class Initialized
DEBUG - 2015-02-08 07:52:40 --> Model Class Initialized
DEBUG - 2015-02-08 07:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:52:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:52:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:52:41 --> Final output sent to browser
DEBUG - 2015-02-08 07:52:41 --> Total execution time: 2.6742
DEBUG - 2015-02-08 07:53:46 --> Config Class Initialized
DEBUG - 2015-02-08 07:53:46 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:53:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:53:46 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:53:46 --> URI Class Initialized
DEBUG - 2015-02-08 07:53:46 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:53:46 --> Router Class Initialized
DEBUG - 2015-02-08 07:53:46 --> Output Class Initialized
DEBUG - 2015-02-08 07:53:46 --> Security Class Initialized
DEBUG - 2015-02-08 07:53:46 --> Input Class Initialized
DEBUG - 2015-02-08 07:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:53:46 --> Language Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Loader Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:53:47 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:53:47 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:53:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Controller Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:53:47 --> Email Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:53:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:53:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:53:47 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:53:47 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:53:47 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:53:47 --> Model Class Initialized
DEBUG - 2015-02-08 07:53:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:53:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:53:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:53:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:53:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:53:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:53:48 --> Final output sent to browser
DEBUG - 2015-02-08 07:53:48 --> Total execution time: 1.3691
DEBUG - 2015-02-08 07:54:54 --> Config Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:54:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:54:54 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:54:54 --> URI Class Initialized
DEBUG - 2015-02-08 07:54:54 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:54:54 --> Router Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Output Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Security Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Input Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:54:54 --> Language Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Loader Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:54:54 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Session: Regenerate ID
DEBUG - 2015-02-08 07:54:54 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:54:54 --> Model Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Model Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Controller Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:54:54 --> Email Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:54:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:54:54 --> Model Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:54:54 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:54:54 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Model Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:54:54 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Model Class Initialized
DEBUG - 2015-02-08 07:54:54 --> Model Class Initialized
DEBUG - 2015-02-08 07:54:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:54:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:54:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:54:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:54:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:54:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:54:54 --> Final output sent to browser
DEBUG - 2015-02-08 07:54:54 --> Total execution time: 0.8380
DEBUG - 2015-02-08 07:55:32 --> Config Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:55:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:55:32 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:55:32 --> URI Class Initialized
DEBUG - 2015-02-08 07:55:32 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:55:32 --> Router Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Output Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Security Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Input Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:55:32 --> Language Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Loader Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:55:32 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:55:32 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:55:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Controller Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:55:32 --> Email Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:55:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:55:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:55:32 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:55:32 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:55:32 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:32 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:55:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:55:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:55:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:55:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:55:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:55:32 --> Final output sent to browser
DEBUG - 2015-02-08 07:55:32 --> Total execution time: 0.9041
DEBUG - 2015-02-08 07:55:55 --> Config Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:55:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:55:55 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:55:55 --> URI Class Initialized
DEBUG - 2015-02-08 07:55:55 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:55:55 --> Router Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Output Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Security Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Input Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:55:55 --> Language Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Loader Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:55:55 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:55:55 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:55:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Controller Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:55:55 --> Email Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:55:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:55:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:55:55 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:55:55 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:55:55 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:55:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:55:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:55:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:55:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:55:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:55:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:55:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:55:56 --> Final output sent to browser
DEBUG - 2015-02-08 07:55:56 --> Total execution time: 0.9821
DEBUG - 2015-02-08 07:56:15 --> Config Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:56:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:56:15 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:56:15 --> URI Class Initialized
DEBUG - 2015-02-08 07:56:15 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:56:15 --> Router Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Output Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Security Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Input Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:56:15 --> Language Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Loader Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:56:15 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:56:15 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Controller Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:56:15 --> Email Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:56:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:56:15 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:56:15 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:56:15 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:56:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:56:16 --> Final output sent to browser
DEBUG - 2015-02-08 07:56:16 --> Total execution time: 0.9641
DEBUG - 2015-02-08 07:56:33 --> Config Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:56:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:56:33 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:56:33 --> URI Class Initialized
DEBUG - 2015-02-08 07:56:33 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:56:33 --> Router Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Output Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Security Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Input Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:56:33 --> Language Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Loader Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:56:33 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:56:33 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:56:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Controller Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:56:33 --> Email Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:56:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:56:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:56:33 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:56:33 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:56:33 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:33 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:56:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:56:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:56:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:56:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:56:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:56:34 --> Final output sent to browser
DEBUG - 2015-02-08 07:56:34 --> Total execution time: 0.7430
DEBUG - 2015-02-08 07:56:43 --> Config Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:56:43 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:56:43 --> URI Class Initialized
DEBUG - 2015-02-08 07:56:43 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:56:43 --> Router Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Output Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Security Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Input Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:56:43 --> Language Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Loader Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:56:43 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:56:43 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:56:43 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Controller Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:56:43 --> Email Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:56:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:56:43 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:56:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:56:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:56:44 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:56:44 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:44 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:56:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:56:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:56:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:56:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:56:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:56:44 --> Final output sent to browser
DEBUG - 2015-02-08 07:56:44 --> Total execution time: 1.0601
DEBUG - 2015-02-08 07:56:55 --> Config Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:56:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:56:55 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:56:55 --> URI Class Initialized
DEBUG - 2015-02-08 07:56:55 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:56:55 --> Router Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Output Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Security Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Input Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:56:55 --> Language Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Loader Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:56:55 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:56:55 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:56:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Controller Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:56:55 --> Email Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:56:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:56:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:56:55 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:56:55 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:56:55 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:56:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:56:56 --> Final output sent to browser
DEBUG - 2015-02-08 07:56:56 --> Total execution time: 0.6300
DEBUG - 2015-02-08 07:57:05 --> Config Class Initialized
DEBUG - 2015-02-08 07:57:05 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:57:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:57:05 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:57:05 --> URI Class Initialized
DEBUG - 2015-02-08 07:57:05 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:57:05 --> Router Class Initialized
DEBUG - 2015-02-08 07:57:05 --> Output Class Initialized
DEBUG - 2015-02-08 07:57:05 --> Security Class Initialized
DEBUG - 2015-02-08 07:57:05 --> Input Class Initialized
DEBUG - 2015-02-08 07:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:57:05 --> Language Class Initialized
DEBUG - 2015-02-08 07:57:05 --> Loader Class Initialized
DEBUG - 2015-02-08 07:57:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:57:05 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:57:05 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:57:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:57:05 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:57:05 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:57:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Controller Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:57:06 --> Email Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:57:06 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:57:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:57:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:57:06 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:57:06 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:57:06 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:57:06 --> Model Class Initialized
DEBUG - 2015-02-08 07:57:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:57:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:57:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:57:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:57:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:57:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:57:06 --> Final output sent to browser
DEBUG - 2015-02-08 07:57:06 --> Total execution time: 0.7860
DEBUG - 2015-02-08 07:58:55 --> Config Class Initialized
DEBUG - 2015-02-08 07:58:55 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:58:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:58:55 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:58:55 --> URI Class Initialized
DEBUG - 2015-02-08 07:58:55 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:58:55 --> Router Class Initialized
DEBUG - 2015-02-08 07:58:55 --> Output Class Initialized
DEBUG - 2015-02-08 07:58:55 --> Security Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Input Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:58:56 --> Language Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Loader Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:58:56 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:58:56 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:58:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Controller Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:58:56 --> Email Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:58:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:58:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:58:56 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:58:56 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:58:56 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:58:56 --> Model Class Initialized
DEBUG - 2015-02-08 07:58:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:58:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:58:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:58:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:58:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:58:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:58:57 --> Final output sent to browser
DEBUG - 2015-02-08 07:58:57 --> Total execution time: 1.1531
DEBUG - 2015-02-08 07:59:34 --> Config Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Hooks Class Initialized
DEBUG - 2015-02-08 07:59:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 07:59:34 --> Utf8 Class Initialized
DEBUG - 2015-02-08 07:59:34 --> URI Class Initialized
DEBUG - 2015-02-08 07:59:34 --> No URI present. Default controller set.
DEBUG - 2015-02-08 07:59:34 --> Router Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Output Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Security Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Input Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 07:59:34 --> Language Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Loader Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 07:59:34 --> Helper loaded: url_helper
DEBUG - 2015-02-08 07:59:34 --> Helper loaded: link_helper
DEBUG - 2015-02-08 07:59:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 07:59:34 --> CI_Session Class Initialized
DEBUG - 2015-02-08 07:59:34 --> CI_Session routines successfully run
DEBUG - 2015-02-08 07:59:34 --> Model Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Model Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Controller Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 07:59:34 --> Email Class Initialized
DEBUG - 2015-02-08 07:59:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 07:59:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 07:59:34 --> Helper loaded: language_helper
DEBUG - 2015-02-08 07:59:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 07:59:34 --> Model Class Initialized
DEBUG - 2015-02-08 07:59:35 --> Database Driver Class Initialized
DEBUG - 2015-02-08 07:59:35 --> Helper loaded: date_helper
DEBUG - 2015-02-08 07:59:35 --> Helper loaded: form_helper
DEBUG - 2015-02-08 07:59:35 --> Form Validation Class Initialized
DEBUG - 2015-02-08 07:59:35 --> Model Class Initialized
DEBUG - 2015-02-08 07:59:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 07:59:35 --> Pagination Class Initialized
DEBUG - 2015-02-08 07:59:35 --> Model Class Initialized
DEBUG - 2015-02-08 07:59:35 --> Model Class Initialized
DEBUG - 2015-02-08 07:59:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 07:59:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 07:59:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 07:59:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 07:59:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 07:59:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 07:59:35 --> Final output sent to browser
DEBUG - 2015-02-08 07:59:35 --> Total execution time: 1.0001
DEBUG - 2015-02-08 08:00:00 --> Config Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:00:00 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:00:00 --> URI Class Initialized
DEBUG - 2015-02-08 08:00:00 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:00:00 --> Router Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Output Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Security Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Input Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:00:00 --> Language Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Loader Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:00:00 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Session: Regenerate ID
DEBUG - 2015-02-08 08:00:00 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:00:00 --> Model Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Model Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Controller Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:00:00 --> Email Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:00:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:00:00 --> Model Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:00:00 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:00:00 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Model Class Initialized
DEBUG - 2015-02-08 08:00:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:00:00 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:00:01 --> Model Class Initialized
DEBUG - 2015-02-08 08:00:01 --> Model Class Initialized
DEBUG - 2015-02-08 08:00:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:00:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:00:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:00:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:00:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:00:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:00:01 --> Final output sent to browser
DEBUG - 2015-02-08 08:00:01 --> Total execution time: 0.9721
DEBUG - 2015-02-08 08:01:07 --> Config Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:01:07 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:01:07 --> URI Class Initialized
DEBUG - 2015-02-08 08:01:07 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:01:07 --> Router Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Output Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Security Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Input Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:01:07 --> Language Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Loader Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:01:07 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:01:07 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:01:07 --> Model Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Model Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Controller Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:01:07 --> Email Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:01:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:01:07 --> Model Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:01:07 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:01:07 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Model Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:01:07 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Model Class Initialized
DEBUG - 2015-02-08 08:01:07 --> Model Class Initialized
DEBUG - 2015-02-08 08:01:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:01:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:01:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:01:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:01:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:01:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:01:07 --> Final output sent to browser
DEBUG - 2015-02-08 08:01:07 --> Total execution time: 0.6790
DEBUG - 2015-02-08 08:03:16 --> Config Class Initialized
DEBUG - 2015-02-08 08:03:16 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:03:16 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:03:16 --> URI Class Initialized
DEBUG - 2015-02-08 08:03:16 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:03:16 --> Router Class Initialized
DEBUG - 2015-02-08 08:03:16 --> Output Class Initialized
DEBUG - 2015-02-08 08:03:16 --> Security Class Initialized
DEBUG - 2015-02-08 08:03:16 --> Input Class Initialized
DEBUG - 2015-02-08 08:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:03:16 --> Language Class Initialized
DEBUG - 2015-02-08 08:03:16 --> Loader Class Initialized
DEBUG - 2015-02-08 08:03:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:03:16 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:03:16 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:03:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:03:16 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:03:16 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:03:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Controller Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:03:17 --> Email Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:03:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:03:17 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:03:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:03:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:03:17 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:03:17 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:03:17 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:03:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:03:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:03:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:03:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:03:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:03:17 --> Final output sent to browser
DEBUG - 2015-02-08 08:03:17 --> Total execution time: 0.8570
DEBUG - 2015-02-08 08:03:29 --> Config Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:03:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:03:29 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:03:29 --> URI Class Initialized
DEBUG - 2015-02-08 08:03:29 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:03:29 --> Router Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Output Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Security Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Input Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:03:29 --> Language Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Loader Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:03:29 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:03:29 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:03:29 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Controller Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:03:29 --> Email Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:03:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:03:29 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:03:29 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:03:29 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:03:29 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:03:30 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:30 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:03:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:03:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:03:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:03:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:03:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:03:30 --> Final output sent to browser
DEBUG - 2015-02-08 08:03:30 --> Total execution time: 0.8370
DEBUG - 2015-02-08 08:03:39 --> Config Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:03:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:03:39 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:03:39 --> URI Class Initialized
DEBUG - 2015-02-08 08:03:39 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:03:39 --> Router Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Output Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Security Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Input Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:03:39 --> Language Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Loader Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:03:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:03:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:03:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:03:39 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:03:39 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:03:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Controller Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:03:39 --> Email Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:03:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:03:39 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:03:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:03:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:03:39 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:03:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:03:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:03:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:03:40 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:03:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:03:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:03:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:03:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:03:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:03:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:03:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:03:41 --> Final output sent to browser
DEBUG - 2015-02-08 08:03:41 --> Total execution time: 1.8181
DEBUG - 2015-02-08 08:04:13 --> Config Class Initialized
DEBUG - 2015-02-08 08:04:13 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:04:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:04:13 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:04:13 --> URI Class Initialized
DEBUG - 2015-02-08 08:04:13 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:04:14 --> Router Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Output Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Security Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Input Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:04:14 --> Language Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Loader Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:04:14 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:04:14 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:04:14 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Controller Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:04:14 --> Email Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:04:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:04:14 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:04:14 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:04:14 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:04:14 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:14 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:04:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:04:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:04:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:04:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:04:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:04:14 --> Final output sent to browser
DEBUG - 2015-02-08 08:04:15 --> Total execution time: 1.0371
DEBUG - 2015-02-08 08:04:36 --> Config Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:04:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:04:36 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:04:36 --> URI Class Initialized
DEBUG - 2015-02-08 08:04:36 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:04:36 --> Router Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Output Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Security Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Input Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:04:36 --> Language Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Loader Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:04:36 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:04:36 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:04:36 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Controller Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:04:36 --> Email Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:04:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:04:36 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:04:36 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:04:36 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:04:36 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:04:37 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:37 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:04:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:04:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:04:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:04:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:04:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:04:37 --> Final output sent to browser
DEBUG - 2015-02-08 08:04:37 --> Total execution time: 0.8770
DEBUG - 2015-02-08 08:04:39 --> Config Class Initialized
DEBUG - 2015-02-08 08:04:39 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:04:39 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:04:39 --> URI Class Initialized
DEBUG - 2015-02-08 08:04:39 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:04:39 --> Router Class Initialized
DEBUG - 2015-02-08 08:04:39 --> Output Class Initialized
DEBUG - 2015-02-08 08:04:39 --> Security Class Initialized
DEBUG - 2015-02-08 08:04:39 --> Input Class Initialized
DEBUG - 2015-02-08 08:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:04:39 --> Language Class Initialized
DEBUG - 2015-02-08 08:04:39 --> Loader Class Initialized
DEBUG - 2015-02-08 08:04:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:04:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:04:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:04:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:04:40 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:04:40 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:04:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Controller Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:04:40 --> Email Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:04:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:04:40 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:04:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:04:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:04:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:04:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:04:40 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:04:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:04:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:04:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:04:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:04:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:04:40 --> Final output sent to browser
DEBUG - 2015-02-08 08:04:40 --> Total execution time: 0.8560
DEBUG - 2015-02-08 08:04:49 --> Config Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:04:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:04:49 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:04:49 --> URI Class Initialized
DEBUG - 2015-02-08 08:04:49 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:04:49 --> Router Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Output Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Security Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Input Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:04:49 --> Language Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Loader Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:04:49 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:04:49 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:04:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:04:49 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:04:49 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:04:49 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Controller Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:04:49 --> Email Class Initialized
DEBUG - 2015-02-08 08:04:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:04:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:04:49 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:04:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:04:49 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:50 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:04:50 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:04:50 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:04:50 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:04:50 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:04:50 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:04:50 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:50 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:04:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:04:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:04:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:04:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:04:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:04:50 --> Final output sent to browser
DEBUG - 2015-02-08 08:04:50 --> Total execution time: 0.9371
DEBUG - 2015-02-08 08:04:52 --> Config Class Initialized
DEBUG - 2015-02-08 08:04:52 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:04:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:04:52 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:04:52 --> URI Class Initialized
DEBUG - 2015-02-08 08:04:52 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:04:52 --> Router Class Initialized
DEBUG - 2015-02-08 08:04:52 --> Output Class Initialized
DEBUG - 2015-02-08 08:04:52 --> Security Class Initialized
DEBUG - 2015-02-08 08:04:52 --> Input Class Initialized
DEBUG - 2015-02-08 08:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:04:52 --> Language Class Initialized
DEBUG - 2015-02-08 08:04:52 --> Loader Class Initialized
DEBUG - 2015-02-08 08:04:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:04:52 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:04:52 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:04:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:04:52 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:04:52 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:04:53 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Controller Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:04:53 --> Email Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:04:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:04:53 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:04:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:04:53 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:04:53 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:04:53 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:04:53 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:53 --> Model Class Initialized
DEBUG - 2015-02-08 08:04:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:04:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:04:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:04:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:04:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:04:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:04:53 --> Final output sent to browser
DEBUG - 2015-02-08 08:04:53 --> Total execution time: 0.8710
DEBUG - 2015-02-08 08:05:03 --> Config Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:05:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:05:03 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:05:03 --> URI Class Initialized
DEBUG - 2015-02-08 08:05:03 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:05:03 --> Router Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Output Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Security Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Input Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:05:03 --> Language Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Loader Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:05:03 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Session: Regenerate ID
DEBUG - 2015-02-08 08:05:03 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:05:03 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Controller Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:05:03 --> Email Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:05:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:05:03 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:05:03 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:05:03 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:05:03 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:05:03 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:04 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:05:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:05:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:05:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:05:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:05:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:05:04 --> Final output sent to browser
DEBUG - 2015-02-08 08:05:04 --> Total execution time: 0.8190
DEBUG - 2015-02-08 08:05:16 --> Config Class Initialized
DEBUG - 2015-02-08 08:05:16 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:05:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:05:16 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:05:16 --> URI Class Initialized
DEBUG - 2015-02-08 08:05:16 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:05:16 --> Router Class Initialized
DEBUG - 2015-02-08 08:05:16 --> Output Class Initialized
DEBUG - 2015-02-08 08:05:16 --> Security Class Initialized
DEBUG - 2015-02-08 08:05:16 --> Input Class Initialized
DEBUG - 2015-02-08 08:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:05:16 --> Language Class Initialized
DEBUG - 2015-02-08 08:05:16 --> Loader Class Initialized
DEBUG - 2015-02-08 08:05:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:05:16 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:05:16 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:05:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:05:16 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:05:16 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:05:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Controller Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:05:17 --> Email Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:05:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:05:17 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:05:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:05:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:05:17 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:05:17 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:05:17 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:05:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:05:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:05:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:05:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:05:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:05:17 --> Final output sent to browser
DEBUG - 2015-02-08 08:05:17 --> Total execution time: 0.9341
DEBUG - 2015-02-08 08:05:42 --> Config Class Initialized
DEBUG - 2015-02-08 08:05:42 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:05:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:05:43 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:05:43 --> URI Class Initialized
DEBUG - 2015-02-08 08:05:43 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:05:43 --> Router Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Output Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Security Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Input Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:05:43 --> Language Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Loader Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:05:43 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:05:43 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:05:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Controller Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:05:43 --> Email Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:05:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:05:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:05:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:05:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:05:43 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:05:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:05:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:05:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:05:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:05:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:05:43 --> Final output sent to browser
DEBUG - 2015-02-08 08:05:43 --> Total execution time: 1.0091
DEBUG - 2015-02-08 08:05:52 --> Config Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:05:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:05:52 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:05:52 --> URI Class Initialized
DEBUG - 2015-02-08 08:05:52 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:05:52 --> Router Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Output Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Security Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Input Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:05:52 --> Language Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Loader Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:05:52 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:05:52 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:05:52 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Controller Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:05:52 --> Email Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:05:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:05:52 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:05:52 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:05:52 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:05:52 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:52 --> Model Class Initialized
DEBUG - 2015-02-08 08:05:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:05:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:05:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:05:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:05:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:05:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:05:52 --> Final output sent to browser
DEBUG - 2015-02-08 08:05:52 --> Total execution time: 0.7480
DEBUG - 2015-02-08 08:06:56 --> Config Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:06:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:06:56 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:06:56 --> URI Class Initialized
DEBUG - 2015-02-08 08:06:56 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:06:56 --> Router Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Output Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Security Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Input Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:06:56 --> Language Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Loader Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:06:56 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:06:56 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:06:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Controller Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:06:56 --> Email Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:06:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:06:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:06:56 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:06:56 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:06:56 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:06:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:06:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:06:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:06:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:06:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:06:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:06:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:06:56 --> Final output sent to browser
DEBUG - 2015-02-08 08:06:56 --> Total execution time: 0.8821
DEBUG - 2015-02-08 08:07:22 --> Config Class Initialized
DEBUG - 2015-02-08 08:07:22 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:07:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:07:22 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:07:22 --> URI Class Initialized
DEBUG - 2015-02-08 08:07:22 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:07:22 --> Router Class Initialized
DEBUG - 2015-02-08 08:07:22 --> Output Class Initialized
DEBUG - 2015-02-08 08:07:22 --> Security Class Initialized
DEBUG - 2015-02-08 08:07:22 --> Input Class Initialized
DEBUG - 2015-02-08 08:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:07:22 --> Language Class Initialized
DEBUG - 2015-02-08 08:07:22 --> Loader Class Initialized
DEBUG - 2015-02-08 08:07:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:07:22 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:07:22 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:07:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:07:22 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:07:22 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:07:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Controller Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:07:23 --> Email Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:07:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:07:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:07:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:07:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:07:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:07:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:07:23 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:07:23 --> Final output sent to browser
DEBUG - 2015-02-08 08:07:23 --> Total execution time: 0.9181
DEBUG - 2015-02-08 08:07:39 --> Config Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:07:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:07:39 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:07:39 --> URI Class Initialized
DEBUG - 2015-02-08 08:07:39 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:07:39 --> Router Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Output Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Security Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Input Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:07:39 --> Language Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Loader Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:07:39 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:07:39 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:07:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Controller Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:07:39 --> Email Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:07:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:07:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:07:39 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:07:39 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:07:39 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:07:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:07:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:07:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:07:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:07:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:07:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:07:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:07:40 --> Final output sent to browser
DEBUG - 2015-02-08 08:07:40 --> Total execution time: 0.9161
DEBUG - 2015-02-08 08:08:46 --> Config Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:08:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:08:46 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:08:46 --> URI Class Initialized
DEBUG - 2015-02-08 08:08:46 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:08:46 --> Router Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Output Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Security Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Input Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:08:46 --> Language Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Loader Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:08:46 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:08:46 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:08:46 --> Model Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Model Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Controller Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:08:46 --> Email Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:08:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:08:46 --> Model Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:08:46 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:08:46 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Model Class Initialized
DEBUG - 2015-02-08 08:08:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:08:46 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:08:47 --> Model Class Initialized
DEBUG - 2015-02-08 08:08:47 --> Model Class Initialized
DEBUG - 2015-02-08 08:08:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:08:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:08:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:08:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:08:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:08:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:08:47 --> Final output sent to browser
DEBUG - 2015-02-08 08:08:47 --> Total execution time: 1.0671
DEBUG - 2015-02-08 08:10:42 --> Config Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:10:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:10:42 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:10:42 --> URI Class Initialized
DEBUG - 2015-02-08 08:10:42 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:10:42 --> Router Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Output Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Security Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Input Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:10:42 --> Language Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Loader Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:10:42 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Session: Regenerate ID
DEBUG - 2015-02-08 08:10:42 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:10:42 --> Model Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Model Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Controller Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:10:42 --> Email Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:10:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:10:42 --> Model Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:10:42 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:10:42 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Model Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:10:42 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Model Class Initialized
DEBUG - 2015-02-08 08:10:42 --> Model Class Initialized
DEBUG - 2015-02-08 08:10:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:10:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:10:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:10:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:10:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:10:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:10:43 --> Final output sent to browser
DEBUG - 2015-02-08 08:10:43 --> Total execution time: 0.9461
DEBUG - 2015-02-08 08:11:01 --> Config Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:11:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:11:01 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:11:01 --> URI Class Initialized
DEBUG - 2015-02-08 08:11:01 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:11:01 --> Router Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Output Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Security Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Input Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:11:01 --> Language Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Loader Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:11:01 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:11:01 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:11:01 --> Model Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Model Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Controller Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:11:01 --> Email Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:11:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:11:01 --> Model Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:11:01 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:11:01 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Model Class Initialized
DEBUG - 2015-02-08 08:11:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:11:01 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:11:02 --> Model Class Initialized
DEBUG - 2015-02-08 08:11:02 --> Model Class Initialized
DEBUG - 2015-02-08 08:11:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:11:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:11:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:11:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:11:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:11:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:11:02 --> Final output sent to browser
DEBUG - 2015-02-08 08:11:02 --> Total execution time: 0.9551
DEBUG - 2015-02-08 08:12:03 --> Config Class Initialized
DEBUG - 2015-02-08 08:12:03 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:12:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:12:03 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:12:03 --> URI Class Initialized
DEBUG - 2015-02-08 08:12:03 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:12:03 --> Router Class Initialized
DEBUG - 2015-02-08 08:12:03 --> Output Class Initialized
DEBUG - 2015-02-08 08:12:03 --> Security Class Initialized
DEBUG - 2015-02-08 08:12:03 --> Input Class Initialized
DEBUG - 2015-02-08 08:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:12:03 --> Language Class Initialized
DEBUG - 2015-02-08 08:12:03 --> Loader Class Initialized
DEBUG - 2015-02-08 08:12:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:12:03 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:12:03 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:12:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:12:03 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:12:03 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:12:04 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Controller Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:12:04 --> Email Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:12:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:12:04 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:12:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:12:04 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:12:04 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:12:04 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:12:04 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:04 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:12:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:12:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:12:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:12:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:12:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:12:04 --> Final output sent to browser
DEBUG - 2015-02-08 08:12:04 --> Total execution time: 0.9911
DEBUG - 2015-02-08 08:12:17 --> Config Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:12:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:12:17 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:12:17 --> URI Class Initialized
DEBUG - 2015-02-08 08:12:17 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:12:17 --> Router Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Output Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Security Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Input Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:12:17 --> Language Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Loader Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:12:17 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:12:17 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:12:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:12:17 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:12:17 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:12:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Controller Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:12:17 --> Email Class Initialized
DEBUG - 2015-02-08 08:12:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:12:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:12:17 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:12:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:12:17 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:18 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:12:18 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:12:18 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:12:18 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:12:18 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:12:18 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:12:18 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:18 --> Model Class Initialized
DEBUG - 2015-02-08 08:12:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:12:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:12:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:12:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:12:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:12:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:12:18 --> Final output sent to browser
DEBUG - 2015-02-08 08:12:18 --> Total execution time: 0.7990
DEBUG - 2015-02-08 08:13:12 --> Config Class Initialized
DEBUG - 2015-02-08 08:13:12 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:13:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:13:12 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:13:12 --> URI Class Initialized
DEBUG - 2015-02-08 08:13:12 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:13:12 --> Router Class Initialized
DEBUG - 2015-02-08 08:13:12 --> Output Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Security Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Input Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:13:13 --> Language Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Loader Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:13:13 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:13:13 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:13:13 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Controller Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:13:13 --> Email Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:13:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:13:13 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:13:13 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:13:13 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:13:13 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:13 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:13:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:13:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:13:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:13:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:13:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:13:13 --> Final output sent to browser
DEBUG - 2015-02-08 08:13:13 --> Total execution time: 0.8590
DEBUG - 2015-02-08 08:13:43 --> Config Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:13:43 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:13:43 --> URI Class Initialized
DEBUG - 2015-02-08 08:13:43 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:13:43 --> Router Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Output Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Security Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Input Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:13:43 --> Language Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Loader Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:13:43 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:13:43 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Controller Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:13:43 --> Email Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:13:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:13:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:13:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:13:43 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 08:13:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:13:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:13:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:13:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:13:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:13:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:13:43 --> Final output sent to browser
DEBUG - 2015-02-08 08:13:43 --> Total execution time: 0.9021
DEBUG - 2015-02-08 08:14:05 --> Config Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:14:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:14:05 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:14:05 --> URI Class Initialized
DEBUG - 2015-02-08 08:14:05 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:14:05 --> Router Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Output Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Security Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Input Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:14:05 --> Language Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Loader Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:14:05 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:14:05 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:14:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:14:05 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:14:05 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:14:05 --> Model Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Model Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Controller Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:14:05 --> Email Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:14:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:14:05 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:14:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:14:05 --> Model Class Initialized
DEBUG - 2015-02-08 08:14:05 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:14:06 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:14:06 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:14:06 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:14:06 --> Model Class Initialized
DEBUG - 2015-02-08 08:14:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:14:06 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:14:06 --> Model Class Initialized
DEBUG - 2015-02-08 08:14:06 --> Model Class Initialized
DEBUG - 2015-02-08 08:14:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:14:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:14:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:14:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:14:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:14:06 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:14:06 --> Final output sent to browser
DEBUG - 2015-02-08 08:14:06 --> Total execution time: 0.9551
DEBUG - 2015-02-08 08:15:55 --> Config Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:15:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:15:55 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:15:55 --> URI Class Initialized
DEBUG - 2015-02-08 08:15:55 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:15:55 --> Router Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Output Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Security Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Input Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:15:55 --> Language Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Loader Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:15:55 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:15:55 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:15:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:15:55 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:15:55 --> Session: Regenerate ID
DEBUG - 2015-02-08 08:15:55 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:15:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Controller Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:15:56 --> Email Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:15:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:15:56 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:15:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:15:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:15:56 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:15:56 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:15:56 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:15:56 --> Model Class Initialized
DEBUG - 2015-02-08 08:15:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:15:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:15:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:15:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:15:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:15:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:15:56 --> Final output sent to browser
DEBUG - 2015-02-08 08:15:56 --> Total execution time: 0.9641
DEBUG - 2015-02-08 08:16:11 --> Config Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:16:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:16:11 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:16:11 --> URI Class Initialized
DEBUG - 2015-02-08 08:16:11 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:16:11 --> Router Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Output Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Security Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Input Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:16:11 --> Language Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Loader Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:16:11 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:16:11 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:16:11 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Controller Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:16:11 --> Email Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:16:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:16:11 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:16:11 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:16:11 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:16:11 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:16:12 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:12 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:16:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:16:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:16:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:16:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:16:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:16:12 --> Final output sent to browser
DEBUG - 2015-02-08 08:16:12 --> Total execution time: 0.8911
DEBUG - 2015-02-08 08:16:29 --> Config Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:16:29 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:16:29 --> URI Class Initialized
DEBUG - 2015-02-08 08:16:29 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:16:29 --> Router Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Output Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Security Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Input Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:16:29 --> Language Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Loader Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:16:29 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:16:29 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:16:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:16:29 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:16:29 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:16:29 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Controller Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:16:29 --> Email Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:16:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:16:29 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:16:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:16:29 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:29 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:16:30 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:16:30 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:16:30 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:16:30 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:30 --> Model Class Initialized
DEBUG - 2015-02-08 08:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:16:30 --> Final output sent to browser
DEBUG - 2015-02-08 08:16:30 --> Total execution time: 0.8330
DEBUG - 2015-02-08 08:17:40 --> Config Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:17:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:17:40 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:17:40 --> URI Class Initialized
DEBUG - 2015-02-08 08:17:40 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:17:40 --> Router Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Output Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Security Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Input Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:17:40 --> Language Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Loader Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:17:40 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:17:40 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:17:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Controller Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:17:40 --> Email Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:17:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:17:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:17:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:17:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Model Class Initialized
DEBUG - 2015-02-08 08:17:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:17:40 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:17:41 --> Model Class Initialized
DEBUG - 2015-02-08 08:17:41 --> Model Class Initialized
DEBUG - 2015-02-08 08:17:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:17:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:17:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:17:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:17:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:17:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:17:41 --> Final output sent to browser
DEBUG - 2015-02-08 08:17:41 --> Total execution time: 0.7930
DEBUG - 2015-02-08 08:20:23 --> Config Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:20:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:20:23 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:20:23 --> URI Class Initialized
DEBUG - 2015-02-08 08:20:23 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:20:23 --> Router Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Output Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Security Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Input Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:20:23 --> Language Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Loader Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:20:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:20:23 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Controller Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:20:23 --> Email Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:20:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:20:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:20:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:20:23 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 08:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:20:23 --> Final output sent to browser
DEBUG - 2015-02-08 08:20:23 --> Total execution time: 0.7450
DEBUG - 2015-02-08 08:21:28 --> Config Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:21:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:21:28 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:21:28 --> URI Class Initialized
DEBUG - 2015-02-08 08:21:28 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:21:28 --> Router Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Output Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Security Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Input Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:21:28 --> Language Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Loader Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:21:28 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Session: Regenerate ID
DEBUG - 2015-02-08 08:21:28 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:21:28 --> Model Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Model Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Controller Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:21:28 --> Email Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:21:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:21:28 --> Model Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:21:28 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:21:28 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Model Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:21:28 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Model Class Initialized
DEBUG - 2015-02-08 08:21:28 --> Model Class Initialized
DEBUG - 2015-02-08 08:21:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:21:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:21:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:21:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:21:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:21:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:21:29 --> Final output sent to browser
DEBUG - 2015-02-08 08:21:29 --> Total execution time: 1.0171
DEBUG - 2015-02-08 08:23:38 --> Config Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Hooks Class Initialized
DEBUG - 2015-02-08 08:23:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 08:23:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 08:23:38 --> URI Class Initialized
DEBUG - 2015-02-08 08:23:38 --> No URI present. Default controller set.
DEBUG - 2015-02-08 08:23:38 --> Router Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Output Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Security Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Input Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 08:23:38 --> Language Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Loader Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: url_helper
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: link_helper
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 08:23:38 --> CI_Session Class Initialized
DEBUG - 2015-02-08 08:23:38 --> CI_Session routines successfully run
DEBUG - 2015-02-08 08:23:38 --> Model Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Model Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Controller Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 08:23:38 --> Email Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: language_helper
DEBUG - 2015-02-08 08:23:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 08:23:38 --> Model Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Database Driver Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: date_helper
DEBUG - 2015-02-08 08:23:38 --> Helper loaded: form_helper
DEBUG - 2015-02-08 08:23:38 --> Form Validation Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Model Class Initialized
DEBUG - 2015-02-08 08:23:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 08:23:38 --> Pagination Class Initialized
DEBUG - 2015-02-08 08:23:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:23:39 --> Model Class Initialized
DEBUG - 2015-02-08 08:23:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 08:23:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 08:23:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 08:23:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 08:23:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 08:23:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 08:23:39 --> Final output sent to browser
DEBUG - 2015-02-08 08:23:39 --> Total execution time: 0.7750
DEBUG - 2015-02-08 13:41:23 --> Config Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:41:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:41:23 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:41:23 --> URI Class Initialized
DEBUG - 2015-02-08 13:41:23 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:41:23 --> Router Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Output Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Security Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Input Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:41:23 --> Language Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Loader Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:41:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:41:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:41:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:41:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:41:23 --> A session cookie was not found.
DEBUG - 2015-02-08 13:41:23 --> Session: Creating new session (c8b4ee5237cf7675284f6f1d360b54ca)
DEBUG - 2015-02-08 13:41:23 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:41:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Controller Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:41:23 --> Email Class Initialized
DEBUG - 2015-02-08 13:41:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:41:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:41:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:41:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:41:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:41:24 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:41:24 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:41:24 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:41:24 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:41:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:41:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:41:24 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:41:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:41:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:41:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:41:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:41:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:41:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:41:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:41:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:41:24 --> Final output sent to browser
DEBUG - 2015-02-08 13:41:24 --> Total execution time: 1.6991
DEBUG - 2015-02-08 13:48:22 --> Config Class Initialized
DEBUG - 2015-02-08 13:48:22 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:48:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:48:22 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:48:23 --> URI Class Initialized
DEBUG - 2015-02-08 13:48:23 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:48:23 --> Router Class Initialized
DEBUG - 2015-02-08 13:48:23 --> Output Class Initialized
DEBUG - 2015-02-08 13:48:23 --> Security Class Initialized
DEBUG - 2015-02-08 13:48:23 --> Input Class Initialized
DEBUG - 2015-02-08 13:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:48:23 --> Language Class Initialized
DEBUG - 2015-02-08 13:48:23 --> Loader Class Initialized
DEBUG - 2015-02-08 13:48:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:48:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:48:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:48:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:48:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:48:24 --> Session: Regenerate ID
DEBUG - 2015-02-08 13:48:24 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:48:27 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:27 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:27 --> Controller Class Initialized
DEBUG - 2015-02-08 13:48:27 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:48:27 --> Email Class Initialized
DEBUG - 2015-02-08 13:48:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:48:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:48:28 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:48:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:48:28 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:28 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:48:28 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:48:28 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:48:28 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:48:29 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:48:29 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:48:32 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:33 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:48:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:48:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:48:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:48:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:48:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:48:33 --> Final output sent to browser
DEBUG - 2015-02-08 13:48:33 --> Total execution time: 11.3326
DEBUG - 2015-02-08 13:48:53 --> Config Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:48:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:48:53 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:48:53 --> URI Class Initialized
DEBUG - 2015-02-08 13:48:53 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:48:53 --> Router Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Output Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Security Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Input Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:48:53 --> Language Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Loader Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:48:53 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:48:53 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:48:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Controller Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:48:53 --> Email Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:48:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:48:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:48:53 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:48:53 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:48:53 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:48:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:48:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:48:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:48:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:48:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:48:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:48:54 --> Final output sent to browser
DEBUG - 2015-02-08 13:48:54 --> Total execution time: 1.0781
DEBUG - 2015-02-08 13:49:20 --> Config Class Initialized
DEBUG - 2015-02-08 13:49:20 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:49:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:49:20 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:49:20 --> URI Class Initialized
DEBUG - 2015-02-08 13:49:20 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:49:20 --> Router Class Initialized
DEBUG - 2015-02-08 13:49:20 --> Output Class Initialized
DEBUG - 2015-02-08 13:49:20 --> Security Class Initialized
DEBUG - 2015-02-08 13:49:20 --> Input Class Initialized
DEBUG - 2015-02-08 13:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:49:20 --> Language Class Initialized
DEBUG - 2015-02-08 13:49:20 --> Loader Class Initialized
DEBUG - 2015-02-08 13:49:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:49:20 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:49:20 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:49:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:49:20 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:49:20 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:49:20 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Controller Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:49:21 --> Email Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:49:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:49:21 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:49:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:49:21 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:49:21 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:49:21 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:49:21 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:21 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:49:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:49:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:49:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:49:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:49:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:49:21 --> Final output sent to browser
DEBUG - 2015-02-08 13:49:21 --> Total execution time: 0.9941
DEBUG - 2015-02-08 13:49:47 --> Config Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:49:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:49:47 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:49:47 --> URI Class Initialized
DEBUG - 2015-02-08 13:49:47 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:49:47 --> Router Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Output Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Security Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Input Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:49:47 --> Language Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Loader Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:49:47 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:49:47 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:49:47 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Controller Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:49:47 --> Email Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:49:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:49:47 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:49:47 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:49:47 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:49:47 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:49:48 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:48 --> Model Class Initialized
DEBUG - 2015-02-08 13:49:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:49:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:49:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:49:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:49:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:49:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:49:48 --> Final output sent to browser
DEBUG - 2015-02-08 13:49:48 --> Total execution time: 0.9241
DEBUG - 2015-02-08 13:50:34 --> Config Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:50:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:50:34 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:50:34 --> URI Class Initialized
DEBUG - 2015-02-08 13:50:34 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:50:34 --> Router Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Output Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Security Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Input Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:50:34 --> Language Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Loader Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:50:34 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:50:34 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:50:34 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Controller Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:50:34 --> Email Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:50:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:50:34 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:50:34 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:50:34 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:50:34 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:34 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:50:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:50:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:50:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:50:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:50:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:50:35 --> Final output sent to browser
DEBUG - 2015-02-08 13:50:35 --> Total execution time: 0.9181
DEBUG - 2015-02-08 13:50:54 --> Config Class Initialized
DEBUG - 2015-02-08 13:50:54 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:50:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:50:54 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:50:54 --> URI Class Initialized
DEBUG - 2015-02-08 13:50:54 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:50:54 --> Router Class Initialized
DEBUG - 2015-02-08 13:50:54 --> Output Class Initialized
DEBUG - 2015-02-08 13:50:54 --> Security Class Initialized
DEBUG - 2015-02-08 13:50:54 --> Input Class Initialized
DEBUG - 2015-02-08 13:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:50:54 --> Language Class Initialized
DEBUG - 2015-02-08 13:50:54 --> Loader Class Initialized
DEBUG - 2015-02-08 13:50:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:50:54 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:50:54 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:50:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:50:54 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:50:54 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:50:55 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Controller Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:50:55 --> Email Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:50:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:50:55 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:50:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:50:55 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:50:55 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:50:55 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:50:55 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:55 --> Model Class Initialized
DEBUG - 2015-02-08 13:50:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:50:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:50:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:50:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:50:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:50:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:50:55 --> Final output sent to browser
DEBUG - 2015-02-08 13:50:55 --> Total execution time: 0.9611
DEBUG - 2015-02-08 13:51:10 --> Config Class Initialized
DEBUG - 2015-02-08 13:51:10 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:51:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:51:10 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:51:10 --> URI Class Initialized
DEBUG - 2015-02-08 13:51:10 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:51:10 --> Router Class Initialized
DEBUG - 2015-02-08 13:51:10 --> Output Class Initialized
DEBUG - 2015-02-08 13:51:10 --> Security Class Initialized
DEBUG - 2015-02-08 13:51:10 --> Input Class Initialized
DEBUG - 2015-02-08 13:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:51:10 --> Language Class Initialized
DEBUG - 2015-02-08 13:51:10 --> Loader Class Initialized
DEBUG - 2015-02-08 13:51:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:51:10 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:51:10 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:51:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:51:10 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:51:10 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:51:11 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Controller Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:51:11 --> Email Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:51:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:51:11 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:51:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:51:11 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:51:11 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:51:11 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:51:11 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:11 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:51:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:51:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:51:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:51:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:51:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:51:11 --> Final output sent to browser
DEBUG - 2015-02-08 13:51:11 --> Total execution time: 0.6880
DEBUG - 2015-02-08 13:51:38 --> Config Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:51:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:51:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:51:38 --> URI Class Initialized
DEBUG - 2015-02-08 13:51:38 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:51:38 --> Router Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Output Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Security Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Input Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:51:38 --> Language Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Loader Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:51:38 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:51:38 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:51:38 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Controller Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:51:38 --> Email Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:51:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:51:38 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:51:38 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:51:38 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:51:38 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:51:39 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:39 --> Model Class Initialized
DEBUG - 2015-02-08 13:51:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:51:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:51:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:51:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:51:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:51:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:51:39 --> Final output sent to browser
DEBUG - 2015-02-08 13:51:39 --> Total execution time: 0.6990
DEBUG - 2015-02-08 13:54:18 --> Config Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:54:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:54:18 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:54:18 --> URI Class Initialized
DEBUG - 2015-02-08 13:54:18 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:54:18 --> Router Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Output Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Security Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Input Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:54:18 --> Language Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Loader Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:54:18 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:54:18 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:54:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:54:18 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:54:18 --> Session: Regenerate ID
DEBUG - 2015-02-08 13:54:18 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:54:19 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Controller Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:54:19 --> Email Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:54:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:54:19 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:54:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:54:19 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:54:19 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:54:19 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:54:19 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:19 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:54:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:54:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:54:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:54:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:54:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:54:19 --> Final output sent to browser
DEBUG - 2015-02-08 13:54:19 --> Total execution time: 0.7790
DEBUG - 2015-02-08 13:54:23 --> Config Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:54:23 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:54:23 --> URI Class Initialized
DEBUG - 2015-02-08 13:54:23 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:54:23 --> Router Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Output Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Security Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Input Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:54:23 --> Language Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Loader Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:54:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:54:23 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:54:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Controller Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:54:23 --> Email Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:54:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:54:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:54:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:54:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:54:23 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:54:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:54:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:54:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:54:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:54:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:54:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:54:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:54:24 --> Final output sent to browser
DEBUG - 2015-02-08 13:54:24 --> Total execution time: 0.8590
DEBUG - 2015-02-08 13:55:23 --> Config Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:55:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:55:23 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:55:23 --> URI Class Initialized
DEBUG - 2015-02-08 13:55:23 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:55:23 --> Router Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Output Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Security Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Input Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:55:23 --> Language Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Loader Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:55:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:55:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:55:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:55:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:55:23 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:55:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Controller Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:55:23 --> Email Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:55:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:55:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:55:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:55:23 --> Model Class Initialized
DEBUG - 2015-02-08 13:55:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:55:24 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:55:24 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:55:24 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:55:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:55:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:55:24 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:55:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:55:24 --> Model Class Initialized
DEBUG - 2015-02-08 13:55:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:55:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:55:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:55:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-08 13:55:24 --> Severity: Error --> Call to undefined method Entity\UserArticles::getFile() C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 118
DEBUG - 2015-02-08 13:56:07 --> Config Class Initialized
DEBUG - 2015-02-08 13:56:07 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:56:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:56:07 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:56:07 --> URI Class Initialized
DEBUG - 2015-02-08 13:56:07 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:56:07 --> Router Class Initialized
DEBUG - 2015-02-08 13:56:07 --> Output Class Initialized
DEBUG - 2015-02-08 13:56:07 --> Security Class Initialized
DEBUG - 2015-02-08 13:56:07 --> Input Class Initialized
DEBUG - 2015-02-08 13:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:56:07 --> Language Class Initialized
DEBUG - 2015-02-08 13:56:07 --> Loader Class Initialized
ERROR - 2015-02-08 13:56:07 --> Severity: Warning --> require_once(./link_helper.php): failed to open stream: No such file or directory C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 2
ERROR - 2015-02-08 13:56:07 --> Severity: Compile Error --> require_once(): Failed opening required './link_helper.php' (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 2
DEBUG - 2015-02-08 13:56:15 --> Config Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:56:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:56:15 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:56:15 --> URI Class Initialized
DEBUG - 2015-02-08 13:56:15 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:56:15 --> Router Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Output Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Security Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Input Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:56:15 --> Language Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Loader Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:56:15 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:56:15 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Controller Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:56:15 --> Email Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:56:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:56:15 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:56:15 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:56:15 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:56:15 --> Model Class Initialized
DEBUG - 2015-02-08 13:56:16 --> Model Class Initialized
DEBUG - 2015-02-08 13:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:56:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-08 13:56:16 --> Severity: Error --> Call to undefined method Entity\UserArticles::getFile() C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 118
DEBUG - 2015-02-08 13:57:50 --> Config Class Initialized
DEBUG - 2015-02-08 13:57:50 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:57:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:57:50 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:57:50 --> URI Class Initialized
DEBUG - 2015-02-08 13:57:50 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:57:50 --> Router Class Initialized
DEBUG - 2015-02-08 13:57:50 --> Output Class Initialized
DEBUG - 2015-02-08 13:57:50 --> Security Class Initialized
DEBUG - 2015-02-08 13:57:50 --> Input Class Initialized
DEBUG - 2015-02-08 13:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:57:50 --> Language Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Loader Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:57:51 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:57:51 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:57:51 --> Model Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Model Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Controller Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:57:51 --> Email Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:57:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:57:51 --> Model Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:57:51 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:57:51 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Model Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:57:51 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Model Class Initialized
DEBUG - 2015-02-08 13:57:51 --> Model Class Initialized
DEBUG - 2015-02-08 13:57:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:57:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:57:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:57:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:57:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:57:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:57:51 --> Final output sent to browser
DEBUG - 2015-02-08 13:57:51 --> Total execution time: 0.9111
DEBUG - 2015-02-08 13:58:30 --> Config Class Initialized
DEBUG - 2015-02-08 13:58:30 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:58:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:58:30 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:58:30 --> URI Class Initialized
DEBUG - 2015-02-08 13:58:30 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:58:30 --> Router Class Initialized
DEBUG - 2015-02-08 13:58:30 --> Output Class Initialized
DEBUG - 2015-02-08 13:58:30 --> Security Class Initialized
DEBUG - 2015-02-08 13:58:30 --> Input Class Initialized
DEBUG - 2015-02-08 13:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:58:30 --> Language Class Initialized
DEBUG - 2015-02-08 13:58:30 --> Loader Class Initialized
DEBUG - 2015-02-08 13:58:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:58:30 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:58:30 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:58:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:58:30 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:58:30 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:58:31 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Controller Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:58:31 --> Email Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:58:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:58:31 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:58:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:58:31 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:58:31 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:58:31 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:58:31 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:31 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:58:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:58:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:58:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:58:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:58:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:58:31 --> Final output sent to browser
DEBUG - 2015-02-08 13:58:31 --> Total execution time: 0.9841
DEBUG - 2015-02-08 13:58:53 --> Config Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:58:53 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:58:53 --> URI Class Initialized
DEBUG - 2015-02-08 13:58:53 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:58:53 --> Router Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Output Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Security Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Input Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:58:53 --> Language Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Loader Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:58:53 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:58:53 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:58:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Controller Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:58:53 --> Email Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:58:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:58:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:58:53 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:58:53 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:58:53 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:53 --> Model Class Initialized
DEBUG - 2015-02-08 13:58:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:58:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:58:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:58:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:58:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:58:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:58:53 --> Final output sent to browser
DEBUG - 2015-02-08 13:58:53 --> Total execution time: 0.6390
DEBUG - 2015-02-08 13:59:13 --> Config Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:59:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:59:13 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:59:13 --> URI Class Initialized
DEBUG - 2015-02-08 13:59:13 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:59:13 --> Router Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Output Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Security Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Input Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:59:13 --> Language Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Loader Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:59:13 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:59:13 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:59:13 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Controller Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:59:13 --> Email Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:59:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:59:13 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:59:13 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:59:13 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:59:13 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:59:14 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:14 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:59:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:59:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:59:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:59:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:59:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:59:14 --> Final output sent to browser
DEBUG - 2015-02-08 13:59:14 --> Total execution time: 0.8250
DEBUG - 2015-02-08 13:59:28 --> Config Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Hooks Class Initialized
DEBUG - 2015-02-08 13:59:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 13:59:28 --> Utf8 Class Initialized
DEBUG - 2015-02-08 13:59:28 --> URI Class Initialized
DEBUG - 2015-02-08 13:59:28 --> No URI present. Default controller set.
DEBUG - 2015-02-08 13:59:28 --> Router Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Output Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Security Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Input Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 13:59:28 --> Language Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Loader Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 13:59:28 --> Helper loaded: url_helper
DEBUG - 2015-02-08 13:59:28 --> Helper loaded: link_helper
DEBUG - 2015-02-08 13:59:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 13:59:28 --> CI_Session Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Session: Regenerate ID
DEBUG - 2015-02-08 13:59:28 --> CI_Session routines successfully run
DEBUG - 2015-02-08 13:59:28 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Controller Class Initialized
DEBUG - 2015-02-08 13:59:28 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 13:59:29 --> Email Class Initialized
DEBUG - 2015-02-08 13:59:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 13:59:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 13:59:29 --> Helper loaded: language_helper
DEBUG - 2015-02-08 13:59:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 13:59:29 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:29 --> Database Driver Class Initialized
DEBUG - 2015-02-08 13:59:29 --> Helper loaded: date_helper
DEBUG - 2015-02-08 13:59:29 --> Helper loaded: form_helper
DEBUG - 2015-02-08 13:59:29 --> Form Validation Class Initialized
DEBUG - 2015-02-08 13:59:29 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 13:59:29 --> Pagination Class Initialized
DEBUG - 2015-02-08 13:59:29 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:29 --> Model Class Initialized
DEBUG - 2015-02-08 13:59:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 13:59:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 13:59:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 13:59:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 13:59:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 13:59:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 13:59:29 --> Final output sent to browser
DEBUG - 2015-02-08 13:59:29 --> Total execution time: 0.9571
DEBUG - 2015-02-08 14:00:56 --> Config Class Initialized
DEBUG - 2015-02-08 14:00:56 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:00:56 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:00:56 --> URI Class Initialized
DEBUG - 2015-02-08 14:00:56 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:00:56 --> Router Class Initialized
DEBUG - 2015-02-08 14:00:56 --> Output Class Initialized
DEBUG - 2015-02-08 14:00:56 --> Security Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Input Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:00:57 --> Language Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Loader Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:00:57 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:00:57 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:00:57 --> Model Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Model Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Controller Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:00:57 --> Email Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:00:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:00:57 --> Model Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:00:57 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:00:57 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Model Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:00:57 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Model Class Initialized
DEBUG - 2015-02-08 14:00:57 --> Model Class Initialized
DEBUG - 2015-02-08 14:00:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:00:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:00:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:00:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:00:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:00:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:00:57 --> Final output sent to browser
DEBUG - 2015-02-08 14:00:57 --> Total execution time: 0.9721
DEBUG - 2015-02-08 14:01:14 --> Config Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:01:14 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:01:14 --> URI Class Initialized
DEBUG - 2015-02-08 14:01:14 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:01:14 --> Router Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Output Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Security Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Input Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:01:14 --> Language Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Loader Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:01:14 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:01:14 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:01:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Controller Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:01:14 --> Email Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:01:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:01:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:01:14 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:01:14 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:01:14 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:01:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:01:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:01:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:01:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:01:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:01:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:01:15 --> Final output sent to browser
DEBUG - 2015-02-08 14:01:15 --> Total execution time: 0.7500
DEBUG - 2015-02-08 14:01:46 --> Config Class Initialized
DEBUG - 2015-02-08 14:01:46 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:01:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:01:46 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:01:47 --> URI Class Initialized
DEBUG - 2015-02-08 14:01:47 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:01:47 --> Router Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Output Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Security Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Input Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:01:47 --> Language Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Loader Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:01:47 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:01:47 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:01:47 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Controller Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:01:47 --> Email Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:01:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:01:47 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:01:47 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:01:47 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:01:47 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:47 --> Model Class Initialized
DEBUG - 2015-02-08 14:01:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:01:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:01:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:01:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:01:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:01:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:01:47 --> Final output sent to browser
DEBUG - 2015-02-08 14:01:47 --> Total execution time: 1.0031
DEBUG - 2015-02-08 14:02:38 --> Config Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:02:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:02:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:02:38 --> URI Class Initialized
DEBUG - 2015-02-08 14:02:38 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:02:38 --> Router Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Output Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Security Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Input Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:02:38 --> Language Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Loader Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:02:38 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:02:38 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:02:38 --> Model Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Model Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Controller Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:02:38 --> Email Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:02:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:02:38 --> Model Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:02:38 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:02:38 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Model Class Initialized
DEBUG - 2015-02-08 14:02:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:02:38 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:02:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:02:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:02:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:02:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:02:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:02:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:02:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:02:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:02:39 --> Final output sent to browser
DEBUG - 2015-02-08 14:02:39 --> Total execution time: 0.9901
DEBUG - 2015-02-08 14:04:21 --> Config Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:04:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:04:21 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:04:21 --> URI Class Initialized
DEBUG - 2015-02-08 14:04:21 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:04:21 --> Router Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Output Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Security Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Input Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:04:21 --> Language Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Loader Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:04:21 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:04:21 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:04:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:04:21 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:04:21 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:04:21 --> Model Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Model Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Controller Class Initialized
DEBUG - 2015-02-08 14:04:21 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:04:21 --> Email Class Initialized
DEBUG - 2015-02-08 14:04:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:04:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:04:22 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:04:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:04:22 --> Model Class Initialized
DEBUG - 2015-02-08 14:04:22 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:04:22 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:04:22 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:04:22 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:04:22 --> Model Class Initialized
DEBUG - 2015-02-08 14:04:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:04:22 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:04:22 --> Model Class Initialized
DEBUG - 2015-02-08 14:04:22 --> Model Class Initialized
DEBUG - 2015-02-08 14:04:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:04:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:04:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:04:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:04:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:04:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:04:22 --> Final output sent to browser
DEBUG - 2015-02-08 14:04:22 --> Total execution time: 0.9981
DEBUG - 2015-02-08 14:05:20 --> Config Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:05:20 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:05:20 --> URI Class Initialized
DEBUG - 2015-02-08 14:05:20 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:05:20 --> Router Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Output Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Security Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Input Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:05:20 --> Language Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Loader Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:05:20 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Session: Regenerate ID
DEBUG - 2015-02-08 14:05:20 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Controller Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:05:20 --> Email Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:05:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:05:20 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:05:20 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:05:20 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:05:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:05:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:05:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:05:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:05:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:05:20 --> Final output sent to browser
DEBUG - 2015-02-08 14:05:20 --> Total execution time: 0.7500
DEBUG - 2015-02-08 14:05:47 --> Config Class Initialized
DEBUG - 2015-02-08 14:05:47 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:05:47 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:05:47 --> URI Class Initialized
DEBUG - 2015-02-08 14:05:47 --> Router Class Initialized
DEBUG - 2015-02-08 14:05:47 --> Output Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Security Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Input Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:05:48 --> Language Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Loader Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:05:48 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:05:48 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:05:48 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Controller Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:05:48 --> Email Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:05:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:05:48 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:05:48 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:05:48 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:05:48 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:05:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:05:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:05:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:05:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:05:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:05:49 --> Final output sent to browser
DEBUG - 2015-02-08 14:05:49 --> Total execution time: 2.0131
DEBUG - 2015-02-08 14:05:58 --> Config Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:05:58 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:05:58 --> URI Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Router Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Output Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Security Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Input Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:05:58 --> Language Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Loader Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:05:58 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:05:58 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:05:58 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Controller Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:05:58 --> Email Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:05:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:05:58 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:05:58 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:05:58 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:58 --> Model Class Initialized
DEBUG - 2015-02-08 14:05:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:05:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:05:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:05:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:05:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:05:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:05:59 --> Final output sent to browser
DEBUG - 2015-02-08 14:05:59 --> Total execution time: 1.0261
DEBUG - 2015-02-08 14:06:01 --> Config Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:06:01 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:06:01 --> URI Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Router Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Output Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Security Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Input Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:06:01 --> Language Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Loader Class Initialized
DEBUG - 2015-02-08 14:06:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:06:01 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:06:01 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:06:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:06:01 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:06:01 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:06:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Controller Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:06:02 --> Email Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:06:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:06:02 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:06:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:06:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:06:02 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:06:02 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:06:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:06:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:06:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:06:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:06:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:06:02 --> Final output sent to browser
DEBUG - 2015-02-08 14:06:02 --> Total execution time: 0.9821
DEBUG - 2015-02-08 14:06:04 --> Config Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:06:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:06:04 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:06:04 --> URI Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Router Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Output Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Security Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Input Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:06:04 --> Language Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Loader Class Initialized
DEBUG - 2015-02-08 14:06:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:06:04 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:06:04 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:06:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:06:04 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:06:04 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:06:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Controller Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:06:05 --> Email Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:06:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:06:05 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:06:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:06:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:06:05 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:06:05 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:06:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:06:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:06:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:06:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:06:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:06:05 --> Final output sent to browser
DEBUG - 2015-02-08 14:06:05 --> Total execution time: 0.7250
DEBUG - 2015-02-08 14:06:08 --> Config Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:06:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:06:08 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:06:08 --> URI Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Router Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Output Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Security Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Input Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:06:08 --> Language Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Loader Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:06:08 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:06:08 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:06:08 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Controller Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:06:08 --> Email Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:06:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:06:08 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:06:08 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:06:08 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:08 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:06:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:06:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:06:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:06:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:06:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:06:09 --> Final output sent to browser
DEBUG - 2015-02-08 14:06:09 --> Total execution time: 0.9241
DEBUG - 2015-02-08 14:06:10 --> Config Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:06:10 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:06:10 --> URI Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Router Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Output Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Security Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Input Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:06:10 --> Language Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Loader Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:06:10 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:06:10 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:06:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Controller Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:06:10 --> Email Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:06:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:06:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:06:10 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:06:10 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:06:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:11 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:11 --> Model Class Initialized
DEBUG - 2015-02-08 14:06:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:06:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:06:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:06:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:06:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:06:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:06:11 --> Final output sent to browser
DEBUG - 2015-02-08 14:06:11 --> Total execution time: 1.0721
DEBUG - 2015-02-08 14:08:00 --> Config Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:08:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:08:00 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:08:00 --> URI Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Router Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Output Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Security Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Input Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:08:00 --> Language Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Loader Class Initialized
DEBUG - 2015-02-08 14:08:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:08:00 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:08:00 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:08:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:08:00 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:08:00 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:08:01 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Controller Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:08:01 --> Email Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:08:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:08:01 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:08:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:08:01 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:08:01 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:08:01 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:01 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:08:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:08:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:08:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:08:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:08:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:08:01 --> Final output sent to browser
DEBUG - 2015-02-08 14:08:01 --> Total execution time: 0.8820
DEBUG - 2015-02-08 14:08:04 --> Config Class Initialized
DEBUG - 2015-02-08 14:08:04 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:08:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:08:04 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:08:04 --> URI Class Initialized
DEBUG - 2015-02-08 14:08:04 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:08:04 --> Router Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Output Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Security Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Input Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:08:05 --> Language Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Loader Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:08:05 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:08:05 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:08:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Controller Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:08:05 --> Email Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:08:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:08:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:08:05 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:08:05 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:08:05 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:05 --> Model Class Initialized
DEBUG - 2015-02-08 14:08:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:08:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:08:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:08:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:08:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:08:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:08:05 --> Final output sent to browser
DEBUG - 2015-02-08 14:08:05 --> Total execution time: 0.9801
DEBUG - 2015-02-08 14:09:06 --> Config Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:09:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:09:06 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:09:06 --> URI Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Router Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Output Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Security Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Input Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:09:06 --> Language Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Loader Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:09:06 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:09:06 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:09:06 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Controller Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:09:06 --> Email Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:09:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:09:06 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:09:06 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:09:06 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:09:06 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:07 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:07 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:09:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:09:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:09:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:09:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:09:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:09:07 --> Final output sent to browser
DEBUG - 2015-02-08 14:09:07 --> Total execution time: 1.1221
DEBUG - 2015-02-08 14:09:12 --> Config Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:09:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:09:12 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:09:12 --> URI Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Router Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Output Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Security Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Input Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:09:12 --> Language Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Loader Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:09:12 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:09:12 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:09:12 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Controller Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:09:12 --> Email Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:09:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:09:12 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:09:12 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:09:12 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:12 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:09:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:09:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:09:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:09:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:09:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:09:13 --> Final output sent to browser
DEBUG - 2015-02-08 14:09:13 --> Total execution time: 0.9791
DEBUG - 2015-02-08 14:09:19 --> Config Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:09:19 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:09:19 --> URI Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Router Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Output Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Security Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Input Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:09:19 --> Language Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Loader Class Initialized
DEBUG - 2015-02-08 14:09:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:09:19 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:09:19 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:09:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:09:19 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:09:19 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:09:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Controller Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:09:20 --> Email Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:09:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:09:20 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:09:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:09:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:09:20 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:09:20 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:20 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:09:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:09:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:09:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:09:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:09:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:09:20 --> Final output sent to browser
DEBUG - 2015-02-08 14:09:20 --> Total execution time: 0.9671
DEBUG - 2015-02-08 14:09:30 --> Config Class Initialized
DEBUG - 2015-02-08 14:09:30 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:09:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:09:30 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:09:30 --> URI Class Initialized
DEBUG - 2015-02-08 14:09:30 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:09:30 --> Router Class Initialized
DEBUG - 2015-02-08 14:09:30 --> Output Class Initialized
DEBUG - 2015-02-08 14:09:30 --> Security Class Initialized
DEBUG - 2015-02-08 14:09:30 --> Input Class Initialized
DEBUG - 2015-02-08 14:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:09:30 --> Language Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Loader Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:09:31 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:09:31 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Controller Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:09:31 --> Email Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:09:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:09:31 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:09:31 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:09:31 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:31 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:09:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:09:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:09:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:09:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:09:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:09:31 --> Final output sent to browser
DEBUG - 2015-02-08 14:09:31 --> Total execution time: 1.0121
DEBUG - 2015-02-08 14:09:35 --> Config Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:09:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:09:35 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:09:35 --> URI Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Router Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Output Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Security Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Input Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:09:35 --> Language Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Loader Class Initialized
DEBUG - 2015-02-08 14:09:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:09:35 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:09:35 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:09:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:09:35 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:09:35 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:09:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Controller Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:09:36 --> Email Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:09:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:09:36 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:09:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:09:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:09:36 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:09:36 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 14:09:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 14:09:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 14:09:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:09:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:09:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:09:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-08 14:09:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:09:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:09:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:09:36 --> Final output sent to browser
DEBUG - 2015-02-08 14:09:36 --> Total execution time: 0.9981
DEBUG - 2015-02-08 14:13:10 --> Config Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:13:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:13:10 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:13:10 --> URI Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Router Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Output Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Security Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Input Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:13:10 --> Language Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Loader Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:13:10 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Session: Regenerate ID
DEBUG - 2015-02-08 14:13:10 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:13:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Controller Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:13:10 --> Email Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:13:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:13:10 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:13:10 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 14:13:10 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:10 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 14:13:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:10 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:13:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:13:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-08 14:13:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-08 14:13:10 --> Severity: Error --> Using $this when not in object context C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 115
DEBUG - 2015-02-08 14:13:24 --> Config Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:13:24 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:13:24 --> URI Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Router Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Output Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Security Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Input Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:13:24 --> Language Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Loader Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:13:24 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:13:24 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Controller Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:13:24 --> Email Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:13:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:13:24 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:13:24 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:13:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 14:13:24 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:13:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:13:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-08 14:13:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:13:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:13:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:13:25 --> Final output sent to browser
DEBUG - 2015-02-08 14:13:25 --> Total execution time: 0.5580
DEBUG - 2015-02-08 14:13:35 --> Config Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:13:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:13:35 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:13:35 --> URI Class Initialized
DEBUG - 2015-02-08 14:13:35 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:13:35 --> Router Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Output Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Security Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Input Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:13:35 --> Language Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Loader Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:13:35 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:13:35 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:13:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:13:35 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:13:35 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:13:35 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:35 --> Controller Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:13:36 --> Email Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:13:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:13:36 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:13:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:13:36 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:13:36 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:13:36 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:36 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:13:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:13:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:13:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:13:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:13:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:13:36 --> Final output sent to browser
DEBUG - 2015-02-08 14:13:36 --> Total execution time: 0.9571
DEBUG - 2015-02-08 14:13:43 --> Config Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:13:43 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:13:43 --> URI Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Router Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Output Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Security Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Input Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:13:43 --> Language Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Loader Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:13:43 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:13:43 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Controller Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:13:43 --> Email Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:13:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:13:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:13:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 14:13:43 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 14:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:13:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:13:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-08 14:13:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:13:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:13:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:13:44 --> Final output sent to browser
DEBUG - 2015-02-08 14:13:44 --> Total execution time: 0.8821
DEBUG - 2015-02-08 14:13:54 --> Config Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:13:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:13:54 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:13:54 --> URI Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Router Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Output Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Security Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Input Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:13:54 --> Language Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Loader Class Initialized
DEBUG - 2015-02-08 14:13:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:13:54 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:13:54 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:13:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:13:54 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:13:54 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:13:55 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:55 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:55 --> Controller Class Initialized
DEBUG - 2015-02-08 14:13:55 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:13:55 --> Email Class Initialized
DEBUG - 2015-02-08 14:13:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:13:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:13:55 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:13:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:55 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:55 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:13:55 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:13:55 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:13:55 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:13:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-08 14:13:55 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-08 14:13:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-08 14:13:56 --> Config Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:13:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:13:56 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:13:56 --> URI Class Initialized
DEBUG - 2015-02-08 14:13:56 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:13:56 --> Router Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Output Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Security Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Input Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:13:56 --> Language Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Loader Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:13:56 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:13:56 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:13:56 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Controller Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:13:56 --> Email Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:13:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:13:56 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:13:56 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:13:56 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:13:56 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:56 --> Model Class Initialized
DEBUG - 2015-02-08 14:13:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:13:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:13:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:13:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:13:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:13:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:13:57 --> Final output sent to browser
DEBUG - 2015-02-08 14:13:57 --> Total execution time: 1.1131
DEBUG - 2015-02-08 14:14:01 --> Config Class Initialized
DEBUG - 2015-02-08 14:14:01 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:14:01 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:14:01 --> URI Class Initialized
DEBUG - 2015-02-08 14:14:01 --> Router Class Initialized
DEBUG - 2015-02-08 14:14:01 --> Output Class Initialized
DEBUG - 2015-02-08 14:14:01 --> Security Class Initialized
DEBUG - 2015-02-08 14:14:01 --> Input Class Initialized
DEBUG - 2015-02-08 14:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:14:01 --> Language Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Loader Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:14:02 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:14:02 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Controller Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:14:02 --> Email Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:14:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:14:02 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:14:02 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:14:02 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:14:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:14:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-08 14:14:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-08 14:14:02 --> Final output sent to browser
DEBUG - 2015-02-08 14:14:02 --> Total execution time: 0.8620
DEBUG - 2015-02-08 14:14:07 --> Config Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:14:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:14:07 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:14:07 --> URI Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Router Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Output Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Security Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Input Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:14:07 --> Language Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Loader Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:14:07 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:14:07 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:14:07 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Controller Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:14:07 --> Email Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:14:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:14:07 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:14:07 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:14:07 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:14:07 --> Model Class Initialized
DEBUG - 2015-02-08 14:14:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:14:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:14:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-08 14:14:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-08 14:14:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-08 14:14:08 --> Final output sent to browser
DEBUG - 2015-02-08 14:14:08 --> Total execution time: 0.8060
DEBUG - 2015-02-08 14:16:42 --> Config Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:16:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:16:42 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:16:42 --> URI Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Router Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Output Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Security Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Input Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:16:42 --> Language Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Loader Class Initialized
DEBUG - 2015-02-08 14:16:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:16:42 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:16:42 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:16:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:16:42 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:16:42 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:16:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:43 --> Controller Class Initialized
DEBUG - 2015-02-08 14:16:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:16:43 --> Email Class Initialized
DEBUG - 2015-02-08 14:16:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:16:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:16:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:16:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:16:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:16:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:16:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:16:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:16:43 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:16:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:16:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-08 14:16:43 --> Upload Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Config Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:16:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:16:44 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:16:44 --> URI Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Router Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Output Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Security Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Input Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:16:44 --> Language Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Loader Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:16:44 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:16:44 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:16:44 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Controller Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:16:44 --> Email Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:16:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:16:44 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:16:44 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:16:44 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:16:44 --> Model Class Initialized
DEBUG - 2015-02-08 14:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:16:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-08 14:16:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-08 14:16:45 --> Final output sent to browser
DEBUG - 2015-02-08 14:16:45 --> Total execution time: 1.0461
DEBUG - 2015-02-08 14:18:16 --> Config Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:18:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:18:16 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:18:16 --> URI Class Initialized
DEBUG - 2015-02-08 14:18:16 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:18:16 --> Router Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Output Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Security Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Input Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:18:16 --> Language Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Loader Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:18:16 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:18:16 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:18:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:18:16 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:18:16 --> Session: Regenerate ID
DEBUG - 2015-02-08 14:18:16 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:18:18 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Controller Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:18:18 --> Email Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:18:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:18:18 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:18:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:18:18 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:18:18 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:18:18 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:18:18 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:18:19 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:19 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:18:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:18:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:18:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:18:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:18:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:18:19 --> Final output sent to browser
DEBUG - 2015-02-08 14:18:19 --> Total execution time: 2.3511
DEBUG - 2015-02-08 14:18:31 --> Config Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:18:31 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:18:31 --> URI Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Router Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Output Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Security Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Input Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:18:31 --> Language Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Loader Class Initialized
DEBUG - 2015-02-08 14:18:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:18:31 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:18:31 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:18:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:18:31 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:18:31 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:18:32 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Controller Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:18:32 --> Email Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:18:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:18:32 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:18:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:18:32 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:18:32 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:18:32 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:32 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:18:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:18:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:18:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:18:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:18:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:18:32 --> Final output sent to browser
DEBUG - 2015-02-08 14:18:32 --> Total execution time: 1.0101
DEBUG - 2015-02-08 14:18:49 --> Config Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:18:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:18:49 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:18:49 --> URI Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Router Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Output Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Security Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Input Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:18:49 --> Language Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Loader Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:18:49 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:18:49 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:18:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Controller Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:18:49 --> Email Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:18:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:18:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:18:49 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:18:49 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:49 --> Model Class Initialized
DEBUG - 2015-02-08 14:18:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:18:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:18:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:18:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:18:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:18:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:18:50 --> Final output sent to browser
DEBUG - 2015-02-08 14:18:50 --> Total execution time: 1.2001
DEBUG - 2015-02-08 14:20:16 --> Config Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:20:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:20:16 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:20:16 --> URI Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Router Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Output Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Security Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Input Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:20:16 --> Language Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Loader Class Initialized
DEBUG - 2015-02-08 14:20:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:20:16 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:20:16 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:20:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:20:16 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:20:16 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:20:17 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:17 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:17 --> Controller Class Initialized
DEBUG - 2015-02-08 14:20:17 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:20:17 --> Email Class Initialized
DEBUG - 2015-02-08 14:20:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:20:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:20:17 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:20:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:20:17 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:17 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:20:17 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:20:17 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:20:17 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:20:17 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:20:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:20:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-08 14:20:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-08 14:20:17 --> Final output sent to browser
DEBUG - 2015-02-08 14:20:17 --> Total execution time: 0.7860
DEBUG - 2015-02-08 14:20:22 --> Config Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:20:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:20:22 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:20:22 --> URI Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Router Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Output Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Security Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Input Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:20:22 --> Language Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Loader Class Initialized
DEBUG - 2015-02-08 14:20:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:20:22 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:20:22 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:20:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:20:22 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:20:22 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:23 --> Controller Class Initialized
DEBUG - 2015-02-08 14:20:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:20:23 --> Email Class Initialized
DEBUG - 2015-02-08 14:20:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:20:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:20:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:20:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:20:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:20:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:20:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:20:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-08 14:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-08 14:20:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-08 14:20:23 --> Final output sent to browser
DEBUG - 2015-02-08 14:20:23 --> Total execution time: 0.7970
DEBUG - 2015-02-08 14:21:25 --> Config Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:21:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:21:25 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:21:25 --> URI Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Router Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Output Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Security Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Input Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:21:25 --> Language Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Loader Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:21:25 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:21:25 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:21:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Controller Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:21:25 --> Email Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:21:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:21:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:21:25 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:21:25 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:21:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:21:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:21:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-08 14:21:25 --> Upload Class Initialized
DEBUG - 2015-02-08 14:21:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-02-08 14:21:25 --> You did not select a file to upload.
DEBUG - 2015-02-08 14:22:22 --> Config Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:22:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:22:22 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:22:22 --> URI Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Router Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Output Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Security Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Input Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:22:22 --> Language Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Loader Class Initialized
DEBUG - 2015-02-08 14:22:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:22:22 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:22:22 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:22:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:22:22 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:22:22 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:22:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Controller Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:22:23 --> Email Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:22:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:22:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:22:23 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:22:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:22:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-08 14:22:23 --> Upload Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Config Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:22:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:22:23 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:22:23 --> URI Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Router Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Output Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Security Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Input Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:22:23 --> Language Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Loader Class Initialized
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:22:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:22:23 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:22:23 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:22:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:24 --> Controller Class Initialized
DEBUG - 2015-02-08 14:22:24 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:22:24 --> Email Class Initialized
DEBUG - 2015-02-08 14:22:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:22:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:22:24 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:22:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:22:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:24 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:22:24 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:22:24 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:22:24 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:22:24 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:22:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:22:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-08 14:22:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-08 14:22:24 --> Final output sent to browser
DEBUG - 2015-02-08 14:22:24 --> Total execution time: 1.1111
DEBUG - 2015-02-08 14:22:28 --> Config Class Initialized
DEBUG - 2015-02-08 14:22:28 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:22:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:22:28 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:22:28 --> URI Class Initialized
DEBUG - 2015-02-08 14:22:28 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:22:28 --> Router Class Initialized
DEBUG - 2015-02-08 14:22:28 --> Output Class Initialized
DEBUG - 2015-02-08 14:22:28 --> Security Class Initialized
DEBUG - 2015-02-08 14:22:28 --> Input Class Initialized
DEBUG - 2015-02-08 14:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:22:28 --> Language Class Initialized
DEBUG - 2015-02-08 14:22:28 --> Loader Class Initialized
DEBUG - 2015-02-08 14:22:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:22:28 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:22:28 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:22:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:22:28 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:22:28 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:22:29 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Controller Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:22:29 --> Email Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:22:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:22:29 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:22:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:22:29 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:22:29 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:22:29 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:22:29 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:29 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:22:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:22:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:22:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:22:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:22:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:22:29 --> Final output sent to browser
DEBUG - 2015-02-08 14:22:29 --> Total execution time: 0.9571
DEBUG - 2015-02-08 14:22:38 --> Config Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:22:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:22:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:22:38 --> URI Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Router Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Output Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Security Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Input Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:22:38 --> Language Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Loader Class Initialized
DEBUG - 2015-02-08 14:22:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:22:38 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:22:38 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:22:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:22:38 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:22:38 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:22:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Controller Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:22:39 --> Email Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:22:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:22:39 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:22:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:22:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:22:39 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:22:39 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:39 --> Model Class Initialized
DEBUG - 2015-02-08 14:22:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:22:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:22:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:22:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:22:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:22:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:22:39 --> Final output sent to browser
DEBUG - 2015-02-08 14:22:39 --> Total execution time: 1.0291
DEBUG - 2015-02-08 14:25:14 --> Config Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:25:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:25:14 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:25:14 --> URI Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Router Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Output Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Security Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Input Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:25:14 --> Language Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Loader Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:25:14 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:25:14 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:25:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:25:14 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Session: Regenerate ID
DEBUG - 2015-02-08 14:25:14 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:25:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Controller Class Initialized
DEBUG - 2015-02-08 14:25:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:25:15 --> Email Class Initialized
DEBUG - 2015-02-08 14:25:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:25:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:25:15 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:25:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:25:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:15 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:25:15 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:25:15 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:25:15 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:25:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:25:15 --> Final output sent to browser
DEBUG - 2015-02-08 14:25:15 --> Total execution time: 0.9811
DEBUG - 2015-02-08 14:25:33 --> Config Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:25:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:25:33 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:25:33 --> URI Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Router Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Output Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Security Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Input Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:25:33 --> Language Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Loader Class Initialized
DEBUG - 2015-02-08 14:25:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:25:33 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:25:33 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:25:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:25:33 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:25:33 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:25:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Controller Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:25:34 --> Email Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:25:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:25:34 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:25:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:25:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:25:34 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:25:34 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:25:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:25:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:25:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:25:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:25:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:25:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:25:34 --> Final output sent to browser
DEBUG - 2015-02-08 14:25:34 --> Total execution time: 0.9411
DEBUG - 2015-02-08 14:26:15 --> Config Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:26:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:26:15 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:26:15 --> URI Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Router Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Output Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Security Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Input Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:26:15 --> Language Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Loader Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:26:15 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:26:15 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:26:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Controller Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:26:15 --> Email Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:26:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:26:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:26:15 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:26:15 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:26:15 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:16 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:16 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:26:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:26:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:26:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:26:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:26:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:26:16 --> Final output sent to browser
DEBUG - 2015-02-08 14:26:16 --> Total execution time: 1.1471
DEBUG - 2015-02-08 14:26:25 --> Config Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:26:25 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:26:25 --> URI Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Router Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Output Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Security Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Input Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:26:25 --> Language Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Loader Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:26:25 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:26:25 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:26:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:26:25 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:26:25 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:26:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Controller Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:26:25 --> Email Class Initialized
DEBUG - 2015-02-08 14:26:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:26:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:26:25 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:26:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:26:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:26 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:26:26 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:26:26 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:26:26 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:26:26 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:26 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:26 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:26:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:26:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:26:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:26:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:26:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:26:26 --> Final output sent to browser
DEBUG - 2015-02-08 14:26:26 --> Total execution time: 1.0661
DEBUG - 2015-02-08 14:26:53 --> Config Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:26:53 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:26:53 --> URI Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Router Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Output Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Security Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Input Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:26:53 --> Language Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Loader Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:26:53 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:26:53 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:26:53 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Controller Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:26:53 --> Email Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:26:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:26:53 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:26:53 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:26:53 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:26:53 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:54 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:54 --> Model Class Initialized
DEBUG - 2015-02-08 14:26:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:26:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:26:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:26:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:26:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:26:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:26:54 --> Final output sent to browser
DEBUG - 2015-02-08 14:26:54 --> Total execution time: 0.7420
DEBUG - 2015-02-08 14:27:13 --> Config Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:27:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:27:13 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:27:13 --> URI Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Router Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Output Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Security Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Input Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:27:13 --> Language Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Loader Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:27:13 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:27:13 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:27:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:27:13 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:27:13 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:27:13 --> Model Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Model Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Controller Class Initialized
DEBUG - 2015-02-08 14:27:13 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:27:14 --> Email Class Initialized
DEBUG - 2015-02-08 14:27:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:27:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:27:14 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:27:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:27:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:27:14 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:27:14 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:27:14 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:27:14 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:27:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:27:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:27:14 --> Model Class Initialized
DEBUG - 2015-02-08 14:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:27:14 --> Final output sent to browser
DEBUG - 2015-02-08 14:27:14 --> Total execution time: 0.8580
DEBUG - 2015-02-08 14:33:25 --> Config Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:33:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:33:25 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:33:25 --> URI Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Router Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Output Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Security Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Input Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:33:25 --> Language Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Loader Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:33:25 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Session: Regenerate ID
DEBUG - 2015-02-08 14:33:25 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:33:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Controller Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:33:25 --> Email Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:33:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:33:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:33:25 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:33:25 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:33:25 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:26 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:26 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:33:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:33:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\article/index.php
DEBUG - 2015-02-08 14:33:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:33:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:33:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:33:26 --> Final output sent to browser
DEBUG - 2015-02-08 14:33:26 --> Total execution time: 1.0581
DEBUG - 2015-02-08 14:33:39 --> Config Class Initialized
DEBUG - 2015-02-08 14:33:39 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:33:39 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:33:39 --> URI Class Initialized
DEBUG - 2015-02-08 14:33:39 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:33:39 --> Router Class Initialized
DEBUG - 2015-02-08 14:33:39 --> Output Class Initialized
DEBUG - 2015-02-08 14:33:39 --> Security Class Initialized
DEBUG - 2015-02-08 14:33:39 --> Input Class Initialized
DEBUG - 2015-02-08 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:33:39 --> Language Class Initialized
DEBUG - 2015-02-08 14:33:39 --> Loader Class Initialized
DEBUG - 2015-02-08 14:33:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:33:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:33:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:33:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:33:39 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:33:39 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:33:40 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Controller Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:33:40 --> Email Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:33:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:33:40 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:33:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:33:40 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:33:40 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:33:40 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:33:40 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:40 --> Model Class Initialized
DEBUG - 2015-02-08 14:33:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:33:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:33:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:33:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:33:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:33:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:33:40 --> Final output sent to browser
DEBUG - 2015-02-08 14:33:40 --> Total execution time: 0.9011
DEBUG - 2015-02-08 14:35:52 --> Config Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:35:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:35:52 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:35:52 --> URI Class Initialized
DEBUG - 2015-02-08 14:35:52 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:35:52 --> Router Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Output Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Security Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Input Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:35:52 --> Language Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Loader Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:35:52 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:35:52 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:35:52 --> Model Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Model Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Controller Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:35:52 --> Email Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:35:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:35:52 --> Model Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:35:52 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:35:52 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Model Class Initialized
DEBUG - 2015-02-08 14:35:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:35:52 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:35:53 --> Model Class Initialized
DEBUG - 2015-02-08 14:35:53 --> Model Class Initialized
DEBUG - 2015-02-08 14:35:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:35:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:35:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:35:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:35:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:35:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:35:53 --> Final output sent to browser
DEBUG - 2015-02-08 14:35:53 --> Total execution time: 0.6910
DEBUG - 2015-02-08 14:38:33 --> Config Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:38:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:38:33 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:38:33 --> URI Class Initialized
DEBUG - 2015-02-08 14:38:33 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:38:33 --> Router Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Output Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Security Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Input Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:38:33 --> Language Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Loader Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:38:33 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:38:33 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:38:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:38:33 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:38:33 --> Session: Regenerate ID
DEBUG - 2015-02-08 14:38:33 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:38:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Controller Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:38:34 --> Email Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:38:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:38:34 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:38:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:38:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:38:34 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:38:34 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:38:34 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:34 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:38:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:38:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:38:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:38:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:38:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:38:34 --> Final output sent to browser
DEBUG - 2015-02-08 14:38:34 --> Total execution time: 0.9301
DEBUG - 2015-02-08 14:38:40 --> Config Class Initialized
DEBUG - 2015-02-08 14:38:40 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:38:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:38:40 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:38:40 --> URI Class Initialized
DEBUG - 2015-02-08 14:38:40 --> Router Class Initialized
DEBUG - 2015-02-08 14:38:40 --> Output Class Initialized
DEBUG - 2015-02-08 14:38:40 --> Security Class Initialized
DEBUG - 2015-02-08 14:38:40 --> Input Class Initialized
DEBUG - 2015-02-08 14:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:38:40 --> Language Class Initialized
DEBUG - 2015-02-08 14:38:40 --> Loader Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:38:41 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:38:41 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:38:41 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Controller Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:38:41 --> Email Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:38:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:38:41 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:38:41 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:38:41 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:38:41 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-08 14:38:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-08 14:38:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-08 14:38:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-08 14:38:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-08 14:38:41 --> Final output sent to browser
DEBUG - 2015-02-08 14:38:41 --> Total execution time: 0.8060
DEBUG - 2015-02-08 14:38:45 --> Config Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Hooks Class Initialized
DEBUG - 2015-02-08 14:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 14:38:45 --> Utf8 Class Initialized
DEBUG - 2015-02-08 14:38:45 --> URI Class Initialized
DEBUG - 2015-02-08 14:38:45 --> No URI present. Default controller set.
DEBUG - 2015-02-08 14:38:45 --> Router Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Output Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Security Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Input Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 14:38:45 --> Language Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Loader Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: url_helper
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: link_helper
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 14:38:45 --> CI_Session Class Initialized
DEBUG - 2015-02-08 14:38:45 --> CI_Session routines successfully run
DEBUG - 2015-02-08 14:38:45 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Controller Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 14:38:45 --> Email Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: language_helper
DEBUG - 2015-02-08 14:38:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 14:38:45 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Database Driver Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: date_helper
DEBUG - 2015-02-08 14:38:45 --> Helper loaded: form_helper
DEBUG - 2015-02-08 14:38:45 --> Form Validation Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 14:38:45 --> Pagination Class Initialized
DEBUG - 2015-02-08 14:38:46 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:46 --> Model Class Initialized
DEBUG - 2015-02-08 14:38:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 14:38:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 14:38:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 14:38:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 14:38:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 14:38:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 14:38:46 --> Final output sent to browser
DEBUG - 2015-02-08 14:38:46 --> Total execution time: 1.0191
DEBUG - 2015-02-08 16:11:18 --> Config Class Initialized
DEBUG - 2015-02-08 16:11:18 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:11:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:11:20 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:11:20 --> URI Class Initialized
DEBUG - 2015-02-08 16:11:21 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:11:21 --> Router Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Output Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Security Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Input Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:11:21 --> Language Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Loader Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:11:21 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:11:21 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:11:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Controller Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:11:21 --> Email Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:11:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:11:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:11:21 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:11:21 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:11:21 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:11:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:11:22 --> Model Class Initialized
DEBUG - 2015-02-08 16:11:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:11:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:11:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:11:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:11:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:11:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:11:22 --> Final output sent to browser
DEBUG - 2015-02-08 16:11:22 --> Total execution time: 5.2383
DEBUG - 2015-02-08 16:15:45 --> Config Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:15:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:15:45 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:15:45 --> URI Class Initialized
DEBUG - 2015-02-08 16:15:45 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:15:45 --> Router Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Output Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Security Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Input Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:15:45 --> Language Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Loader Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:15:45 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:15:45 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:15:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:15:45 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:15:45 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:15:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Controller Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:15:45 --> Email Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:15:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:15:45 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:15:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:15:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:15:45 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:15:46 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:15:46 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:15:46 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:15:46 --> Model Class Initialized
DEBUG - 2015-02-08 16:15:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:15:46 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:15:46 --> Model Class Initialized
DEBUG - 2015-02-08 16:15:46 --> Model Class Initialized
DEBUG - 2015-02-08 16:15:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:15:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:15:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:15:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:15:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:15:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:15:46 --> Final output sent to browser
DEBUG - 2015-02-08 16:15:46 --> Total execution time: 1.2081
DEBUG - 2015-02-08 16:16:38 --> Config Class Initialized
DEBUG - 2015-02-08 16:16:38 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:16:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:16:38 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:16:38 --> URI Class Initialized
DEBUG - 2015-02-08 16:16:38 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:16:38 --> Router Class Initialized
DEBUG - 2015-02-08 16:16:38 --> Output Class Initialized
DEBUG - 2015-02-08 16:16:38 --> Security Class Initialized
DEBUG - 2015-02-08 16:16:38 --> Input Class Initialized
DEBUG - 2015-02-08 16:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:16:38 --> Language Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Loader Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:16:39 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:16:39 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:16:39 --> Model Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Model Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Controller Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:16:39 --> Email Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:16:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:16:39 --> Model Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:16:39 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:16:39 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Model Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:16:39 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Model Class Initialized
DEBUG - 2015-02-08 16:16:39 --> Model Class Initialized
DEBUG - 2015-02-08 16:16:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:16:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:16:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:16:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:16:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:16:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:16:39 --> Final output sent to browser
DEBUG - 2015-02-08 16:16:39 --> Total execution time: 0.9751
DEBUG - 2015-02-08 16:17:24 --> Config Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:17:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:17:24 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:17:24 --> URI Class Initialized
DEBUG - 2015-02-08 16:17:24 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:17:24 --> Router Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Output Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Security Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Input Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:17:24 --> Language Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Loader Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:17:24 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:17:24 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:17:24 --> Model Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Model Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Controller Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:17:24 --> Email Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:17:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:17:24 --> Model Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:17:24 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:17:24 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:17:24 --> Model Class Initialized
DEBUG - 2015-02-08 16:17:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:17:25 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:17:25 --> Model Class Initialized
DEBUG - 2015-02-08 16:17:25 --> Model Class Initialized
DEBUG - 2015-02-08 16:17:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:17:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:17:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:17:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:17:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:17:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:17:25 --> Final output sent to browser
DEBUG - 2015-02-08 16:17:25 --> Total execution time: 0.9981
DEBUG - 2015-02-08 16:19:44 --> Config Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:19:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:19:44 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:19:44 --> URI Class Initialized
DEBUG - 2015-02-08 16:19:44 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:19:44 --> Router Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Output Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Security Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Input Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:19:44 --> Language Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Loader Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:19:44 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:19:44 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:19:44 --> Model Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Model Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Controller Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:19:44 --> Email Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:19:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:19:44 --> Model Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:19:44 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:19:44 --> Form Validation Class Initialized
ERROR - 2015-02-08 16:19:45 --> Severity: Warning --> file_get_contents(contents.html): failed to open stream: No such file or directory C:\xampp\htdocs\myblog\application\controllers\Welcome.php 26
DEBUG - 2015-02-08 16:19:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:19:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:19:45 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:19:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:19:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:19:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:19:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:19:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:19:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:19:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:19:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:19:45 --> Final output sent to browser
DEBUG - 2015-02-08 16:19:45 --> Total execution time: 1.2511
DEBUG - 2015-02-08 16:20:44 --> Config Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:20:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:20:44 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:20:44 --> URI Class Initialized
DEBUG - 2015-02-08 16:20:44 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:20:44 --> Router Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Output Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Security Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Input Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:20:44 --> Language Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Loader Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:20:44 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:20:44 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:20:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:20:44 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:20:44 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:20:44 --> Model Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Model Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Controller Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:20:44 --> Email Class Initialized
DEBUG - 2015-02-08 16:20:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:20:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:20:44 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:20:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:20:44 --> Model Class Initialized
DEBUG - 2015-02-08 16:20:45 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:20:45 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:20:45 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:20:45 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:20:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:20:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:20:45 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:20:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:20:45 --> Model Class Initialized
DEBUG - 2015-02-08 16:20:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:20:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:20:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:20:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:20:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:20:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:20:45 --> Final output sent to browser
DEBUG - 2015-02-08 16:20:45 --> Total execution time: 1.1361
DEBUG - 2015-02-08 16:21:29 --> Config Class Initialized
DEBUG - 2015-02-08 16:21:29 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:21:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:21:30 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:21:30 --> URI Class Initialized
DEBUG - 2015-02-08 16:21:30 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:21:30 --> Router Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Output Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Security Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Input Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:21:30 --> Language Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Loader Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:21:30 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:21:30 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:21:30 --> Model Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Model Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Controller Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:21:30 --> Email Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:21:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:21:30 --> Model Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:21:30 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:21:30 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Model Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:21:30 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Model Class Initialized
DEBUG - 2015-02-08 16:21:30 --> Model Class Initialized
DEBUG - 2015-02-08 16:21:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:21:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:21:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:21:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:21:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:21:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:21:31 --> Final output sent to browser
DEBUG - 2015-02-08 16:21:31 --> Total execution time: 1.1111
DEBUG - 2015-02-08 16:21:59 --> Config Class Initialized
DEBUG - 2015-02-08 16:21:59 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:21:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:21:59 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:21:59 --> URI Class Initialized
DEBUG - 2015-02-08 16:21:59 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:21:59 --> Router Class Initialized
DEBUG - 2015-02-08 16:21:59 --> Output Class Initialized
DEBUG - 2015-02-08 16:21:59 --> Security Class Initialized
DEBUG - 2015-02-08 16:21:59 --> Input Class Initialized
DEBUG - 2015-02-08 16:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:21:59 --> Language Class Initialized
DEBUG - 2015-02-08 16:21:59 --> Loader Class Initialized
DEBUG - 2015-02-08 16:21:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:21:59 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:22:00 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:22:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:22:00 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:22:00 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:22:00 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:22:00 --> Model Class Initialized
DEBUG - 2015-02-08 16:22:00 --> Model Class Initialized
DEBUG - 2015-02-08 16:22:00 --> Controller Class Initialized
DEBUG - 2015-02-08 16:22:00 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:22:00 --> Email Class Initialized
DEBUG - 2015-02-08 16:22:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:22:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:22:00 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:22:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:22:00 --> Model Class Initialized
DEBUG - 2015-02-08 16:22:00 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:22:00 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:22:00 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:22:00 --> Form Validation Class Initialized
ERROR - 2015-02-08 16:22:04 --> Severity: Warning --> stream_socket_enable_crypto(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\xampp\htdocs\myblog\vendor\phpmailer\phpmailer\class.smtp.php 338
DEBUG - 2015-02-08 16:22:04 --> Model Class Initialized
DEBUG - 2015-02-08 16:22:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:22:04 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:22:04 --> Model Class Initialized
DEBUG - 2015-02-08 16:22:04 --> Model Class Initialized
DEBUG - 2015-02-08 16:22:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:22:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:22:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:22:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:22:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:22:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:22:05 --> Final output sent to browser
DEBUG - 2015-02-08 16:22:05 --> Total execution time: 5.2073
DEBUG - 2015-02-08 16:23:22 --> Config Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:23:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:23:22 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:23:22 --> URI Class Initialized
DEBUG - 2015-02-08 16:23:22 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:23:22 --> Router Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Output Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Security Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Input Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:23:22 --> Language Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Loader Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:23:22 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:23:22 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:23:22 --> Model Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Model Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Controller Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:23:22 --> Email Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:23:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:23:22 --> Model Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:23:22 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:23:22 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:23:23 --> Model Class Initialized
DEBUG - 2015-02-08 16:23:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:23:23 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:23:23 --> Model Class Initialized
DEBUG - 2015-02-08 16:23:24 --> Model Class Initialized
DEBUG - 2015-02-08 16:23:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:23:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:23:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:23:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:23:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:23:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:23:24 --> Final output sent to browser
DEBUG - 2015-02-08 16:23:24 --> Total execution time: 2.1081
DEBUG - 2015-02-08 16:24:40 --> Config Class Initialized
DEBUG - 2015-02-08 16:24:40 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:24:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:24:40 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:24:40 --> URI Class Initialized
DEBUG - 2015-02-08 16:24:40 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:24:40 --> Router Class Initialized
DEBUG - 2015-02-08 16:24:40 --> Output Class Initialized
DEBUG - 2015-02-08 16:24:40 --> Security Class Initialized
DEBUG - 2015-02-08 16:24:40 --> Input Class Initialized
DEBUG - 2015-02-08 16:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:24:40 --> Language Class Initialized
DEBUG - 2015-02-08 16:24:40 --> Loader Class Initialized
DEBUG - 2015-02-08 16:24:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:24:40 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:24:40 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:24:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:24:41 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:24:41 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:24:41 --> Model Class Initialized
DEBUG - 2015-02-08 16:24:41 --> Model Class Initialized
DEBUG - 2015-02-08 16:24:41 --> Controller Class Initialized
DEBUG - 2015-02-08 16:24:41 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:24:41 --> Email Class Initialized
DEBUG - 2015-02-08 16:24:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:24:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:24:41 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:24:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:24:41 --> Model Class Initialized
DEBUG - 2015-02-08 16:24:41 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:24:41 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:24:41 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:24:41 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:24:42 --> Model Class Initialized
DEBUG - 2015-02-08 16:24:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:24:42 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:24:42 --> Model Class Initialized
DEBUG - 2015-02-08 16:24:42 --> Model Class Initialized
DEBUG - 2015-02-08 16:24:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:24:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:24:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:24:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:24:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:24:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:24:42 --> Final output sent to browser
DEBUG - 2015-02-08 16:24:42 --> Total execution time: 2.0471
DEBUG - 2015-02-08 16:28:11 --> Config Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:28:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:28:11 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:28:11 --> URI Class Initialized
DEBUG - 2015-02-08 16:28:11 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:28:11 --> Router Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Output Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Security Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Input Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:28:11 --> Language Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Loader Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:28:11 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:28:11 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:28:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Controller Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:28:11 --> Email Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:28:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:28:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:28:11 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:28:11 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:28:12 --> Model Class Initialized
DEBUG - 2015-02-08 16:28:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:28:12 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:28:12 --> Model Class Initialized
DEBUG - 2015-02-08 16:28:13 --> Model Class Initialized
DEBUG - 2015-02-08 16:28:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:28:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:28:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:28:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:28:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:28:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:28:13 --> Final output sent to browser
DEBUG - 2015-02-08 16:28:13 --> Total execution time: 1.8841
DEBUG - 2015-02-08 16:30:11 --> Config Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:30:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:30:11 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:30:11 --> URI Class Initialized
DEBUG - 2015-02-08 16:30:11 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:30:11 --> Router Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Output Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Security Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Input Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:30:11 --> Language Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Loader Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:30:11 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:30:11 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:30:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Controller Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:30:11 --> Email Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:30:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:30:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:30:11 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:30:11 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:30:12 --> Model Class Initialized
DEBUG - 2015-02-08 16:30:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:30:12 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:30:12 --> Model Class Initialized
DEBUG - 2015-02-08 16:30:12 --> Model Class Initialized
DEBUG - 2015-02-08 16:30:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:30:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:30:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:30:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:30:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:30:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:30:13 --> Final output sent to browser
DEBUG - 2015-02-08 16:30:13 --> Total execution time: 1.9621
DEBUG - 2015-02-08 16:33:16 --> Config Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:33:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:33:16 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:33:16 --> URI Class Initialized
DEBUG - 2015-02-08 16:33:16 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:33:16 --> Router Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Output Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Security Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Input Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:33:16 --> Language Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Loader Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:33:16 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:33:16 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:33:16 --> Model Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Model Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Controller Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:33:16 --> Email Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:33:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:33:16 --> Model Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:33:16 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:33:16 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:33:17 --> Model Class Initialized
DEBUG - 2015-02-08 16:33:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:33:17 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:33:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:33:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:33:18 --> Final output sent to browser
DEBUG - 2015-02-08 16:33:18 --> Total execution time: 2.2381
DEBUG - 2015-02-08 16:34:17 --> Config Class Initialized
DEBUG - 2015-02-08 16:34:17 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:34:17 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:34:17 --> URI Class Initialized
DEBUG - 2015-02-08 16:34:17 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:34:17 --> Router Class Initialized
DEBUG - 2015-02-08 16:34:17 --> Output Class Initialized
DEBUG - 2015-02-08 16:34:17 --> Security Class Initialized
DEBUG - 2015-02-08 16:34:17 --> Input Class Initialized
DEBUG - 2015-02-08 16:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:34:17 --> Language Class Initialized
DEBUG - 2015-02-08 16:34:17 --> Loader Class Initialized
DEBUG - 2015-02-08 16:34:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:34:17 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:34:17 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:34:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:34:17 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:34:17 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:34:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:34:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:34:18 --> Controller Class Initialized
DEBUG - 2015-02-08 16:34:18 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:34:18 --> Email Class Initialized
DEBUG - 2015-02-08 16:34:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:34:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:34:18 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:34:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:34:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:34:18 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:34:18 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:34:18 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:34:18 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:34:19 --> Model Class Initialized
DEBUG - 2015-02-08 16:34:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:34:19 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:34:19 --> Model Class Initialized
DEBUG - 2015-02-08 16:34:19 --> Model Class Initialized
DEBUG - 2015-02-08 16:34:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:34:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:34:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:34:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:34:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:34:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:34:19 --> Final output sent to browser
DEBUG - 2015-02-08 16:34:19 --> Total execution time: 1.9421
DEBUG - 2015-02-08 16:35:20 --> Config Class Initialized
DEBUG - 2015-02-08 16:35:20 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:35:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:35:20 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:35:20 --> URI Class Initialized
DEBUG - 2015-02-08 16:35:20 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:35:20 --> Router Class Initialized
DEBUG - 2015-02-08 16:35:20 --> Output Class Initialized
DEBUG - 2015-02-08 16:35:20 --> Security Class Initialized
DEBUG - 2015-02-08 16:35:20 --> Input Class Initialized
DEBUG - 2015-02-08 16:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:35:20 --> Language Class Initialized
DEBUG - 2015-02-08 16:35:20 --> Loader Class Initialized
DEBUG - 2015-02-08 16:35:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:35:20 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:35:20 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:35:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:35:20 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:35:20 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:35:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Controller Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:35:21 --> Email Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:35:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:35:21 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:35:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:35:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:35:21 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:35:21 --> Form Validation Class Initialized
ERROR - 2015-02-08 16:35:21 --> Severity: Warning --> file_get_contents(contents.html): failed to open stream: No such file or directory C:\xampp\htdocs\myblog\application\controllers\Welcome.php 56
DEBUG - 2015-02-08 16:35:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:35:21 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:35:21 --> Model Class Initialized
DEBUG - 2015-02-08 16:35:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:35:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:35:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:35:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:35:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:35:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:35:21 --> Final output sent to browser
DEBUG - 2015-02-08 16:35:21 --> Total execution time: 1.1961
DEBUG - 2015-02-08 16:37:55 --> Config Class Initialized
DEBUG - 2015-02-08 16:37:55 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:37:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:37:55 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:37:55 --> URI Class Initialized
DEBUG - 2015-02-08 16:37:55 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:37:55 --> Router Class Initialized
DEBUG - 2015-02-08 16:37:55 --> Output Class Initialized
DEBUG - 2015-02-08 16:37:55 --> Security Class Initialized
DEBUG - 2015-02-08 16:37:55 --> Input Class Initialized
DEBUG - 2015-02-08 16:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:37:55 --> Language Class Initialized
DEBUG - 2015-02-08 16:37:55 --> Loader Class Initialized
DEBUG - 2015-02-08 16:37:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:37:55 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:37:55 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:37:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:37:56 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:37:56 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:37:56 --> Model Class Initialized
DEBUG - 2015-02-08 16:37:56 --> Model Class Initialized
DEBUG - 2015-02-08 16:37:56 --> Controller Class Initialized
DEBUG - 2015-02-08 16:37:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:37:56 --> Email Class Initialized
DEBUG - 2015-02-08 16:37:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:37:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:37:56 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:37:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:37:56 --> Model Class Initialized
DEBUG - 2015-02-08 16:37:56 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:37:56 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:37:56 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:37:56 --> Form Validation Class Initialized
ERROR - 2015-02-08 16:37:58 --> Severity: Warning --> stream_socket_enable_crypto(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\xampp\htdocs\myblog\vendor\phpmailer\phpmailer\class.smtp.php 338
DEBUG - 2015-02-08 16:37:58 --> Model Class Initialized
DEBUG - 2015-02-08 16:37:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:37:58 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:37:58 --> Model Class Initialized
DEBUG - 2015-02-08 16:37:58 --> Model Class Initialized
DEBUG - 2015-02-08 16:37:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:37:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:37:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:37:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:37:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:37:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:37:59 --> Final output sent to browser
DEBUG - 2015-02-08 16:37:59 --> Total execution time: 3.2962
DEBUG - 2015-02-08 16:42:14 --> Config Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:42:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:42:14 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:42:14 --> URI Class Initialized
DEBUG - 2015-02-08 16:42:14 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:42:14 --> Router Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Output Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Security Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Input Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:42:14 --> Language Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Loader Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:42:14 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:42:14 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:42:14 --> Model Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Model Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Controller Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:42:14 --> Email Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:42:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:42:14 --> Model Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:42:14 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:42:14 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:42:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:42:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:42:18 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:42:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:42:18 --> Model Class Initialized
DEBUG - 2015-02-08 16:42:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:42:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:42:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:42:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:42:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:42:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:42:18 --> Final output sent to browser
DEBUG - 2015-02-08 16:42:18 --> Total execution time: 4.4473
DEBUG - 2015-02-08 16:52:04 --> Config Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:52:04 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:52:04 --> URI Class Initialized
DEBUG - 2015-02-08 16:52:04 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:52:04 --> Router Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Output Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Security Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Input Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:52:04 --> Language Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Loader Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:52:04 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:52:04 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:52:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:52:04 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:52:04 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:52:04 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:52:05 --> Model Class Initialized
DEBUG - 2015-02-08 16:52:05 --> Model Class Initialized
DEBUG - 2015-02-08 16:52:05 --> Controller Class Initialized
DEBUG - 2015-02-08 16:52:05 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:52:05 --> Email Class Initialized
DEBUG - 2015-02-08 16:52:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:52:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:52:05 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:52:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:52:05 --> Model Class Initialized
DEBUG - 2015-02-08 16:52:05 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:52:05 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:52:05 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:52:05 --> Form Validation Class Initialized
DEBUG - 2015-02-08 16:52:10 --> Model Class Initialized
DEBUG - 2015-02-08 16:52:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:52:10 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:52:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:52:11 --> Model Class Initialized
DEBUG - 2015-02-08 16:52:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:52:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:52:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:52:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:52:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:52:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:52:11 --> Final output sent to browser
DEBUG - 2015-02-08 16:52:11 --> Total execution time: 6.7764
DEBUG - 2015-02-08 16:59:51 --> Config Class Initialized
DEBUG - 2015-02-08 16:59:51 --> Hooks Class Initialized
DEBUG - 2015-02-08 16:59:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 16:59:51 --> Utf8 Class Initialized
DEBUG - 2015-02-08 16:59:51 --> URI Class Initialized
DEBUG - 2015-02-08 16:59:52 --> No URI present. Default controller set.
DEBUG - 2015-02-08 16:59:52 --> Router Class Initialized
DEBUG - 2015-02-08 16:59:52 --> Output Class Initialized
DEBUG - 2015-02-08 16:59:52 --> Security Class Initialized
DEBUG - 2015-02-08 16:59:52 --> Input Class Initialized
DEBUG - 2015-02-08 16:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 16:59:52 --> Language Class Initialized
DEBUG - 2015-02-08 16:59:52 --> Loader Class Initialized
DEBUG - 2015-02-08 16:59:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 16:59:52 --> Helper loaded: url_helper
DEBUG - 2015-02-08 16:59:52 --> Helper loaded: link_helper
DEBUG - 2015-02-08 16:59:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 16:59:52 --> CI_Session Class Initialized
DEBUG - 2015-02-08 16:59:52 --> Session: Regenerate ID
DEBUG - 2015-02-08 16:59:52 --> CI_Session routines successfully run
DEBUG - 2015-02-08 16:59:54 --> Model Class Initialized
DEBUG - 2015-02-08 16:59:54 --> Model Class Initialized
DEBUG - 2015-02-08 16:59:54 --> Controller Class Initialized
DEBUG - 2015-02-08 16:59:54 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 16:59:54 --> Email Class Initialized
DEBUG - 2015-02-08 16:59:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 16:59:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 16:59:54 --> Helper loaded: language_helper
DEBUG - 2015-02-08 16:59:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 16:59:54 --> Model Class Initialized
DEBUG - 2015-02-08 16:59:54 --> Database Driver Class Initialized
DEBUG - 2015-02-08 16:59:54 --> Helper loaded: date_helper
DEBUG - 2015-02-08 16:59:54 --> Helper loaded: form_helper
DEBUG - 2015-02-08 16:59:54 --> Form Validation Class Initialized
ERROR - 2015-02-08 16:59:56 --> Severity: Warning --> stream_socket_enable_crypto(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:SSL3_GET_SERVER_CERTIFICATE:certificate verify failed C:\xampp\htdocs\myblog\vendor\phpmailer\phpmailer\class.smtp.php 338
DEBUG - 2015-02-08 16:59:56 --> Model Class Initialized
DEBUG - 2015-02-08 16:59:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 16:59:56 --> Pagination Class Initialized
DEBUG - 2015-02-08 16:59:57 --> Model Class Initialized
DEBUG - 2015-02-08 16:59:57 --> Model Class Initialized
DEBUG - 2015-02-08 16:59:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 16:59:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 16:59:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 16:59:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 16:59:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 16:59:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 16:59:58 --> Final output sent to browser
DEBUG - 2015-02-08 16:59:58 --> Total execution time: 6.8654
DEBUG - 2015-02-08 17:00:43 --> Config Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Hooks Class Initialized
DEBUG - 2015-02-08 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-08 17:00:43 --> Utf8 Class Initialized
DEBUG - 2015-02-08 17:00:43 --> URI Class Initialized
DEBUG - 2015-02-08 17:00:43 --> No URI present. Default controller set.
DEBUG - 2015-02-08 17:00:43 --> Router Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Output Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Security Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Input Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-08 17:00:43 --> Language Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Loader Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: url_helper
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: link_helper
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-08 17:00:43 --> CI_Session Class Initialized
DEBUG - 2015-02-08 17:00:43 --> CI_Session routines successfully run
DEBUG - 2015-02-08 17:00:43 --> Model Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Model Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Controller Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-08 17:00:43 --> Email Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: language_helper
DEBUG - 2015-02-08 17:00:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-08 17:00:43 --> Model Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Database Driver Class Initialized
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: date_helper
DEBUG - 2015-02-08 17:00:43 --> Helper loaded: form_helper
DEBUG - 2015-02-08 17:00:43 --> Form Validation Class Initialized
DEBUG - 2015-02-08 17:00:48 --> Model Class Initialized
DEBUG - 2015-02-08 17:00:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-08 17:00:48 --> Pagination Class Initialized
DEBUG - 2015-02-08 17:00:48 --> Model Class Initialized
DEBUG - 2015-02-08 17:00:49 --> Model Class Initialized
DEBUG - 2015-02-08 17:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-08 17:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-08 17:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-08 17:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-08 17:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-08 17:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-08 17:00:49 --> Final output sent to browser
DEBUG - 2015-02-08 17:00:49 --> Total execution time: 6.0713
