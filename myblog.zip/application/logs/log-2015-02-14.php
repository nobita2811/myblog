<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-14 00:14:23 --> Config Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Hooks Class Initialized
DEBUG - 2015-02-14 00:14:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 00:14:23 --> Utf8 Class Initialized
DEBUG - 2015-02-14 00:14:23 --> URI Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Router Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Output Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Security Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Input Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 00:14:23 --> Language Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Loader Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: url_helper
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: link_helper
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 00:14:23 --> CI_Session Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Session: Regenerate ID
DEBUG - 2015-02-14 00:14:23 --> CI_Session routines successfully run
DEBUG - 2015-02-14 00:14:23 --> Model Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Model Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Controller Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 00:14:23 --> Email Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 00:14:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 00:14:23 --> Model Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 00:14:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 00:14:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 00:14:23 --> Model Class Initialized
DEBUG - 2015-02-14 00:14:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 00:14:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 00:14:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 00:14:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 00:14:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 00:14:24 --> Final output sent to browser
DEBUG - 2015-02-14 00:14:24 --> Total execution time: 1.1259
DEBUG - 2015-02-14 00:29:24 --> Config Class Initialized
DEBUG - 2015-02-14 00:29:24 --> Hooks Class Initialized
DEBUG - 2015-02-14 00:29:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 00:29:24 --> Utf8 Class Initialized
DEBUG - 2015-02-14 00:29:24 --> URI Class Initialized
DEBUG - 2015-02-14 00:29:24 --> Router Class Initialized
DEBUG - 2015-02-14 00:29:24 --> Output Class Initialized
DEBUG - 2015-02-14 00:29:24 --> Security Class Initialized
DEBUG - 2015-02-14 00:29:24 --> Input Class Initialized
DEBUG - 2015-02-14 00:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 00:29:24 --> Language Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Loader Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 00:29:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Session: Regenerate ID
DEBUG - 2015-02-14 00:29:25 --> CI_Session routines successfully run
DEBUG - 2015-02-14 00:29:25 --> Model Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Model Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Controller Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 00:29:25 --> Email Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: language_helper
DEBUG - 2015-02-14 00:29:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 00:29:25 --> Model Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Database Driver Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: date_helper
DEBUG - 2015-02-14 00:29:25 --> Helper loaded: form_helper
DEBUG - 2015-02-14 00:29:25 --> Form Validation Class Initialized
DEBUG - 2015-02-14 00:29:25 --> Model Class Initialized
DEBUG - 2015-02-14 00:29:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 00:29:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 00:29:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 00:29:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 00:29:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 00:29:26 --> Final output sent to browser
DEBUG - 2015-02-14 00:29:26 --> Total execution time: 1.2081
DEBUG - 2015-02-14 00:44:26 --> Config Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Hooks Class Initialized
DEBUG - 2015-02-14 00:44:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 00:44:26 --> Utf8 Class Initialized
DEBUG - 2015-02-14 00:44:26 --> URI Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Router Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Output Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Security Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Input Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 00:44:26 --> Language Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Loader Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: url_helper
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: link_helper
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 00:44:26 --> CI_Session Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Session: Regenerate ID
DEBUG - 2015-02-14 00:44:26 --> CI_Session routines successfully run
DEBUG - 2015-02-14 00:44:26 --> Model Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Model Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Controller Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 00:44:26 --> Email Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: language_helper
DEBUG - 2015-02-14 00:44:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 00:44:26 --> Model Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Database Driver Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: date_helper
DEBUG - 2015-02-14 00:44:26 --> Helper loaded: form_helper
DEBUG - 2015-02-14 00:44:26 --> Form Validation Class Initialized
DEBUG - 2015-02-14 00:44:26 --> Model Class Initialized
DEBUG - 2015-02-14 00:44:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 00:44:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 00:44:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 00:44:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 00:44:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 00:44:27 --> Final output sent to browser
DEBUG - 2015-02-14 00:44:27 --> Total execution time: 1.1521
DEBUG - 2015-02-14 00:59:28 --> Config Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Hooks Class Initialized
DEBUG - 2015-02-14 00:59:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 00:59:28 --> Utf8 Class Initialized
DEBUG - 2015-02-14 00:59:28 --> URI Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Router Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Output Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Security Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Input Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 00:59:28 --> Language Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Loader Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: url_helper
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: link_helper
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 00:59:28 --> CI_Session Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Session: Regenerate ID
DEBUG - 2015-02-14 00:59:28 --> CI_Session routines successfully run
DEBUG - 2015-02-14 00:59:28 --> Model Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Model Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Controller Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 00:59:28 --> Email Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: language_helper
DEBUG - 2015-02-14 00:59:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 00:59:28 --> Model Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Database Driver Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: date_helper
DEBUG - 2015-02-14 00:59:28 --> Helper loaded: form_helper
DEBUG - 2015-02-14 00:59:28 --> Form Validation Class Initialized
DEBUG - 2015-02-14 00:59:28 --> Model Class Initialized
DEBUG - 2015-02-14 00:59:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 00:59:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 00:59:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 00:59:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 00:59:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 00:59:29 --> Final output sent to browser
DEBUG - 2015-02-14 00:59:29 --> Total execution time: 1.1221
DEBUG - 2015-02-14 01:14:29 --> Config Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Hooks Class Initialized
DEBUG - 2015-02-14 01:14:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 01:14:29 --> Utf8 Class Initialized
DEBUG - 2015-02-14 01:14:29 --> URI Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Router Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Output Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Security Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Input Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 01:14:29 --> Language Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Loader Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: url_helper
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: link_helper
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 01:14:29 --> CI_Session Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Session: Regenerate ID
DEBUG - 2015-02-14 01:14:29 --> CI_Session routines successfully run
DEBUG - 2015-02-14 01:14:29 --> Model Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Model Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Controller Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 01:14:29 --> Email Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: language_helper
DEBUG - 2015-02-14 01:14:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 01:14:29 --> Model Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Database Driver Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: date_helper
DEBUG - 2015-02-14 01:14:29 --> Helper loaded: form_helper
DEBUG - 2015-02-14 01:14:29 --> Form Validation Class Initialized
DEBUG - 2015-02-14 01:14:29 --> Model Class Initialized
DEBUG - 2015-02-14 01:14:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 01:14:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 01:14:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 01:14:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 01:14:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 01:14:30 --> Final output sent to browser
DEBUG - 2015-02-14 01:14:30 --> Total execution time: 1.1311
DEBUG - 2015-02-14 01:29:31 --> Config Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Hooks Class Initialized
DEBUG - 2015-02-14 01:29:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 01:29:31 --> Utf8 Class Initialized
DEBUG - 2015-02-14 01:29:31 --> URI Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Router Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Output Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Security Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Input Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 01:29:31 --> Language Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Loader Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: url_helper
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: link_helper
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 01:29:31 --> CI_Session Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Session: Regenerate ID
DEBUG - 2015-02-14 01:29:31 --> CI_Session routines successfully run
DEBUG - 2015-02-14 01:29:31 --> Model Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Model Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Controller Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 01:29:31 --> Email Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: language_helper
DEBUG - 2015-02-14 01:29:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 01:29:31 --> Model Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Database Driver Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: date_helper
DEBUG - 2015-02-14 01:29:31 --> Helper loaded: form_helper
DEBUG - 2015-02-14 01:29:31 --> Form Validation Class Initialized
DEBUG - 2015-02-14 01:29:31 --> Model Class Initialized
DEBUG - 2015-02-14 01:29:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 01:29:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 01:29:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 01:29:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 01:29:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 01:29:32 --> Final output sent to browser
DEBUG - 2015-02-14 01:29:32 --> Total execution time: 1.0821
DEBUG - 2015-02-14 01:44:32 --> Config Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Hooks Class Initialized
DEBUG - 2015-02-14 01:44:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 01:44:32 --> Utf8 Class Initialized
DEBUG - 2015-02-14 01:44:32 --> URI Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Router Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Output Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Security Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Input Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 01:44:32 --> Language Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Loader Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 01:44:32 --> Helper loaded: url_helper
DEBUG - 2015-02-14 01:44:32 --> Helper loaded: link_helper
DEBUG - 2015-02-14 01:44:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 01:44:32 --> CI_Session Class Initialized
DEBUG - 2015-02-14 01:44:32 --> Session: Regenerate ID
DEBUG - 2015-02-14 01:44:32 --> CI_Session routines successfully run
DEBUG - 2015-02-14 01:44:33 --> Model Class Initialized
DEBUG - 2015-02-14 01:44:33 --> Model Class Initialized
DEBUG - 2015-02-14 01:44:33 --> Controller Class Initialized
DEBUG - 2015-02-14 01:44:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 01:44:33 --> Email Class Initialized
DEBUG - 2015-02-14 01:44:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 01:44:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 01:44:33 --> Helper loaded: language_helper
DEBUG - 2015-02-14 01:44:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 01:44:33 --> Model Class Initialized
DEBUG - 2015-02-14 01:44:33 --> Database Driver Class Initialized
DEBUG - 2015-02-14 01:44:33 --> Helper loaded: date_helper
DEBUG - 2015-02-14 01:44:33 --> Helper loaded: form_helper
DEBUG - 2015-02-14 01:44:33 --> Form Validation Class Initialized
DEBUG - 2015-02-14 01:44:33 --> Model Class Initialized
DEBUG - 2015-02-14 01:44:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 01:44:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 01:44:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 01:44:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 01:44:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 01:44:34 --> Final output sent to browser
DEBUG - 2015-02-14 01:44:34 --> Total execution time: 1.1271
DEBUG - 2015-02-14 01:59:34 --> Config Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Hooks Class Initialized
DEBUG - 2015-02-14 01:59:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 01:59:34 --> Utf8 Class Initialized
DEBUG - 2015-02-14 01:59:34 --> URI Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Router Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Output Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Security Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Input Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 01:59:34 --> Language Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Loader Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: url_helper
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: link_helper
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 01:59:34 --> CI_Session Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Session: Regenerate ID
DEBUG - 2015-02-14 01:59:34 --> CI_Session routines successfully run
DEBUG - 2015-02-14 01:59:34 --> Model Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Model Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Controller Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 01:59:34 --> Email Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 01:59:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 01:59:34 --> Model Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 01:59:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 01:59:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 01:59:34 --> Model Class Initialized
DEBUG - 2015-02-14 01:59:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 01:59:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 01:59:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 01:59:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 01:59:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 01:59:35 --> Final output sent to browser
DEBUG - 2015-02-14 01:59:35 --> Total execution time: 1.1561
DEBUG - 2015-02-14 02:14:35 --> Config Class Initialized
DEBUG - 2015-02-14 02:14:35 --> Hooks Class Initialized
DEBUG - 2015-02-14 02:14:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 02:14:35 --> Utf8 Class Initialized
DEBUG - 2015-02-14 02:14:35 --> URI Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Router Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Output Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Security Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Input Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 02:14:36 --> Language Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Loader Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: url_helper
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: link_helper
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 02:14:36 --> CI_Session Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Session: Regenerate ID
DEBUG - 2015-02-14 02:14:36 --> CI_Session routines successfully run
DEBUG - 2015-02-14 02:14:36 --> Model Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Model Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Controller Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 02:14:36 --> Email Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: language_helper
DEBUG - 2015-02-14 02:14:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 02:14:36 --> Model Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Database Driver Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: date_helper
DEBUG - 2015-02-14 02:14:36 --> Helper loaded: form_helper
DEBUG - 2015-02-14 02:14:36 --> Form Validation Class Initialized
DEBUG - 2015-02-14 02:14:36 --> Model Class Initialized
DEBUG - 2015-02-14 02:14:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 02:14:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 02:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 02:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 02:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 02:14:37 --> Final output sent to browser
DEBUG - 2015-02-14 02:14:37 --> Total execution time: 1.1341
DEBUG - 2015-02-14 02:29:37 --> Config Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Hooks Class Initialized
DEBUG - 2015-02-14 02:29:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 02:29:37 --> Utf8 Class Initialized
DEBUG - 2015-02-14 02:29:37 --> URI Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Router Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Output Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Security Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Input Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 02:29:37 --> Language Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Loader Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: url_helper
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: link_helper
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 02:29:37 --> CI_Session Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Session: Regenerate ID
DEBUG - 2015-02-14 02:29:37 --> CI_Session routines successfully run
DEBUG - 2015-02-14 02:29:37 --> Model Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Model Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Controller Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 02:29:37 --> Email Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: language_helper
DEBUG - 2015-02-14 02:29:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 02:29:37 --> Model Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Database Driver Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: date_helper
DEBUG - 2015-02-14 02:29:37 --> Helper loaded: form_helper
DEBUG - 2015-02-14 02:29:37 --> Form Validation Class Initialized
DEBUG - 2015-02-14 02:29:37 --> Model Class Initialized
DEBUG - 2015-02-14 02:29:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 02:29:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 02:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 02:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 02:29:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 02:29:38 --> Final output sent to browser
DEBUG - 2015-02-14 02:29:38 --> Total execution time: 1.1011
DEBUG - 2015-02-14 02:44:39 --> Config Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 02:44:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 02:44:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 02:44:39 --> URI Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Router Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Output Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Security Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Input Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 02:44:39 --> Language Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Loader Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: url_helper
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: link_helper
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 02:44:39 --> CI_Session Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Session: Regenerate ID
DEBUG - 2015-02-14 02:44:39 --> CI_Session routines successfully run
DEBUG - 2015-02-14 02:44:39 --> Model Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Model Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Controller Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 02:44:39 --> Email Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: language_helper
DEBUG - 2015-02-14 02:44:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 02:44:39 --> Model Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Database Driver Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: date_helper
DEBUG - 2015-02-14 02:44:39 --> Helper loaded: form_helper
DEBUG - 2015-02-14 02:44:39 --> Form Validation Class Initialized
DEBUG - 2015-02-14 02:44:39 --> Model Class Initialized
DEBUG - 2015-02-14 02:44:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 02:44:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 02:44:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 02:44:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 02:44:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 02:44:40 --> Final output sent to browser
DEBUG - 2015-02-14 02:44:40 --> Total execution time: 1.1441
DEBUG - 2015-02-14 02:59:40 --> Config Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Hooks Class Initialized
DEBUG - 2015-02-14 02:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 02:59:40 --> Utf8 Class Initialized
DEBUG - 2015-02-14 02:59:40 --> URI Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Router Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Output Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Security Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Input Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 02:59:40 --> Language Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Loader Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 02:59:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Session: Regenerate ID
DEBUG - 2015-02-14 02:59:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 02:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Controller Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 02:59:40 --> Email Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 02:59:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 02:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 02:59:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 02:59:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 02:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 02:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 02:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 02:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 02:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 02:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 02:59:41 --> Final output sent to browser
DEBUG - 2015-02-14 02:59:41 --> Total execution time: 1.0831
DEBUG - 2015-02-14 03:14:42 --> Config Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 03:14:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 03:14:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 03:14:42 --> URI Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Router Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Output Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Security Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Input Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 03:14:42 --> Language Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Loader Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 03:14:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Session: Regenerate ID
DEBUG - 2015-02-14 03:14:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 03:14:42 --> Model Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Model Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Controller Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 03:14:42 --> Email Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: language_helper
DEBUG - 2015-02-14 03:14:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 03:14:42 --> Model Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Database Driver Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: date_helper
DEBUG - 2015-02-14 03:14:42 --> Helper loaded: form_helper
DEBUG - 2015-02-14 03:14:42 --> Form Validation Class Initialized
DEBUG - 2015-02-14 03:14:42 --> Model Class Initialized
DEBUG - 2015-02-14 03:14:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 03:14:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 03:14:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 03:14:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 03:14:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 03:14:43 --> Final output sent to browser
DEBUG - 2015-02-14 03:14:43 --> Total execution time: 1.1501
DEBUG - 2015-02-14 03:29:43 --> Config Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Hooks Class Initialized
DEBUG - 2015-02-14 03:29:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 03:29:43 --> Utf8 Class Initialized
DEBUG - 2015-02-14 03:29:43 --> URI Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Router Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Output Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Security Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Input Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 03:29:43 --> Language Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Loader Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: url_helper
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: link_helper
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 03:29:43 --> CI_Session Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Session: Regenerate ID
DEBUG - 2015-02-14 03:29:43 --> CI_Session routines successfully run
DEBUG - 2015-02-14 03:29:43 --> Model Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Model Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Controller Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 03:29:43 --> Email Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: language_helper
DEBUG - 2015-02-14 03:29:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 03:29:43 --> Model Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Database Driver Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: date_helper
DEBUG - 2015-02-14 03:29:43 --> Helper loaded: form_helper
DEBUG - 2015-02-14 03:29:43 --> Form Validation Class Initialized
DEBUG - 2015-02-14 03:29:43 --> Model Class Initialized
DEBUG - 2015-02-14 03:29:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 03:29:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 03:29:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 03:29:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 03:29:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 03:29:44 --> Final output sent to browser
DEBUG - 2015-02-14 03:29:44 --> Total execution time: 1.0881
DEBUG - 2015-02-14 03:44:45 --> Config Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Hooks Class Initialized
DEBUG - 2015-02-14 03:44:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 03:44:45 --> Utf8 Class Initialized
DEBUG - 2015-02-14 03:44:45 --> URI Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Router Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Output Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Security Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Input Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 03:44:45 --> Language Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Loader Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: url_helper
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: link_helper
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 03:44:45 --> CI_Session Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Session: Regenerate ID
DEBUG - 2015-02-14 03:44:45 --> CI_Session routines successfully run
DEBUG - 2015-02-14 03:44:45 --> Model Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Model Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Controller Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 03:44:45 --> Email Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: language_helper
DEBUG - 2015-02-14 03:44:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 03:44:45 --> Model Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Database Driver Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: date_helper
DEBUG - 2015-02-14 03:44:45 --> Helper loaded: form_helper
DEBUG - 2015-02-14 03:44:45 --> Form Validation Class Initialized
DEBUG - 2015-02-14 03:44:45 --> Model Class Initialized
DEBUG - 2015-02-14 03:44:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 03:44:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 03:44:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 03:44:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 03:44:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 03:44:46 --> Final output sent to browser
DEBUG - 2015-02-14 03:44:46 --> Total execution time: 1.1121
DEBUG - 2015-02-14 03:59:46 --> Config Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Hooks Class Initialized
DEBUG - 2015-02-14 03:59:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 03:59:46 --> Utf8 Class Initialized
DEBUG - 2015-02-14 03:59:46 --> URI Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Router Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Output Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Security Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Input Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 03:59:46 --> Language Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Loader Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: url_helper
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: link_helper
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 03:59:46 --> CI_Session Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Session: Regenerate ID
DEBUG - 2015-02-14 03:59:46 --> CI_Session routines successfully run
DEBUG - 2015-02-14 03:59:46 --> Model Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Model Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Controller Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 03:59:46 --> Email Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: language_helper
DEBUG - 2015-02-14 03:59:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 03:59:46 --> Model Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Database Driver Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: date_helper
DEBUG - 2015-02-14 03:59:46 --> Helper loaded: form_helper
DEBUG - 2015-02-14 03:59:46 --> Form Validation Class Initialized
DEBUG - 2015-02-14 03:59:46 --> Model Class Initialized
DEBUG - 2015-02-14 03:59:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 03:59:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 03:59:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 03:59:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 03:59:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 03:59:47 --> Final output sent to browser
DEBUG - 2015-02-14 03:59:47 --> Total execution time: 1.2281
DEBUG - 2015-02-14 04:14:48 --> Config Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 04:14:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 04:14:48 --> URI Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Router Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Output Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Security Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Input Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 04:14:48 --> Language Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Loader Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: url_helper
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 04:14:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Session: Regenerate ID
DEBUG - 2015-02-14 04:14:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 04:14:48 --> Model Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Model Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Controller Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 04:14:48 --> Email Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: language_helper
DEBUG - 2015-02-14 04:14:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 04:14:48 --> Model Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Database Driver Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: date_helper
DEBUG - 2015-02-14 04:14:48 --> Helper loaded: form_helper
DEBUG - 2015-02-14 04:14:48 --> Form Validation Class Initialized
DEBUG - 2015-02-14 04:14:48 --> Model Class Initialized
DEBUG - 2015-02-14 04:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 04:14:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 04:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 04:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 04:14:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 04:14:49 --> Final output sent to browser
DEBUG - 2015-02-14 04:14:49 --> Total execution time: 1.2361
DEBUG - 2015-02-14 04:29:49 --> Config Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Hooks Class Initialized
DEBUG - 2015-02-14 04:29:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 04:29:49 --> Utf8 Class Initialized
DEBUG - 2015-02-14 04:29:49 --> URI Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Router Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Output Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Security Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Input Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 04:29:49 --> Language Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Loader Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 04:29:49 --> Helper loaded: url_helper
DEBUG - 2015-02-14 04:29:49 --> Helper loaded: link_helper
DEBUG - 2015-02-14 04:29:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 04:29:49 --> CI_Session Class Initialized
DEBUG - 2015-02-14 04:29:49 --> Session: Regenerate ID
DEBUG - 2015-02-14 04:29:49 --> CI_Session routines successfully run
DEBUG - 2015-02-14 04:29:50 --> Model Class Initialized
DEBUG - 2015-02-14 04:29:50 --> Model Class Initialized
DEBUG - 2015-02-14 04:29:50 --> Controller Class Initialized
DEBUG - 2015-02-14 04:29:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 04:29:50 --> Email Class Initialized
DEBUG - 2015-02-14 04:29:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 04:29:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 04:29:50 --> Helper loaded: language_helper
DEBUG - 2015-02-14 04:29:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 04:29:50 --> Model Class Initialized
DEBUG - 2015-02-14 04:29:50 --> Database Driver Class Initialized
DEBUG - 2015-02-14 04:29:50 --> Helper loaded: date_helper
DEBUG - 2015-02-14 04:29:50 --> Helper loaded: form_helper
DEBUG - 2015-02-14 04:29:50 --> Form Validation Class Initialized
DEBUG - 2015-02-14 04:29:50 --> Model Class Initialized
DEBUG - 2015-02-14 04:29:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 04:29:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 04:29:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 04:29:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 04:29:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 04:29:50 --> Final output sent to browser
DEBUG - 2015-02-14 04:29:50 --> Total execution time: 1.0661
DEBUG - 2015-02-14 04:44:51 --> Config Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Hooks Class Initialized
DEBUG - 2015-02-14 04:44:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 04:44:51 --> Utf8 Class Initialized
DEBUG - 2015-02-14 04:44:51 --> URI Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Router Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Output Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Security Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Input Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 04:44:51 --> Language Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Loader Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: url_helper
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: link_helper
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 04:44:51 --> CI_Session Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Session: Regenerate ID
DEBUG - 2015-02-14 04:44:51 --> CI_Session routines successfully run
DEBUG - 2015-02-14 04:44:51 --> Model Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Model Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Controller Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 04:44:51 --> Email Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: language_helper
DEBUG - 2015-02-14 04:44:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 04:44:51 --> Model Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Database Driver Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: date_helper
DEBUG - 2015-02-14 04:44:51 --> Helper loaded: form_helper
DEBUG - 2015-02-14 04:44:51 --> Form Validation Class Initialized
DEBUG - 2015-02-14 04:44:51 --> Model Class Initialized
DEBUG - 2015-02-14 04:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 04:44:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 04:44:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 04:44:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 04:44:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 04:44:52 --> Final output sent to browser
DEBUG - 2015-02-14 04:44:52 --> Total execution time: 1.1301
DEBUG - 2015-02-14 04:59:53 --> Config Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Hooks Class Initialized
DEBUG - 2015-02-14 04:59:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 04:59:53 --> Utf8 Class Initialized
DEBUG - 2015-02-14 04:59:53 --> URI Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Router Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Output Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Security Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Input Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 04:59:53 --> Language Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Loader Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: url_helper
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: link_helper
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 04:59:53 --> CI_Session Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Session: Regenerate ID
DEBUG - 2015-02-14 04:59:53 --> CI_Session routines successfully run
DEBUG - 2015-02-14 04:59:53 --> Model Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Model Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Controller Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 04:59:53 --> Email Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: language_helper
DEBUG - 2015-02-14 04:59:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 04:59:53 --> Model Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Database Driver Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: date_helper
DEBUG - 2015-02-14 04:59:53 --> Helper loaded: form_helper
DEBUG - 2015-02-14 04:59:53 --> Form Validation Class Initialized
DEBUG - 2015-02-14 04:59:53 --> Model Class Initialized
DEBUG - 2015-02-14 04:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 04:59:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 04:59:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 04:59:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 04:59:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 04:59:54 --> Final output sent to browser
DEBUG - 2015-02-14 04:59:54 --> Total execution time: 1.1121
DEBUG - 2015-02-14 05:14:54 --> Config Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Hooks Class Initialized
DEBUG - 2015-02-14 05:14:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 05:14:54 --> Utf8 Class Initialized
DEBUG - 2015-02-14 05:14:54 --> URI Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Router Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Output Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Security Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Input Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 05:14:54 --> Language Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Loader Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: url_helper
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: link_helper
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 05:14:54 --> CI_Session Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Session: Regenerate ID
DEBUG - 2015-02-14 05:14:54 --> CI_Session routines successfully run
DEBUG - 2015-02-14 05:14:54 --> Model Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Model Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Controller Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 05:14:54 --> Email Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: language_helper
DEBUG - 2015-02-14 05:14:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 05:14:54 --> Model Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Database Driver Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: date_helper
DEBUG - 2015-02-14 05:14:54 --> Helper loaded: form_helper
DEBUG - 2015-02-14 05:14:54 --> Form Validation Class Initialized
DEBUG - 2015-02-14 05:14:54 --> Model Class Initialized
DEBUG - 2015-02-14 05:14:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 05:14:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 05:14:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 05:14:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 05:14:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 05:14:55 --> Final output sent to browser
DEBUG - 2015-02-14 05:14:55 --> Total execution time: 1.2271
DEBUG - 2015-02-14 05:29:56 --> Config Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Hooks Class Initialized
DEBUG - 2015-02-14 05:29:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 05:29:56 --> Utf8 Class Initialized
DEBUG - 2015-02-14 05:29:56 --> URI Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Router Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Output Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Security Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Input Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 05:29:56 --> Language Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Loader Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: url_helper
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: link_helper
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 05:29:56 --> CI_Session Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Session: Regenerate ID
DEBUG - 2015-02-14 05:29:56 --> CI_Session routines successfully run
DEBUG - 2015-02-14 05:29:56 --> Model Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Model Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Controller Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 05:29:56 --> Email Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: language_helper
DEBUG - 2015-02-14 05:29:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 05:29:56 --> Model Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Database Driver Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: date_helper
DEBUG - 2015-02-14 05:29:56 --> Helper loaded: form_helper
DEBUG - 2015-02-14 05:29:56 --> Form Validation Class Initialized
DEBUG - 2015-02-14 05:29:56 --> Model Class Initialized
DEBUG - 2015-02-14 05:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 05:29:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 05:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 05:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 05:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 05:29:57 --> Final output sent to browser
DEBUG - 2015-02-14 05:29:57 --> Total execution time: 1.0991
DEBUG - 2015-02-14 05:44:57 --> Config Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 05:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 05:44:57 --> Utf8 Class Initialized
DEBUG - 2015-02-14 05:44:57 --> URI Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Router Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Output Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Security Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Input Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 05:44:57 --> Language Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Loader Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 05:44:57 --> Helper loaded: url_helper
DEBUG - 2015-02-14 05:44:57 --> Helper loaded: link_helper
DEBUG - 2015-02-14 05:44:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 05:44:57 --> CI_Session Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Session: Regenerate ID
DEBUG - 2015-02-14 05:44:57 --> CI_Session routines successfully run
DEBUG - 2015-02-14 05:44:57 --> Model Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Model Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Controller Class Initialized
DEBUG - 2015-02-14 05:44:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 05:44:57 --> Email Class Initialized
DEBUG - 2015-02-14 05:44:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 05:44:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 05:44:58 --> Helper loaded: language_helper
DEBUG - 2015-02-14 05:44:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 05:44:58 --> Model Class Initialized
DEBUG - 2015-02-14 05:44:58 --> Database Driver Class Initialized
DEBUG - 2015-02-14 05:44:58 --> Helper loaded: date_helper
DEBUG - 2015-02-14 05:44:58 --> Helper loaded: form_helper
DEBUG - 2015-02-14 05:44:58 --> Form Validation Class Initialized
DEBUG - 2015-02-14 05:44:58 --> Model Class Initialized
DEBUG - 2015-02-14 05:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 05:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 05:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 05:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 05:44:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 05:44:58 --> Final output sent to browser
DEBUG - 2015-02-14 05:44:58 --> Total execution time: 1.2011
DEBUG - 2015-02-14 05:59:59 --> Config Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Hooks Class Initialized
DEBUG - 2015-02-14 05:59:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 05:59:59 --> Utf8 Class Initialized
DEBUG - 2015-02-14 05:59:59 --> URI Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Router Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Output Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Security Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Input Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 05:59:59 --> Language Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Loader Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: url_helper
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: link_helper
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 05:59:59 --> CI_Session Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Session: Regenerate ID
DEBUG - 2015-02-14 05:59:59 --> CI_Session routines successfully run
DEBUG - 2015-02-14 05:59:59 --> Model Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Model Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Controller Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 05:59:59 --> Email Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: language_helper
DEBUG - 2015-02-14 05:59:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 05:59:59 --> Model Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Database Driver Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: date_helper
DEBUG - 2015-02-14 05:59:59 --> Helper loaded: form_helper
DEBUG - 2015-02-14 05:59:59 --> Form Validation Class Initialized
DEBUG - 2015-02-14 05:59:59 --> Model Class Initialized
DEBUG - 2015-02-14 05:59:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 05:59:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 06:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 06:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 06:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 06:00:00 --> Final output sent to browser
DEBUG - 2015-02-14 06:00:00 --> Total execution time: 1.1611
DEBUG - 2015-02-14 06:15:01 --> Config Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Hooks Class Initialized
DEBUG - 2015-02-14 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 06:15:01 --> Utf8 Class Initialized
DEBUG - 2015-02-14 06:15:01 --> URI Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Router Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Output Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Security Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Input Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 06:15:01 --> Language Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Loader Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 06:15:01 --> CI_Session Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Session: Regenerate ID
DEBUG - 2015-02-14 06:15:01 --> CI_Session routines successfully run
DEBUG - 2015-02-14 06:15:01 --> Model Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Model Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Controller Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 06:15:01 --> Email Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: language_helper
DEBUG - 2015-02-14 06:15:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 06:15:01 --> Model Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Database Driver Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: date_helper
DEBUG - 2015-02-14 06:15:01 --> Helper loaded: form_helper
DEBUG - 2015-02-14 06:15:01 --> Form Validation Class Initialized
DEBUG - 2015-02-14 06:15:01 --> Model Class Initialized
DEBUG - 2015-02-14 06:15:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 06:15:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 06:15:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 06:15:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 06:15:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 06:15:02 --> Final output sent to browser
DEBUG - 2015-02-14 06:15:02 --> Total execution time: 1.0471
DEBUG - 2015-02-14 06:30:02 --> Config Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Hooks Class Initialized
DEBUG - 2015-02-14 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 06:30:02 --> Utf8 Class Initialized
DEBUG - 2015-02-14 06:30:02 --> URI Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Router Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Output Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Security Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Input Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 06:30:02 --> Language Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Loader Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: url_helper
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: link_helper
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 06:30:02 --> CI_Session Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Session: Regenerate ID
DEBUG - 2015-02-14 06:30:02 --> CI_Session routines successfully run
DEBUG - 2015-02-14 06:30:02 --> Model Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Model Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Controller Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 06:30:02 --> Email Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: language_helper
DEBUG - 2015-02-14 06:30:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 06:30:02 --> Model Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Database Driver Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: date_helper
DEBUG - 2015-02-14 06:30:02 --> Helper loaded: form_helper
DEBUG - 2015-02-14 06:30:02 --> Form Validation Class Initialized
DEBUG - 2015-02-14 06:30:02 --> Model Class Initialized
DEBUG - 2015-02-14 06:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 06:30:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 06:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 06:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 06:30:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 06:30:03 --> Final output sent to browser
DEBUG - 2015-02-14 06:30:03 --> Total execution time: 1.1511
DEBUG - 2015-02-14 06:45:04 --> Config Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Hooks Class Initialized
DEBUG - 2015-02-14 06:45:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 06:45:04 --> Utf8 Class Initialized
DEBUG - 2015-02-14 06:45:04 --> URI Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Router Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Output Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Security Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Input Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 06:45:04 --> Language Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Loader Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: url_helper
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: link_helper
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 06:45:04 --> CI_Session Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Session: Regenerate ID
DEBUG - 2015-02-14 06:45:04 --> CI_Session routines successfully run
DEBUG - 2015-02-14 06:45:04 --> Model Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Model Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Controller Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 06:45:04 --> Email Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: language_helper
DEBUG - 2015-02-14 06:45:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 06:45:04 --> Model Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Database Driver Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: date_helper
DEBUG - 2015-02-14 06:45:04 --> Helper loaded: form_helper
DEBUG - 2015-02-14 06:45:04 --> Form Validation Class Initialized
DEBUG - 2015-02-14 06:45:04 --> Model Class Initialized
DEBUG - 2015-02-14 06:45:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 06:45:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 06:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 06:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 06:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 06:45:05 --> Final output sent to browser
DEBUG - 2015-02-14 06:45:05 --> Total execution time: 1.0661
DEBUG - 2015-02-14 07:00:05 --> Config Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Hooks Class Initialized
DEBUG - 2015-02-14 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 07:00:05 --> Utf8 Class Initialized
DEBUG - 2015-02-14 07:00:05 --> URI Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Router Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Output Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Security Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Input Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 07:00:05 --> Language Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Loader Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: url_helper
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: link_helper
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 07:00:05 --> CI_Session Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Session: Regenerate ID
DEBUG - 2015-02-14 07:00:05 --> CI_Session routines successfully run
DEBUG - 2015-02-14 07:00:05 --> Model Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Model Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Controller Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 07:00:05 --> Email Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: language_helper
DEBUG - 2015-02-14 07:00:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 07:00:05 --> Model Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Database Driver Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: date_helper
DEBUG - 2015-02-14 07:00:05 --> Helper loaded: form_helper
DEBUG - 2015-02-14 07:00:05 --> Form Validation Class Initialized
DEBUG - 2015-02-14 07:00:05 --> Model Class Initialized
DEBUG - 2015-02-14 07:00:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 07:00:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 07:00:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 07:00:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 07:00:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 07:00:06 --> Final output sent to browser
DEBUG - 2015-02-14 07:00:06 --> Total execution time: 1.0871
DEBUG - 2015-02-14 07:15:07 --> Config Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Hooks Class Initialized
DEBUG - 2015-02-14 07:15:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 07:15:07 --> Utf8 Class Initialized
DEBUG - 2015-02-14 07:15:07 --> URI Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Router Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Output Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Security Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Input Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 07:15:07 --> Language Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Loader Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: url_helper
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: link_helper
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 07:15:07 --> CI_Session Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Session: Regenerate ID
DEBUG - 2015-02-14 07:15:07 --> CI_Session routines successfully run
DEBUG - 2015-02-14 07:15:07 --> Model Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Model Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Controller Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 07:15:07 --> Email Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: language_helper
DEBUG - 2015-02-14 07:15:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 07:15:07 --> Model Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Database Driver Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: date_helper
DEBUG - 2015-02-14 07:15:07 --> Helper loaded: form_helper
DEBUG - 2015-02-14 07:15:07 --> Form Validation Class Initialized
DEBUG - 2015-02-14 07:15:07 --> Model Class Initialized
DEBUG - 2015-02-14 07:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 07:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 07:15:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 07:15:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 07:15:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 07:15:08 --> Final output sent to browser
DEBUG - 2015-02-14 07:15:08 --> Total execution time: 1.0761
DEBUG - 2015-02-14 07:30:08 --> Config Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Hooks Class Initialized
DEBUG - 2015-02-14 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 07:30:08 --> Utf8 Class Initialized
DEBUG - 2015-02-14 07:30:08 --> URI Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Router Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Output Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Security Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Input Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 07:30:08 --> Language Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Loader Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: url_helper
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: link_helper
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 07:30:08 --> CI_Session Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Session: Regenerate ID
DEBUG - 2015-02-14 07:30:08 --> CI_Session routines successfully run
DEBUG - 2015-02-14 07:30:08 --> Model Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Model Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Controller Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 07:30:08 --> Email Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: language_helper
DEBUG - 2015-02-14 07:30:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 07:30:08 --> Model Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Database Driver Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: date_helper
DEBUG - 2015-02-14 07:30:08 --> Helper loaded: form_helper
DEBUG - 2015-02-14 07:30:08 --> Form Validation Class Initialized
DEBUG - 2015-02-14 07:30:08 --> Model Class Initialized
DEBUG - 2015-02-14 07:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 07:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 07:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 07:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 07:30:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 07:30:09 --> Final output sent to browser
DEBUG - 2015-02-14 07:30:09 --> Total execution time: 1.0761
DEBUG - 2015-02-14 07:45:10 --> Config Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Hooks Class Initialized
DEBUG - 2015-02-14 07:45:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 07:45:10 --> Utf8 Class Initialized
DEBUG - 2015-02-14 07:45:10 --> URI Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Router Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Output Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Security Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Input Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 07:45:10 --> Language Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Loader Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: url_helper
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: link_helper
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 07:45:10 --> CI_Session Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Session: Regenerate ID
DEBUG - 2015-02-14 07:45:10 --> CI_Session routines successfully run
DEBUG - 2015-02-14 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Controller Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 07:45:10 --> Email Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: language_helper
DEBUG - 2015-02-14 07:45:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Database Driver Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: date_helper
DEBUG - 2015-02-14 07:45:10 --> Helper loaded: form_helper
DEBUG - 2015-02-14 07:45:10 --> Form Validation Class Initialized
DEBUG - 2015-02-14 07:45:10 --> Model Class Initialized
DEBUG - 2015-02-14 07:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 07:45:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 07:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 07:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 07:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 07:45:11 --> Final output sent to browser
DEBUG - 2015-02-14 07:45:11 --> Total execution time: 1.1441
DEBUG - 2015-02-14 08:00:11 --> Config Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:00:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:00:11 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:00:11 --> URI Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Router Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Output Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Security Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Input Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:00:11 --> Language Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Loader Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:00:11 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:00:11 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:00:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:00:11 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:00:11 --> Session: Regenerate ID
DEBUG - 2015-02-14 08:00:11 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:00:12 --> Model Class Initialized
DEBUG - 2015-02-14 08:00:12 --> Model Class Initialized
DEBUG - 2015-02-14 08:00:12 --> Controller Class Initialized
DEBUG - 2015-02-14 08:00:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:00:12 --> Email Class Initialized
DEBUG - 2015-02-14 08:00:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:00:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:00:12 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:00:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:00:12 --> Model Class Initialized
DEBUG - 2015-02-14 08:00:12 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:00:12 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:00:12 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:00:12 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:00:12 --> Model Class Initialized
DEBUG - 2015-02-14 08:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 08:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 08:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 08:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 08:00:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 08:00:13 --> Final output sent to browser
DEBUG - 2015-02-14 08:00:13 --> Total execution time: 1.1291
DEBUG - 2015-02-14 08:15:13 --> Config Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:15:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:15:13 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:15:13 --> URI Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Router Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Output Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Security Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Input Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:15:13 --> Language Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Loader Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:15:13 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Session: Regenerate ID
DEBUG - 2015-02-14 08:15:13 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:15:13 --> Model Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Model Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Controller Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:15:13 --> Email Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:15:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:15:13 --> Model Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:15:13 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:15:13 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:15:13 --> Model Class Initialized
DEBUG - 2015-02-14 08:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 08:15:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 08:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 08:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 08:15:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 08:15:14 --> Final output sent to browser
DEBUG - 2015-02-14 08:15:14 --> Total execution time: 1.1081
DEBUG - 2015-02-14 08:30:14 --> Config Class Initialized
DEBUG - 2015-02-14 08:30:14 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:30:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:30:14 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:30:14 --> URI Class Initialized
DEBUG - 2015-02-14 08:30:14 --> Router Class Initialized
DEBUG - 2015-02-14 08:30:14 --> Output Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Security Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Input Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:30:15 --> Language Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Loader Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:30:15 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Session: Regenerate ID
DEBUG - 2015-02-14 08:30:15 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:30:15 --> Model Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Model Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Controller Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:30:15 --> Email Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:30:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:30:15 --> Model Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:30:15 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:30:15 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:30:15 --> Model Class Initialized
DEBUG - 2015-02-14 08:30:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 08:30:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 08:30:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 08:30:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 08:30:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 08:30:16 --> Final output sent to browser
DEBUG - 2015-02-14 08:30:16 --> Total execution time: 1.1321
DEBUG - 2015-02-14 08:45:16 --> Config Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:45:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:45:16 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:45:16 --> URI Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Router Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Output Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Security Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Input Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:45:16 --> Language Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Loader Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:45:16 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Session: Regenerate ID
DEBUG - 2015-02-14 08:45:16 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:45:16 --> Model Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Model Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Controller Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:45:16 --> Email Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:45:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:45:16 --> Model Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:45:16 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:45:16 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:45:16 --> Model Class Initialized
DEBUG - 2015-02-14 08:45:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 08:45:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 08:45:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-14 08:45:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 08:45:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 08:45:17 --> Final output sent to browser
DEBUG - 2015-02-14 08:45:17 --> Total execution time: 1.2321
DEBUG - 2015-02-14 08:48:30 --> Config Class Initialized
DEBUG - 2015-02-14 08:48:30 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:48:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:48:30 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:48:30 --> URI Class Initialized
DEBUG - 2015-02-14 08:48:30 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:48:30 --> Router Class Initialized
DEBUG - 2015-02-14 08:48:30 --> Output Class Initialized
DEBUG - 2015-02-14 08:48:30 --> Security Class Initialized
DEBUG - 2015-02-14 08:48:30 --> Input Class Initialized
DEBUG - 2015-02-14 08:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:48:30 --> Language Class Initialized
DEBUG - 2015-02-14 08:48:30 --> Loader Class Initialized
DEBUG - 2015-02-14 08:48:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:48:30 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:48:30 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:48:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:48:30 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:48:30 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:48:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Controller Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:48:31 --> Email Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:48:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:48:31 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:48:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:48:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:48:31 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:48:31 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:48:31 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:48:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:48:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:48:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:48:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:48:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:48:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:48:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:48:32 --> Final output sent to browser
DEBUG - 2015-02-14 08:48:32 --> Total execution time: 1.6042
DEBUG - 2015-02-14 08:49:44 --> Config Class Initialized
DEBUG - 2015-02-14 08:49:44 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:49:45 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:49:45 --> URI Class Initialized
DEBUG - 2015-02-14 08:49:45 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:49:45 --> Router Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Output Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Security Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Input Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:49:45 --> Language Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Loader Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:49:45 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:49:45 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:49:45 --> Model Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Model Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Controller Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:49:45 --> Email Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:49:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:49:45 --> Model Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:49:45 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:49:45 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Model Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:49:45 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Model Class Initialized
DEBUG - 2015-02-14 08:49:45 --> Model Class Initialized
DEBUG - 2015-02-14 08:49:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:49:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:49:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:49:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:49:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:49:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:49:46 --> Final output sent to browser
DEBUG - 2015-02-14 08:49:46 --> Total execution time: 1.5362
DEBUG - 2015-02-14 08:50:17 --> Config Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:50:17 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:50:17 --> URI Class Initialized
DEBUG - 2015-02-14 08:50:17 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:50:17 --> Router Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Output Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Security Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Input Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:50:17 --> Language Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Loader Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:50:17 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Session: Regenerate ID
DEBUG - 2015-02-14 08:50:17 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:50:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Controller Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:50:17 --> Email Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:50:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:50:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:50:17 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:50:17 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:50:17 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:50:18 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:18 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:50:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:50:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:50:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:50:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:50:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:50:19 --> Final output sent to browser
DEBUG - 2015-02-14 08:50:19 --> Total execution time: 1.4531
DEBUG - 2015-02-14 08:50:35 --> Config Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:50:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:50:35 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:50:35 --> URI Class Initialized
DEBUG - 2015-02-14 08:50:35 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:50:35 --> Router Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Output Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Security Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Input Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:50:35 --> Language Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Loader Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:50:35 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:50:35 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:50:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Controller Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:50:35 --> Email Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:50:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:50:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:50:35 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:50:35 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:50:35 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:50:36 --> Final output sent to browser
DEBUG - 2015-02-14 08:50:36 --> Total execution time: 1.5852
DEBUG - 2015-02-14 08:51:09 --> Config Class Initialized
DEBUG - 2015-02-14 08:51:09 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:51:10 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:51:10 --> URI Class Initialized
DEBUG - 2015-02-14 08:51:10 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:51:10 --> Router Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Output Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Security Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Input Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:51:10 --> Language Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Loader Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:51:10 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:51:10 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Controller Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:51:10 --> Email Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:51:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:51:10 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:51:10 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:51:10 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:51:11 --> Final output sent to browser
DEBUG - 2015-02-14 08:51:11 --> Total execution time: 1.5252
DEBUG - 2015-02-14 08:51:40 --> Config Class Initialized
DEBUG - 2015-02-14 08:51:40 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:51:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:51:40 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:51:40 --> URI Class Initialized
DEBUG - 2015-02-14 08:51:40 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:51:40 --> Router Class Initialized
DEBUG - 2015-02-14 08:51:40 --> Output Class Initialized
DEBUG - 2015-02-14 08:51:40 --> Security Class Initialized
DEBUG - 2015-02-14 08:51:40 --> Input Class Initialized
DEBUG - 2015-02-14 08:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:51:40 --> Language Class Initialized
DEBUG - 2015-02-14 08:51:40 --> Loader Class Initialized
DEBUG - 2015-02-14 08:51:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:51:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:51:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:51:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:51:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:51:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:51:41 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Controller Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:51:41 --> Email Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:51:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:51:41 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:51:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:51:41 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:51:41 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:51:41 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:51:41 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:41 --> Model Class Initialized
DEBUG - 2015-02-14 08:51:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:51:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:51:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:51:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:51:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:51:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:51:42 --> Final output sent to browser
DEBUG - 2015-02-14 08:51:42 --> Total execution time: 1.4641
DEBUG - 2015-02-14 08:52:11 --> Config Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:52:11 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:52:11 --> URI Class Initialized
DEBUG - 2015-02-14 08:52:11 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:52:11 --> Router Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Output Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Security Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Input Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:52:11 --> Language Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Loader Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:52:11 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:52:11 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:52:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:52:11 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:52:11 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:52:11 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Controller Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:52:11 --> Email Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:52:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:52:11 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:52:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:52:11 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:11 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:52:12 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:52:12 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:52:12 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:52:12 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:52:12 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:52:12 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:12 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:52:13 --> Final output sent to browser
DEBUG - 2015-02-14 08:52:13 --> Total execution time: 1.5312
DEBUG - 2015-02-14 08:52:29 --> Config Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:52:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:52:29 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:52:29 --> URI Class Initialized
DEBUG - 2015-02-14 08:52:29 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:52:29 --> Router Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Output Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Security Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Input Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:52:29 --> Language Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Loader Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:52:29 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:52:29 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:52:29 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Controller Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:52:29 --> Email Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:52:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:52:29 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:52:29 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:52:29 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:52:29 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:52:30 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:30 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:52:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:52:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:52:31 --> Final output sent to browser
DEBUG - 2015-02-14 08:52:31 --> Total execution time: 1.5052
DEBUG - 2015-02-14 08:52:42 --> Config Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:52:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:52:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:52:42 --> URI Class Initialized
DEBUG - 2015-02-14 08:52:42 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:52:42 --> Router Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Output Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Security Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Input Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:52:42 --> Language Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Loader Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:52:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:52:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:52:42 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Controller Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:52:42 --> Email Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:52:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:52:42 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:52:42 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:52:42 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:52:42 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 08:52:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:52:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:52:44 --> Final output sent to browser
DEBUG - 2015-02-14 08:52:44 --> Total execution time: 1.5052
DEBUG - 2015-02-14 08:53:01 --> Config Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:53:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:53:01 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:53:01 --> URI Class Initialized
DEBUG - 2015-02-14 08:53:01 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:53:01 --> Router Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Output Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Security Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Input Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:53:01 --> Language Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Loader Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:53:01 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:53:01 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:53:01 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Controller Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:53:01 --> Email Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:53:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:53:01 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:53:01 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:53:01 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:53:01 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:53:02 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:02 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:53:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:53:03 --> Final output sent to browser
DEBUG - 2015-02-14 08:53:03 --> Total execution time: 1.5832
DEBUG - 2015-02-14 08:53:16 --> Config Class Initialized
DEBUG - 2015-02-14 08:53:16 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:53:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:53:16 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:53:16 --> URI Class Initialized
DEBUG - 2015-02-14 08:53:16 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:53:16 --> Router Class Initialized
DEBUG - 2015-02-14 08:53:16 --> Output Class Initialized
DEBUG - 2015-02-14 08:53:16 --> Security Class Initialized
DEBUG - 2015-02-14 08:53:16 --> Input Class Initialized
DEBUG - 2015-02-14 08:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:53:16 --> Language Class Initialized
DEBUG - 2015-02-14 08:53:16 --> Loader Class Initialized
DEBUG - 2015-02-14 08:53:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:53:16 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:53:16 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:53:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:53:16 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:53:16 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:53:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Controller Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:53:17 --> Email Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:53:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:53:17 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:53:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:53:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:53:17 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:53:17 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:53:17 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:17 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:53:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:53:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:53:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:53:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:53:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:53:18 --> Final output sent to browser
DEBUG - 2015-02-14 08:53:18 --> Total execution time: 1.5212
DEBUG - 2015-02-14 08:53:23 --> Config Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:53:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:53:23 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:53:23 --> URI Class Initialized
DEBUG - 2015-02-14 08:53:23 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:53:23 --> Router Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Output Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Security Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Input Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:53:23 --> Language Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Loader Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:53:23 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:53:23 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:53:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Controller Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:53:23 --> Email Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:53:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:53:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:53:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:53:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:53:23 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:53:24 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:24 --> Model Class Initialized
DEBUG - 2015-02-14 08:53:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:53:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:53:25 --> Final output sent to browser
DEBUG - 2015-02-14 08:53:25 --> Total execution time: 1.6202
DEBUG - 2015-02-14 08:55:23 --> Config Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:55:23 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:55:23 --> URI Class Initialized
DEBUG - 2015-02-14 08:55:23 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:55:23 --> Router Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Output Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Security Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Input Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:55:23 --> Language Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Loader Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:55:23 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Session: Regenerate ID
DEBUG - 2015-02-14 08:55:23 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:55:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Controller Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:55:23 --> Email Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:55:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:55:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:55:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:55:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:55:23 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:55:24 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:24 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:55:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:55:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:55:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:55:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:55:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:55:25 --> Final output sent to browser
DEBUG - 2015-02-14 08:55:25 --> Total execution time: 1.6972
DEBUG - 2015-02-14 08:55:39 --> Config Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:55:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:55:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:55:39 --> URI Class Initialized
DEBUG - 2015-02-14 08:55:39 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:55:39 --> Router Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Output Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Security Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Input Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:55:39 --> Language Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Loader Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:55:39 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:55:39 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:55:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Controller Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:55:39 --> Email Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:55:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:55:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:55:39 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:55:39 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:55:39 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:55:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:55:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:55:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:55:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:55:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:55:40 --> Final output sent to browser
DEBUG - 2015-02-14 08:55:40 --> Total execution time: 1.4651
DEBUG - 2015-02-14 08:55:48 --> Config Class Initialized
DEBUG - 2015-02-14 08:55:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:55:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:55:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:55:48 --> URI Class Initialized
DEBUG - 2015-02-14 08:55:49 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:55:49 --> Router Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Output Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Security Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Input Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:55:49 --> Language Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Loader Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:55:49 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:55:49 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:55:49 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Controller Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:55:49 --> Email Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:55:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:55:49 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:55:49 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:55:49 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:55:49 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:49 --> Model Class Initialized
DEBUG - 2015-02-14 08:55:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:55:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:55:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:55:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:55:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:55:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:55:50 --> Final output sent to browser
DEBUG - 2015-02-14 08:55:50 --> Total execution time: 1.5872
DEBUG - 2015-02-14 08:56:34 --> Config Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:56:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:56:34 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:56:34 --> URI Class Initialized
DEBUG - 2015-02-14 08:56:34 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:56:34 --> Router Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Output Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Security Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Input Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:56:34 --> Language Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Loader Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:56:34 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:56:34 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:56:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Controller Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:56:34 --> Email Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:56:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:56:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:56:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:56:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:56:34 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:56:36 --> Final output sent to browser
DEBUG - 2015-02-14 08:56:36 --> Total execution time: 1.5562
DEBUG - 2015-02-14 08:56:58 --> Config Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:56:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:56:58 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:56:58 --> URI Class Initialized
DEBUG - 2015-02-14 08:56:58 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:56:58 --> Router Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Output Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Security Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Input Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:56:58 --> Language Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Loader Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:56:58 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:56:58 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:56:58 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Controller Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:56:58 --> Email Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:56:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:56:58 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:56:58 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:56:58 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:56:58 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:58 --> Model Class Initialized
DEBUG - 2015-02-14 08:56:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:56:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:56:59 --> Final output sent to browser
DEBUG - 2015-02-14 08:56:59 --> Total execution time: 1.4641
DEBUG - 2015-02-14 08:57:34 --> Config Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:57:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:57:34 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:57:34 --> URI Class Initialized
DEBUG - 2015-02-14 08:57:34 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:57:34 --> Router Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Output Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Security Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Input Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:57:34 --> Language Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Loader Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:57:34 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:57:34 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:57:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Controller Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:57:34 --> Email Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:57:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:57:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:57:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:57:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:57:34 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:34 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:57:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:57:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:57:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:57:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:57:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:57:35 --> Final output sent to browser
DEBUG - 2015-02-14 08:57:35 --> Total execution time: 1.5242
DEBUG - 2015-02-14 08:57:52 --> Config Class Initialized
DEBUG - 2015-02-14 08:57:52 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:57:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:57:52 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:57:52 --> URI Class Initialized
DEBUG - 2015-02-14 08:57:52 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:57:52 --> Router Class Initialized
DEBUG - 2015-02-14 08:57:52 --> Output Class Initialized
DEBUG - 2015-02-14 08:57:52 --> Security Class Initialized
DEBUG - 2015-02-14 08:57:52 --> Input Class Initialized
DEBUG - 2015-02-14 08:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:57:52 --> Language Class Initialized
DEBUG - 2015-02-14 08:57:52 --> Loader Class Initialized
DEBUG - 2015-02-14 08:57:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:57:52 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:57:52 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:57:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:57:52 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:57:52 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:57:53 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Controller Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:57:53 --> Email Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:57:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:57:53 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:57:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:57:53 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:57:53 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:57:53 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:57:53 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:53 --> Model Class Initialized
DEBUG - 2015-02-14 08:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:57:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:57:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:57:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:57:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:57:54 --> Final output sent to browser
DEBUG - 2015-02-14 08:57:54 --> Total execution time: 1.4711
DEBUG - 2015-02-14 08:58:30 --> Config Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:58:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:58:30 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:58:30 --> URI Class Initialized
DEBUG - 2015-02-14 08:58:30 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:58:30 --> Router Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Output Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Security Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Input Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:58:30 --> Language Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Loader Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:58:30 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:58:30 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:58:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:58:30 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:58:30 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:58:30 --> Model Class Initialized
DEBUG - 2015-02-14 08:58:30 --> Model Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Controller Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:58:31 --> Email Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:58:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:58:31 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:58:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:58:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:58:31 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:58:31 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:58:31 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:58:31 --> Model Class Initialized
DEBUG - 2015-02-14 08:58:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:58:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:58:32 --> Final output sent to browser
DEBUG - 2015-02-14 08:58:32 --> Total execution time: 1.6422
DEBUG - 2015-02-14 08:59:39 --> Config Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:59:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:59:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:59:39 --> URI Class Initialized
DEBUG - 2015-02-14 08:59:39 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:59:39 --> Router Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Output Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Security Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Input Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:59:39 --> Language Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Loader Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:59:39 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:59:39 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Controller Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:59:39 --> Email Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:59:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:59:39 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:59:39 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:59:39 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:59:41 --> Final output sent to browser
DEBUG - 2015-02-14 08:59:41 --> Total execution time: 1.4601
DEBUG - 2015-02-14 08:59:54 --> Config Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Hooks Class Initialized
DEBUG - 2015-02-14 08:59:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 08:59:54 --> Utf8 Class Initialized
DEBUG - 2015-02-14 08:59:54 --> URI Class Initialized
DEBUG - 2015-02-14 08:59:54 --> No URI present. Default controller set.
DEBUG - 2015-02-14 08:59:54 --> Router Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Output Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Security Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Input Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 08:59:54 --> Language Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Loader Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: url_helper
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: link_helper
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 08:59:54 --> CI_Session Class Initialized
DEBUG - 2015-02-14 08:59:54 --> CI_Session routines successfully run
DEBUG - 2015-02-14 08:59:54 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Controller Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 08:59:54 --> Email Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: language_helper
DEBUG - 2015-02-14 08:59:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 08:59:54 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Database Driver Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: date_helper
DEBUG - 2015-02-14 08:59:54 --> Helper loaded: form_helper
DEBUG - 2015-02-14 08:59:54 --> Form Validation Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 08:59:54 --> Pagination Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:54 --> Model Class Initialized
DEBUG - 2015-02-14 08:59:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 08:59:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 08:59:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 08:59:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 08:59:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 08:59:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 08:59:55 --> Final output sent to browser
DEBUG - 2015-02-14 08:59:55 --> Total execution time: 1.4691
DEBUG - 2015-02-14 09:00:07 --> Config Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:00:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:00:07 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:00:07 --> URI Class Initialized
DEBUG - 2015-02-14 09:00:07 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:00:07 --> Router Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Output Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Security Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Input Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:00:07 --> Language Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Loader Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:00:07 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:00:07 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:00:07 --> Model Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Model Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Controller Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:00:07 --> Email Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:00:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:00:07 --> Model Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:00:07 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:00:07 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Model Class Initialized
DEBUG - 2015-02-14 09:00:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:00:07 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:00:08 --> Model Class Initialized
DEBUG - 2015-02-14 09:00:08 --> Model Class Initialized
DEBUG - 2015-02-14 09:00:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:00:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:00:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:00:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:00:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:00:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:00:09 --> Final output sent to browser
DEBUG - 2015-02-14 09:00:09 --> Total execution time: 1.5232
DEBUG - 2015-02-14 09:01:42 --> Config Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:01:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:01:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:01:42 --> URI Class Initialized
DEBUG - 2015-02-14 09:01:42 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:01:42 --> Router Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Output Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Security Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Input Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:01:42 --> Language Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Loader Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:01:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Session: Regenerate ID
DEBUG - 2015-02-14 09:01:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:01:42 --> Model Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Model Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Controller Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:01:42 --> Email Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:01:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:01:42 --> Model Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:01:42 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:01:42 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Model Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:01:42 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Model Class Initialized
DEBUG - 2015-02-14 09:01:42 --> Model Class Initialized
DEBUG - 2015-02-14 09:01:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:01:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:01:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:01:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:01:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:01:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:01:43 --> Final output sent to browser
DEBUG - 2015-02-14 09:01:43 --> Total execution time: 1.5242
DEBUG - 2015-02-14 09:07:48 --> Config Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:07:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:07:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:07:48 --> URI Class Initialized
DEBUG - 2015-02-14 09:07:48 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:07:48 --> Router Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Output Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Security Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Input Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:07:48 --> Language Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Loader Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:07:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Session: Regenerate ID
DEBUG - 2015-02-14 09:07:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:07:48 --> Model Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Model Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Controller Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:07:48 --> Email Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:07:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:07:48 --> Model Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:07:48 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:07:48 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Model Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:07:48 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:07:48 --> Model Class Initialized
DEBUG - 2015-02-14 09:07:49 --> Model Class Initialized
DEBUG - 2015-02-14 09:07:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:07:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:07:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:07:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:07:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:07:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:07:49 --> Final output sent to browser
DEBUG - 2015-02-14 09:07:49 --> Total execution time: 1.5788
DEBUG - 2015-02-14 09:09:46 --> Config Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:09:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:09:46 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:09:46 --> URI Class Initialized
DEBUG - 2015-02-14 09:09:46 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:09:46 --> Router Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Output Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Security Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Input Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:09:46 --> Language Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Loader Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:09:46 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:09:46 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:09:46 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Controller Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:09:46 --> Email Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:09:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:09:46 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:09:46 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:09:46 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:09:46 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:46 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:09:47 --> Final output sent to browser
DEBUG - 2015-02-14 09:09:47 --> Total execution time: 1.5039
DEBUG - 2015-02-14 09:09:57 --> Config Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:09:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:09:57 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:09:57 --> URI Class Initialized
DEBUG - 2015-02-14 09:09:57 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:09:57 --> Router Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Output Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Security Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Input Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:09:57 --> Language Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Loader Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:09:57 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:09:57 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:09:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Controller Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:09:57 --> Email Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:09:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:09:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:09:57 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:09:57 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:09:57 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:09:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:09:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:09:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:09:59 --> Final output sent to browser
DEBUG - 2015-02-14 09:09:59 --> Total execution time: 1.4889
DEBUG - 2015-02-14 09:11:18 --> Config Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:11:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:11:18 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:11:18 --> URI Class Initialized
DEBUG - 2015-02-14 09:11:18 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:11:18 --> Router Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Output Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Security Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Input Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:11:18 --> Language Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Loader Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:11:18 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:11:18 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:11:18 --> Model Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Model Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Controller Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:11:18 --> Email Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:11:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:11:18 --> Model Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:11:18 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:11:18 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Model Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:11:18 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Model Class Initialized
DEBUG - 2015-02-14 09:11:18 --> Model Class Initialized
DEBUG - 2015-02-14 09:11:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:11:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:11:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:11:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:11:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:11:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:11:19 --> Final output sent to browser
DEBUG - 2015-02-14 09:11:19 --> Total execution time: 1.5492
DEBUG - 2015-02-14 09:12:57 --> Config Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:12:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:12:57 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:12:57 --> URI Class Initialized
DEBUG - 2015-02-14 09:12:57 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:12:57 --> Router Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Output Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Security Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Input Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:12:57 --> Language Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Loader Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:12:57 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Session: Regenerate ID
DEBUG - 2015-02-14 09:12:57 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:12:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Controller Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:12:57 --> Email Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:12:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:12:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:12:57 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:12:57 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:12:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:12:57 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:12:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:12:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:12:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:12:59 --> Final output sent to browser
DEBUG - 2015-02-14 09:12:59 --> Total execution time: 1.5262
DEBUG - 2015-02-14 09:14:39 --> Config Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:14:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:14:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:14:39 --> URI Class Initialized
DEBUG - 2015-02-14 09:14:39 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:14:39 --> Router Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Output Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Security Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Input Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:14:39 --> Language Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Loader Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:14:39 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:14:39 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:14:39 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Controller Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:14:39 --> Email Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:14:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:14:39 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:14:39 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:14:39 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:14:39 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:14:40 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:40 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:14:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:14:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:14:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:14:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:14:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:14:41 --> Final output sent to browser
DEBUG - 2015-02-14 09:14:41 --> Total execution time: 1.6082
DEBUG - 2015-02-14 09:14:57 --> Config Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:14:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:14:57 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:14:57 --> URI Class Initialized
DEBUG - 2015-02-14 09:14:57 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:14:57 --> Router Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Output Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Security Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Input Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:14:57 --> Language Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Loader Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:14:57 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:14:57 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:14:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Controller Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:14:57 --> Email Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:14:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:14:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:14:57 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:14:57 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:14:57 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:14:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:14:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:14:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:14:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:14:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:14:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:14:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:14:59 --> Final output sent to browser
DEBUG - 2015-02-14 09:14:59 --> Total execution time: 1.7571
DEBUG - 2015-02-14 09:15:25 --> Config Class Initialized
DEBUG - 2015-02-14 09:15:25 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:15:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:15:25 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:15:25 --> URI Class Initialized
DEBUG - 2015-02-14 09:15:25 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:15:25 --> Router Class Initialized
DEBUG - 2015-02-14 09:15:25 --> Output Class Initialized
DEBUG - 2015-02-14 09:15:25 --> Security Class Initialized
DEBUG - 2015-02-14 09:15:25 --> Input Class Initialized
DEBUG - 2015-02-14 09:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:15:25 --> Language Class Initialized
DEBUG - 2015-02-14 09:15:25 --> Loader Class Initialized
DEBUG - 2015-02-14 09:15:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:15:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:15:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:15:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:15:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:15:26 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:15:26 --> Model Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Model Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Controller Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:15:26 --> Email Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:15:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:15:26 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:15:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:15:26 --> Model Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:15:26 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:15:26 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Model Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:15:26 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Model Class Initialized
DEBUG - 2015-02-14 09:15:26 --> Model Class Initialized
DEBUG - 2015-02-14 09:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:15:27 --> Final output sent to browser
DEBUG - 2015-02-14 09:15:27 --> Total execution time: 1.4733
DEBUG - 2015-02-14 09:16:38 --> Config Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:16:38 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:16:38 --> URI Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Router Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Output Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Security Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Input Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:16:38 --> Language Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Loader Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:16:38 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:16:38 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:16:38 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Controller Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:16:38 --> Email Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:16:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:16:38 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:16:38 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 09:16:38 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 09:16:38 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 09:16:38 --> Session: Creating new session (cf90440896f46c71a28de283dd988a20)
DEBUG - 2015-02-14 09:16:38 --> Config Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:16:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:16:38 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:16:38 --> URI Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Router Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Output Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Security Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Input Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:16:38 --> Language Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Loader Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:16:38 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:16:38 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:16:38 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Controller Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:16:38 --> Email Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:16:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:16:38 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:16:38 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:16:38 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:16:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 09:16:38 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 09:16:38 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 09:16:38 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:39 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:39 --> Model Class Initialized
DEBUG - 2015-02-14 09:16:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:16:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:16:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-14 09:16:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:16:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:16:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:16:39 --> Final output sent to browser
DEBUG - 2015-02-14 09:16:39 --> Total execution time: 0.9189
DEBUG - 2015-02-14 09:18:33 --> Config Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:18:33 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:18:33 --> URI Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Router Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Output Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Security Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Input Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:18:33 --> Language Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Loader Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:18:33 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:18:33 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:18:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Controller Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:18:33 --> Email Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:18:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:18:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:18:33 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:18:33 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 09:18:33 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 09:18:33 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 09:18:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:18:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:18:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:18:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:18:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-14 09:18:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:18:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:18:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:18:33 --> Final output sent to browser
DEBUG - 2015-02-14 09:18:33 --> Total execution time: 0.8849
DEBUG - 2015-02-14 09:20:09 --> Config Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:20:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:20:09 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:20:09 --> URI Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Router Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Output Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Security Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Input Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:20:09 --> Language Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Loader Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:20:09 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:20:09 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:20:09 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Controller Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:20:09 --> Email Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:20:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:20:09 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:20:09 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:20:09 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:20:09 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 09:20:09 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 09:20:09 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 09:20:09 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-14 09:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:20:10 --> Final output sent to browser
DEBUG - 2015-02-14 09:20:10 --> Total execution time: 1.0119
DEBUG - 2015-02-14 09:20:34 --> Config Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:20:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:20:34 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:20:34 --> URI Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Router Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Output Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Security Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Input Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:20:34 --> Language Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Loader Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:20:34 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:20:34 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Controller Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:20:34 --> Email Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:20:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:20:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:20:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:20:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 09:20:34 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 09:20:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 09:20:34 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:35 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:35 --> Model Class Initialized
DEBUG - 2015-02-14 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-14 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:20:35 --> Final output sent to browser
DEBUG - 2015-02-14 09:20:35 --> Total execution time: 0.8819
DEBUG - 2015-02-14 09:21:51 --> Config Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:21:51 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:21:51 --> URI Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Router Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Output Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Security Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Input Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:21:51 --> Language Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Loader Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:21:51 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:21:51 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:21:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:21:51 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:21:51 --> Session: Regenerate ID
DEBUG - 2015-02-14 09:21:51 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:21:52 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Controller Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:21:52 --> Email Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:21:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:21:52 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:21:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:21:52 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:21:52 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:21:52 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 09:21:52 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 09:21:52 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 09:21:52 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:52 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:21:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:21:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-14 09:21:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:21:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:21:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:21:52 --> Final output sent to browser
DEBUG - 2015-02-14 09:21:52 --> Total execution time: 0.8770
DEBUG - 2015-02-14 09:21:57 --> Config Class Initialized
DEBUG - 2015-02-14 09:21:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:21:58 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:21:58 --> URI Class Initialized
DEBUG - 2015-02-14 09:21:58 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:21:58 --> Router Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Output Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Security Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Input Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:21:58 --> Language Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Loader Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:21:58 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:21:58 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:21:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Controller Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:21:58 --> Email Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:21:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:21:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:21:58 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:21:58 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:21:58 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:58 --> Model Class Initialized
DEBUG - 2015-02-14 09:21:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:21:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:21:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:21:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:21:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:21:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:21:59 --> Final output sent to browser
DEBUG - 2015-02-14 09:21:59 --> Total execution time: 1.3290
DEBUG - 2015-02-14 09:22:27 --> Config Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:22:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:22:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:22:27 --> URI Class Initialized
DEBUG - 2015-02-14 09:22:27 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:22:27 --> Router Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Output Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Security Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Input Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:22:27 --> Language Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Loader Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:22:27 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:22:27 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Controller Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:22:27 --> Email Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:22:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:22:27 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:22:27 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:22:27 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 09:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 09:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:22:28 --> Final output sent to browser
DEBUG - 2015-02-14 09:22:28 --> Total execution time: 1.4250
DEBUG - 2015-02-14 09:23:33 --> Config Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:23:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:23:33 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:23:33 --> URI Class Initialized
DEBUG - 2015-02-14 09:23:33 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:23:33 --> Router Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Output Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Security Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Input Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:23:33 --> Language Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Loader Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:23:33 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:23:33 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:23:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Controller Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:23:33 --> Email Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:23:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:23:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:23:33 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:23:33 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:23:33 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:23:33 --> Model Class Initialized
DEBUG - 2015-02-14 09:23:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:23:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:23:34 --> Final output sent to browser
DEBUG - 2015-02-14 09:23:34 --> Total execution time: 1.3980
DEBUG - 2015-02-14 09:24:06 --> Config Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:24:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:24:06 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:24:06 --> URI Class Initialized
DEBUG - 2015-02-14 09:24:06 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:24:06 --> Router Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Output Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Security Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Input Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:24:06 --> Language Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Loader Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:24:06 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:24:06 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Controller Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:24:06 --> Email Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:24:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:24:06 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:24:06 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:24:06 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:24:07 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:07 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:24:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:24:08 --> Final output sent to browser
DEBUG - 2015-02-14 09:24:08 --> Total execution time: 1.3410
DEBUG - 2015-02-14 09:24:22 --> Config Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:24:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:24:22 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:24:22 --> URI Class Initialized
DEBUG - 2015-02-14 09:24:22 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:24:22 --> Router Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Output Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Security Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Input Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:24:22 --> Language Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Loader Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:24:22 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:24:22 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:24:22 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Controller Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:24:22 --> Email Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:24:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:24:22 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:24:22 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:24:22 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:24:22 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:24:23 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:23 --> Model Class Initialized
DEBUG - 2015-02-14 09:24:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:24:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:24:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:24:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:24:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:24:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:24:23 --> Final output sent to browser
DEBUG - 2015-02-14 09:24:23 --> Total execution time: 1.3500
DEBUG - 2015-02-14 09:39:25 --> Config Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:39:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:39:25 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:39:25 --> URI Class Initialized
DEBUG - 2015-02-14 09:39:25 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:39:25 --> Router Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Output Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Security Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Input Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:39:25 --> Language Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Loader Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:39:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Session: Regenerate ID
DEBUG - 2015-02-14 09:39:25 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:39:25 --> Model Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Model Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Controller Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:39:25 --> Email Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:39:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:39:25 --> Model Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:39:25 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:39:25 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Model Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:39:25 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Model Class Initialized
DEBUG - 2015-02-14 09:39:25 --> Model Class Initialized
DEBUG - 2015-02-14 09:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:39:26 --> Final output sent to browser
DEBUG - 2015-02-14 09:39:26 --> Total execution time: 1.3131
DEBUG - 2015-02-14 09:54:27 --> Config Class Initialized
DEBUG - 2015-02-14 09:54:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:54:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:54:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:54:27 --> URI Class Initialized
DEBUG - 2015-02-14 09:54:27 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:54:27 --> Router Class Initialized
DEBUG - 2015-02-14 09:54:27 --> Output Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Security Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Input Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:54:28 --> Language Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Loader Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:54:28 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Session: Regenerate ID
DEBUG - 2015-02-14 09:54:28 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:54:28 --> Model Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Model Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Controller Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:54:28 --> Email Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:54:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:54:28 --> Model Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:54:28 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:54:28 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Model Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:54:28 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Model Class Initialized
DEBUG - 2015-02-14 09:54:28 --> Model Class Initialized
DEBUG - 2015-02-14 09:54:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:54:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:54:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:54:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:54:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:54:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:54:29 --> Final output sent to browser
DEBUG - 2015-02-14 09:54:29 --> Total execution time: 1.4271
DEBUG - 2015-02-14 09:59:01 --> Config Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Hooks Class Initialized
DEBUG - 2015-02-14 09:59:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 09:59:01 --> Utf8 Class Initialized
DEBUG - 2015-02-14 09:59:01 --> URI Class Initialized
DEBUG - 2015-02-14 09:59:01 --> No URI present. Default controller set.
DEBUG - 2015-02-14 09:59:01 --> Router Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Output Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Security Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Input Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 09:59:01 --> Language Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Loader Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 09:59:01 --> CI_Session Class Initialized
DEBUG - 2015-02-14 09:59:01 --> CI_Session routines successfully run
DEBUG - 2015-02-14 09:59:01 --> Model Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Model Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Controller Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 09:59:01 --> Email Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: language_helper
DEBUG - 2015-02-14 09:59:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 09:59:01 --> Model Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Database Driver Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: date_helper
DEBUG - 2015-02-14 09:59:01 --> Helper loaded: form_helper
DEBUG - 2015-02-14 09:59:01 --> Form Validation Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Model Class Initialized
DEBUG - 2015-02-14 09:59:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 09:59:01 --> Pagination Class Initialized
DEBUG - 2015-02-14 09:59:02 --> Model Class Initialized
DEBUG - 2015-02-14 09:59:02 --> Model Class Initialized
DEBUG - 2015-02-14 09:59:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 09:59:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 09:59:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 09:59:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 09:59:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 09:59:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 09:59:02 --> Final output sent to browser
DEBUG - 2015-02-14 09:59:02 --> Total execution time: 1.3181
DEBUG - 2015-02-14 10:01:41 --> Config Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:01:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:01:41 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:01:41 --> URI Class Initialized
DEBUG - 2015-02-14 10:01:41 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:01:41 --> Router Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Output Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Security Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Input Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:01:41 --> Language Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Loader Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:01:41 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:01:41 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:01:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Controller Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:01:41 --> Email Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:01:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:01:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:01:41 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:01:41 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:01:41 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:01:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:01:42 --> Model Class Initialized
DEBUG - 2015-02-14 10:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:01:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:01:42 --> Final output sent to browser
DEBUG - 2015-02-14 10:01:42 --> Total execution time: 1.3061
DEBUG - 2015-02-14 10:03:06 --> Config Class Initialized
DEBUG - 2015-02-14 10:03:06 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:03:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:03:06 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:03:06 --> URI Class Initialized
DEBUG - 2015-02-14 10:03:06 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:03:06 --> Router Class Initialized
DEBUG - 2015-02-14 10:03:06 --> Output Class Initialized
DEBUG - 2015-02-14 10:03:06 --> Security Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Input Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:03:07 --> Language Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Loader Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:03:07 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:03:07 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Controller Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:03:07 --> Email Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:03:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:03:07 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:03:07 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:03:07 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:03:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:03:08 --> Final output sent to browser
DEBUG - 2015-02-14 10:03:08 --> Total execution time: 1.3431
DEBUG - 2015-02-14 10:03:44 --> Config Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:03:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:03:44 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:03:44 --> URI Class Initialized
DEBUG - 2015-02-14 10:03:44 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:03:44 --> Router Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Output Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Security Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Input Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:03:44 --> Language Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Loader Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:03:44 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:03:44 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:03:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Controller Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:03:44 --> Email Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:03:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:03:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:03:44 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:03:44 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:03:44 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:03:45 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:45 --> Model Class Initialized
DEBUG - 2015-02-14 10:03:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:03:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:03:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:03:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:03:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:03:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:03:45 --> Final output sent to browser
DEBUG - 2015-02-14 10:03:45 --> Total execution time: 1.3591
DEBUG - 2015-02-14 10:04:12 --> Config Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:04:12 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:04:12 --> URI Class Initialized
DEBUG - 2015-02-14 10:04:12 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:04:12 --> Router Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Output Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Security Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Input Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:04:12 --> Language Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Loader Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:04:12 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:04:12 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:04:12 --> Model Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Model Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Controller Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:04:12 --> Email Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:04:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:04:12 --> Model Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:04:12 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:04:12 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Model Class Initialized
DEBUG - 2015-02-14 10:04:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:04:12 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:04:13 --> Model Class Initialized
DEBUG - 2015-02-14 10:04:13 --> Model Class Initialized
DEBUG - 2015-02-14 10:04:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:04:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:04:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:04:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:04:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:04:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:04:14 --> Final output sent to browser
DEBUG - 2015-02-14 10:04:14 --> Total execution time: 1.3091
DEBUG - 2015-02-14 10:06:43 --> Config Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:06:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:06:43 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:06:43 --> URI Class Initialized
DEBUG - 2015-02-14 10:06:43 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:06:43 --> Router Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Output Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Security Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Input Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:06:43 --> Language Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Loader Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:06:43 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:06:43 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:06:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:06:43 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:06:43 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:06:43 --> Model Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Model Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Controller Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:06:43 --> Email Class Initialized
DEBUG - 2015-02-14 10:06:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:06:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:06:43 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:06:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:06:43 --> Model Class Initialized
DEBUG - 2015-02-14 10:06:44 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:06:44 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:06:44 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:06:44 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:06:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:06:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:06:44 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:06:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:06:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:06:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:06:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:06:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:06:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:06:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:06:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:06:45 --> Final output sent to browser
DEBUG - 2015-02-14 10:06:45 --> Total execution time: 1.3901
DEBUG - 2015-02-14 10:07:15 --> Config Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:07:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:07:15 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:07:15 --> URI Class Initialized
DEBUG - 2015-02-14 10:07:15 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:07:15 --> Router Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Output Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Security Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Input Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:07:15 --> Language Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Loader Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:07:15 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:07:15 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:07:15 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Controller Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:07:15 --> Email Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:07:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:07:15 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:07:15 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:07:15 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:07:15 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:15 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:07:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
ERROR - 2015-02-14 10:07:16 --> Severity: Error --> Call to a member function getCreated() on a non-object D:\phutx\project\ups\myblog\application\helpers\admin_helper.php 116
DEBUG - 2015-02-14 10:07:27 --> Config Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:07:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:07:27 --> URI Class Initialized
DEBUG - 2015-02-14 10:07:27 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:07:27 --> Router Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Output Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Security Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Input Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:07:27 --> Language Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Loader Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:07:27 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:07:27 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:07:27 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Controller Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:07:27 --> Email Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:07:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:07:27 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:07:27 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:07:27 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:07:27 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:07:27 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:28 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
ERROR - 2015-02-14 10:07:28 --> Severity: Error --> Call to undefined method Entity\Articles::getArticle() D:\phutx\project\ups\myblog\application\helpers\admin_helper.php 117
DEBUG - 2015-02-14 10:07:51 --> Config Class Initialized
DEBUG - 2015-02-14 10:07:51 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:07:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:07:51 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:07:52 --> URI Class Initialized
DEBUG - 2015-02-14 10:07:52 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:07:52 --> Router Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Output Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Security Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Input Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:07:52 --> Language Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Loader Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:07:52 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:07:52 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:07:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Controller Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:07:52 --> Email Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:07:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:07:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:07:52 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:07:52 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:07:52 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:07:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:07:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
ERROR - 2015-02-14 10:07:53 --> Severity: Error --> Call to undefined method Entity\Articles::getArticle() D:\phutx\project\ups\myblog\application\helpers\admin_helper.php 117
DEBUG - 2015-02-14 10:08:23 --> Config Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:08:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:08:23 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:08:23 --> URI Class Initialized
DEBUG - 2015-02-14 10:08:23 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:08:23 --> Router Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Output Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Security Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Input Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:08:23 --> Language Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Loader Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:08:23 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:08:23 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:08:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Controller Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:08:23 --> Email Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:08:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:08:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:08:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:08:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:08:23 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:08:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:08:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:08:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:08:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:08:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
ERROR - 2015-02-14 10:08:24 --> Severity: Error --> Call to undefined method Entity\Articles::getArticle() D:\phutx\project\ups\myblog\application\helpers\admin_helper.php 118
DEBUG - 2015-02-14 10:09:21 --> Config Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:09:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:09:21 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:09:21 --> URI Class Initialized
DEBUG - 2015-02-14 10:09:21 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:09:21 --> Router Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Output Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Security Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Input Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:09:21 --> Language Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Loader Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:09:21 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:09:21 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:09:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Controller Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:09:21 --> Email Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:09:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:09:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:09:21 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:09:21 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:09:21 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:09:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:09:22 --> Model Class Initialized
DEBUG - 2015-02-14 10:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:09:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:09:22 --> Final output sent to browser
DEBUG - 2015-02-14 10:09:22 --> Total execution time: 1.3201
DEBUG - 2015-02-14 10:12:48 --> Config Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:12:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:12:48 --> URI Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Router Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Output Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Security Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Input Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:12:48 --> Language Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Loader Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:12:48 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:12:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:12:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:12:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:12:48 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:12:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:12:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Controller Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:12:49 --> Email Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:12:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:12:49 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:12:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:12:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:12:49 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:12:49 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 10:12:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 10:12:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 10:12:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:12:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:12:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-14 10:12:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:12:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:12:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:12:50 --> Final output sent to browser
DEBUG - 2015-02-14 10:12:50 --> Total execution time: 1.4271
DEBUG - 2015-02-14 10:12:53 --> Config Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:12:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:12:53 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:12:53 --> URI Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Router Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Output Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Security Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Input Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:12:53 --> Language Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Loader Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:12:53 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:12:53 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:12:53 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Controller Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:12:53 --> Email Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:12:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:12:53 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:12:53 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:12:53 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:12:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-14 10:12:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-14 10:12:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-14 10:12:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-14 10:12:54 --> Config Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:12:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:12:54 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:12:54 --> URI Class Initialized
DEBUG - 2015-02-14 10:12:54 --> No URI present. Default controller set.
DEBUG - 2015-02-14 10:12:54 --> Router Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Output Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Security Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Input Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:12:54 --> Language Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Loader Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:12:54 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:12:54 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:12:54 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Controller Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:12:54 --> Email Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:12:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:12:54 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:12:54 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:12:54 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 10:12:54 --> Pagination Class Initialized
DEBUG - 2015-02-14 10:12:54 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:55 --> Model Class Initialized
DEBUG - 2015-02-14 10:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 10:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 10:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 10:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 10:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 10:12:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 10:12:55 --> Final output sent to browser
DEBUG - 2015-02-14 10:12:55 --> Total execution time: 1.5372
DEBUG - 2015-02-14 10:13:00 --> Config Class Initialized
DEBUG - 2015-02-14 10:13:00 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:13:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:13:00 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:13:00 --> URI Class Initialized
DEBUG - 2015-02-14 10:13:00 --> Router Class Initialized
DEBUG - 2015-02-14 10:13:00 --> Output Class Initialized
DEBUG - 2015-02-14 10:13:00 --> Security Class Initialized
DEBUG - 2015-02-14 10:13:00 --> Input Class Initialized
DEBUG - 2015-02-14 10:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:13:00 --> Language Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Loader Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:13:01 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:13:01 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:13:01 --> Model Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Model Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Controller Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:13:01 --> Email Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:13:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:13:01 --> Model Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:13:01 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:13:01 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:13:01 --> Model Class Initialized
DEBUG - 2015-02-14 10:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:13:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:13:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-14 10:13:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:13:02 --> Final output sent to browser
DEBUG - 2015-02-14 10:13:02 --> Total execution time: 1.4261
DEBUG - 2015-02-14 10:14:52 --> Config Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:14:52 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:14:52 --> URI Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Router Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Output Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Security Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Input Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:14:52 --> Language Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Loader Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:14:52 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:14:52 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:14:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Controller Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:14:52 --> Email Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:14:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:14:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:14:52 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:14:52 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:14:52 --> Model Class Initialized
DEBUG - 2015-02-14 10:14:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:14:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:14:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-14 10:14:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:14:53 --> Final output sent to browser
DEBUG - 2015-02-14 10:14:53 --> Total execution time: 1.3051
DEBUG - 2015-02-14 10:15:09 --> Config Class Initialized
DEBUG - 2015-02-14 10:15:09 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:15:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:15:09 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:15:09 --> URI Class Initialized
DEBUG - 2015-02-14 10:15:09 --> Router Class Initialized
DEBUG - 2015-02-14 10:15:09 --> Output Class Initialized
DEBUG - 2015-02-14 10:15:09 --> Security Class Initialized
DEBUG - 2015-02-14 10:15:09 --> Input Class Initialized
DEBUG - 2015-02-14 10:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:15:09 --> Language Class Initialized
ERROR - 2015-02-14 10:15:09 --> 404 Page Not Found: Auth/settings
DEBUG - 2015-02-14 10:15:29 --> Config Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:15:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:15:29 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:15:29 --> URI Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Router Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Output Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Security Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Input Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:15:29 --> Language Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Loader Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:15:29 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:15:29 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:15:29 --> Model Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Model Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Controller Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:15:29 --> Email Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:15:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:15:29 --> Model Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:15:29 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:15:29 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:15:29 --> Model Class Initialized
DEBUG - 2015-02-14 10:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:15:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-14 10:15:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:15:30 --> Final output sent to browser
DEBUG - 2015-02-14 10:15:30 --> Total execution time: 1.3251
DEBUG - 2015-02-14 10:15:37 --> Config Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:15:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:15:37 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:15:37 --> URI Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Router Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Output Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Security Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Input Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:15:37 --> Language Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Loader Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:15:37 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:15:37 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:15:37 --> Model Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Model Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Controller Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:15:37 --> Email Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:15:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:15:37 --> Model Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:15:37 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:15:37 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-14 10:15:37 --> Severity: Notice --> Undefined property: Settings::$article_model D:\phutx\project\ups\myblog\application\controllers\admin\Settings.php 11
ERROR - 2015-02-14 10:15:37 --> Severity: Error --> Call to a member function getAll() on a non-object D:\phutx\project\ups\myblog\application\controllers\admin\Settings.php 11
DEBUG - 2015-02-14 10:21:09 --> Config Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:21:09 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:21:09 --> URI Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Router Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Output Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Security Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Input Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:21:09 --> Language Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Loader Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:21:09 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:21:09 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:21:09 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Controller Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:21:09 --> Email Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:21:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:21:09 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:21:09 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:21:09 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-14 10:21:09 --> Severity: Notice --> Undefined property: Settings::$article_model D:\phutx\project\ups\myblog\application\controllers\admin\Settings.php 11
ERROR - 2015-02-14 10:21:09 --> Severity: Error --> Call to a member function getAll() on a non-object D:\phutx\project\ups\myblog\application\controllers\admin\Settings.php 11
DEBUG - 2015-02-14 10:21:23 --> Config Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:21:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:21:23 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:21:23 --> URI Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Router Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Output Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Security Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Input Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:21:23 --> Language Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Loader Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:21:23 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:21:23 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:21:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Controller Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:21:23 --> Email Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:21:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:21:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:21:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:21:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:21:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:21:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-14 10:21:23 --> Severity: Notice --> Undefined variable: data D:\phutx\project\ups\myblog\application\controllers\admin\Settings.php 12
DEBUG - 2015-02-14 10:21:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:21:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:21:23 --> Final output sent to browser
DEBUG - 2015-02-14 10:21:23 --> Total execution time: 0.2770
DEBUG - 2015-02-14 10:21:48 --> Config Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:21:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:21:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:21:48 --> URI Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Router Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Output Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Security Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Input Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:21:48 --> Language Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Loader Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:21:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:21:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:21:48 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Controller Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:21:48 --> Email Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:21:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:21:48 --> Model Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:21:48 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:21:48 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:21:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:21:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:21:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:21:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:21:48 --> Final output sent to browser
DEBUG - 2015-02-14 10:21:48 --> Total execution time: 0.2830
DEBUG - 2015-02-14 10:22:09 --> Config Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:22:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:22:09 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:22:09 --> URI Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Router Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Output Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Security Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Input Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:22:09 --> Language Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Loader Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:22:09 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:22:09 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:22:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:22:09 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:22:09 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:22:09 --> Model Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Model Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Controller Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:22:09 --> Email Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:22:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:22:09 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:22:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:22:09 --> Model Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:22:09 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:22:10 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:22:10 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:22:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:22:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:22:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:22:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:22:10 --> Final output sent to browser
DEBUG - 2015-02-14 10:22:10 --> Total execution time: 0.2530
DEBUG - 2015-02-14 10:22:25 --> Config Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:22:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:22:25 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:22:25 --> URI Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Router Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Output Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Security Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Input Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:22:25 --> Language Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Loader Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:22:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:22:25 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:22:25 --> Model Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Model Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Controller Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:22:25 --> Email Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:22:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:22:25 --> Model Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:22:25 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:22:25 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:22:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:22:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:22:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:22:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:22:25 --> Final output sent to browser
DEBUG - 2015-02-14 10:22:25 --> Total execution time: 0.2170
DEBUG - 2015-02-14 10:23:55 --> Config Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:23:55 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:23:55 --> URI Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Router Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Output Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Security Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Input Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:23:55 --> Language Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Loader Class Initialized
DEBUG - 2015-02-14 10:23:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:23:55 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:23:55 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:23:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:23:55 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:23:55 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:23:56 --> Model Class Initialized
DEBUG - 2015-02-14 10:23:56 --> Model Class Initialized
DEBUG - 2015-02-14 10:23:56 --> Controller Class Initialized
DEBUG - 2015-02-14 10:23:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:23:56 --> Email Class Initialized
DEBUG - 2015-02-14 10:23:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:23:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:23:56 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:23:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:23:56 --> Model Class Initialized
DEBUG - 2015-02-14 10:23:56 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:23:56 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:23:56 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:23:56 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:23:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:23:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:23:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:23:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:23:56 --> Final output sent to browser
DEBUG - 2015-02-14 10:23:56 --> Total execution time: 0.2760
DEBUG - 2015-02-14 10:25:49 --> Config Class Initialized
DEBUG - 2015-02-14 10:25:49 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:25:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:25:49 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:25:49 --> URI Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Router Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Output Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Security Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Input Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:25:50 --> Language Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Loader Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:25:50 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:25:50 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:25:50 --> Model Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Model Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Controller Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:25:50 --> Email Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:25:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:25:50 --> Model Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:25:50 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:25:50 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:25:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:25:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:25:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:25:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:25:50 --> Final output sent to browser
DEBUG - 2015-02-14 10:25:50 --> Total execution time: 0.2250
DEBUG - 2015-02-14 10:26:04 --> Config Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:26:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:26:04 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:26:04 --> URI Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Router Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Output Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Security Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Input Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:26:04 --> Language Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Loader Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:26:04 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:26:04 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:26:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:26:04 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:26:04 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:26:04 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:04 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:05 --> Controller Class Initialized
DEBUG - 2015-02-14 10:26:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:26:05 --> Email Class Initialized
DEBUG - 2015-02-14 10:26:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:26:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:26:05 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:26:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:26:05 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:05 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:26:05 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:26:05 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:26:05 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:26:05 --> Final output sent to browser
DEBUG - 2015-02-14 10:26:05 --> Total execution time: 0.2110
DEBUG - 2015-02-14 10:26:24 --> Config Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:26:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:26:24 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:26:24 --> URI Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Router Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Output Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Security Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Input Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:26:24 --> Language Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Loader Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:26:24 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:26:24 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:26:24 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Controller Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:26:24 --> Email Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:26:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:26:24 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:26:24 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:26:24 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:26:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:26:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:26:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:26:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:26:24 --> Final output sent to browser
DEBUG - 2015-02-14 10:26:24 --> Total execution time: 0.2330
DEBUG - 2015-02-14 10:26:33 --> Config Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:26:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:26:33 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:26:33 --> URI Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Router Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Output Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Security Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Input Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:26:33 --> Language Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Loader Class Initialized
DEBUG - 2015-02-14 10:26:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:26:33 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:26:33 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:26:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:26:33 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:26:33 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:26:34 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:34 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:34 --> Controller Class Initialized
DEBUG - 2015-02-14 10:26:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:26:34 --> Email Class Initialized
DEBUG - 2015-02-14 10:26:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:26:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:26:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:26:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:26:34 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:26:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:26:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:26:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:26:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:26:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:26:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:26:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:26:34 --> Final output sent to browser
DEBUG - 2015-02-14 10:26:34 --> Total execution time: 0.2400
DEBUG - 2015-02-14 10:26:44 --> Config Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:26:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:26:44 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:26:44 --> URI Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Router Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Output Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Security Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Input Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:26:44 --> Language Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Loader Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:26:44 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:26:44 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:26:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Controller Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:26:44 --> Email Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:26:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:26:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:26:44 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:26:44 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:26:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:26:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:26:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:26:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:26:44 --> Final output sent to browser
DEBUG - 2015-02-14 10:26:44 --> Total execution time: 0.2010
DEBUG - 2015-02-14 10:26:55 --> Config Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:26:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:26:55 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:26:55 --> URI Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Router Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Output Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Security Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Input Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:26:55 --> Language Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Loader Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:26:55 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:26:55 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:26:55 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Controller Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:26:55 --> Email Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:26:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:26:55 --> Model Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:26:55 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:26:55 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:26:55 --> Final output sent to browser
DEBUG - 2015-02-14 10:26:55 --> Total execution time: 0.3050
DEBUG - 2015-02-14 10:27:30 --> Config Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:27:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:27:30 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:27:30 --> URI Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Router Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Output Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Security Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Input Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:27:30 --> Language Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Loader Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:27:30 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:27:30 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:27:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Controller Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:27:30 --> Email Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:27:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:27:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:27:30 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:27:30 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:27:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:27:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:27:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:27:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:27:30 --> Final output sent to browser
DEBUG - 2015-02-14 10:27:30 --> Total execution time: 0.2090
DEBUG - 2015-02-14 10:28:27 --> Config Class Initialized
DEBUG - 2015-02-14 10:28:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:28:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:28:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:28:27 --> URI Class Initialized
DEBUG - 2015-02-14 10:28:27 --> Router Class Initialized
DEBUG - 2015-02-14 10:28:27 --> Output Class Initialized
DEBUG - 2015-02-14 10:28:27 --> Security Class Initialized
DEBUG - 2015-02-14 10:28:27 --> Input Class Initialized
DEBUG - 2015-02-14 10:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:28:27 --> Language Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Loader Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:28:28 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:28:28 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:28:28 --> Model Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Model Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Controller Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:28:28 --> Email Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:28:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:28:28 --> Model Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:28:28 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:28:28 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:28:28 --> Final output sent to browser
DEBUG - 2015-02-14 10:28:28 --> Total execution time: 0.2360
DEBUG - 2015-02-14 10:28:41 --> Config Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:28:41 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:28:41 --> URI Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Router Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Output Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Security Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Input Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:28:41 --> Language Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Loader Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:28:41 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:28:41 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:28:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Controller Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:28:41 --> Email Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:28:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:28:41 --> Model Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:28:41 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:28:41 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:28:41 --> Final output sent to browser
DEBUG - 2015-02-14 10:28:41 --> Total execution time: 0.2480
DEBUG - 2015-02-14 10:30:08 --> Config Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:30:08 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:30:08 --> URI Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Router Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Output Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Security Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Input Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:30:08 --> Language Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Loader Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:30:08 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:30:08 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:30:08 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Controller Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:30:08 --> Email Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:30:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:30:08 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:30:08 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:30:08 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:30:08 --> Final output sent to browser
DEBUG - 2015-02-14 10:30:08 --> Total execution time: 0.2320
DEBUG - 2015-02-14 10:30:24 --> Config Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:30:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:30:24 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:30:24 --> URI Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Router Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Output Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Security Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Input Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:30:24 --> Language Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Loader Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:30:24 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:30:24 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:30:24 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Controller Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:30:24 --> Email Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:30:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:30:24 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:30:24 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:30:24 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:30:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:30:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:30:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:30:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:30:24 --> Final output sent to browser
DEBUG - 2015-02-14 10:30:24 --> Total execution time: 0.2150
DEBUG - 2015-02-14 10:30:32 --> Config Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:30:32 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:30:32 --> URI Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Router Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Output Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Security Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Input Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:30:32 --> Language Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Loader Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:30:32 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:30:32 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:30:32 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Controller Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:30:32 --> Email Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:30:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:30:32 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:30:32 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:30:32 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:30:32 --> Final output sent to browser
DEBUG - 2015-02-14 10:30:32 --> Total execution time: 0.2230
DEBUG - 2015-02-14 10:30:49 --> Config Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:30:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:30:49 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:30:49 --> URI Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Router Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Output Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Security Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Input Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:30:49 --> Language Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Loader Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:30:49 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:30:49 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:30:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Controller Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:30:49 --> Email Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:30:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:30:49 --> Model Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:30:49 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:30:49 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:30:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:30:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:30:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:30:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:30:49 --> Final output sent to browser
DEBUG - 2015-02-14 10:30:49 --> Total execution time: 0.2310
DEBUG - 2015-02-14 10:31:12 --> Config Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:31:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:31:12 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:31:12 --> URI Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Router Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Output Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Security Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Input Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:31:12 --> Language Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Loader Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:31:12 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:31:12 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:31:12 --> Model Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Model Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Controller Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:31:12 --> Email Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:31:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:31:12 --> Model Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:31:12 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:31:12 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:31:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:31:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:31:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:31:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:31:12 --> Final output sent to browser
DEBUG - 2015-02-14 10:31:12 --> Total execution time: 0.2380
DEBUG - 2015-02-14 10:31:21 --> Config Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:31:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:31:21 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:31:21 --> URI Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Router Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Output Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Security Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Input Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:31:21 --> Language Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Loader Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:31:21 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:31:21 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:31:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Controller Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:31:21 --> Email Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:31:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:31:21 --> Model Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:31:21 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:31:21 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:31:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:31:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:31:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:31:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:31:21 --> Final output sent to browser
DEBUG - 2015-02-14 10:31:21 --> Total execution time: 0.2080
DEBUG - 2015-02-14 10:32:20 --> Config Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:32:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:32:20 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:32:20 --> URI Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Router Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Output Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Security Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Input Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:32:20 --> Language Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Loader Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:32:20 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:32:20 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:32:20 --> Model Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Model Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Controller Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:32:20 --> Email Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:32:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:32:20 --> Model Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:32:20 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:32:20 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:32:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:32:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:32:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:32:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:32:20 --> Final output sent to browser
DEBUG - 2015-02-14 10:32:20 --> Total execution time: 0.2400
DEBUG - 2015-02-14 10:33:31 --> Config Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:33:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:33:31 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:33:31 --> URI Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Router Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Output Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Security Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Input Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:33:31 --> Language Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Loader Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:33:31 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:33:31 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:33:31 --> Model Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Model Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Controller Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:33:31 --> Email Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:33:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:33:31 --> Model Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:33:31 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:33:31 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:33:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:33:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:33:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:33:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:33:31 --> Final output sent to browser
DEBUG - 2015-02-14 10:33:31 --> Total execution time: 0.2070
DEBUG - 2015-02-14 10:38:27 --> Config Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:38:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:38:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:38:27 --> URI Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Router Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Output Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Security Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Input Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:38:27 --> Language Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Loader Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:38:27 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:38:27 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:38:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:38:27 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:38:27 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:38:27 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:38:28 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:28 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:28 --> Controller Class Initialized
DEBUG - 2015-02-14 10:38:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:38:28 --> Email Class Initialized
DEBUG - 2015-02-14 10:38:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:38:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:38:28 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:38:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:38:28 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:28 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:38:28 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:38:28 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:38:28 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:38:28 --> Final output sent to browser
DEBUG - 2015-02-14 10:38:28 --> Total execution time: 0.2430
DEBUG - 2015-02-14 10:38:29 --> Config Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:38:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:38:29 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:38:29 --> URI Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Router Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Output Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Security Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Input Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:38:29 --> Language Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Loader Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:38:29 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:38:29 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:38:29 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Controller Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:38:29 --> Email Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:38:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:38:29 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:38:29 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:38:29 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:38:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:38:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:38:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:38:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:38:29 --> Final output sent to browser
DEBUG - 2015-02-14 10:38:29 --> Total execution time: 0.2280
DEBUG - 2015-02-14 10:38:32 --> Config Class Initialized
DEBUG - 2015-02-14 10:38:32 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:38:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:38:32 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:38:32 --> URI Class Initialized
DEBUG - 2015-02-14 10:38:32 --> Router Class Initialized
DEBUG - 2015-02-14 10:38:32 --> Output Class Initialized
DEBUG - 2015-02-14 10:38:32 --> Security Class Initialized
DEBUG - 2015-02-14 10:38:32 --> Input Class Initialized
DEBUG - 2015-02-14 10:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:38:32 --> Language Class Initialized
ERROR - 2015-02-14 10:38:32 --> 404 Page Not Found: Settings/deleteUserHistory
DEBUG - 2015-02-14 10:38:40 --> Config Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:38:40 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:38:40 --> URI Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Router Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Output Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Security Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Input Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:38:40 --> Language Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Loader Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:38:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:38:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Controller Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:38:40 --> Email Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:38:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:38:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:38:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:38:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 10:38:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 10:38:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 10:38:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 10:38:40 --> Final output sent to browser
DEBUG - 2015-02-14 10:38:40 --> Total execution time: 0.2050
DEBUG - 2015-02-14 10:38:43 --> Config Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:38:43 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:38:43 --> URI Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Router Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Output Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Security Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Input Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:38:43 --> Language Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Loader Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:38:43 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:38:43 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:38:43 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Controller Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:38:43 --> Email Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:38:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:38:43 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:38:43 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:38:43 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:38:43 --> Model Class Initialized
ERROR - 2015-02-14 10:38:43 --> Severity: Notice --> Undefined property: Settings::$em D:\phutx\project\ups\myblog\system\core\Model.php 77
ERROR - 2015-02-14 10:38:43 --> Severity: Error --> Call to a member function createQueryBuilder() on a non-object D:\phutx\project\ups\myblog\application\models\User_article_model.php 6
DEBUG - 2015-02-14 10:38:53 --> Config Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:38:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:38:53 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:38:53 --> URI Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Router Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Output Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Security Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Input Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:38:53 --> Language Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Loader Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:38:53 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:38:53 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:38:53 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Controller Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:38:53 --> Email Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:38:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:38:53 --> Model Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:38:53 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:38:53 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:38:53 --> Model Class Initialized
ERROR - 2015-02-14 10:38:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\vendor\tracy\tracy\src\Tracy\Dumper.php:73) D:\phutx\project\ups\myblog\system\helpers\url_helper.php 564
DEBUG - 2015-02-14 10:39:43 --> Config Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:39:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:39:43 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:39:43 --> URI Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Router Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Output Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Security Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Input Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:39:43 --> Language Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Loader Class Initialized
DEBUG - 2015-02-14 10:39:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:39:43 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:39:43 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:39:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:39:43 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:39:43 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:39:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:39:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:39:44 --> Controller Class Initialized
DEBUG - 2015-02-14 10:39:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:39:44 --> Email Class Initialized
DEBUG - 2015-02-14 10:39:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:39:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:39:44 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:39:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:39:44 --> Model Class Initialized
DEBUG - 2015-02-14 10:39:44 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:39:44 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:39:44 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:39:44 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:39:44 --> Model Class Initialized
ERROR - 2015-02-14 10:39:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\vendor\tracy\tracy\src\Tracy\Dumper.php:73) D:\phutx\project\ups\myblog\system\helpers\url_helper.php 564
DEBUG - 2015-02-14 10:40:06 --> Config Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:40:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:40:06 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:40:06 --> URI Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Router Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Output Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Security Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Input Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:40:06 --> Language Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Loader Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:40:06 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:40:06 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:40:06 --> Model Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Model Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Controller Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:40:06 --> Email Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:40:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:40:06 --> Model Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:40:06 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:40:06 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:40:06 --> Model Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Config Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:40:18 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:40:18 --> URI Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Router Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Output Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Security Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Input Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:40:18 --> Language Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Loader Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:40:18 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:40:18 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:40:18 --> Model Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Model Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Controller Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:40:18 --> Email Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:40:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:40:18 --> Model Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:40:18 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:40:18 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:40:18 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Config Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:44:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:44:34 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:44:34 --> URI Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Router Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Output Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Security Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Input Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:44:34 --> Language Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Loader Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:44:34 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:44:34 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:44:34 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Controller Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:44:34 --> Email Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:44:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:44:34 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:44:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:44:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:44:34 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Config Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:44:57 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:44:57 --> URI Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Router Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Output Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Security Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Input Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:44:57 --> Language Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Loader Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:44:57 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:44:57 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:44:57 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Controller Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:44:57 --> Email Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:44:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:44:57 --> Model Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:44:57 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:44:57 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:44:57 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Config Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:45:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:45:12 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:45:12 --> URI Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Router Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Output Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Security Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Input Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:45:12 --> Language Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Loader Class Initialized
DEBUG - 2015-02-14 10:45:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:45:12 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:45:12 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:45:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:45:12 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:45:12 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:45:13 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:13 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:13 --> Controller Class Initialized
DEBUG - 2015-02-14 10:45:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:45:13 --> Email Class Initialized
DEBUG - 2015-02-14 10:45:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:45:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:45:13 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:45:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:45:13 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:13 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:45:13 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:45:13 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:45:13 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:45:13 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Config Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:45:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:45:22 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:45:22 --> URI Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Router Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Output Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Security Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Input Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:45:22 --> Language Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Loader Class Initialized
DEBUG - 2015-02-14 10:45:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:45:22 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:45:22 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:45:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:45:22 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:45:22 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:45:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:23 --> Controller Class Initialized
DEBUG - 2015-02-14 10:45:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:45:23 --> Email Class Initialized
DEBUG - 2015-02-14 10:45:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:45:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:45:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:45:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:45:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:45:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:45:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:45:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:45:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:45:23 --> Model Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Config Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:54:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:54:01 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:54:01 --> URI Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Router Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Output Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Security Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Input Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:54:01 --> Language Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Loader Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:54:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:54:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:54:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:54:01 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Session: Regenerate ID
DEBUG - 2015-02-14 10:54:01 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:54:01 --> Model Class Initialized
DEBUG - 2015-02-14 10:54:01 --> Model Class Initialized
DEBUG - 2015-02-14 10:54:02 --> Controller Class Initialized
DEBUG - 2015-02-14 10:54:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:54:02 --> Email Class Initialized
DEBUG - 2015-02-14 10:54:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:54:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:54:02 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:54:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:54:02 --> Model Class Initialized
DEBUG - 2015-02-14 10:54:02 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:54:02 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:54:02 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:54:02 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:54:02 --> Model Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Config Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:55:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:55:30 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:55:30 --> URI Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Router Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Output Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Security Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Input Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:55:30 --> Language Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Loader Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:55:30 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:55:30 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:55:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:55:30 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:55:30 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:55:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:55:30 --> Controller Class Initialized
DEBUG - 2015-02-14 10:55:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:55:31 --> Email Class Initialized
DEBUG - 2015-02-14 10:55:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:55:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:55:31 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:55:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:55:31 --> Model Class Initialized
DEBUG - 2015-02-14 10:55:31 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:55:31 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:55:31 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:55:31 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:55:31 --> Model Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Config Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Hooks Class Initialized
DEBUG - 2015-02-14 10:56:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 10:56:30 --> Utf8 Class Initialized
DEBUG - 2015-02-14 10:56:30 --> URI Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Router Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Output Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Security Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Input Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 10:56:30 --> Language Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Loader Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: url_helper
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: link_helper
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 10:56:30 --> CI_Session Class Initialized
DEBUG - 2015-02-14 10:56:30 --> CI_Session routines successfully run
DEBUG - 2015-02-14 10:56:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Controller Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 10:56:30 --> Email Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: language_helper
DEBUG - 2015-02-14 10:56:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 10:56:30 --> Model Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Database Driver Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: date_helper
DEBUG - 2015-02-14 10:56:30 --> Helper loaded: form_helper
DEBUG - 2015-02-14 10:56:30 --> Form Validation Class Initialized
DEBUG - 2015-02-14 10:56:30 --> Model Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Config Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:00:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:00:16 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:00:16 --> URI Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Router Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Output Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Security Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Input Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:00:16 --> Language Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Loader Class Initialized
DEBUG - 2015-02-14 11:00:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:00:16 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:00:16 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:00:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:00:17 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:00:17 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:00:17 --> Model Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Model Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Controller Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:00:17 --> Email Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:00:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:00:17 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:00:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:00:17 --> Model Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:00:17 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:00:17 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:00:17 --> Model Class Initialized
ERROR - 2015-02-14 11:00:17 --> Severity: error --> Exception: EntityManager#remove() expects parameter 1 to be an entity object, array given. D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMInvalidArgumentException.php 101
DEBUG - 2015-02-14 11:00:57 --> Config Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:00:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:00:57 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:00:57 --> URI Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Router Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Output Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Security Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Input Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:00:57 --> Language Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Loader Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:00:57 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:00:57 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:00:57 --> Model Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Model Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Controller Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:00:57 --> Email Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:00:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:00:57 --> Model Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:00:57 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:00:57 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:00:57 --> Model Class Initialized
ERROR - 2015-02-14 11:00:58 --> Severity: error --> Exception: EntityManager#remove() expects parameter 1 to be an entity object, array given. D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMInvalidArgumentException.php 101
ERROR - 2015-02-14 11:00:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at D:\phutx\project\ups\myblog\vendor\tracy\tracy\src\Tracy\Dumper.php:73) D:\phutx\project\ups\myblog\system\core\Common.php 566
DEBUG - 2015-02-14 11:02:31 --> Config Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:02:31 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:02:31 --> URI Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Router Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Output Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Security Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Input Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:02:31 --> Language Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Loader Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:02:31 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:02:31 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:02:31 --> Model Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Model Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Controller Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:02:31 --> Email Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:02:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:02:31 --> Model Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:02:31 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:02:31 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:02:31 --> Model Class Initialized
DEBUG - 2015-02-14 11:02:33 --> Config Class Initialized
DEBUG - 2015-02-14 11:02:33 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:02:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:02:33 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:02:33 --> URI Class Initialized
DEBUG - 2015-02-14 11:02:33 --> Router Class Initialized
DEBUG - 2015-02-14 11:02:33 --> Output Class Initialized
DEBUG - 2015-02-14 11:02:33 --> Security Class Initialized
DEBUG - 2015-02-14 11:02:33 --> Input Class Initialized
DEBUG - 2015-02-14 11:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:02:33 --> Language Class Initialized
ERROR - 2015-02-14 11:02:33 --> 404 Page Not Found: Settings/index
DEBUG - 2015-02-14 11:14:15 --> Config Class Initialized
DEBUG - 2015-02-14 11:14:15 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:14:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:14:15 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:14:15 --> URI Class Initialized
DEBUG - 2015-02-14 11:14:15 --> Router Class Initialized
DEBUG - 2015-02-14 11:14:15 --> Output Class Initialized
DEBUG - 2015-02-14 11:14:15 --> Security Class Initialized
DEBUG - 2015-02-14 11:14:15 --> Input Class Initialized
DEBUG - 2015-02-14 11:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:14:15 --> Language Class Initialized
ERROR - 2015-02-14 11:14:15 --> 404 Page Not Found: Settings/index
DEBUG - 2015-02-14 11:14:18 --> Config Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:14:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:14:18 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:14:18 --> URI Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Router Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Output Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Security Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Input Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:14:18 --> Language Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Loader Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:14:18 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:14:18 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:14:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Controller Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:14:18 --> Email Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:14:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:14:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:14:18 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:14:18 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:14:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Config Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:16:54 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:16:54 --> URI Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Router Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Output Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Security Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Input Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:16:54 --> Language Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Loader Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:16:54 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:16:54 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:16:54 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Controller Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:16:54 --> Email Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:16:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:16:54 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:16:54 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:16:54 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:16:54 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Config Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:16:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:16:56 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:16:56 --> URI Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Router Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Output Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Security Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Input Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:16:56 --> Language Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Loader Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:16:56 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:16:56 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:16:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Controller Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:16:56 --> Email Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:16:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:16:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:16:56 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:16:56 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:16:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:16:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:16:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 11:16:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:16:56 --> Final output sent to browser
DEBUG - 2015-02-14 11:16:56 --> Total execution time: 0.2620
DEBUG - 2015-02-14 11:19:23 --> Config Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:19:23 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:19:23 --> URI Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Router Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Output Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Security Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Input Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:19:23 --> Language Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Loader Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:19:23 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:19:23 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:19:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Controller Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:19:23 --> Email Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:19:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:19:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:19:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:19:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:19:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Config Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:19:24 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:19:24 --> URI Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Router Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Output Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Security Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Input Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:19:24 --> Language Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Loader Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:19:24 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:19:24 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:19:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Controller Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:19:24 --> Email Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:19:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:19:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:19:24 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:19:24 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:19:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:19:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:19:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 11:19:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:19:25 --> Final output sent to browser
DEBUG - 2015-02-14 11:19:25 --> Total execution time: 0.6211
DEBUG - 2015-02-14 11:19:58 --> Config Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:19:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:19:58 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:19:58 --> URI Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Router Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Output Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Security Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Input Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:19:58 --> Language Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Loader Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:19:58 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:19:58 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:19:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:19:58 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:19:58 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:19:58 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Controller Class Initialized
DEBUG - 2015-02-14 11:19:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:19:59 --> Email Class Initialized
DEBUG - 2015-02-14 11:19:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:19:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:19:59 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:19:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:19:59 --> Model Class Initialized
DEBUG - 2015-02-14 11:19:59 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:19:59 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:19:59 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:19:59 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:19:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:19:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:19:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/setting/index.php
DEBUG - 2015-02-14 11:19:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:19:59 --> Final output sent to browser
DEBUG - 2015-02-14 11:19:59 --> Total execution time: 0.2540
DEBUG - 2015-02-14 11:20:10 --> Config Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:20:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:20:10 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:20:10 --> URI Class Initialized
DEBUG - 2015-02-14 11:20:10 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:20:10 --> Router Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Output Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Security Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Input Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:20:10 --> Language Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Loader Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:20:10 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:20:10 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Controller Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:20:10 --> Email Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:20:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:20:10 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:20:10 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:20:10 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:20:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:20:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:20:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:20:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:20:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:20:11 --> Final output sent to browser
DEBUG - 2015-02-14 11:20:11 --> Total execution time: 1.6502
DEBUG - 2015-02-14 11:20:22 --> Config Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:20:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:20:22 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:20:22 --> URI Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Router Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Output Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Security Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Input Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:20:22 --> Language Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Loader Class Initialized
DEBUG - 2015-02-14 11:20:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:20:22 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:20:22 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:20:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:20:22 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:20:23 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:20:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:23 --> Controller Class Initialized
DEBUG - 2015-02-14 11:20:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:20:23 --> Email Class Initialized
DEBUG - 2015-02-14 11:20:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:20:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:20:23 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:20:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:20:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:23 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:20:23 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:20:23 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:20:23 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:20:23 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:20:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:20:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-14 11:20:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:20:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-14 11:20:23 --> Final output sent to browser
DEBUG - 2015-02-14 11:20:23 --> Total execution time: 0.6031
DEBUG - 2015-02-14 11:20:33 --> Config Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:20:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:20:33 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:20:33 --> URI Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Router Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Output Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Security Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Input Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:20:33 --> Language Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Loader Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:20:33 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:20:33 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:20:33 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Controller Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:20:33 --> Email Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:20:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:20:33 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:20:33 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:20:33 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:20:33 --> Model Class Initialized
DEBUG - 2015-02-14 11:20:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:20:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-14 11:20:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:20:35 --> Final output sent to browser
DEBUG - 2015-02-14 11:20:35 --> Total execution time: 2.0502
DEBUG - 2015-02-14 11:23:17 --> Config Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:23:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:23:17 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:23:17 --> URI Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Router Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Output Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Security Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Input Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:23:17 --> Language Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Loader Class Initialized
DEBUG - 2015-02-14 11:23:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:23:18 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:23:18 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:23:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:23:18 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:23:18 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:23:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:23:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:23:18 --> Controller Class Initialized
DEBUG - 2015-02-14 11:23:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:23:18 --> Email Class Initialized
DEBUG - 2015-02-14 11:23:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:23:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:23:18 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:23:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:23:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:23:18 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:23:18 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:23:18 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:23:18 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:23:18 --> Model Class Initialized
DEBUG - 2015-02-14 11:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:23:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-14 11:23:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:23:19 --> Final output sent to browser
DEBUG - 2015-02-14 11:23:19 --> Total execution time: 1.6832
DEBUG - 2015-02-14 11:24:06 --> Config Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:24:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:24:06 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:24:06 --> URI Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Router Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Output Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Security Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Input Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:24:06 --> Language Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Loader Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:24:06 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:24:06 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Controller Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:24:06 --> Email Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:24:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:24:06 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:24:06 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:24:06 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-14 11:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:24:08 --> Final output sent to browser
DEBUG - 2015-02-14 11:24:08 --> Total execution time: 1.6742
DEBUG - 2015-02-14 11:24:20 --> Config Class Initialized
DEBUG - 2015-02-14 11:24:20 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:24:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:24:20 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:24:20 --> URI Class Initialized
DEBUG - 2015-02-14 11:24:20 --> Router Class Initialized
DEBUG - 2015-02-14 11:24:20 --> Output Class Initialized
DEBUG - 2015-02-14 11:24:20 --> Security Class Initialized
DEBUG - 2015-02-14 11:24:20 --> Input Class Initialized
DEBUG - 2015-02-14 11:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:24:20 --> Language Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Loader Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:24:21 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:24:21 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Controller Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:24:21 --> Email Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:24:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:24:21 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:24:21 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:24:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:24:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-14 11:24:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:24:22 --> Final output sent to browser
DEBUG - 2015-02-14 11:24:22 --> Total execution time: 1.6612
DEBUG - 2015-02-14 11:24:41 --> Config Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:24:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:24:41 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:24:41 --> URI Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Router Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Output Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Security Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Input Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:24:41 --> Language Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Loader Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:24:41 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:24:41 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:24:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Controller Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:24:41 --> Email Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:24:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:24:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:24:41 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:24:41 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:24:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:24:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-14 11:24:42 --> Severity: error --> Exception: Unrecognized field: 0 D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 70
DEBUG - 2015-02-14 11:24:50 --> Config Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:24:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:24:50 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:24:50 --> URI Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Router Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Output Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Security Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Input Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:24:50 --> Language Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Loader Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:24:50 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:24:50 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:24:50 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Controller Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:24:50 --> Email Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:24:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:24:50 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:24:50 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:24:50 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:24:50 --> Model Class Initialized
DEBUG - 2015-02-14 11:24:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:24:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:24:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-14 11:24:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:24:51 --> Final output sent to browser
DEBUG - 2015-02-14 11:24:51 --> Total execution time: 1.1751
DEBUG - 2015-02-14 11:25:48 --> Config Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:25:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:25:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:25:48 --> URI Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Router Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Output Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Security Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Input Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:25:48 --> Language Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Loader Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:25:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:25:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:25:48 --> Model Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Model Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Controller Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:25:48 --> Email Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:25:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:25:48 --> Model Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:25:48 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:25:48 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:25:48 --> Model Class Initialized
DEBUG - 2015-02-14 11:25:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:25:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:25:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/sticky.php
DEBUG - 2015-02-14 11:25:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:25:49 --> Final output sent to browser
DEBUG - 2015-02-14 11:25:49 --> Total execution time: 1.2461
DEBUG - 2015-02-14 11:26:39 --> Config Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:26:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:26:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:26:39 --> URI Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Router Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Output Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Security Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Input Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:26:39 --> Language Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Loader Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:26:39 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:26:39 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:26:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Controller Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:26:39 --> Email Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:26:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:26:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:26:39 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:26:39 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:26:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:26:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:26:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/sticky.php
DEBUG - 2015-02-14 11:26:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:26:40 --> Final output sent to browser
DEBUG - 2015-02-14 11:26:40 --> Total execution time: 1.0811
DEBUG - 2015-02-14 11:26:42 --> Config Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:26:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:26:42 --> URI Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Router Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Output Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Security Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Input Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:26:42 --> Language Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Loader Class Initialized
DEBUG - 2015-02-14 11:26:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:26:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:26:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:26:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:26:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:26:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:26:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:43 --> Controller Class Initialized
DEBUG - 2015-02-14 11:26:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:26:43 --> Email Class Initialized
DEBUG - 2015-02-14 11:26:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:26:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:26:43 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:26:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:26:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:43 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:26:43 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:26:43 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:26:43 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:26:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:26:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:26:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:26:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/sticky.php
DEBUG - 2015-02-14 11:26:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:26:44 --> Final output sent to browser
DEBUG - 2015-02-14 11:26:44 --> Total execution time: 1.1531
DEBUG - 2015-02-14 11:27:40 --> Config Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:27:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:27:40 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:27:40 --> URI Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Router Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Output Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Security Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Input Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:27:40 --> Language Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Loader Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:27:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:27:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:27:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Controller Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:27:40 --> Email Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:27:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:27:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:27:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:27:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:27:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:27:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-14 11:27:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-14 11:27:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-14 11:27:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-14 11:27:47 --> Final output sent to browser
DEBUG - 2015-02-14 11:27:47 --> Total execution time: 6.5207
DEBUG - 2015-02-14 11:28:26 --> Config Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:28:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:28:26 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:28:26 --> URI Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Router Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Output Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Security Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Input Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:28:26 --> Language Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Loader Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:28:26 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:28:26 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:28:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Controller Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:28:26 --> Email Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:28:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:28:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:28:26 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:28:26 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:28:26 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:28:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:28:27 --> Final output sent to browser
DEBUG - 2015-02-14 11:28:27 --> Total execution time: 1.4291
DEBUG - 2015-02-14 11:30:03 --> Config Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:30:03 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:30:03 --> URI Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Router Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Output Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Security Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Input Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:30:03 --> Language Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Loader Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:30:03 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:30:03 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:30:03 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Controller Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:30:03 --> Email Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:30:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:30:03 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:30:03 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:30:03 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:30:03 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:30:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:30:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:30:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:30:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:30:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:30:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:30:05 --> Final output sent to browser
DEBUG - 2015-02-14 11:30:05 --> Total execution time: 1.5842
DEBUG - 2015-02-14 11:30:41 --> Config Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:30:41 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:30:41 --> URI Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Router Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Output Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Security Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Input Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:30:41 --> Language Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Loader Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:30:41 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:30:41 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:30:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Controller Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:30:41 --> Email Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:30:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:30:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:30:41 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:30:41 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:30:41 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:30:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:30:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:30:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:30:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:30:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:30:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:30:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:30:42 --> Final output sent to browser
DEBUG - 2015-02-14 11:30:42 --> Total execution time: 1.4301
DEBUG - 2015-02-14 11:34:42 --> Config Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:34:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:34:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:34:42 --> URI Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Router Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Output Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Security Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Input Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:34:42 --> Language Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Loader Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:34:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:34:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:34:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Controller Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:34:42 --> Email Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:34:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:34:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:34:42 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:34:42 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:34:42 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:34:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:34:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:34:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:34:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:34:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:34:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:34:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:34:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:34:43 --> Final output sent to browser
DEBUG - 2015-02-14 11:34:43 --> Total execution time: 1.4651
DEBUG - 2015-02-14 11:36:45 --> Config Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:36:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:36:45 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:36:45 --> URI Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Router Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Output Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Security Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Input Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:36:45 --> Language Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Loader Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:36:45 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:36:45 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:36:45 --> Model Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Model Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Controller Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:36:45 --> Email Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:36:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:36:45 --> Model Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:36:45 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:36:45 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Model Class Initialized
DEBUG - 2015-02-14 11:36:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:36:45 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:36:46 --> Model Class Initialized
DEBUG - 2015-02-14 11:36:46 --> Model Class Initialized
DEBUG - 2015-02-14 11:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:36:47 --> Final output sent to browser
DEBUG - 2015-02-14 11:36:47 --> Total execution time: 1.8832
DEBUG - 2015-02-14 11:38:01 --> Config Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:38:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:38:01 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:38:01 --> URI Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Router Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Output Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Security Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Input Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:38:01 --> Language Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Loader Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:38:01 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:38:01 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Controller Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:38:01 --> Email Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:38:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:38:01 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:38:01 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:38:01 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:38:02 --> Final output sent to browser
DEBUG - 2015-02-14 11:38:02 --> Total execution time: 1.3941
DEBUG - 2015-02-14 11:38:39 --> Config Class Initialized
DEBUG - 2015-02-14 11:38:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:38:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:38:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:38:39 --> URI Class Initialized
DEBUG - 2015-02-14 11:38:39 --> Router Class Initialized
DEBUG - 2015-02-14 11:38:39 --> Output Class Initialized
DEBUG - 2015-02-14 11:38:39 --> Security Class Initialized
DEBUG - 2015-02-14 11:38:39 --> Input Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:38:40 --> Language Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Loader Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:38:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:38:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Controller Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:38:40 --> Email Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:38:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:38:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:38:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:38:40 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:38:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:38:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:38:41 --> Final output sent to browser
DEBUG - 2015-02-14 11:38:41 --> Total execution time: 1.5382
DEBUG - 2015-02-14 11:40:25 --> Config Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:40:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:40:25 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:40:25 --> URI Class Initialized
DEBUG - 2015-02-14 11:40:25 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:40:25 --> Router Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Output Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Security Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Input Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:40:25 --> Language Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Loader Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:40:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:40:25 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:40:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Controller Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:40:25 --> Email Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:40:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:40:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:40:25 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:40:25 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:40:25 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:40:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:26 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:40:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:40:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:40:27 --> Final output sent to browser
DEBUG - 2015-02-14 11:40:27 --> Total execution time: 1.5212
DEBUG - 2015-02-14 11:40:42 --> Config Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:40:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:40:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:40:42 --> URI Class Initialized
DEBUG - 2015-02-14 11:40:42 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:40:42 --> Router Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Output Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Security Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Input Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:40:42 --> Language Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Loader Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:40:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:40:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:40:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:40:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:40:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:40:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Controller Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:40:42 --> Email Class Initialized
DEBUG - 2015-02-14 11:40:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:40:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:40:42 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:40:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:40:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:43 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:40:43 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:40:43 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:40:43 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:40:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:40:43 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:40:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:40:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:40:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:40:44 --> Final output sent to browser
DEBUG - 2015-02-14 11:40:44 --> Total execution time: 1.6072
DEBUG - 2015-02-14 11:41:04 --> Config Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:41:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:41:04 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:41:04 --> URI Class Initialized
DEBUG - 2015-02-14 11:41:04 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:41:04 --> Router Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Output Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Security Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Input Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:41:04 --> Language Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Loader Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:41:04 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:41:04 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:41:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Controller Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:41:04 --> Email Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:41:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:41:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:41:04 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:41:04 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:41:04 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:04 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:41:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:41:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:41:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:41:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:41:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:41:05 --> Final output sent to browser
DEBUG - 2015-02-14 11:41:05 --> Total execution time: 1.5222
DEBUG - 2015-02-14 11:41:08 --> Config Class Initialized
DEBUG - 2015-02-14 11:41:08 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:41:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:41:08 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:41:08 --> URI Class Initialized
DEBUG - 2015-02-14 11:41:08 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:41:08 --> Router Class Initialized
DEBUG - 2015-02-14 11:41:08 --> Output Class Initialized
DEBUG - 2015-02-14 11:41:08 --> Security Class Initialized
DEBUG - 2015-02-14 11:41:08 --> Input Class Initialized
DEBUG - 2015-02-14 11:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:41:08 --> Language Class Initialized
DEBUG - 2015-02-14 11:41:08 --> Loader Class Initialized
DEBUG - 2015-02-14 11:41:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:41:08 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:41:08 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:41:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:41:08 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:41:08 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:41:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Controller Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:41:09 --> Email Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:41:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:41:09 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:41:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:41:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:41:09 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:41:09 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:41:09 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:41:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:41:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:41:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:41:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:41:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:41:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:41:10 --> Final output sent to browser
DEBUG - 2015-02-14 11:41:10 --> Total execution time: 1.5902
DEBUG - 2015-02-14 11:43:11 --> Config Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:43:11 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:43:11 --> URI Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Router Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Output Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Security Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Input Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:43:11 --> Language Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Loader Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:43:11 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:43:11 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:43:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Controller Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:43:11 --> Email Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:43:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:43:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:43:11 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:43:11 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:43:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:12 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:12 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:43:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:43:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-14 11:43:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-14 11:43:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:43:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:43:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:43:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-14 11:43:13 --> Final output sent to browser
DEBUG - 2015-02-14 11:43:13 --> Total execution time: 2.0782
DEBUG - 2015-02-14 11:43:14 --> Config Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:43:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:43:14 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:43:14 --> URI Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Router Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Output Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Security Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Input Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:43:14 --> Language Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Loader Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:43:14 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:43:14 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:43:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Controller Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:43:14 --> Email Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:43:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:43:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:43:14 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:43:14 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:43:15 --> Final output sent to browser
DEBUG - 2015-02-14 11:43:15 --> Total execution time: 1.3171
DEBUG - 2015-02-14 11:44:22 --> Config Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:44:22 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:44:22 --> URI Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Router Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Output Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Security Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Input Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:44:22 --> Language Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Loader Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:44:22 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:44:22 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:44:22 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Controller Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:44:22 --> Email Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:44:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:44:22 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:44:22 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:44:22 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:44:22 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:44:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-14 11:44:24 --> Final output sent to browser
DEBUG - 2015-02-14 11:44:24 --> Total execution time: 1.9572
DEBUG - 2015-02-14 11:44:25 --> Config Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:44:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:44:25 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:44:25 --> URI Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Router Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Output Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Security Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Input Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:44:25 --> Language Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Loader Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:44:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:44:25 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:44:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Controller Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:44:25 --> Email Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:44:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:44:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:44:25 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:44:25 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:26 --> Final output sent to browser
DEBUG - 2015-02-14 11:44:26 --> Total execution time: 1.2451
DEBUG - 2015-02-14 11:44:40 --> Config Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:44:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:44:40 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:44:40 --> URI Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Router Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Output Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Security Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Input Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:44:40 --> Language Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Loader Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:44:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:44:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:44:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Controller Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:44:40 --> Email Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:44:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:44:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:44:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:44:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:44:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:44:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-14 11:44:41 --> Final output sent to browser
DEBUG - 2015-02-14 11:44:41 --> Total execution time: 1.7092
DEBUG - 2015-02-14 11:44:46 --> Config Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:44:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:44:46 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:44:46 --> URI Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Router Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Output Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Security Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Input Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:44:46 --> Language Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Loader Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:44:46 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:44:46 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:44:46 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Controller Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:44:46 --> Email Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:44:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:44:46 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:44:46 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:44:46 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:46 --> Model Class Initialized
DEBUG - 2015-02-14 11:44:47 --> Final output sent to browser
DEBUG - 2015-02-14 11:44:47 --> Total execution time: 1.1511
DEBUG - 2015-02-14 11:45:08 --> Config Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:45:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:45:08 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:45:08 --> URI Class Initialized
DEBUG - 2015-02-14 11:45:08 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:45:08 --> Router Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Output Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Security Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Input Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:45:08 --> Language Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Loader Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:45:08 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:45:08 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:45:08 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Controller Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:45:08 --> Email Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:45:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:45:08 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:45:08 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:45:08 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:45:08 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:08 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:45:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:45:09 --> Final output sent to browser
DEBUG - 2015-02-14 11:45:09 --> Total execution time: 1.4941
DEBUG - 2015-02-14 11:45:35 --> Config Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:45:35 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:45:35 --> URI Class Initialized
DEBUG - 2015-02-14 11:45:35 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:45:35 --> Router Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Output Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Security Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Input Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:45:35 --> Language Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Loader Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:45:35 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:45:35 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:45:35 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Controller Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:45:35 --> Email Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:45:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:45:35 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:45:35 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:45:35 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:45:35 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:45:36 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:36 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:45:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:45:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:45:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:45:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:45:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:45:37 --> Final output sent to browser
DEBUG - 2015-02-14 11:45:37 --> Total execution time: 1.4591
DEBUG - 2015-02-14 11:45:51 --> Config Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:45:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:45:51 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:45:51 --> URI Class Initialized
DEBUG - 2015-02-14 11:45:51 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:45:51 --> Router Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Output Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Security Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Input Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:45:51 --> Language Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Loader Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:45:51 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:45:51 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:45:51 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Controller Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:45:51 --> Email Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:45:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:45:51 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:45:51 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:45:51 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:45:51 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:45:52 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:52 --> Model Class Initialized
DEBUG - 2015-02-14 11:45:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:45:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:45:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:45:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:45:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:45:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:45:53 --> Final output sent to browser
DEBUG - 2015-02-14 11:45:53 --> Total execution time: 1.5172
DEBUG - 2015-02-14 11:46:21 --> Config Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:46:21 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:46:21 --> URI Class Initialized
DEBUG - 2015-02-14 11:46:21 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:46:21 --> Router Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Output Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Security Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Input Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:46:21 --> Language Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Loader Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:46:21 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:46:21 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:46:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Controller Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:46:21 --> Email Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:46:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:46:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:46:21 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:46:21 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:46:21 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:46:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:46:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:46:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:46:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:46:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:46:22 --> Final output sent to browser
DEBUG - 2015-02-14 11:46:22 --> Total execution time: 1.5292
DEBUG - 2015-02-14 11:46:40 --> Config Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:46:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:46:40 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:46:40 --> URI Class Initialized
DEBUG - 2015-02-14 11:46:40 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:46:40 --> Router Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Output Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Security Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Input Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:46:40 --> Language Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Loader Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:46:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:46:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:46:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Controller Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:46:40 --> Email Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:46:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:46:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:46:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:46:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:46:40 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:46:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:41 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:46:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:46:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:46:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:46:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:46:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:46:41 --> Final output sent to browser
DEBUG - 2015-02-14 11:46:41 --> Total execution time: 1.7592
DEBUG - 2015-02-14 11:46:43 --> Config Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:46:43 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:46:43 --> URI Class Initialized
DEBUG - 2015-02-14 11:46:43 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:46:43 --> Router Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Output Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Security Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Input Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:46:43 --> Language Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Loader Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:46:43 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:46:43 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:46:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Controller Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:46:43 --> Email Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:46:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:46:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:46:43 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:46:43 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:46:43 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:46:44 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:44 --> Model Class Initialized
DEBUG - 2015-02-14 11:46:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:46:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:46:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:46:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:46:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:46:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:46:45 --> Final output sent to browser
DEBUG - 2015-02-14 11:46:45 --> Total execution time: 1.5092
DEBUG - 2015-02-14 11:47:10 --> Config Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:47:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:47:10 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:47:10 --> URI Class Initialized
DEBUG - 2015-02-14 11:47:10 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:47:10 --> Router Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Output Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Security Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Input Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:47:10 --> Language Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Loader Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:47:10 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:47:10 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:47:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Controller Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:47:10 --> Email Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:47:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:47:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:47:10 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:47:10 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:47:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:47:10 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:47:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:47:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:47:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:47:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:47:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:47:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:47:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:47:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:47:12 --> Final output sent to browser
DEBUG - 2015-02-14 11:47:12 --> Total execution time: 1.5542
DEBUG - 2015-02-14 11:48:20 --> Config Class Initialized
DEBUG - 2015-02-14 11:48:20 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:48:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:48:20 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:48:20 --> URI Class Initialized
DEBUG - 2015-02-14 11:48:20 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:48:20 --> Router Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Output Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Security Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Input Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:48:21 --> Language Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Loader Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:48:21 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:48:21 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:48:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Controller Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:48:21 --> Email Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:48:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:48:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:48:21 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:48:21 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:48:21 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:48:21 --> Model Class Initialized
DEBUG - 2015-02-14 11:48:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:48:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:48:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:48:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:48:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:48:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:48:22 --> Final output sent to browser
DEBUG - 2015-02-14 11:48:22 --> Total execution time: 1.5852
DEBUG - 2015-02-14 11:49:24 --> Config Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:49:24 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:49:24 --> URI Class Initialized
DEBUG - 2015-02-14 11:49:24 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:49:24 --> Router Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Output Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Security Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Input Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:49:24 --> Language Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Loader Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:49:24 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:49:24 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:49:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Controller Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:49:24 --> Email Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:49:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:49:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:49:24 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:49:24 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:49:24 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:49:24 --> Model Class Initialized
DEBUG - 2015-02-14 11:49:25 --> Model Class Initialized
DEBUG - 2015-02-14 11:49:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:49:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:49:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:49:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:49:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:49:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:49:25 --> Final output sent to browser
DEBUG - 2015-02-14 11:49:25 --> Total execution time: 1.4411
DEBUG - 2015-02-14 11:50:19 --> Config Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:50:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:50:19 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:50:19 --> URI Class Initialized
DEBUG - 2015-02-14 11:50:19 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:50:19 --> Router Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Output Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Security Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Input Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:50:19 --> Language Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Loader Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:50:19 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:50:19 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:50:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Controller Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:50:19 --> Email Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:50:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:50:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:50:19 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:50:19 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:50:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:50:19 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:50:20 --> Model Class Initialized
DEBUG - 2015-02-14 11:50:20 --> Model Class Initialized
DEBUG - 2015-02-14 11:50:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:50:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:50:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:50:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:50:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:50:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:50:21 --> Final output sent to browser
DEBUG - 2015-02-14 11:50:21 --> Total execution time: 1.5322
DEBUG - 2015-02-14 11:51:10 --> Config Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:51:10 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:51:10 --> URI Class Initialized
DEBUG - 2015-02-14 11:51:10 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:51:10 --> Router Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Output Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Security Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Input Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:51:10 --> Language Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Loader Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:51:10 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:51:10 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Controller Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:51:10 --> Email Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:51:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:51:10 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:51:10 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:51:10 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:51:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:51:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:51:11 --> Final output sent to browser
DEBUG - 2015-02-14 11:51:11 --> Total execution time: 1.5192
DEBUG - 2015-02-14 11:51:36 --> Config Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:51:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:51:36 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:51:36 --> URI Class Initialized
DEBUG - 2015-02-14 11:51:36 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:51:36 --> Router Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Output Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Security Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Input Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:51:36 --> Language Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Loader Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:51:36 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:51:36 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:51:36 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Controller Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:51:36 --> Email Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:51:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:51:36 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:51:36 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:51:36 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:51:36 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:51:37 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:37 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:51:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:51:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:51:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:51:38 --> Final output sent to browser
DEBUG - 2015-02-14 11:51:38 --> Total execution time: 1.5952
DEBUG - 2015-02-14 11:51:59 --> Config Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:51:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:51:59 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:51:59 --> URI Class Initialized
DEBUG - 2015-02-14 11:51:59 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:51:59 --> Router Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Output Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Security Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Input Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:51:59 --> Language Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Loader Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:51:59 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:51:59 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Controller Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:51:59 --> Email Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:51:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:51:59 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:51:59 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:51:59 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 11:52:00 --> Model Class Initialized
DEBUG - 2015-02-14 11:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:52:00 --> Final output sent to browser
DEBUG - 2015-02-14 11:52:00 --> Total execution time: 1.5602
DEBUG - 2015-02-14 11:54:19 --> Config Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:54:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:54:19 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:54:19 --> URI Class Initialized
DEBUG - 2015-02-14 11:54:19 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:54:19 --> Router Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Output Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Security Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Input Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:54:19 --> Language Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Loader Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:54:19 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:54:19 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:54:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Controller Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:54:19 --> Email Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:54:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:54:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:54:19 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:54:19 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:54:19 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:19 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:54:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:54:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:54:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:54:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:54:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:54:20 --> Final output sent to browser
DEBUG - 2015-02-14 11:54:20 --> Total execution time: 1.6362
DEBUG - 2015-02-14 11:54:56 --> Config Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:54:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:54:56 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:54:56 --> URI Class Initialized
DEBUG - 2015-02-14 11:54:56 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:54:56 --> Router Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Output Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Security Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Input Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:54:56 --> Language Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Loader Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:54:56 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:54:56 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:54:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Controller Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:54:56 --> Email Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:54:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:54:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:54:56 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:54:56 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:54:56 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:54:57 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:57 --> Model Class Initialized
DEBUG - 2015-02-14 11:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:54:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:54:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:54:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:54:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:54:58 --> Final output sent to browser
DEBUG - 2015-02-14 11:54:58 --> Total execution time: 1.6232
DEBUG - 2015-02-14 11:55:14 --> Config Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:55:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:55:14 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:55:14 --> URI Class Initialized
DEBUG - 2015-02-14 11:55:14 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:55:14 --> Router Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Output Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Security Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Input Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:55:14 --> Language Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Loader Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:55:14 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:55:14 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:55:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Controller Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:55:14 --> Email Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:55:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:55:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:55:14 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:55:14 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Model Class Initialized
DEBUG - 2015-02-14 11:55:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:55:14 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:55:15 --> Model Class Initialized
DEBUG - 2015-02-14 11:55:15 --> Model Class Initialized
DEBUG - 2015-02-14 11:55:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:55:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:55:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:55:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:55:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:55:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:55:16 --> Final output sent to browser
DEBUG - 2015-02-14 11:55:16 --> Total execution time: 1.5492
DEBUG - 2015-02-14 11:56:11 --> Config Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:56:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:56:11 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:56:11 --> URI Class Initialized
DEBUG - 2015-02-14 11:56:11 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:56:11 --> Router Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Output Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Security Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Input Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:56:11 --> Language Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Loader Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:56:11 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:56:11 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:56:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Controller Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:56:11 --> Email Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:56:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:56:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:56:11 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:56:11 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:56:11 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:56:11 --> Model Class Initialized
DEBUG - 2015-02-14 11:56:12 --> Model Class Initialized
DEBUG - 2015-02-14 11:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:56:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:56:12 --> Final output sent to browser
DEBUG - 2015-02-14 11:56:12 --> Total execution time: 1.6702
DEBUG - 2015-02-14 11:57:07 --> Config Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:57:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:57:07 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:57:07 --> URI Class Initialized
DEBUG - 2015-02-14 11:57:07 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:57:07 --> Router Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Output Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Security Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Input Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:57:07 --> Language Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Loader Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:57:07 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:57:07 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:57:07 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Controller Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:57:07 --> Email Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:57:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:57:07 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:57:07 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:57:07 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:57:07 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:07 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:57:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:57:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:57:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:57:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:57:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:57:08 --> Final output sent to browser
DEBUG - 2015-02-14 11:57:08 --> Total execution time: 1.5302
DEBUG - 2015-02-14 11:57:55 --> Config Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:57:55 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:57:55 --> URI Class Initialized
DEBUG - 2015-02-14 11:57:55 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:57:55 --> Router Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Output Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Security Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Input Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:57:55 --> Language Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Loader Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:57:55 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:57:55 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:57:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:57:55 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:57:55 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:57:55 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Controller Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:57:55 --> Email Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:57:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:57:55 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:57:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:57:55 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:55 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:57:56 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:57:56 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:57:56 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:57:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:57:56 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:57:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:56 --> Model Class Initialized
DEBUG - 2015-02-14 11:57:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:57:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:57:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:57:57 --> Final output sent to browser
DEBUG - 2015-02-14 11:57:57 --> Total execution time: 1.5462
DEBUG - 2015-02-14 11:58:09 --> Config Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:58:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:58:09 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:58:09 --> URI Class Initialized
DEBUG - 2015-02-14 11:58:09 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:58:09 --> Router Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Output Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Security Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Input Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:58:09 --> Language Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Loader Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:58:09 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:58:09 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:58:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Controller Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:58:09 --> Email Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:58:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:58:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:58:09 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:58:09 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:58:09 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:58:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:10 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:58:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:58:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:58:11 --> Final output sent to browser
DEBUG - 2015-02-14 11:58:11 --> Total execution time: 1.5682
DEBUG - 2015-02-14 11:58:38 --> Config Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:58:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:58:38 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:58:38 --> URI Class Initialized
DEBUG - 2015-02-14 11:58:38 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:58:38 --> Router Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Output Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Security Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Input Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:58:38 --> Language Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Loader Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:58:38 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:58:38 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:58:38 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Controller Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:58:38 --> Email Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:58:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:58:38 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:58:38 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:58:38 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:58:38 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:58:38 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:58:39 --> Final output sent to browser
DEBUG - 2015-02-14 11:58:39 --> Total execution time: 1.4881
DEBUG - 2015-02-14 11:59:39 --> Config Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 11:59:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 11:59:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 11:59:39 --> URI Class Initialized
DEBUG - 2015-02-14 11:59:39 --> No URI present. Default controller set.
DEBUG - 2015-02-14 11:59:39 --> Router Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Output Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Security Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Input Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 11:59:39 --> Language Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Loader Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: url_helper
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: link_helper
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 11:59:39 --> CI_Session Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Session: Regenerate ID
DEBUG - 2015-02-14 11:59:39 --> CI_Session routines successfully run
DEBUG - 2015-02-14 11:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Controller Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 11:59:39 --> Email Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: language_helper
DEBUG - 2015-02-14 11:59:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 11:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Database Driver Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: date_helper
DEBUG - 2015-02-14 11:59:39 --> Helper loaded: form_helper
DEBUG - 2015-02-14 11:59:39 --> Form Validation Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Model Class Initialized
DEBUG - 2015-02-14 11:59:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 11:59:39 --> Pagination Class Initialized
DEBUG - 2015-02-14 11:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:59:40 --> Model Class Initialized
DEBUG - 2015-02-14 11:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 11:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 11:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 11:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 11:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 11:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 11:59:41 --> Final output sent to browser
DEBUG - 2015-02-14 11:59:41 --> Total execution time: 1.5752
DEBUG - 2015-02-14 12:00:11 --> Config Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:00:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:00:11 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:00:11 --> URI Class Initialized
DEBUG - 2015-02-14 12:00:11 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:00:11 --> Router Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Output Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Security Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Input Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:00:11 --> Language Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Loader Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:00:11 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:00:11 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:00:11 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Controller Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:00:11 --> Email Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:00:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:00:11 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:00:11 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:00:11 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:00:11 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:00:11 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:12 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:00:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:00:12 --> Final output sent to browser
DEBUG - 2015-02-14 12:00:12 --> Total execution time: 1.5062
DEBUG - 2015-02-14 12:00:34 --> Config Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:00:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:00:34 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:00:34 --> URI Class Initialized
DEBUG - 2015-02-14 12:00:34 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:00:34 --> Router Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Output Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Security Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Input Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:00:34 --> Language Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Loader Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:00:34 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:00:34 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Controller Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:00:34 --> Email Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:00:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:00:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:00:34 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Config Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:00:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:00:34 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:00:34 --> URI Class Initialized
DEBUG - 2015-02-14 12:00:34 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:00:34 --> Router Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Output Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Security Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Input Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:00:34 --> Language Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Loader Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:00:34 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:00:34 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Controller Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:00:34 --> Email Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:00:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:00:34 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:00:34 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:00:34 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:00:34 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:35 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:35 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:00:35 --> Model Class Initialized
DEBUG - 2015-02-14 12:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:00:36 --> Final output sent to browser
DEBUG - 2015-02-14 12:00:36 --> Total execution time: 1.8382
DEBUG - 2015-02-14 12:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:00:36 --> Final output sent to browser
DEBUG - 2015-02-14 12:00:36 --> Total execution time: 1.9262
DEBUG - 2015-02-14 12:00:59 --> Config Class Initialized
DEBUG - 2015-02-14 12:00:59 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:00:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:00:59 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:00:59 --> URI Class Initialized
DEBUG - 2015-02-14 12:00:59 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:00:59 --> Router Class Initialized
DEBUG - 2015-02-14 12:00:59 --> Output Class Initialized
DEBUG - 2015-02-14 12:00:59 --> Security Class Initialized
DEBUG - 2015-02-14 12:00:59 --> Input Class Initialized
DEBUG - 2015-02-14 12:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:00:59 --> Language Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Loader Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:01:00 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:01:00 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:01:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Controller Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:01:00 --> Email Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:01:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:01:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:01:00 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:01:00 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:01:00 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:01:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:01:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:01:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:01:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:01:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:01:01 --> Final output sent to browser
DEBUG - 2015-02-14 12:01:01 --> Total execution time: 1.5372
DEBUG - 2015-02-14 12:01:35 --> Config Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:01:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:01:35 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:01:35 --> URI Class Initialized
DEBUG - 2015-02-14 12:01:35 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:01:35 --> Router Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Output Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Security Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Input Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:01:35 --> Language Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Loader Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:01:35 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:01:35 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Controller Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:01:35 --> Email Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:01:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:01:35 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:01:35 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:01:35 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:01:36 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:36 --> Model Class Initialized
DEBUG - 2015-02-14 12:01:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:01:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:01:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:01:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:01:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:01:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:01:37 --> Final output sent to browser
DEBUG - 2015-02-14 12:01:37 --> Total execution time: 1.5001
DEBUG - 2015-02-14 12:02:06 --> Config Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:02:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:02:06 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:02:06 --> URI Class Initialized
DEBUG - 2015-02-14 12:02:06 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:02:06 --> Router Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Output Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Security Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Input Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:02:06 --> Language Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Loader Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:02:06 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:02:06 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:02:06 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Controller Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:02:06 --> Email Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:02:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:02:06 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:02:06 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:02:06 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:02:06 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:02:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:02:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:02:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:02:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:02:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:02:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:02:07 --> Final output sent to browser
DEBUG - 2015-02-14 12:02:07 --> Total execution time: 1.5142
DEBUG - 2015-02-14 12:02:17 --> Config Class Initialized
DEBUG - 2015-02-14 12:02:17 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:02:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:02:17 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:02:17 --> URI Class Initialized
DEBUG - 2015-02-14 12:02:17 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:02:17 --> Router Class Initialized
DEBUG - 2015-02-14 12:02:17 --> Output Class Initialized
DEBUG - 2015-02-14 12:02:17 --> Security Class Initialized
DEBUG - 2015-02-14 12:02:17 --> Input Class Initialized
DEBUG - 2015-02-14 12:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:02:17 --> Language Class Initialized
DEBUG - 2015-02-14 12:02:17 --> Loader Class Initialized
DEBUG - 2015-02-14 12:02:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:02:17 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:02:17 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:02:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:02:17 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:02:17 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:02:18 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Controller Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:02:18 --> Email Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:02:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:02:18 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:02:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:02:18 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:02:18 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:02:18 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:02:18 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:18 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:02:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:02:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:02:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:02:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:02:19 --> Final output sent to browser
DEBUG - 2015-02-14 12:02:19 --> Total execution time: 1.4861
DEBUG - 2015-02-14 12:02:42 --> Config Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:02:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:02:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:02:42 --> URI Class Initialized
DEBUG - 2015-02-14 12:02:42 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:02:42 --> Router Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Output Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Security Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Input Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:02:42 --> Language Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Loader Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:02:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:02:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:02:42 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Controller Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:02:42 --> Email Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:02:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:02:42 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:02:42 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:02:42 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:02:42 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:02:43 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:43 --> Model Class Initialized
DEBUG - 2015-02-14 12:02:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:02:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:02:44 --> Final output sent to browser
DEBUG - 2015-02-14 12:02:44 --> Total execution time: 1.4591
DEBUG - 2015-02-14 12:03:07 --> Config Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:03:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:03:07 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:03:07 --> URI Class Initialized
DEBUG - 2015-02-14 12:03:07 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:03:07 --> Router Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Output Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Security Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Input Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:03:07 --> Language Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Loader Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:03:07 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:03:07 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Controller Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:03:07 --> Email Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:03:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:03:07 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:03:07 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:03:07 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:07 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:03:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:03:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:03:08 --> Final output sent to browser
DEBUG - 2015-02-14 12:03:08 --> Total execution time: 1.5632
DEBUG - 2015-02-14 12:03:27 --> Config Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:03:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:03:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:03:27 --> URI Class Initialized
DEBUG - 2015-02-14 12:03:27 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:03:27 --> Router Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Output Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Security Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Input Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:03:27 --> Language Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Loader Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:03:27 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:03:27 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:03:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Controller Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:03:27 --> Email Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:03:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:03:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:03:27 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:03:27 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:03:27 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:03:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:28 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:03:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:03:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:03:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:03:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:03:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:03:28 --> Final output sent to browser
DEBUG - 2015-02-14 12:03:28 --> Total execution time: 1.4761
DEBUG - 2015-02-14 12:03:58 --> Config Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:03:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:03:58 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:03:58 --> URI Class Initialized
DEBUG - 2015-02-14 12:03:58 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:03:58 --> Router Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Output Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Security Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Input Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:03:58 --> Language Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Loader Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:03:58 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:03:58 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:03:58 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Controller Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:03:58 --> Email Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:03:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:03:58 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:03:58 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:03:58 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:03:58 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:58 --> Model Class Initialized
DEBUG - 2015-02-14 12:03:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:03:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:03:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:03:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:03:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:03:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:03:59 --> Final output sent to browser
DEBUG - 2015-02-14 12:03:59 --> Total execution time: 1.5732
DEBUG - 2015-02-14 12:04:00 --> Config Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:04:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:04:00 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:04:00 --> URI Class Initialized
DEBUG - 2015-02-14 12:04:00 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:04:00 --> Router Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Output Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Security Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Input Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:04:00 --> Language Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Loader Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:04:00 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:04:00 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:04:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Controller Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:04:00 --> Email Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:04:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:04:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:04:00 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:04:00 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:04:00 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:04:00 --> Model Class Initialized
DEBUG - 2015-02-14 12:04:01 --> Model Class Initialized
DEBUG - 2015-02-14 12:04:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:04:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:04:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:04:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:04:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:04:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:04:01 --> Final output sent to browser
DEBUG - 2015-02-14 12:04:01 --> Total execution time: 1.5692
DEBUG - 2015-02-14 12:06:25 --> Config Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:06:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:06:25 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:06:25 --> URI Class Initialized
DEBUG - 2015-02-14 12:06:25 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:06:25 --> Router Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Output Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Security Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Input Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:06:25 --> Language Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Loader Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:06:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Session: Regenerate ID
DEBUG - 2015-02-14 12:06:25 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:06:25 --> Model Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Model Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Controller Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:06:25 --> Email Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:06:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:06:25 --> Model Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:06:25 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:06:25 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Model Class Initialized
DEBUG - 2015-02-14 12:06:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:06:25 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:06:26 --> Model Class Initialized
DEBUG - 2015-02-14 12:06:26 --> Model Class Initialized
DEBUG - 2015-02-14 12:06:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:06:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:06:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:06:27 --> Final output sent to browser
DEBUG - 2015-02-14 12:06:27 --> Total execution time: 1.5312
DEBUG - 2015-02-14 12:20:26 --> Config Class Initialized
DEBUG - 2015-02-14 12:20:26 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:20:26 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:20:26 --> URI Class Initialized
DEBUG - 2015-02-14 12:20:26 --> No URI present. Default controller set.
DEBUG - 2015-02-14 12:20:26 --> Router Class Initialized
DEBUG - 2015-02-14 12:20:26 --> Output Class Initialized
DEBUG - 2015-02-14 12:20:26 --> Security Class Initialized
DEBUG - 2015-02-14 12:20:26 --> Input Class Initialized
DEBUG - 2015-02-14 12:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:20:26 --> Language Class Initialized
DEBUG - 2015-02-14 12:20:26 --> Loader Class Initialized
DEBUG - 2015-02-14 12:20:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:20:27 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:20:27 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:20:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:20:27 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Session: Regenerate ID
DEBUG - 2015-02-14 12:20:27 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:20:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Controller Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:20:27 --> Email Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:20:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:20:27 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:20:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:20:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:20:27 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:20:27 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:20:27 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:27 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:20:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:20:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:20:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:20:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:20:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:20:28 --> Final output sent to browser
DEBUG - 2015-02-14 12:20:28 --> Total execution time: 1.4901
DEBUG - 2015-02-14 12:20:39 --> Config Class Initialized
DEBUG - 2015-02-14 12:20:39 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:20:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:20:39 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:20:39 --> URI Class Initialized
DEBUG - 2015-02-14 12:20:39 --> Router Class Initialized
DEBUG - 2015-02-14 12:20:39 --> Output Class Initialized
DEBUG - 2015-02-14 12:20:39 --> Security Class Initialized
DEBUG - 2015-02-14 12:20:39 --> Input Class Initialized
DEBUG - 2015-02-14 12:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:20:39 --> Language Class Initialized
DEBUG - 2015-02-14 12:20:39 --> Loader Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:20:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:20:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:20:40 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Controller Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:20:40 --> Email Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:20:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:20:40 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:20:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:20:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:20:40 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:40 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:20:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:20:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:20:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:20:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:20:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:20:41 --> Final output sent to browser
DEBUG - 2015-02-14 12:20:41 --> Total execution time: 1.3861
DEBUG - 2015-02-14 12:20:48 --> Config Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:20:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:20:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:20:48 --> URI Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Router Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Output Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Security Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Input Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:20:48 --> Language Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Loader Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:20:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:20:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:20:48 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Controller Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:20:48 --> Email Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:20:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:20:48 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:20:48 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:20:48 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:20:48 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:48 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:20:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:20:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:20:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:20:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:20:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:20:49 --> Final output sent to browser
DEBUG - 2015-02-14 12:20:49 --> Total execution time: 1.3831
DEBUG - 2015-02-14 12:20:53 --> Config Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:20:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:20:53 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:20:53 --> URI Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Router Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Output Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Security Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Input Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:20:53 --> Language Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Loader Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:20:53 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:20:53 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:20:53 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Controller Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:20:53 --> Email Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:20:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:20:53 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:20:53 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:20:53 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:20:53 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:20:54 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:54 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:20:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:20:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:20:55 --> Final output sent to browser
DEBUG - 2015-02-14 12:20:55 --> Total execution time: 1.4041
DEBUG - 2015-02-14 12:20:57 --> Config Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:20:57 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:20:57 --> URI Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Router Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Output Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Security Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Input Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:20:57 --> Language Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Loader Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:20:57 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:20:57 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:20:57 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Controller Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:20:57 --> Email Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:20:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:20:57 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:20:57 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:20:57 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:20:57 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:20:57 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:58 --> Model Class Initialized
DEBUG - 2015-02-14 12:20:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:20:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:20:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:20:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:20:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:20:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:20:58 --> Final output sent to browser
DEBUG - 2015-02-14 12:20:58 --> Total execution time: 1.4381
DEBUG - 2015-02-14 12:35:59 --> Config Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:35:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:35:59 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:35:59 --> URI Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Router Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Output Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Security Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Input Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:35:59 --> Language Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Loader Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:35:59 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Session: Regenerate ID
DEBUG - 2015-02-14 12:35:59 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:35:59 --> Model Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Model Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Controller Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:35:59 --> Email Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:35:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:35:59 --> Model Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:35:59 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:35:59 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Model Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:35:59 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Model Class Initialized
DEBUG - 2015-02-14 12:35:59 --> Model Class Initialized
DEBUG - 2015-02-14 12:35:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:35:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:36:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:36:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:36:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:36:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:36:00 --> Final output sent to browser
DEBUG - 2015-02-14 12:36:00 --> Total execution time: 1.3261
DEBUG - 2015-02-14 12:51:01 --> Config Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Hooks Class Initialized
DEBUG - 2015-02-14 12:51:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 12:51:01 --> Utf8 Class Initialized
DEBUG - 2015-02-14 12:51:01 --> URI Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Router Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Output Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Security Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Input Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 12:51:01 --> Language Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Loader Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 12:51:01 --> CI_Session Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Session: Regenerate ID
DEBUG - 2015-02-14 12:51:01 --> CI_Session routines successfully run
DEBUG - 2015-02-14 12:51:01 --> Model Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Model Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Controller Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 12:51:01 --> Email Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: language_helper
DEBUG - 2015-02-14 12:51:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 12:51:01 --> Model Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Database Driver Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: date_helper
DEBUG - 2015-02-14 12:51:01 --> Helper loaded: form_helper
DEBUG - 2015-02-14 12:51:01 --> Form Validation Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Model Class Initialized
DEBUG - 2015-02-14 12:51:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 12:51:01 --> Pagination Class Initialized
DEBUG - 2015-02-14 12:51:02 --> Model Class Initialized
DEBUG - 2015-02-14 12:51:02 --> Model Class Initialized
DEBUG - 2015-02-14 12:51:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 12:51:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 12:51:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 12:51:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 12:51:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 12:51:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 12:51:03 --> Final output sent to browser
DEBUG - 2015-02-14 12:51:03 --> Total execution time: 1.5962
DEBUG - 2015-02-14 13:06:05 --> Config Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Hooks Class Initialized
DEBUG - 2015-02-14 13:06:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 13:06:05 --> Utf8 Class Initialized
DEBUG - 2015-02-14 13:06:05 --> URI Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Router Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Output Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Security Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Input Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 13:06:05 --> Language Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Loader Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: url_helper
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: link_helper
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 13:06:05 --> CI_Session Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Session: Regenerate ID
DEBUG - 2015-02-14 13:06:05 --> CI_Session routines successfully run
DEBUG - 2015-02-14 13:06:05 --> Model Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Model Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Controller Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 13:06:05 --> Email Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: language_helper
DEBUG - 2015-02-14 13:06:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 13:06:05 --> Model Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Database Driver Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: date_helper
DEBUG - 2015-02-14 13:06:05 --> Helper loaded: form_helper
DEBUG - 2015-02-14 13:06:05 --> Form Validation Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Model Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 13:06:05 --> Pagination Class Initialized
DEBUG - 2015-02-14 13:06:05 --> Model Class Initialized
DEBUG - 2015-02-14 13:06:06 --> Model Class Initialized
DEBUG - 2015-02-14 13:06:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 13:06:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 13:06:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 13:06:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 13:06:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 13:06:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 13:06:06 --> Final output sent to browser
DEBUG - 2015-02-14 13:06:06 --> Total execution time: 1.5272
DEBUG - 2015-02-14 13:21:07 --> Config Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Hooks Class Initialized
DEBUG - 2015-02-14 13:21:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 13:21:07 --> Utf8 Class Initialized
DEBUG - 2015-02-14 13:21:07 --> URI Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Router Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Output Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Security Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Input Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 13:21:07 --> Language Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Loader Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: url_helper
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: link_helper
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 13:21:07 --> CI_Session Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Session: Regenerate ID
DEBUG - 2015-02-14 13:21:07 --> CI_Session routines successfully run
DEBUG - 2015-02-14 13:21:07 --> Model Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Model Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Controller Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 13:21:07 --> Email Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: language_helper
DEBUG - 2015-02-14 13:21:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 13:21:07 --> Model Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Database Driver Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: date_helper
DEBUG - 2015-02-14 13:21:07 --> Helper loaded: form_helper
DEBUG - 2015-02-14 13:21:07 --> Form Validation Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Model Class Initialized
DEBUG - 2015-02-14 13:21:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 13:21:07 --> Pagination Class Initialized
DEBUG - 2015-02-14 13:21:08 --> Model Class Initialized
DEBUG - 2015-02-14 13:21:08 --> Model Class Initialized
DEBUG - 2015-02-14 13:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 13:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 13:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 13:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 13:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 13:21:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 13:21:09 --> Final output sent to browser
DEBUG - 2015-02-14 13:21:09 --> Total execution time: 1.4091
DEBUG - 2015-02-14 13:36:10 --> Config Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Hooks Class Initialized
DEBUG - 2015-02-14 13:36:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 13:36:10 --> Utf8 Class Initialized
DEBUG - 2015-02-14 13:36:10 --> URI Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Router Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Output Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Security Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Input Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 13:36:10 --> Language Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Loader Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: url_helper
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: link_helper
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 13:36:10 --> CI_Session Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Session: Regenerate ID
DEBUG - 2015-02-14 13:36:10 --> CI_Session routines successfully run
DEBUG - 2015-02-14 13:36:10 --> Model Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Model Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Controller Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 13:36:10 --> Email Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: language_helper
DEBUG - 2015-02-14 13:36:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 13:36:10 --> Model Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Database Driver Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: date_helper
DEBUG - 2015-02-14 13:36:10 --> Helper loaded: form_helper
DEBUG - 2015-02-14 13:36:10 --> Form Validation Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Model Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 13:36:10 --> Pagination Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Model Class Initialized
DEBUG - 2015-02-14 13:36:10 --> Model Class Initialized
DEBUG - 2015-02-14 13:36:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 13:36:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 13:36:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 13:36:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 13:36:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 13:36:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 13:36:11 --> Final output sent to browser
DEBUG - 2015-02-14 13:36:11 --> Total execution time: 1.3231
DEBUG - 2015-02-14 13:51:12 --> Config Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Hooks Class Initialized
DEBUG - 2015-02-14 13:51:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 13:51:12 --> Utf8 Class Initialized
DEBUG - 2015-02-14 13:51:12 --> URI Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Router Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Output Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Security Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Input Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 13:51:12 --> Language Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Loader Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: url_helper
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: link_helper
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 13:51:12 --> CI_Session Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Session: Regenerate ID
DEBUG - 2015-02-14 13:51:12 --> CI_Session routines successfully run
DEBUG - 2015-02-14 13:51:12 --> Model Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Model Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Controller Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 13:51:12 --> Email Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: language_helper
DEBUG - 2015-02-14 13:51:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 13:51:12 --> Model Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Database Driver Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: date_helper
DEBUG - 2015-02-14 13:51:12 --> Helper loaded: form_helper
DEBUG - 2015-02-14 13:51:12 --> Form Validation Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Model Class Initialized
DEBUG - 2015-02-14 13:51:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 13:51:12 --> Pagination Class Initialized
DEBUG - 2015-02-14 13:51:13 --> Model Class Initialized
DEBUG - 2015-02-14 13:51:13 --> Model Class Initialized
DEBUG - 2015-02-14 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 13:51:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 13:51:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 13:51:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 13:51:14 --> Final output sent to browser
DEBUG - 2015-02-14 13:51:14 --> Total execution time: 1.7172
DEBUG - 2015-02-14 14:06:15 --> Config Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Hooks Class Initialized
DEBUG - 2015-02-14 14:06:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 14:06:15 --> Utf8 Class Initialized
DEBUG - 2015-02-14 14:06:15 --> URI Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Router Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Output Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Security Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Input Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 14:06:15 --> Language Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Loader Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: url_helper
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: link_helper
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 14:06:15 --> CI_Session Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Session: Regenerate ID
DEBUG - 2015-02-14 14:06:15 --> CI_Session routines successfully run
DEBUG - 2015-02-14 14:06:15 --> Model Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Model Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Controller Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 14:06:15 --> Email Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: language_helper
DEBUG - 2015-02-14 14:06:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 14:06:15 --> Model Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Database Driver Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: date_helper
DEBUG - 2015-02-14 14:06:15 --> Helper loaded: form_helper
DEBUG - 2015-02-14 14:06:15 --> Form Validation Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Model Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 14:06:15 --> Pagination Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Model Class Initialized
DEBUG - 2015-02-14 14:06:15 --> Model Class Initialized
DEBUG - 2015-02-14 14:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 14:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 14:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 14:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 14:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 14:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 14:06:16 --> Final output sent to browser
DEBUG - 2015-02-14 14:06:16 --> Total execution time: 1.5992
DEBUG - 2015-02-14 14:21:17 --> Config Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Hooks Class Initialized
DEBUG - 2015-02-14 14:21:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 14:21:17 --> Utf8 Class Initialized
DEBUG - 2015-02-14 14:21:17 --> URI Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Router Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Output Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Security Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Input Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 14:21:17 --> Language Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Loader Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: url_helper
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: link_helper
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 14:21:17 --> CI_Session Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Session: Regenerate ID
DEBUG - 2015-02-14 14:21:17 --> CI_Session routines successfully run
DEBUG - 2015-02-14 14:21:17 --> Model Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Model Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Controller Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 14:21:17 --> Email Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: language_helper
DEBUG - 2015-02-14 14:21:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 14:21:17 --> Model Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Database Driver Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: date_helper
DEBUG - 2015-02-14 14:21:17 --> Helper loaded: form_helper
DEBUG - 2015-02-14 14:21:17 --> Form Validation Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Model Class Initialized
DEBUG - 2015-02-14 14:21:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 14:21:17 --> Pagination Class Initialized
DEBUG - 2015-02-14 14:21:18 --> Model Class Initialized
DEBUG - 2015-02-14 14:21:18 --> Model Class Initialized
DEBUG - 2015-02-14 14:21:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 14:21:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 14:21:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 14:21:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 14:21:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 14:21:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 14:21:19 --> Final output sent to browser
DEBUG - 2015-02-14 14:21:19 --> Total execution time: 1.3431
DEBUG - 2015-02-14 14:36:21 --> Config Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Hooks Class Initialized
DEBUG - 2015-02-14 14:36:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 14:36:21 --> Utf8 Class Initialized
DEBUG - 2015-02-14 14:36:21 --> URI Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Router Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Output Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Security Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Input Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 14:36:21 --> Language Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Loader Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: url_helper
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: link_helper
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 14:36:21 --> CI_Session Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Session: Regenerate ID
DEBUG - 2015-02-14 14:36:21 --> CI_Session routines successfully run
DEBUG - 2015-02-14 14:36:21 --> Model Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Model Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Controller Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 14:36:21 --> Email Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: language_helper
DEBUG - 2015-02-14 14:36:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 14:36:21 --> Model Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Database Driver Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: date_helper
DEBUG - 2015-02-14 14:36:21 --> Helper loaded: form_helper
DEBUG - 2015-02-14 14:36:21 --> Form Validation Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Model Class Initialized
DEBUG - 2015-02-14 14:36:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 14:36:21 --> Pagination Class Initialized
DEBUG - 2015-02-14 14:36:22 --> Model Class Initialized
DEBUG - 2015-02-14 14:36:22 --> Model Class Initialized
DEBUG - 2015-02-14 14:36:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 14:36:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 14:36:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 14:36:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 14:36:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 14:36:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 14:36:23 --> Final output sent to browser
DEBUG - 2015-02-14 14:36:23 --> Total execution time: 1.3391
DEBUG - 2015-02-14 14:51:24 --> Config Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Hooks Class Initialized
DEBUG - 2015-02-14 14:51:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 14:51:24 --> Utf8 Class Initialized
DEBUG - 2015-02-14 14:51:24 --> URI Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Router Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Output Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Security Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Input Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 14:51:24 --> Language Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Loader Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: url_helper
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: link_helper
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 14:51:24 --> CI_Session Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Session: Regenerate ID
DEBUG - 2015-02-14 14:51:24 --> CI_Session routines successfully run
DEBUG - 2015-02-14 14:51:24 --> Model Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Model Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Controller Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 14:51:24 --> Email Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: language_helper
DEBUG - 2015-02-14 14:51:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 14:51:24 --> Model Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Database Driver Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: date_helper
DEBUG - 2015-02-14 14:51:24 --> Helper loaded: form_helper
DEBUG - 2015-02-14 14:51:24 --> Form Validation Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Model Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 14:51:24 --> Pagination Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Model Class Initialized
DEBUG - 2015-02-14 14:51:24 --> Model Class Initialized
DEBUG - 2015-02-14 14:51:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 14:51:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 14:51:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 14:51:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 14:51:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 14:51:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 14:51:25 --> Final output sent to browser
DEBUG - 2015-02-14 14:51:25 --> Total execution time: 1.4111
DEBUG - 2015-02-14 15:06:27 --> Config Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 15:06:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 15:06:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 15:06:27 --> URI Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Router Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Output Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Security Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Input Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 15:06:27 --> Language Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Loader Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: url_helper
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: link_helper
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 15:06:27 --> CI_Session Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Session: Regenerate ID
DEBUG - 2015-02-14 15:06:27 --> CI_Session routines successfully run
DEBUG - 2015-02-14 15:06:27 --> Model Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Model Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Controller Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 15:06:27 --> Email Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: language_helper
DEBUG - 2015-02-14 15:06:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 15:06:27 --> Model Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Database Driver Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: date_helper
DEBUG - 2015-02-14 15:06:27 --> Helper loaded: form_helper
DEBUG - 2015-02-14 15:06:27 --> Form Validation Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Model Class Initialized
DEBUG - 2015-02-14 15:06:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 15:06:27 --> Pagination Class Initialized
DEBUG - 2015-02-14 15:06:28 --> Model Class Initialized
DEBUG - 2015-02-14 15:06:28 --> Model Class Initialized
DEBUG - 2015-02-14 15:06:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 15:06:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 15:06:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 15:06:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 15:06:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 15:06:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 15:06:28 --> Final output sent to browser
DEBUG - 2015-02-14 15:06:28 --> Total execution time: 1.3221
DEBUG - 2015-02-14 15:21:31 --> Config Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Hooks Class Initialized
DEBUG - 2015-02-14 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 15:21:31 --> Utf8 Class Initialized
DEBUG - 2015-02-14 15:21:31 --> URI Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Router Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Output Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Security Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Input Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 15:21:31 --> Language Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Loader Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: url_helper
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: link_helper
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 15:21:31 --> CI_Session Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Session: Regenerate ID
DEBUG - 2015-02-14 15:21:31 --> CI_Session routines successfully run
DEBUG - 2015-02-14 15:21:31 --> Model Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Model Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Controller Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 15:21:31 --> Email Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: language_helper
DEBUG - 2015-02-14 15:21:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 15:21:31 --> Model Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Database Driver Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: date_helper
DEBUG - 2015-02-14 15:21:31 --> Helper loaded: form_helper
DEBUG - 2015-02-14 15:21:31 --> Form Validation Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Model Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 15:21:31 --> Pagination Class Initialized
DEBUG - 2015-02-14 15:21:31 --> Model Class Initialized
DEBUG - 2015-02-14 15:21:32 --> Model Class Initialized
DEBUG - 2015-02-14 15:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 15:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 15:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 15:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 15:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 15:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 15:21:32 --> Final output sent to browser
DEBUG - 2015-02-14 15:21:32 --> Total execution time: 1.5652
DEBUG - 2015-02-14 15:36:35 --> Config Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Hooks Class Initialized
DEBUG - 2015-02-14 15:36:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 15:36:35 --> Utf8 Class Initialized
DEBUG - 2015-02-14 15:36:35 --> URI Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Router Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Output Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Security Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Input Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 15:36:35 --> Language Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Loader Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: url_helper
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: link_helper
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 15:36:35 --> CI_Session Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Session: Regenerate ID
DEBUG - 2015-02-14 15:36:35 --> CI_Session routines successfully run
DEBUG - 2015-02-14 15:36:35 --> Model Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Model Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Controller Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 15:36:35 --> Email Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: language_helper
DEBUG - 2015-02-14 15:36:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 15:36:35 --> Model Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Database Driver Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: date_helper
DEBUG - 2015-02-14 15:36:35 --> Helper loaded: form_helper
DEBUG - 2015-02-14 15:36:35 --> Form Validation Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Model Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 15:36:35 --> Pagination Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Model Class Initialized
DEBUG - 2015-02-14 15:36:35 --> Model Class Initialized
DEBUG - 2015-02-14 15:36:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 15:36:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 15:36:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 15:36:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 15:36:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 15:36:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 15:36:36 --> Final output sent to browser
DEBUG - 2015-02-14 15:36:36 --> Total execution time: 1.4081
DEBUG - 2015-02-14 15:51:37 --> Config Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Hooks Class Initialized
DEBUG - 2015-02-14 15:51:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 15:51:37 --> Utf8 Class Initialized
DEBUG - 2015-02-14 15:51:37 --> URI Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Router Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Output Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Security Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Input Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 15:51:37 --> Language Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Loader Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: url_helper
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: link_helper
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 15:51:37 --> CI_Session Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Session: Regenerate ID
DEBUG - 2015-02-14 15:51:37 --> CI_Session routines successfully run
DEBUG - 2015-02-14 15:51:37 --> Model Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Model Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Controller Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 15:51:37 --> Email Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: language_helper
DEBUG - 2015-02-14 15:51:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 15:51:37 --> Model Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Database Driver Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: date_helper
DEBUG - 2015-02-14 15:51:37 --> Helper loaded: form_helper
DEBUG - 2015-02-14 15:51:37 --> Form Validation Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Model Class Initialized
DEBUG - 2015-02-14 15:51:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 15:51:37 --> Pagination Class Initialized
DEBUG - 2015-02-14 15:51:38 --> Model Class Initialized
DEBUG - 2015-02-14 15:51:38 --> Model Class Initialized
DEBUG - 2015-02-14 15:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 15:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 15:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 15:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 15:51:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 15:51:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 15:51:39 --> Final output sent to browser
DEBUG - 2015-02-14 15:51:39 --> Total execution time: 1.4051
DEBUG - 2015-02-14 16:06:41 --> Config Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Hooks Class Initialized
DEBUG - 2015-02-14 16:06:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 16:06:41 --> Utf8 Class Initialized
DEBUG - 2015-02-14 16:06:41 --> URI Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Router Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Output Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Security Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Input Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 16:06:41 --> Language Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Loader Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: url_helper
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: link_helper
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 16:06:41 --> CI_Session Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Session: Regenerate ID
DEBUG - 2015-02-14 16:06:41 --> CI_Session routines successfully run
DEBUG - 2015-02-14 16:06:41 --> Model Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Model Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Controller Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 16:06:41 --> Email Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: language_helper
DEBUG - 2015-02-14 16:06:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 16:06:41 --> Model Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Database Driver Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: date_helper
DEBUG - 2015-02-14 16:06:41 --> Helper loaded: form_helper
DEBUG - 2015-02-14 16:06:41 --> Form Validation Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Model Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 16:06:41 --> Pagination Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Model Class Initialized
DEBUG - 2015-02-14 16:06:41 --> Model Class Initialized
DEBUG - 2015-02-14 16:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 16:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 16:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 16:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 16:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 16:06:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 16:06:42 --> Final output sent to browser
DEBUG - 2015-02-14 16:06:42 --> Total execution time: 1.5092
DEBUG - 2015-02-14 16:21:43 --> Config Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Hooks Class Initialized
DEBUG - 2015-02-14 16:21:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 16:21:43 --> Utf8 Class Initialized
DEBUG - 2015-02-14 16:21:43 --> URI Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Router Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Output Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Security Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Input Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 16:21:43 --> Language Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Loader Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 16:21:43 --> Helper loaded: url_helper
DEBUG - 2015-02-14 16:21:43 --> Helper loaded: link_helper
DEBUG - 2015-02-14 16:21:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 16:21:43 --> CI_Session Class Initialized
DEBUG - 2015-02-14 16:21:43 --> Session: Regenerate ID
DEBUG - 2015-02-14 16:21:43 --> CI_Session routines successfully run
DEBUG - 2015-02-14 16:21:44 --> Model Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Model Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Controller Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 16:21:44 --> Email Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 16:21:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 16:21:44 --> Helper loaded: language_helper
DEBUG - 2015-02-14 16:21:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 16:21:44 --> Model Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Database Driver Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Helper loaded: date_helper
DEBUG - 2015-02-14 16:21:44 --> Helper loaded: form_helper
DEBUG - 2015-02-14 16:21:44 --> Form Validation Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Model Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 16:21:44 --> Pagination Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Model Class Initialized
DEBUG - 2015-02-14 16:21:44 --> Model Class Initialized
DEBUG - 2015-02-14 16:21:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 16:21:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 16:21:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 16:21:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 16:21:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 16:21:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 16:21:45 --> Final output sent to browser
DEBUG - 2015-02-14 16:21:45 --> Total execution time: 1.4281
DEBUG - 2015-02-14 16:36:46 --> Config Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Hooks Class Initialized
DEBUG - 2015-02-14 16:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 16:36:46 --> Utf8 Class Initialized
DEBUG - 2015-02-14 16:36:46 --> URI Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Router Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Output Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Security Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Input Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 16:36:46 --> Language Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Loader Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: url_helper
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: link_helper
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 16:36:46 --> CI_Session Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Session: Regenerate ID
DEBUG - 2015-02-14 16:36:46 --> CI_Session routines successfully run
DEBUG - 2015-02-14 16:36:46 --> Model Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Model Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Controller Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 16:36:46 --> Email Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: language_helper
DEBUG - 2015-02-14 16:36:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 16:36:46 --> Model Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Database Driver Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: date_helper
DEBUG - 2015-02-14 16:36:46 --> Helper loaded: form_helper
DEBUG - 2015-02-14 16:36:46 --> Form Validation Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Model Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 16:36:46 --> Pagination Class Initialized
DEBUG - 2015-02-14 16:36:46 --> Model Class Initialized
DEBUG - 2015-02-14 16:36:47 --> Model Class Initialized
DEBUG - 2015-02-14 16:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 16:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 16:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 16:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 16:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 16:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 16:36:47 --> Final output sent to browser
DEBUG - 2015-02-14 16:36:47 --> Total execution time: 1.3991
DEBUG - 2015-02-14 16:51:48 --> Config Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Hooks Class Initialized
DEBUG - 2015-02-14 16:51:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 16:51:48 --> Utf8 Class Initialized
DEBUG - 2015-02-14 16:51:48 --> URI Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Router Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Output Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Security Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Input Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 16:51:48 --> Language Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Loader Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: url_helper
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 16:51:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Session: Regenerate ID
DEBUG - 2015-02-14 16:51:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 16:51:48 --> Model Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Model Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Controller Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 16:51:48 --> Email Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: language_helper
DEBUG - 2015-02-14 16:51:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 16:51:48 --> Model Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Database Driver Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: date_helper
DEBUG - 2015-02-14 16:51:48 --> Helper loaded: form_helper
DEBUG - 2015-02-14 16:51:48 --> Form Validation Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Model Class Initialized
DEBUG - 2015-02-14 16:51:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 16:51:48 --> Pagination Class Initialized
DEBUG - 2015-02-14 16:51:49 --> Model Class Initialized
DEBUG - 2015-02-14 16:51:49 --> Model Class Initialized
DEBUG - 2015-02-14 16:51:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 16:51:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 16:51:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 16:51:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 16:51:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 16:51:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 16:51:50 --> Final output sent to browser
DEBUG - 2015-02-14 16:51:50 --> Total execution time: 1.3581
DEBUG - 2015-02-14 17:06:50 --> Config Class Initialized
DEBUG - 2015-02-14 17:06:50 --> Hooks Class Initialized
DEBUG - 2015-02-14 17:06:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 17:06:50 --> Utf8 Class Initialized
DEBUG - 2015-02-14 17:06:50 --> URI Class Initialized
DEBUG - 2015-02-14 17:06:50 --> Router Class Initialized
DEBUG - 2015-02-14 17:06:50 --> Output Class Initialized
DEBUG - 2015-02-14 17:06:50 --> Security Class Initialized
DEBUG - 2015-02-14 17:06:50 --> Input Class Initialized
DEBUG - 2015-02-14 17:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 17:06:50 --> Language Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Loader Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: url_helper
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: link_helper
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 17:06:51 --> CI_Session Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Session: Regenerate ID
DEBUG - 2015-02-14 17:06:51 --> CI_Session routines successfully run
DEBUG - 2015-02-14 17:06:51 --> Model Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Model Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Controller Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 17:06:51 --> Email Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: language_helper
DEBUG - 2015-02-14 17:06:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 17:06:51 --> Model Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Database Driver Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: date_helper
DEBUG - 2015-02-14 17:06:51 --> Helper loaded: form_helper
DEBUG - 2015-02-14 17:06:51 --> Form Validation Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Model Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 17:06:51 --> Pagination Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Model Class Initialized
DEBUG - 2015-02-14 17:06:51 --> Model Class Initialized
DEBUG - 2015-02-14 17:06:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 17:06:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 17:06:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 17:06:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 17:06:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 17:06:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 17:06:52 --> Final output sent to browser
DEBUG - 2015-02-14 17:06:52 --> Total execution time: 1.3961
DEBUG - 2015-02-14 17:21:53 --> Config Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Hooks Class Initialized
DEBUG - 2015-02-14 17:21:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 17:21:53 --> Utf8 Class Initialized
DEBUG - 2015-02-14 17:21:53 --> URI Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Router Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Output Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Security Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Input Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 17:21:53 --> Language Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Loader Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: url_helper
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: link_helper
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 17:21:53 --> CI_Session Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Session: Regenerate ID
DEBUG - 2015-02-14 17:21:53 --> CI_Session routines successfully run
DEBUG - 2015-02-14 17:21:53 --> Model Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Model Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Controller Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 17:21:53 --> Email Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: language_helper
DEBUG - 2015-02-14 17:21:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 17:21:53 --> Model Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Database Driver Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: date_helper
DEBUG - 2015-02-14 17:21:53 --> Helper loaded: form_helper
DEBUG - 2015-02-14 17:21:53 --> Form Validation Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Model Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 17:21:53 --> Pagination Class Initialized
DEBUG - 2015-02-14 17:21:53 --> Model Class Initialized
DEBUG - 2015-02-14 17:21:54 --> Model Class Initialized
DEBUG - 2015-02-14 17:21:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 17:21:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 17:21:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 17:21:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 17:21:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 17:21:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 17:21:54 --> Final output sent to browser
DEBUG - 2015-02-14 17:21:54 --> Total execution time: 1.3561
DEBUG - 2015-02-14 17:36:55 --> Config Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Hooks Class Initialized
DEBUG - 2015-02-14 17:36:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 17:36:55 --> Utf8 Class Initialized
DEBUG - 2015-02-14 17:36:55 --> URI Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Router Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Output Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Security Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Input Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 17:36:55 --> Language Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Loader Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 17:36:55 --> Helper loaded: url_helper
DEBUG - 2015-02-14 17:36:55 --> Helper loaded: link_helper
DEBUG - 2015-02-14 17:36:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 17:36:55 --> CI_Session Class Initialized
DEBUG - 2015-02-14 17:36:55 --> Session: Regenerate ID
DEBUG - 2015-02-14 17:36:55 --> CI_Session routines successfully run
DEBUG - 2015-02-14 17:36:56 --> Model Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Model Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Controller Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 17:36:56 --> Email Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 17:36:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 17:36:56 --> Helper loaded: language_helper
DEBUG - 2015-02-14 17:36:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 17:36:56 --> Model Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Database Driver Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Helper loaded: date_helper
DEBUG - 2015-02-14 17:36:56 --> Helper loaded: form_helper
DEBUG - 2015-02-14 17:36:56 --> Form Validation Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Model Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 17:36:56 --> Pagination Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Model Class Initialized
DEBUG - 2015-02-14 17:36:56 --> Model Class Initialized
DEBUG - 2015-02-14 17:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 17:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 17:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 17:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 17:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 17:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 17:36:57 --> Final output sent to browser
DEBUG - 2015-02-14 17:36:57 --> Total execution time: 1.4171
DEBUG - 2015-02-14 17:51:59 --> Config Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Hooks Class Initialized
DEBUG - 2015-02-14 17:51:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 17:51:59 --> Utf8 Class Initialized
DEBUG - 2015-02-14 17:51:59 --> URI Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Router Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Output Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Security Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Input Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 17:51:59 --> Language Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Loader Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: url_helper
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: link_helper
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 17:51:59 --> CI_Session Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Session: Regenerate ID
DEBUG - 2015-02-14 17:51:59 --> CI_Session routines successfully run
DEBUG - 2015-02-14 17:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Controller Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 17:51:59 --> Email Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: language_helper
DEBUG - 2015-02-14 17:51:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 17:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Database Driver Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: date_helper
DEBUG - 2015-02-14 17:51:59 --> Helper loaded: form_helper
DEBUG - 2015-02-14 17:51:59 --> Form Validation Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 17:51:59 --> Pagination Class Initialized
DEBUG - 2015-02-14 17:51:59 --> Model Class Initialized
DEBUG - 2015-02-14 17:52:00 --> Model Class Initialized
DEBUG - 2015-02-14 17:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 17:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 17:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 17:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 17:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 17:52:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 17:52:00 --> Final output sent to browser
DEBUG - 2015-02-14 17:52:00 --> Total execution time: 1.4181
DEBUG - 2015-02-14 18:07:01 --> Config Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Hooks Class Initialized
DEBUG - 2015-02-14 18:07:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 18:07:01 --> Utf8 Class Initialized
DEBUG - 2015-02-14 18:07:01 --> URI Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Router Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Output Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Security Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Input Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 18:07:01 --> Language Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Loader Class Initialized
DEBUG - 2015-02-14 18:07:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 18:07:01 --> Helper loaded: url_helper
DEBUG - 2015-02-14 18:07:01 --> Helper loaded: link_helper
DEBUG - 2015-02-14 18:07:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 18:07:02 --> CI_Session Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Session: Regenerate ID
DEBUG - 2015-02-14 18:07:02 --> CI_Session routines successfully run
DEBUG - 2015-02-14 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Controller Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 18:07:02 --> Email Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 18:07:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 18:07:02 --> Helper loaded: language_helper
DEBUG - 2015-02-14 18:07:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Database Driver Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Helper loaded: date_helper
DEBUG - 2015-02-14 18:07:02 --> Helper loaded: form_helper
DEBUG - 2015-02-14 18:07:02 --> Form Validation Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 18:07:02 --> Pagination Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-14 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-14 18:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 18:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 18:07:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 18:07:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 18:07:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 18:07:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 18:07:03 --> Final output sent to browser
DEBUG - 2015-02-14 18:07:03 --> Total execution time: 1.5062
DEBUG - 2015-02-14 18:22:07 --> Config Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Hooks Class Initialized
DEBUG - 2015-02-14 18:22:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 18:22:07 --> Utf8 Class Initialized
DEBUG - 2015-02-14 18:22:07 --> URI Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Router Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Output Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Security Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Input Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 18:22:07 --> Language Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Loader Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: url_helper
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: link_helper
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 18:22:07 --> CI_Session Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Session: Regenerate ID
DEBUG - 2015-02-14 18:22:07 --> CI_Session routines successfully run
DEBUG - 2015-02-14 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Controller Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 18:22:07 --> Email Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: language_helper
DEBUG - 2015-02-14 18:22:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Database Driver Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: date_helper
DEBUG - 2015-02-14 18:22:07 --> Helper loaded: form_helper
DEBUG - 2015-02-14 18:22:07 --> Form Validation Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 18:22:07 --> Pagination Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-14 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-14 18:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 18:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 18:22:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 18:22:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 18:22:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 18:22:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 18:22:08 --> Final output sent to browser
DEBUG - 2015-02-14 18:22:08 --> Total execution time: 1.3427
DEBUG - 2015-02-14 18:37:09 --> Config Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Hooks Class Initialized
DEBUG - 2015-02-14 18:37:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 18:37:09 --> Utf8 Class Initialized
DEBUG - 2015-02-14 18:37:09 --> URI Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Router Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Output Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Security Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Input Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 18:37:09 --> Language Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Loader Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: url_helper
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: link_helper
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 18:37:09 --> CI_Session Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Session: Regenerate ID
DEBUG - 2015-02-14 18:37:09 --> CI_Session routines successfully run
DEBUG - 2015-02-14 18:37:09 --> Model Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Model Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Controller Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 18:37:09 --> Email Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: language_helper
DEBUG - 2015-02-14 18:37:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 18:37:09 --> Model Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Database Driver Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: date_helper
DEBUG - 2015-02-14 18:37:09 --> Helper loaded: form_helper
DEBUG - 2015-02-14 18:37:09 --> Form Validation Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Model Class Initialized
DEBUG - 2015-02-14 18:37:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 18:37:09 --> Pagination Class Initialized
DEBUG - 2015-02-14 18:37:10 --> Model Class Initialized
DEBUG - 2015-02-14 18:37:10 --> Model Class Initialized
DEBUG - 2015-02-14 18:37:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 18:37:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 18:37:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 18:37:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 18:37:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 18:37:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 18:37:10 --> Final output sent to browser
DEBUG - 2015-02-14 18:37:10 --> Total execution time: 1.4141
DEBUG - 2015-02-14 18:52:11 --> Config Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Hooks Class Initialized
DEBUG - 2015-02-14 18:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 18:52:11 --> Utf8 Class Initialized
DEBUG - 2015-02-14 18:52:11 --> URI Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Router Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Output Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Security Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Input Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 18:52:11 --> Language Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Loader Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 18:52:11 --> Helper loaded: url_helper
DEBUG - 2015-02-14 18:52:11 --> Helper loaded: link_helper
DEBUG - 2015-02-14 18:52:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 18:52:11 --> CI_Session Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Session: Regenerate ID
DEBUG - 2015-02-14 18:52:11 --> CI_Session routines successfully run
DEBUG - 2015-02-14 18:52:11 --> Model Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Model Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Controller Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 18:52:11 --> Email Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 18:52:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 18:52:11 --> Helper loaded: language_helper
DEBUG - 2015-02-14 18:52:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 18:52:11 --> Model Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Database Driver Class Initialized
DEBUG - 2015-02-14 18:52:11 --> Helper loaded: date_helper
DEBUG - 2015-02-14 18:52:12 --> Helper loaded: form_helper
DEBUG - 2015-02-14 18:52:12 --> Form Validation Class Initialized
DEBUG - 2015-02-14 18:52:12 --> Model Class Initialized
DEBUG - 2015-02-14 18:52:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 18:52:12 --> Pagination Class Initialized
DEBUG - 2015-02-14 18:52:12 --> Model Class Initialized
DEBUG - 2015-02-14 18:52:12 --> Model Class Initialized
DEBUG - 2015-02-14 18:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 18:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 18:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 18:52:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 18:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 18:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 18:52:13 --> Final output sent to browser
DEBUG - 2015-02-14 18:52:13 --> Total execution time: 1.3361
DEBUG - 2015-02-14 19:07:14 --> Config Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Hooks Class Initialized
DEBUG - 2015-02-14 19:07:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 19:07:14 --> Utf8 Class Initialized
DEBUG - 2015-02-14 19:07:14 --> URI Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Router Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Output Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Security Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Input Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 19:07:14 --> Language Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Loader Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: url_helper
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: link_helper
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 19:07:14 --> CI_Session Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Session: Regenerate ID
DEBUG - 2015-02-14 19:07:14 --> CI_Session routines successfully run
DEBUG - 2015-02-14 19:07:14 --> Model Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Model Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Controller Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 19:07:14 --> Email Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: language_helper
DEBUG - 2015-02-14 19:07:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 19:07:14 --> Model Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Database Driver Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: date_helper
DEBUG - 2015-02-14 19:07:14 --> Helper loaded: form_helper
DEBUG - 2015-02-14 19:07:14 --> Form Validation Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Model Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 19:07:14 --> Pagination Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Model Class Initialized
DEBUG - 2015-02-14 19:07:14 --> Model Class Initialized
DEBUG - 2015-02-14 19:07:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 19:07:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 19:07:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 19:07:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 19:07:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 19:07:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 19:07:15 --> Final output sent to browser
DEBUG - 2015-02-14 19:07:15 --> Total execution time: 1.4971
DEBUG - 2015-02-14 19:22:16 --> Config Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Hooks Class Initialized
DEBUG - 2015-02-14 19:22:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 19:22:16 --> Utf8 Class Initialized
DEBUG - 2015-02-14 19:22:16 --> URI Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Router Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Output Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Security Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Input Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 19:22:16 --> Language Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Loader Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: url_helper
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: link_helper
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 19:22:16 --> CI_Session Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Session: Regenerate ID
DEBUG - 2015-02-14 19:22:16 --> CI_Session routines successfully run
DEBUG - 2015-02-14 19:22:16 --> Model Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Model Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Controller Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 19:22:16 --> Email Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: language_helper
DEBUG - 2015-02-14 19:22:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 19:22:16 --> Model Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Database Driver Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: date_helper
DEBUG - 2015-02-14 19:22:16 --> Helper loaded: form_helper
DEBUG - 2015-02-14 19:22:16 --> Form Validation Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Model Class Initialized
DEBUG - 2015-02-14 19:22:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 19:22:16 --> Pagination Class Initialized
DEBUG - 2015-02-14 19:22:17 --> Model Class Initialized
DEBUG - 2015-02-14 19:22:17 --> Model Class Initialized
DEBUG - 2015-02-14 19:22:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 19:22:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 19:22:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 19:22:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 19:22:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 19:22:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 19:22:18 --> Final output sent to browser
DEBUG - 2015-02-14 19:22:18 --> Total execution time: 1.4841
DEBUG - 2015-02-14 19:37:20 --> Config Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Hooks Class Initialized
DEBUG - 2015-02-14 19:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 19:37:20 --> Utf8 Class Initialized
DEBUG - 2015-02-14 19:37:20 --> URI Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Router Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Output Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Security Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Input Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 19:37:20 --> Language Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Loader Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: url_helper
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: link_helper
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 19:37:20 --> CI_Session Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Session: Regenerate ID
DEBUG - 2015-02-14 19:37:20 --> CI_Session routines successfully run
DEBUG - 2015-02-14 19:37:20 --> Model Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Model Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Controller Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 19:37:20 --> Email Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: language_helper
DEBUG - 2015-02-14 19:37:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 19:37:20 --> Model Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Database Driver Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: date_helper
DEBUG - 2015-02-14 19:37:20 --> Helper loaded: form_helper
DEBUG - 2015-02-14 19:37:20 --> Form Validation Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Model Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 19:37:20 --> Pagination Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Model Class Initialized
DEBUG - 2015-02-14 19:37:20 --> Model Class Initialized
DEBUG - 2015-02-14 19:37:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 19:37:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 19:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 19:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 19:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 19:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 19:37:21 --> Final output sent to browser
DEBUG - 2015-02-14 19:37:21 --> Total execution time: 1.4551
DEBUG - 2015-02-14 19:52:22 --> Config Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Hooks Class Initialized
DEBUG - 2015-02-14 19:52:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 19:52:22 --> Utf8 Class Initialized
DEBUG - 2015-02-14 19:52:22 --> URI Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Router Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Output Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Security Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Input Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 19:52:22 --> Language Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Loader Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: url_helper
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: link_helper
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 19:52:22 --> CI_Session Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Session: Regenerate ID
DEBUG - 2015-02-14 19:52:22 --> CI_Session routines successfully run
DEBUG - 2015-02-14 19:52:22 --> Model Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Model Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Controller Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 19:52:22 --> Email Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: language_helper
DEBUG - 2015-02-14 19:52:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 19:52:22 --> Model Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Database Driver Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: date_helper
DEBUG - 2015-02-14 19:52:22 --> Helper loaded: form_helper
DEBUG - 2015-02-14 19:52:22 --> Form Validation Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Model Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 19:52:22 --> Pagination Class Initialized
DEBUG - 2015-02-14 19:52:22 --> Model Class Initialized
DEBUG - 2015-02-14 19:52:23 --> Model Class Initialized
DEBUG - 2015-02-14 19:52:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 19:52:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 19:52:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 19:52:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 19:52:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 19:52:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 19:52:23 --> Final output sent to browser
DEBUG - 2015-02-14 19:52:23 --> Total execution time: 1.3861
DEBUG - 2015-02-14 20:07:25 --> Config Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:07:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:07:25 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:07:25 --> URI Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Router Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Output Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Security Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Input Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:07:25 --> Language Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Loader Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: url_helper
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: link_helper
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 20:07:25 --> CI_Session Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Session: Regenerate ID
DEBUG - 2015-02-14 20:07:25 --> CI_Session routines successfully run
DEBUG - 2015-02-14 20:07:25 --> Model Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Model Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Controller Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 20:07:25 --> Email Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: language_helper
DEBUG - 2015-02-14 20:07:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 20:07:25 --> Model Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Database Driver Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: date_helper
DEBUG - 2015-02-14 20:07:25 --> Helper loaded: form_helper
DEBUG - 2015-02-14 20:07:25 --> Form Validation Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Model Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 20:07:25 --> Pagination Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Model Class Initialized
DEBUG - 2015-02-14 20:07:25 --> Model Class Initialized
DEBUG - 2015-02-14 20:07:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 20:07:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 20:07:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 20:07:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 20:07:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 20:07:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 20:07:26 --> Final output sent to browser
DEBUG - 2015-02-14 20:07:26 --> Total execution time: 1.5092
DEBUG - 2015-02-14 20:22:27 --> Config Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:22:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:22:27 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:22:27 --> URI Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Router Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Output Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Security Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Input Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:22:27 --> Language Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Loader Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: url_helper
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: link_helper
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 20:22:27 --> CI_Session Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Session: Regenerate ID
DEBUG - 2015-02-14 20:22:27 --> CI_Session routines successfully run
DEBUG - 2015-02-14 20:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Controller Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 20:22:27 --> Email Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: language_helper
DEBUG - 2015-02-14 20:22:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 20:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Database Driver Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: date_helper
DEBUG - 2015-02-14 20:22:27 --> Helper loaded: form_helper
DEBUG - 2015-02-14 20:22:27 --> Form Validation Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Model Class Initialized
DEBUG - 2015-02-14 20:22:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 20:22:27 --> Pagination Class Initialized
DEBUG - 2015-02-14 20:22:28 --> Model Class Initialized
DEBUG - 2015-02-14 20:22:28 --> Model Class Initialized
DEBUG - 2015-02-14 20:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 20:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 20:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 20:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 20:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 20:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 20:22:28 --> Final output sent to browser
DEBUG - 2015-02-14 20:22:28 --> Total execution time: 1.3401
DEBUG - 2015-02-14 20:37:30 --> Config Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:37:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:37:30 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:37:30 --> URI Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Router Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Output Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Security Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Input Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:37:30 --> Language Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Loader Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: url_helper
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: link_helper
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 20:37:30 --> CI_Session Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Session: Regenerate ID
DEBUG - 2015-02-14 20:37:30 --> CI_Session routines successfully run
DEBUG - 2015-02-14 20:37:30 --> Model Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Model Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Controller Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 20:37:30 --> Email Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: language_helper
DEBUG - 2015-02-14 20:37:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 20:37:30 --> Model Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Database Driver Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: date_helper
DEBUG - 2015-02-14 20:37:30 --> Helper loaded: form_helper
DEBUG - 2015-02-14 20:37:30 --> Form Validation Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Model Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 20:37:30 --> Pagination Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Model Class Initialized
DEBUG - 2015-02-14 20:37:30 --> Model Class Initialized
DEBUG - 2015-02-14 20:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 20:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 20:37:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 20:37:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 20:37:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 20:37:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 20:37:31 --> Final output sent to browser
DEBUG - 2015-02-14 20:37:31 --> Total execution time: 1.4021
DEBUG - 2015-02-14 20:52:33 --> Config Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:52:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:52:33 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:52:33 --> URI Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Router Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Output Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Security Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Input Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:52:33 --> Language Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Loader Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: url_helper
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: link_helper
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 20:52:33 --> CI_Session Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Session: Regenerate ID
DEBUG - 2015-02-14 20:52:33 --> CI_Session routines successfully run
DEBUG - 2015-02-14 20:52:33 --> Model Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Model Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Controller Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 20:52:33 --> Email Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: language_helper
DEBUG - 2015-02-14 20:52:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 20:52:33 --> Model Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Database Driver Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: date_helper
DEBUG - 2015-02-14 20:52:33 --> Helper loaded: form_helper
DEBUG - 2015-02-14 20:52:33 --> Form Validation Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Model Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 20:52:33 --> Pagination Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Model Class Initialized
DEBUG - 2015-02-14 20:52:33 --> Model Class Initialized
DEBUG - 2015-02-14 20:52:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 20:52:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 20:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 20:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 20:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 20:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 20:52:34 --> Final output sent to browser
DEBUG - 2015-02-14 20:52:34 --> Total execution time: 1.3341
DEBUG - 2015-02-14 21:07:35 --> Config Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Hooks Class Initialized
DEBUG - 2015-02-14 21:07:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 21:07:35 --> Utf8 Class Initialized
DEBUG - 2015-02-14 21:07:35 --> URI Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Router Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Output Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Security Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Input Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 21:07:35 --> Language Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Loader Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: url_helper
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: link_helper
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 21:07:35 --> CI_Session Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Session: Regenerate ID
DEBUG - 2015-02-14 21:07:35 --> CI_Session routines successfully run
DEBUG - 2015-02-14 21:07:35 --> Model Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Model Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Controller Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 21:07:35 --> Email Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: language_helper
DEBUG - 2015-02-14 21:07:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 21:07:35 --> Model Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Database Driver Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: date_helper
DEBUG - 2015-02-14 21:07:35 --> Helper loaded: form_helper
DEBUG - 2015-02-14 21:07:35 --> Form Validation Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Model Class Initialized
DEBUG - 2015-02-14 21:07:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 21:07:35 --> Pagination Class Initialized
DEBUG - 2015-02-14 21:07:36 --> Model Class Initialized
DEBUG - 2015-02-14 21:07:36 --> Model Class Initialized
DEBUG - 2015-02-14 21:07:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 21:07:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 21:07:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 21:07:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 21:07:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 21:07:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 21:07:36 --> Final output sent to browser
DEBUG - 2015-02-14 21:07:36 --> Total execution time: 1.3821
DEBUG - 2015-02-14 21:22:37 --> Config Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Hooks Class Initialized
DEBUG - 2015-02-14 21:22:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 21:22:37 --> Utf8 Class Initialized
DEBUG - 2015-02-14 21:22:37 --> URI Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Router Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Output Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Security Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Input Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 21:22:37 --> Language Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Loader Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 21:22:37 --> Helper loaded: url_helper
DEBUG - 2015-02-14 21:22:37 --> Helper loaded: link_helper
DEBUG - 2015-02-14 21:22:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 21:22:37 --> CI_Session Class Initialized
DEBUG - 2015-02-14 21:22:37 --> Session: Regenerate ID
DEBUG - 2015-02-14 21:22:37 --> CI_Session routines successfully run
DEBUG - 2015-02-14 21:22:38 --> Model Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Model Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Controller Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 21:22:38 --> Email Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 21:22:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 21:22:38 --> Helper loaded: language_helper
DEBUG - 2015-02-14 21:22:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 21:22:38 --> Model Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Database Driver Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Helper loaded: date_helper
DEBUG - 2015-02-14 21:22:38 --> Helper loaded: form_helper
DEBUG - 2015-02-14 21:22:38 --> Form Validation Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Model Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 21:22:38 --> Pagination Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Model Class Initialized
DEBUG - 2015-02-14 21:22:38 --> Model Class Initialized
DEBUG - 2015-02-14 21:22:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 21:22:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 21:22:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 21:22:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 21:22:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 21:22:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 21:22:39 --> Final output sent to browser
DEBUG - 2015-02-14 21:22:39 --> Total execution time: 1.3471
DEBUG - 2015-02-14 21:37:40 --> Config Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Hooks Class Initialized
DEBUG - 2015-02-14 21:37:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 21:37:40 --> Utf8 Class Initialized
DEBUG - 2015-02-14 21:37:40 --> URI Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Router Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Output Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Security Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Input Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 21:37:40 --> Language Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Loader Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: url_helper
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: link_helper
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 21:37:40 --> CI_Session Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Session: Regenerate ID
DEBUG - 2015-02-14 21:37:40 --> CI_Session routines successfully run
DEBUG - 2015-02-14 21:37:40 --> Model Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Model Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Controller Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 21:37:40 --> Email Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: language_helper
DEBUG - 2015-02-14 21:37:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 21:37:40 --> Model Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Database Driver Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: date_helper
DEBUG - 2015-02-14 21:37:40 --> Helper loaded: form_helper
DEBUG - 2015-02-14 21:37:40 --> Form Validation Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Model Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 21:37:40 --> Pagination Class Initialized
DEBUG - 2015-02-14 21:37:40 --> Model Class Initialized
DEBUG - 2015-02-14 21:37:41 --> Model Class Initialized
DEBUG - 2015-02-14 21:37:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 21:37:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 21:37:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 21:37:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 21:37:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 21:37:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 21:37:41 --> Final output sent to browser
DEBUG - 2015-02-14 21:37:41 --> Total execution time: 1.3601
DEBUG - 2015-02-14 21:52:42 --> Config Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Hooks Class Initialized
DEBUG - 2015-02-14 21:52:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 21:52:42 --> Utf8 Class Initialized
DEBUG - 2015-02-14 21:52:42 --> URI Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Router Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Output Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Security Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Input Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 21:52:42 --> Language Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Loader Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 21:52:42 --> Helper loaded: url_helper
DEBUG - 2015-02-14 21:52:42 --> Helper loaded: link_helper
DEBUG - 2015-02-14 21:52:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 21:52:42 --> CI_Session Class Initialized
DEBUG - 2015-02-14 21:52:42 --> Session: Regenerate ID
DEBUG - 2015-02-14 21:52:42 --> CI_Session routines successfully run
DEBUG - 2015-02-14 21:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Controller Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 21:52:43 --> Email Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 21:52:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 21:52:43 --> Helper loaded: language_helper
DEBUG - 2015-02-14 21:52:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 21:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Database Driver Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Helper loaded: date_helper
DEBUG - 2015-02-14 21:52:43 --> Helper loaded: form_helper
DEBUG - 2015-02-14 21:52:43 --> Form Validation Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 21:52:43 --> Pagination Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 21:52:43 --> Model Class Initialized
DEBUG - 2015-02-14 21:52:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 21:52:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 21:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 21:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 21:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 21:52:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 21:52:44 --> Final output sent to browser
DEBUG - 2015-02-14 21:52:44 --> Total execution time: 1.4571
DEBUG - 2015-02-14 22:07:45 --> Config Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Hooks Class Initialized
DEBUG - 2015-02-14 22:07:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 22:07:45 --> Utf8 Class Initialized
DEBUG - 2015-02-14 22:07:45 --> URI Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Router Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Output Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Security Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Input Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 22:07:45 --> Language Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Loader Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: url_helper
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: link_helper
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 22:07:45 --> CI_Session Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Session: Regenerate ID
DEBUG - 2015-02-14 22:07:45 --> CI_Session routines successfully run
DEBUG - 2015-02-14 22:07:45 --> Model Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Model Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Controller Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 22:07:45 --> Email Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: language_helper
DEBUG - 2015-02-14 22:07:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 22:07:45 --> Model Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Database Driver Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: date_helper
DEBUG - 2015-02-14 22:07:45 --> Helper loaded: form_helper
DEBUG - 2015-02-14 22:07:45 --> Form Validation Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Model Class Initialized
DEBUG - 2015-02-14 22:07:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 22:07:45 --> Pagination Class Initialized
DEBUG - 2015-02-14 22:07:46 --> Model Class Initialized
DEBUG - 2015-02-14 22:07:46 --> Model Class Initialized
DEBUG - 2015-02-14 22:07:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 22:07:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 22:07:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 22:07:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 22:07:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 22:07:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 22:07:46 --> Final output sent to browser
DEBUG - 2015-02-14 22:07:46 --> Total execution time: 1.4962
DEBUG - 2015-02-14 22:22:47 --> Config Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Hooks Class Initialized
DEBUG - 2015-02-14 22:22:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 22:22:47 --> Utf8 Class Initialized
DEBUG - 2015-02-14 22:22:47 --> URI Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Router Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Output Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Security Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Input Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 22:22:47 --> Language Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Loader Class Initialized
DEBUG - 2015-02-14 22:22:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 22:22:47 --> Helper loaded: url_helper
DEBUG - 2015-02-14 22:22:48 --> Helper loaded: link_helper
DEBUG - 2015-02-14 22:22:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 22:22:48 --> CI_Session Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Session: Regenerate ID
DEBUG - 2015-02-14 22:22:48 --> CI_Session routines successfully run
DEBUG - 2015-02-14 22:22:48 --> Model Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Model Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Controller Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 22:22:48 --> Email Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 22:22:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 22:22:48 --> Helper loaded: language_helper
DEBUG - 2015-02-14 22:22:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 22:22:48 --> Model Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Database Driver Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Helper loaded: date_helper
DEBUG - 2015-02-14 22:22:48 --> Helper loaded: form_helper
DEBUG - 2015-02-14 22:22:48 --> Form Validation Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Model Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 22:22:48 --> Pagination Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Model Class Initialized
DEBUG - 2015-02-14 22:22:48 --> Model Class Initialized
DEBUG - 2015-02-14 22:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 22:22:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 22:22:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 22:22:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 22:22:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 22:22:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 22:22:49 --> Final output sent to browser
DEBUG - 2015-02-14 22:22:49 --> Total execution time: 1.4731
DEBUG - 2015-02-14 22:37:50 --> Config Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Hooks Class Initialized
DEBUG - 2015-02-14 22:37:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 22:37:50 --> Utf8 Class Initialized
DEBUG - 2015-02-14 22:37:50 --> URI Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Router Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Output Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Security Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Input Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 22:37:50 --> Language Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Loader Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: url_helper
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: link_helper
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 22:37:50 --> CI_Session Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Session: Regenerate ID
DEBUG - 2015-02-14 22:37:50 --> CI_Session routines successfully run
DEBUG - 2015-02-14 22:37:50 --> Model Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Model Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Controller Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 22:37:50 --> Email Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: language_helper
DEBUG - 2015-02-14 22:37:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 22:37:50 --> Model Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Database Driver Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: date_helper
DEBUG - 2015-02-14 22:37:50 --> Helper loaded: form_helper
DEBUG - 2015-02-14 22:37:50 --> Form Validation Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Model Class Initialized
DEBUG - 2015-02-14 22:37:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 22:37:50 --> Pagination Class Initialized
DEBUG - 2015-02-14 22:37:51 --> Model Class Initialized
DEBUG - 2015-02-14 22:37:51 --> Model Class Initialized
DEBUG - 2015-02-14 22:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 22:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 22:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 22:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 22:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 22:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 22:37:51 --> Final output sent to browser
DEBUG - 2015-02-14 22:37:51 --> Total execution time: 1.3931
DEBUG - 2015-02-14 22:52:52 --> Config Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Hooks Class Initialized
DEBUG - 2015-02-14 22:52:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 22:52:52 --> Utf8 Class Initialized
DEBUG - 2015-02-14 22:52:52 --> URI Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Router Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Output Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Security Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Input Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 22:52:52 --> Language Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Loader Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 22:52:52 --> Helper loaded: url_helper
DEBUG - 2015-02-14 22:52:52 --> Helper loaded: link_helper
DEBUG - 2015-02-14 22:52:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 22:52:52 --> CI_Session Class Initialized
DEBUG - 2015-02-14 22:52:52 --> Session: Regenerate ID
DEBUG - 2015-02-14 22:52:52 --> CI_Session routines successfully run
DEBUG - 2015-02-14 22:52:53 --> Model Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Model Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Controller Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 22:52:53 --> Email Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 22:52:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 22:52:53 --> Helper loaded: language_helper
DEBUG - 2015-02-14 22:52:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 22:52:53 --> Model Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Database Driver Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Helper loaded: date_helper
DEBUG - 2015-02-14 22:52:53 --> Helper loaded: form_helper
DEBUG - 2015-02-14 22:52:53 --> Form Validation Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Model Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 22:52:53 --> Pagination Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Model Class Initialized
DEBUG - 2015-02-14 22:52:53 --> Model Class Initialized
DEBUG - 2015-02-14 22:52:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 22:52:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 22:52:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 22:52:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 22:52:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 22:52:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 22:52:54 --> Final output sent to browser
DEBUG - 2015-02-14 22:52:54 --> Total execution time: 1.3481
DEBUG - 2015-02-14 23:07:55 --> Config Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Hooks Class Initialized
DEBUG - 2015-02-14 23:07:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 23:07:55 --> Utf8 Class Initialized
DEBUG - 2015-02-14 23:07:55 --> URI Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Router Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Output Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Security Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Input Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 23:07:55 --> Language Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Loader Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: url_helper
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: link_helper
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 23:07:55 --> CI_Session Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Session: Regenerate ID
DEBUG - 2015-02-14 23:07:55 --> CI_Session routines successfully run
DEBUG - 2015-02-14 23:07:55 --> Model Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Model Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Controller Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 23:07:55 --> Email Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: language_helper
DEBUG - 2015-02-14 23:07:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 23:07:55 --> Model Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Database Driver Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: date_helper
DEBUG - 2015-02-14 23:07:55 --> Helper loaded: form_helper
DEBUG - 2015-02-14 23:07:55 --> Form Validation Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Model Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 23:07:55 --> Pagination Class Initialized
DEBUG - 2015-02-14 23:07:55 --> Model Class Initialized
DEBUG - 2015-02-14 23:07:56 --> Model Class Initialized
DEBUG - 2015-02-14 23:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 23:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 23:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 23:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 23:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 23:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 23:07:56 --> Final output sent to browser
DEBUG - 2015-02-14 23:07:56 --> Total execution time: 1.5642
DEBUG - 2015-02-14 23:22:57 --> Config Class Initialized
DEBUG - 2015-02-14 23:22:57 --> Hooks Class Initialized
DEBUG - 2015-02-14 23:22:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 23:22:58 --> Utf8 Class Initialized
DEBUG - 2015-02-14 23:22:58 --> URI Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Router Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Output Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Security Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Input Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 23:22:58 --> Language Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Loader Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: url_helper
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: link_helper
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 23:22:58 --> CI_Session Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Session: Regenerate ID
DEBUG - 2015-02-14 23:22:58 --> CI_Session routines successfully run
DEBUG - 2015-02-14 23:22:58 --> Model Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Model Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Controller Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 23:22:58 --> Email Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: language_helper
DEBUG - 2015-02-14 23:22:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 23:22:58 --> Model Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Database Driver Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: date_helper
DEBUG - 2015-02-14 23:22:58 --> Helper loaded: form_helper
DEBUG - 2015-02-14 23:22:58 --> Form Validation Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Model Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 23:22:58 --> Pagination Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Model Class Initialized
DEBUG - 2015-02-14 23:22:58 --> Model Class Initialized
DEBUG - 2015-02-14 23:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 23:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 23:22:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 23:22:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 23:22:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 23:22:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 23:22:59 --> Final output sent to browser
DEBUG - 2015-02-14 23:22:59 --> Total execution time: 1.5262
DEBUG - 2015-02-14 23:38:00 --> Config Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Hooks Class Initialized
DEBUG - 2015-02-14 23:38:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 23:38:00 --> Utf8 Class Initialized
DEBUG - 2015-02-14 23:38:00 --> URI Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Router Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Output Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Security Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Input Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 23:38:00 --> Language Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Loader Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: url_helper
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: link_helper
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 23:38:00 --> CI_Session Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Session: Regenerate ID
DEBUG - 2015-02-14 23:38:00 --> CI_Session routines successfully run
DEBUG - 2015-02-14 23:38:00 --> Model Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Model Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Controller Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 23:38:00 --> Email Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: language_helper
DEBUG - 2015-02-14 23:38:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 23:38:00 --> Model Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Database Driver Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: date_helper
DEBUG - 2015-02-14 23:38:00 --> Helper loaded: form_helper
DEBUG - 2015-02-14 23:38:00 --> Form Validation Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Model Class Initialized
DEBUG - 2015-02-14 23:38:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 23:38:00 --> Pagination Class Initialized
DEBUG - 2015-02-14 23:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 23:38:01 --> Model Class Initialized
DEBUG - 2015-02-14 23:38:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 23:38:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 23:38:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 23:38:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 23:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 23:38:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 23:38:02 --> Final output sent to browser
DEBUG - 2015-02-14 23:38:02 --> Total execution time: 1.4041
DEBUG - 2015-02-14 23:53:03 --> Config Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Hooks Class Initialized
DEBUG - 2015-02-14 23:53:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 23:53:03 --> Utf8 Class Initialized
DEBUG - 2015-02-14 23:53:03 --> URI Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Router Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Output Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Security Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Input Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 23:53:03 --> Language Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Loader Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: url_helper
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: link_helper
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-14 23:53:03 --> CI_Session Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Session: Regenerate ID
DEBUG - 2015-02-14 23:53:03 --> CI_Session routines successfully run
DEBUG - 2015-02-14 23:53:03 --> Model Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Model Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Controller Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-14 23:53:03 --> Email Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: language_helper
DEBUG - 2015-02-14 23:53:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-14 23:53:03 --> Model Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Database Driver Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: date_helper
DEBUG - 2015-02-14 23:53:03 --> Helper loaded: form_helper
DEBUG - 2015-02-14 23:53:03 --> Form Validation Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Model Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-14 23:53:03 --> Pagination Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Model Class Initialized
DEBUG - 2015-02-14 23:53:03 --> Model Class Initialized
DEBUG - 2015-02-14 23:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-14 23:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-14 23:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-14 23:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-14 23:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-14 23:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-14 23:53:04 --> Final output sent to browser
DEBUG - 2015-02-14 23:53:04 --> Total execution time: 1.3451
