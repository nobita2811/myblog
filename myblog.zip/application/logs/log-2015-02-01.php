<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-01 06:08:24 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-01 06:08:24 --> Config Class Initialized
DEBUG - 2015-02-01 06:08:24 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:08:24 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:08:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:08:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:08:25 --> URI Class Initialized
DEBUG - 2015-02-01 06:08:25 --> URI Class Initialized
DEBUG - 2015-02-01 06:08:25 --> Router Class Initialized
DEBUG - 2015-02-01 06:08:25 --> Router Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Output Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Output Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Security Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Security Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Input Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Input Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:08:26 --> Language Class Initialized
DEBUG - 2015-02-01 06:08:26 --> Language Class Initialized
DEBUG - 2015-02-01 06:08:27 --> Loader Class Initialized
DEBUG - 2015-02-01 06:08:27 --> Loader Class Initialized
DEBUG - 2015-02-01 06:08:27 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:08:27 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:08:27 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:08:27 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:08:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:08:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:08:27 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:08:27 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:08:28 --> A session cookie was not found.
DEBUG - 2015-02-01 06:08:28 --> A session cookie was not found.
DEBUG - 2015-02-01 06:08:28 --> Session: Creating new session (76c894e594aa7231da41b10718339587)
DEBUG - 2015-02-01 06:08:28 --> Session: Creating new session (fd42474222621454cab29714b37b8c8f)
DEBUG - 2015-02-01 06:08:28 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:08:28 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-01 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-01 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-01 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-01 06:08:33 --> Controller Class Initialized
DEBUG - 2015-02-01 06:08:33 --> Controller Class Initialized
DEBUG - 2015-02-01 06:08:34 --> Model Class Initialized
DEBUG - 2015-02-01 06:08:34 --> Model Class Initialized
DEBUG - 2015-02-01 06:08:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:08:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:08:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:08:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-02-01 06:08:45 --> Severity: Error --> Call to undefined method Entity\Articles::getUsername() C:\xampp\htdocs\myblog\application\views\admin\article\index.php 29
ERROR - 2015-02-01 06:08:45 --> Severity: Error --> Call to undefined method Entity\Articles::getUsername() C:\xampp\htdocs\myblog\application\views\admin\article\index.php 29
DEBUG - 2015-02-01 06:10:41 --> Config Class Initialized
DEBUG - 2015-02-01 06:10:41 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:10:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:10:41 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:10:41 --> URI Class Initialized
DEBUG - 2015-02-01 06:10:41 --> Router Class Initialized
DEBUG - 2015-02-01 06:10:41 --> Output Class Initialized
DEBUG - 2015-02-01 06:10:41 --> Security Class Initialized
DEBUG - 2015-02-01 06:10:41 --> Input Class Initialized
DEBUG - 2015-02-01 06:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:10:42 --> Language Class Initialized
DEBUG - 2015-02-01 06:10:42 --> Loader Class Initialized
DEBUG - 2015-02-01 06:10:42 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:10:42 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:10:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:10:42 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:10:42 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:10:42 --> Model Class Initialized
DEBUG - 2015-02-01 06:10:42 --> Model Class Initialized
DEBUG - 2015-02-01 06:10:42 --> Controller Class Initialized
DEBUG - 2015-02-01 06:10:42 --> Model Class Initialized
DEBUG - 2015-02-01 06:10:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:10:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:10:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 06:10:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 06:10:42 --> Final output sent to browser
DEBUG - 2015-02-01 06:10:42 --> Total execution time: 0.8530
DEBUG - 2015-02-01 06:11:20 --> Config Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:11:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:11:20 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:11:20 --> URI Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Router Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Output Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Security Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Input Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:11:20 --> Language Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Loader Class Initialized
DEBUG - 2015-02-01 06:11:20 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:11:20 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:11:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:11:20 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:11:20 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:11:21 --> Model Class Initialized
DEBUG - 2015-02-01 06:11:21 --> Model Class Initialized
DEBUG - 2015-02-01 06:11:21 --> Controller Class Initialized
DEBUG - 2015-02-01 06:11:21 --> Model Class Initialized
DEBUG - 2015-02-01 06:11:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:11:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:11:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 06:11:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 06:11:21 --> Final output sent to browser
DEBUG - 2015-02-01 06:11:21 --> Total execution time: 0.6080
DEBUG - 2015-02-01 06:11:37 --> Config Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:11:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:11:37 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:11:37 --> URI Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Router Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Output Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Security Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Input Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:11:37 --> Language Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Loader Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:11:37 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:11:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:11:37 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:11:37 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:11:37 --> Model Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Model Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Controller Class Initialized
DEBUG - 2015-02-01 06:11:37 --> Model Class Initialized
ERROR - 2015-02-01 06:11:37 --> Severity: Error --> Call to undefined method Article_model::getBySlugName() C:\xampp\htdocs\myblog\application\models\Article_model.php 23
DEBUG - 2015-02-01 06:12:54 --> Config Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:12:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:12:54 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:12:54 --> URI Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Router Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Output Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Security Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Input Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:12:54 --> Language Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Loader Class Initialized
DEBUG - 2015-02-01 06:12:54 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:12:54 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:12:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:12:54 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:12:54 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:12:55 --> Model Class Initialized
DEBUG - 2015-02-01 06:12:55 --> Model Class Initialized
DEBUG - 2015-02-01 06:12:55 --> Controller Class Initialized
DEBUG - 2015-02-01 06:12:55 --> Model Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Config Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:12:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:12:56 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:12:56 --> URI Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Router Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Output Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Security Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Input Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:12:56 --> Language Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Loader Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:12:56 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:12:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:12:56 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:12:56 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:12:56 --> Model Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Model Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Controller Class Initialized
DEBUG - 2015-02-01 06:12:56 --> Model Class Initialized
DEBUG - 2015-02-01 06:12:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:12:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:12:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 06:12:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 06:12:56 --> Final output sent to browser
DEBUG - 2015-02-01 06:12:56 --> Total execution time: 0.6210
DEBUG - 2015-02-01 06:14:24 --> Config Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:14:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:14:24 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:14:24 --> URI Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Router Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Output Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Security Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Input Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:14:24 --> Language Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Loader Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:14:24 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:14:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:14:24 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Session: Regenerate ID
DEBUG - 2015-02-01 06:14:24 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:14:24 --> Model Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Model Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Controller Class Initialized
DEBUG - 2015-02-01 06:14:24 --> Model Class Initialized
DEBUG - 2015-02-01 06:14:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:14:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:14:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 06:14:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 06:14:24 --> Final output sent to browser
DEBUG - 2015-02-01 06:14:24 --> Total execution time: 0.6000
DEBUG - 2015-02-01 06:14:40 --> Config Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:14:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:14:40 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:14:40 --> URI Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Router Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Output Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Security Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Input Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:14:40 --> Language Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Loader Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:14:40 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:14:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:14:40 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:14:40 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:14:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Controller Class Initialized
DEBUG - 2015-02-01 06:14:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:14:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:14:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:14:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 06:14:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 06:14:40 --> Final output sent to browser
DEBUG - 2015-02-01 06:14:40 --> Total execution time: 0.4730
DEBUG - 2015-02-01 06:19:09 --> Config Class Initialized
DEBUG - 2015-02-01 06:19:09 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:19:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:19:09 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:19:09 --> URI Class Initialized
DEBUG - 2015-02-01 06:19:09 --> Router Class Initialized
DEBUG - 2015-02-01 06:19:09 --> Output Class Initialized
DEBUG - 2015-02-01 06:19:09 --> Security Class Initialized
DEBUG - 2015-02-01 06:19:10 --> Input Class Initialized
DEBUG - 2015-02-01 06:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:19:10 --> Language Class Initialized
DEBUG - 2015-02-01 06:19:10 --> Loader Class Initialized
DEBUG - 2015-02-01 06:19:10 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:19:10 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:19:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:19:10 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:19:10 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:19:10 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:10 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:10 --> Controller Class Initialized
DEBUG - 2015-02-01 06:19:10 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:19:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:19:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 06:19:10 --> Upload Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Config Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:19:11 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:19:11 --> URI Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Router Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Output Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Security Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Input Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:19:11 --> Language Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Loader Class Initialized
DEBUG - 2015-02-01 06:19:11 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:19:11 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:19:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:19:11 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:19:11 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:19:12 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:12 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:12 --> Controller Class Initialized
DEBUG - 2015-02-01 06:19:12 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 06:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 06:19:12 --> Final output sent to browser
DEBUG - 2015-02-01 06:19:12 --> Total execution time: 1.0491
DEBUG - 2015-02-01 06:19:35 --> Config Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:19:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:19:35 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:19:35 --> URI Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Router Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Output Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Security Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Input Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:19:35 --> Language Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Loader Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:19:35 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:19:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:19:35 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Session: Regenerate ID
DEBUG - 2015-02-01 06:19:35 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:19:35 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:35 --> Controller Class Initialized
DEBUG - 2015-02-01 06:19:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\login.php
DEBUG - 2015-02-01 06:19:35 --> Final output sent to browser
DEBUG - 2015-02-01 06:19:35 --> Total execution time: 0.5540
DEBUG - 2015-02-01 06:19:58 --> Config Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:19:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:19:58 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:19:58 --> URI Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Router Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Output Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Security Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Input Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:19:58 --> Language Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Loader Class Initialized
DEBUG - 2015-02-01 06:19:58 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:19:59 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:19:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:19:59 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:19:59 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:19:59 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:59 --> Model Class Initialized
DEBUG - 2015-02-01 06:19:59 --> Controller Class Initialized
DEBUG - 2015-02-01 06:19:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\login.php
DEBUG - 2015-02-01 06:19:59 --> Final output sent to browser
DEBUG - 2015-02-01 06:19:59 --> Total execution time: 0.4350
DEBUG - 2015-02-01 06:20:04 --> Config Class Initialized
DEBUG - 2015-02-01 06:20:04 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:20:04 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:20:04 --> URI Class Initialized
DEBUG - 2015-02-01 06:20:04 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:20:04 --> Router Class Initialized
DEBUG - 2015-02-01 06:20:04 --> Output Class Initialized
DEBUG - 2015-02-01 06:20:04 --> Security Class Initialized
DEBUG - 2015-02-01 06:20:04 --> Input Class Initialized
DEBUG - 2015-02-01 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:20:04 --> Language Class Initialized
DEBUG - 2015-02-01 06:20:04 --> Loader Class Initialized
DEBUG - 2015-02-01 06:20:04 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:20:04 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:20:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:20:04 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:20:04 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:20:05 --> Model Class Initialized
DEBUG - 2015-02-01 06:20:05 --> Model Class Initialized
DEBUG - 2015-02-01 06:20:05 --> Controller Class Initialized
DEBUG - 2015-02-01 06:20:05 --> Model Class Initialized
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:20:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:20:05 --> Final output sent to browser
DEBUG - 2015-02-01 06:20:05 --> Total execution time: 0.8010
DEBUG - 2015-02-01 06:29:38 --> Config Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:29:38 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:29:38 --> URI Class Initialized
DEBUG - 2015-02-01 06:29:38 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:29:38 --> Router Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Output Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Security Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Input Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:29:38 --> Language Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Loader Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:29:38 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:29:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:29:38 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:29:38 --> Session: Regenerate ID
DEBUG - 2015-02-01 06:29:38 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:29:39 --> Model Class Initialized
DEBUG - 2015-02-01 06:29:39 --> Model Class Initialized
DEBUG - 2015-02-01 06:29:39 --> Controller Class Initialized
DEBUG - 2015-02-01 06:29:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:29:39 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:29:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:29:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:29:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:29:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-02-01 06:29:39 --> Severity: Notice --> Undefined property: Welcome::$article_model C:\xampp\htdocs\myblog\application\controllers\Welcome.php 56
ERROR - 2015-02-01 06:29:39 --> Severity: Error --> Call to a member function getAll() on null C:\xampp\htdocs\myblog\application\controllers\Welcome.php 56
DEBUG - 2015-02-01 06:30:16 --> Config Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:30:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:30:16 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:30:16 --> URI Class Initialized
DEBUG - 2015-02-01 06:30:16 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:30:16 --> Router Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Output Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Security Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Input Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:30:16 --> Language Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Loader Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:30:16 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:30:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:30:16 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:30:16 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:30:16 --> Model Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Model Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Controller Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:30:16 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:30:16 --> Model Class Initialized
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:30:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:30:16 --> Final output sent to browser
DEBUG - 2015-02-01 06:30:16 --> Total execution time: 0.6790
DEBUG - 2015-02-01 06:30:33 --> Config Class Initialized
DEBUG - 2015-02-01 06:30:33 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:30:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:30:33 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:30:33 --> URI Class Initialized
DEBUG - 2015-02-01 06:30:33 --> Router Class Initialized
DEBUG - 2015-02-01 06:30:33 --> Output Class Initialized
DEBUG - 2015-02-01 06:30:33 --> Security Class Initialized
DEBUG - 2015-02-01 06:30:33 --> Input Class Initialized
DEBUG - 2015-02-01 06:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:30:33 --> Language Class Initialized
ERROR - 2015-02-01 06:30:33 --> 404 Page Not Found: 180/index
DEBUG - 2015-02-01 06:31:44 --> Config Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:31:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:31:44 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:31:44 --> URI Class Initialized
DEBUG - 2015-02-01 06:31:44 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:31:44 --> Router Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Output Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Security Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Input Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:31:44 --> Language Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Loader Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:31:44 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:31:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:31:44 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:31:44 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:31:44 --> Model Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Model Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Controller Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:31:44 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:31:44 --> Model Class Initialized
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:31:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:31:44 --> Final output sent to browser
DEBUG - 2015-02-01 06:31:44 --> Total execution time: 0.5160
DEBUG - 2015-02-01 06:31:54 --> Config Class Initialized
DEBUG - 2015-02-01 06:31:54 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:31:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:31:54 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:31:54 --> URI Class Initialized
DEBUG - 2015-02-01 06:31:55 --> Router Class Initialized
DEBUG - 2015-02-01 06:31:55 --> Output Class Initialized
DEBUG - 2015-02-01 06:31:55 --> Security Class Initialized
DEBUG - 2015-02-01 06:31:55 --> Input Class Initialized
DEBUG - 2015-02-01 06:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:31:55 --> Language Class Initialized
ERROR - 2015-02-01 06:31:55 --> 404 Page Not Found: 20/index
DEBUG - 2015-02-01 06:33:31 --> Config Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:33:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:33:31 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:33:31 --> URI Class Initialized
DEBUG - 2015-02-01 06:33:31 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:33:31 --> Router Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Output Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Security Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Input Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:33:31 --> Language Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Loader Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:33:31 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:33:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:33:31 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:33:31 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:33:31 --> Model Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Model Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Controller Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:33:31 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:33:31 --> Model Class Initialized
DEBUG - 2015-02-01 06:33:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:33:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:33:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:33:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:33:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:33:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:33:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:33:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:33:32 --> Final output sent to browser
DEBUG - 2015-02-01 06:33:32 --> Total execution time: 0.6810
DEBUG - 2015-02-01 06:34:39 --> Config Class Initialized
DEBUG - 2015-02-01 06:34:39 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:34:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:34:39 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:34:39 --> URI Class Initialized
DEBUG - 2015-02-01 06:34:39 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:34:39 --> Router Class Initialized
DEBUG - 2015-02-01 06:34:39 --> Output Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Security Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Input Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:34:40 --> Language Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Loader Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:34:40 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:34:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:34:40 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Session: Regenerate ID
DEBUG - 2015-02-01 06:34:40 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:34:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Controller Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:34:40 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:34:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:34:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:34:40 --> Final output sent to browser
DEBUG - 2015-02-01 06:34:40 --> Total execution time: 0.6500
DEBUG - 2015-02-01 06:35:59 --> Config Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:35:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:35:59 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:35:59 --> URI Class Initialized
DEBUG - 2015-02-01 06:35:59 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:35:59 --> Router Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Output Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Security Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Input Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:35:59 --> Language Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Loader Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:35:59 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:35:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:35:59 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:35:59 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:35:59 --> Model Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Model Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Controller Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:35:59 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:35:59 --> Model Class Initialized
DEBUG - 2015-02-01 06:35:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:35:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:35:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:35:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:36:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:36:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:36:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:36:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:36:00 --> Final output sent to browser
DEBUG - 2015-02-01 06:36:00 --> Total execution time: 0.5900
DEBUG - 2015-02-01 06:36:29 --> Config Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:36:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:36:29 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:36:29 --> URI Class Initialized
DEBUG - 2015-02-01 06:36:29 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:36:29 --> Router Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Output Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Security Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Input Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:36:29 --> Language Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Loader Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:36:29 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:36:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:36:29 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:36:29 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:36:29 --> Model Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Model Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Controller Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:36:29 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:36:29 --> Model Class Initialized
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:36:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:36:30 --> Final output sent to browser
DEBUG - 2015-02-01 06:36:30 --> Total execution time: 0.6930
DEBUG - 2015-02-01 06:37:14 --> Config Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:37:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:37:14 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:37:14 --> URI Class Initialized
DEBUG - 2015-02-01 06:37:14 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:37:14 --> Router Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Output Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Security Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Input Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:37:14 --> Language Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Loader Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:37:14 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:37:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:37:14 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:37:14 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:37:14 --> Model Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Model Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Controller Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:37:14 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:37:14 --> Model Class Initialized
DEBUG - 2015-02-01 06:37:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:37:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:37:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:37:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:37:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:37:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:37:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:37:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:37:15 --> Final output sent to browser
DEBUG - 2015-02-01 06:37:15 --> Total execution time: 0.5570
DEBUG - 2015-02-01 06:37:50 --> Config Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:37:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:37:50 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:37:50 --> URI Class Initialized
DEBUG - 2015-02-01 06:37:50 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:37:50 --> Router Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Output Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Security Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Input Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:37:50 --> Language Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Loader Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:37:50 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:37:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:37:50 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:37:50 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:37:50 --> Model Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Model Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Controller Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:37:50 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:37:50 --> Model Class Initialized
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:37:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:37:50 --> Final output sent to browser
DEBUG - 2015-02-01 06:37:50 --> Total execution time: 0.6480
DEBUG - 2015-02-01 06:38:01 --> Config Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:38:01 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:38:01 --> URI Class Initialized
DEBUG - 2015-02-01 06:38:01 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:38:01 --> Router Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Output Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Security Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Input Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:38:01 --> Language Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Loader Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:38:01 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:38:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:38:01 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:38:01 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:38:01 --> Model Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Model Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Controller Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:38:01 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:38:01 --> Model Class Initialized
DEBUG - 2015-02-01 06:38:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:38:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:38:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:38:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:38:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:38:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:38:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:38:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:38:02 --> Final output sent to browser
DEBUG - 2015-02-01 06:38:02 --> Total execution time: 0.6220
DEBUG - 2015-02-01 06:38:11 --> Config Class Initialized
DEBUG - 2015-02-01 06:38:11 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:38:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:38:11 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:38:11 --> URI Class Initialized
DEBUG - 2015-02-01 06:38:11 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:38:11 --> Router Class Initialized
DEBUG - 2015-02-01 06:38:11 --> Output Class Initialized
DEBUG - 2015-02-01 06:38:11 --> Security Class Initialized
DEBUG - 2015-02-01 06:38:11 --> Input Class Initialized
DEBUG - 2015-02-01 06:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:38:11 --> Language Class Initialized
DEBUG - 2015-02-01 06:38:11 --> Loader Class Initialized
DEBUG - 2015-02-01 06:38:11 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:38:11 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:38:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:38:11 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:38:11 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:38:12 --> Model Class Initialized
DEBUG - 2015-02-01 06:38:12 --> Model Class Initialized
DEBUG - 2015-02-01 06:38:12 --> Controller Class Initialized
DEBUG - 2015-02-01 06:38:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:38:12 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:38:12 --> Model Class Initialized
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:38:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:38:12 --> Final output sent to browser
DEBUG - 2015-02-01 06:38:12 --> Total execution time: 0.5570
DEBUG - 2015-02-01 06:42:48 --> Config Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:42:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:42:48 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:42:48 --> URI Class Initialized
DEBUG - 2015-02-01 06:42:48 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:42:48 --> Router Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Output Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Security Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Input Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:42:48 --> Language Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Loader Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:42:48 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:42:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:42:48 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:42:48 --> Session: Regenerate ID
DEBUG - 2015-02-01 06:42:48 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:42:49 --> Model Class Initialized
DEBUG - 2015-02-01 06:42:49 --> Model Class Initialized
DEBUG - 2015-02-01 06:42:49 --> Controller Class Initialized
DEBUG - 2015-02-01 06:42:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:42:49 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:42:49 --> Model Class Initialized
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:42:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:42:49 --> Final output sent to browser
DEBUG - 2015-02-01 06:42:49 --> Total execution time: 0.8821
DEBUG - 2015-02-01 06:43:34 --> Config Class Initialized
DEBUG - 2015-02-01 06:43:34 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:43:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:43:34 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:43:34 --> URI Class Initialized
DEBUG - 2015-02-01 06:43:34 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:43:34 --> Router Class Initialized
DEBUG - 2015-02-01 06:43:34 --> Output Class Initialized
DEBUG - 2015-02-01 06:43:34 --> Security Class Initialized
DEBUG - 2015-02-01 06:43:34 --> Input Class Initialized
DEBUG - 2015-02-01 06:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:43:34 --> Language Class Initialized
DEBUG - 2015-02-01 06:43:34 --> Loader Class Initialized
DEBUG - 2015-02-01 06:43:34 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:43:34 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:43:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:43:34 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:43:34 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:43:35 --> Model Class Initialized
DEBUG - 2015-02-01 06:43:35 --> Model Class Initialized
DEBUG - 2015-02-01 06:43:35 --> Controller Class Initialized
DEBUG - 2015-02-01 06:43:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:43:35 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:43:35 --> Model Class Initialized
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:43:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:43:35 --> Final output sent to browser
DEBUG - 2015-02-01 06:43:35 --> Total execution time: 0.8891
DEBUG - 2015-02-01 06:45:54 --> Config Class Initialized
DEBUG - 2015-02-01 06:45:54 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:45:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:45:54 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:45:54 --> URI Class Initialized
DEBUG - 2015-02-01 06:45:54 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:45:54 --> Router Class Initialized
DEBUG - 2015-02-01 06:45:54 --> Output Class Initialized
DEBUG - 2015-02-01 06:45:54 --> Security Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Input Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:45:55 --> Language Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Loader Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:45:55 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:45:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:45:55 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:45:55 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:45:55 --> Model Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Model Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Controller Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:45:55 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:45:55 --> Model Class Initialized
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:45:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:45:55 --> Final output sent to browser
DEBUG - 2015-02-01 06:45:55 --> Total execution time: 0.7050
DEBUG - 2015-02-01 06:46:01 --> Config Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:46:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:46:01 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:46:01 --> URI Class Initialized
DEBUG - 2015-02-01 06:46:01 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:46:01 --> Router Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Output Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Security Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Input Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:46:01 --> Language Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Loader Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:46:01 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:46:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:46:01 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:46:01 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:46:01 --> Model Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Model Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Controller Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:46:01 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:46:01 --> Model Class Initialized
DEBUG - 2015-02-01 06:46:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:46:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:46:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:46:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:46:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:46:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:46:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:46:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:46:02 --> Final output sent to browser
DEBUG - 2015-02-01 06:46:02 --> Total execution time: 0.5970
DEBUG - 2015-02-01 06:46:10 --> Config Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:46:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:46:10 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:46:10 --> URI Class Initialized
DEBUG - 2015-02-01 06:46:10 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:46:10 --> Router Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Output Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Security Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Input Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:46:10 --> Language Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Loader Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:46:10 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:46:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:46:10 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:46:10 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:46:10 --> Model Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Model Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Controller Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:46:10 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:46:10 --> Model Class Initialized
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:46:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:46:11 --> Final output sent to browser
DEBUG - 2015-02-01 06:46:11 --> Total execution time: 0.4620
DEBUG - 2015-02-01 06:49:39 --> Config Class Initialized
DEBUG - 2015-02-01 06:49:39 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:49:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:49:39 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:49:39 --> URI Class Initialized
DEBUG - 2015-02-01 06:49:39 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:49:39 --> Router Class Initialized
DEBUG - 2015-02-01 06:49:39 --> Output Class Initialized
DEBUG - 2015-02-01 06:49:39 --> Security Class Initialized
DEBUG - 2015-02-01 06:49:39 --> Input Class Initialized
DEBUG - 2015-02-01 06:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:49:39 --> Language Class Initialized
DEBUG - 2015-02-01 06:49:39 --> Loader Class Initialized
DEBUG - 2015-02-01 06:49:39 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:49:40 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:49:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:49:40 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:49:40 --> Session: Regenerate ID
DEBUG - 2015-02-01 06:49:40 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:49:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:40 --> Controller Class Initialized
DEBUG - 2015-02-01 06:49:40 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:49:40 --> Pagination Class Initialized
ERROR - 2015-02-01 06:49:40 --> Severity: Warning --> require(C:\xampp\htdocs\myblog\application\models\Entity\Article.php): failed to open stream: No such file or directory C:\xampp\htdocs\myblog\vendor\doctrine\common\lib\Doctrine\Common\ClassLoader.php 182
ERROR - 2015-02-01 06:49:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myblog\vendor\doctrine\common\lib\Doctrine\Common\ClassLoader.php:182) C:\xampp\htdocs\myblog\system\core\Common.php 566
ERROR - 2015-02-01 06:49:40 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\myblog\application\models\Entity\Article.php' (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\myblog\vendor\doctrine\common\lib\Doctrine\Common\ClassLoader.php 182
DEBUG - 2015-02-01 06:49:48 --> Config Class Initialized
DEBUG - 2015-02-01 06:49:48 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:49:48 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:49:48 --> URI Class Initialized
DEBUG - 2015-02-01 06:49:49 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:49:49 --> Router Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Output Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Security Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Input Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:49:49 --> Language Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Loader Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:49:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:49:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:49:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:49:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:49:49 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Controller Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:49:49 --> Pagination Class Initialized
ERROR - 2015-02-01 06:49:49 --> Severity: error --> Exception: [Semantical Error] line 0, col 13 near '1) FROM Entity\Articles': Error: '1' is not defined. C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Query\QueryException.php 49
DEBUG - 2015-02-01 06:49:57 --> Config Class Initialized
DEBUG - 2015-02-01 06:49:57 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:49:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:49:57 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:49:57 --> URI Class Initialized
DEBUG - 2015-02-01 06:49:57 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:49:57 --> Router Class Initialized
DEBUG - 2015-02-01 06:49:57 --> Output Class Initialized
DEBUG - 2015-02-01 06:49:57 --> Security Class Initialized
DEBUG - 2015-02-01 06:49:57 --> Input Class Initialized
DEBUG - 2015-02-01 06:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:49:57 --> Language Class Initialized
DEBUG - 2015-02-01 06:49:57 --> Loader Class Initialized
DEBUG - 2015-02-01 06:49:57 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:49:57 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:49:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:49:57 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:49:57 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:49:58 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:58 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:58 --> Controller Class Initialized
DEBUG - 2015-02-01 06:49:58 --> Model Class Initialized
DEBUG - 2015-02-01 06:49:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:49:58 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:49:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:49:58 --> Final output sent to browser
DEBUG - 2015-02-01 06:49:58 --> Total execution time: 0.6670
DEBUG - 2015-02-01 06:51:25 --> Config Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:51:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:51:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:51:25 --> URI Class Initialized
DEBUG - 2015-02-01 06:51:25 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:51:25 --> Router Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Output Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Security Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Input Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:51:25 --> Language Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Loader Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:51:25 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:51:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:51:25 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:51:25 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:51:25 --> Model Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Model Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Controller Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Model Class Initialized
DEBUG - 2015-02-01 06:51:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:51:25 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:51:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:51:26 --> Final output sent to browser
DEBUG - 2015-02-01 06:51:26 --> Total execution time: 0.6040
DEBUG - 2015-02-01 06:52:29 --> Config Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:52:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:52:29 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:52:29 --> URI Class Initialized
DEBUG - 2015-02-01 06:52:29 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:52:29 --> Router Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Output Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Security Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Input Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:52:29 --> Language Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Loader Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:52:29 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:52:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:52:29 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:52:29 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:52:29 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Controller Class Initialized
ERROR - 2015-02-01 06:52:29 --> Severity: Warning --> Missing argument 1 for Welcome::index() C:\xampp\htdocs\myblog\application\controllers\Welcome.php 43
DEBUG - 2015-02-01 06:52:29 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:52:29 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:52:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:52:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-02-01 06:52:30 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\myblog\application\controllers\Welcome.php 78
ERROR - 2015-02-01 06:52:30 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\myblog\application\controllers\Welcome.php 78
DEBUG - 2015-02-01 06:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:52:30 --> Final output sent to browser
DEBUG - 2015-02-01 06:52:30 --> Total execution time: 0.6550
DEBUG - 2015-02-01 06:52:37 --> Config Class Initialized
DEBUG - 2015-02-01 06:52:37 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:52:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:52:37 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:52:37 --> URI Class Initialized
DEBUG - 2015-02-01 06:52:37 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:52:37 --> Router Class Initialized
DEBUG - 2015-02-01 06:52:37 --> Output Class Initialized
DEBUG - 2015-02-01 06:52:37 --> Security Class Initialized
DEBUG - 2015-02-01 06:52:37 --> Input Class Initialized
DEBUG - 2015-02-01 06:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:52:37 --> Language Class Initialized
DEBUG - 2015-02-01 06:52:37 --> Loader Class Initialized
DEBUG - 2015-02-01 06:52:37 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:52:37 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:52:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:52:37 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:52:37 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:52:38 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:38 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:38 --> Controller Class Initialized
ERROR - 2015-02-01 06:52:38 --> Severity: Warning --> Missing argument 1 for Welcome::index() C:\xampp\htdocs\myblog\application\controllers\Welcome.php 43
DEBUG - 2015-02-01 06:52:38 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:52:38 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-02-01 06:52:38 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\myblog\application\controllers\Welcome.php 78
ERROR - 2015-02-01 06:52:38 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\myblog\application\controllers\Welcome.php 78
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:52:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:52:38 --> Final output sent to browser
DEBUG - 2015-02-01 06:52:38 --> Total execution time: 0.7170
DEBUG - 2015-02-01 06:52:52 --> Config Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:52:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:52:52 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:52:52 --> URI Class Initialized
DEBUG - 2015-02-01 06:52:52 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:52:52 --> Router Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Output Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Security Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Input Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:52:52 --> Language Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Loader Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:52:52 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:52:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:52:52 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:52:52 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:52:52 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:52 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:53 --> Controller Class Initialized
DEBUG - 2015-02-01 06:52:53 --> Model Class Initialized
DEBUG - 2015-02-01 06:52:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:52:53 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-02-01 06:52:53 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\myblog\application\controllers\Welcome.php 78
ERROR - 2015-02-01 06:52:53 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\myblog\application\controllers\Welcome.php 78
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:52:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:52:53 --> Final output sent to browser
DEBUG - 2015-02-01 06:52:53 --> Total execution time: 0.6510
DEBUG - 2015-02-01 06:53:08 --> Config Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:53:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:53:08 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:53:08 --> URI Class Initialized
DEBUG - 2015-02-01 06:53:08 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:53:08 --> Router Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Output Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Security Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Input Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:53:08 --> Language Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Loader Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:53:08 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:53:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:53:08 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:53:08 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:53:08 --> Model Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Model Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Controller Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Model Class Initialized
DEBUG - 2015-02-01 06:53:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:53:08 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:53:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:53:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:53:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:53:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-02-01 06:53:08 --> Severity: Notice --> Undefined variable: from C:\xampp\htdocs\myblog\application\controllers\Welcome.php 79
ERROR - 2015-02-01 06:53:08 --> Severity: Notice --> Undefined variable: to C:\xampp\htdocs\myblog\application\controllers\Welcome.php 79
DEBUG - 2015-02-01 06:53:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:53:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:53:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:53:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:53:09 --> Final output sent to browser
DEBUG - 2015-02-01 06:53:09 --> Total execution time: 0.7310
DEBUG - 2015-02-01 06:53:17 --> Config Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:53:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:53:17 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:53:17 --> URI Class Initialized
DEBUG - 2015-02-01 06:53:17 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:53:17 --> Router Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Output Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Security Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Input Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:53:17 --> Language Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Loader Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:53:17 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:53:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:53:17 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:53:17 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:53:17 --> Model Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Model Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Controller Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Model Class Initialized
DEBUG - 2015-02-01 06:53:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:53:17 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:53:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:53:17 --> Final output sent to browser
DEBUG - 2015-02-01 06:53:17 --> Total execution time: 0.5430
DEBUG - 2015-02-01 06:54:09 --> Config Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:54:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:54:09 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:54:09 --> URI Class Initialized
DEBUG - 2015-02-01 06:54:09 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:54:09 --> Router Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Output Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Security Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Input Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:54:09 --> Language Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Loader Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:54:09 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:54:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:54:09 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:54:09 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:54:09 --> Model Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Model Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Controller Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Model Class Initialized
DEBUG - 2015-02-01 06:54:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:54:09 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:54:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:54:09 --> Final output sent to browser
DEBUG - 2015-02-01 06:54:09 --> Total execution time: 0.6300
DEBUG - 2015-02-01 06:54:52 --> Config Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:54:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:54:52 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:54:52 --> URI Class Initialized
DEBUG - 2015-02-01 06:54:52 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:54:52 --> Router Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Output Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Security Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Input Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:54:52 --> Language Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Loader Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:54:52 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:54:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:54:52 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Session: Regenerate ID
DEBUG - 2015-02-01 06:54:52 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:54:52 --> Model Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Model Class Initialized
DEBUG - 2015-02-01 06:54:52 --> Controller Class Initialized
DEBUG - 2015-02-01 06:54:53 --> Model Class Initialized
DEBUG - 2015-02-01 06:54:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:54:53 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:54:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:54:53 --> Final output sent to browser
DEBUG - 2015-02-01 06:54:53 --> Total execution time: 0.6870
DEBUG - 2015-02-01 06:56:51 --> Config Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:56:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:56:51 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:56:51 --> URI Class Initialized
DEBUG - 2015-02-01 06:56:51 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:56:51 --> Router Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Output Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Security Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Input Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:56:51 --> Language Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Loader Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:56:51 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:56:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:56:51 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:56:51 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:56:51 --> Model Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Model Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Controller Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Model Class Initialized
DEBUG - 2015-02-01 06:56:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:56:51 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:56:51 --> Final output sent to browser
DEBUG - 2015-02-01 06:56:51 --> Total execution time: 0.4630
DEBUG - 2015-02-01 06:56:53 --> Config Class Initialized
DEBUG - 2015-02-01 06:56:53 --> Hooks Class Initialized
DEBUG - 2015-02-01 06:56:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 06:56:53 --> Utf8 Class Initialized
DEBUG - 2015-02-01 06:56:53 --> URI Class Initialized
DEBUG - 2015-02-01 06:56:53 --> No URI present. Default controller set.
DEBUG - 2015-02-01 06:56:53 --> Router Class Initialized
DEBUG - 2015-02-01 06:56:53 --> Output Class Initialized
DEBUG - 2015-02-01 06:56:53 --> Security Class Initialized
DEBUG - 2015-02-01 06:56:53 --> Input Class Initialized
DEBUG - 2015-02-01 06:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 06:56:53 --> Language Class Initialized
DEBUG - 2015-02-01 06:56:53 --> Loader Class Initialized
DEBUG - 2015-02-01 06:56:53 --> Helper loaded: url_helper
DEBUG - 2015-02-01 06:56:53 --> Helper loaded: link_helper
DEBUG - 2015-02-01 06:56:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 06:56:53 --> CI_Session Class Initialized
DEBUG - 2015-02-01 06:56:53 --> CI_Session routines successfully run
DEBUG - 2015-02-01 06:56:54 --> Model Class Initialized
DEBUG - 2015-02-01 06:56:54 --> Model Class Initialized
DEBUG - 2015-02-01 06:56:54 --> Controller Class Initialized
DEBUG - 2015-02-01 06:56:54 --> Model Class Initialized
DEBUG - 2015-02-01 06:56:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 06:56:54 --> Pagination Class Initialized
DEBUG - 2015-02-01 06:56:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 06:56:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 06:56:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 06:56:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 06:56:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 06:56:54 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 06:56:54 --> Final output sent to browser
DEBUG - 2015-02-01 06:56:54 --> Total execution time: 0.8580
DEBUG - 2015-02-01 07:02:17 --> Config Class Initialized
DEBUG - 2015-02-01 07:02:17 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:02:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:02:17 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:02:17 --> URI Class Initialized
DEBUG - 2015-02-01 07:02:17 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:02:17 --> Router Class Initialized
DEBUG - 2015-02-01 07:02:17 --> Output Class Initialized
DEBUG - 2015-02-01 07:02:17 --> Security Class Initialized
DEBUG - 2015-02-01 07:02:17 --> Input Class Initialized
DEBUG - 2015-02-01 07:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:02:17 --> Language Class Initialized
DEBUG - 2015-02-01 07:02:17 --> Loader Class Initialized
DEBUG - 2015-02-01 07:02:17 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:02:17 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:02:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:02:17 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:02:18 --> Session: Regenerate ID
DEBUG - 2015-02-01 07:02:18 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:02:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:02:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:02:18 --> Controller Class Initialized
DEBUG - 2015-02-01 07:02:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:02:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:02:18 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:02:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:02:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:02:18 --> Severity: Notice --> Undefined variable: datas C:\xampp\htdocs\myblog\application\views\welcome_message.php 2
ERROR - 2015-02-01 07:02:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myblog\application\views\welcome_message.php 2
DEBUG - 2015-02-01 07:02:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:02:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:02:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:02:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:02:18 --> Final output sent to browser
DEBUG - 2015-02-01 07:02:18 --> Total execution time: 0.6050
DEBUG - 2015-02-01 07:07:04 --> Config Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:07:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:07:04 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:07:04 --> URI Class Initialized
DEBUG - 2015-02-01 07:07:04 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:07:04 --> Router Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Output Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Security Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Input Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:07:04 --> Language Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Loader Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:07:04 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:07:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:07:04 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:07:04 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:07:04 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Controller Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:07:04 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:07:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:07:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:07:05 --> Severity: Notice --> Undefined variable: condition C:\xampp\htdocs\myblog\application\models\Article_model.php 13
ERROR - 2015-02-01 07:07:05 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\EntityRepository::findBy() must be of the type array, null given, called in C:\xampp\htdocs\myblog\application\models\Article_model.php on line 13 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php 153
ERROR - 2015-02-01 07:07:05 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\Persisters\BasicEntityPersister::loadAll() must be of the type array, null given, called in C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php on line 157 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 861
ERROR - 2015-02-01 07:07:05 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\Persisters\BasicEntityPersister::_getSelectConditionSQL() must be of the type array, null given, called in C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php on line 1039 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1552
ERROR - 2015-02-01 07:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1556
ERROR - 2015-02-01 07:07:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1645
ERROR - 2015-02-01 07:07:05 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:07:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myblog\system\core\Exceptions.php:272) C:\xampp\htdocs\myblog\system\core\Common.php 566
ERROR - 2015-02-01 07:07:05 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:07:11 --> Config Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:07:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:07:11 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:07:11 --> URI Class Initialized
DEBUG - 2015-02-01 07:07:11 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:07:11 --> Router Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Output Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Security Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Input Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:07:11 --> Language Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Loader Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:07:11 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:07:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:07:11 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:07:11 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:07:11 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Controller Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:07:11 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:07:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:07:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:07:11 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\EntityRepository::findBy() must be of the type array, none given, called in C:\xampp\htdocs\myblog\application\models\Article_model.php on line 13 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php 153
ERROR - 2015-02-01 07:07:11 --> Severity: Notice --> Undefined variable: criteria C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php 157
ERROR - 2015-02-01 07:07:11 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\Persisters\BasicEntityPersister::loadAll() must be of the type array, null given, called in C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php on line 157 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 861
ERROR - 2015-02-01 07:07:11 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\Persisters\BasicEntityPersister::_getSelectConditionSQL() must be of the type array, null given, called in C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php on line 1039 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1552
ERROR - 2015-02-01 07:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1556
ERROR - 2015-02-01 07:07:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1645
ERROR - 2015-02-01 07:07:11 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:07:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myblog\system\core\Exceptions.php:272) C:\xampp\htdocs\myblog\system\core\Common.php 566
ERROR - 2015-02-01 07:07:11 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:07:14 --> Config Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:07:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:07:14 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:07:14 --> URI Class Initialized
DEBUG - 2015-02-01 07:07:14 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:07:14 --> Router Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Output Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Security Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Input Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:07:14 --> Language Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Loader Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:07:14 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:07:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:07:14 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:07:14 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:07:14 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Controller Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:07:14 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:07:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:07:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:07:14 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\EntityRepository::findBy() must be of the type array, none given, called in C:\xampp\htdocs\myblog\application\models\Article_model.php on line 13 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php 153
ERROR - 2015-02-01 07:07:14 --> Severity: Notice --> Undefined variable: criteria C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php 157
ERROR - 2015-02-01 07:07:14 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\Persisters\BasicEntityPersister::loadAll() must be of the type array, null given, called in C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\EntityRepository.php on line 157 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 861
ERROR - 2015-02-01 07:07:14 --> Severity: 4096 --> Argument 1 passed to Doctrine\ORM\Persisters\BasicEntityPersister::_getSelectConditionSQL() must be of the type array, null given, called in C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php on line 1039 and defined C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1552
ERROR - 2015-02-01 07:07:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1556
ERROR - 2015-02-01 07:07:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\Persisters\BasicEntityPersister.php 1645
ERROR - 2015-02-01 07:07:14 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:07:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myblog\system\core\Exceptions.php:272) C:\xampp\htdocs\myblog\system\core\Common.php 566
ERROR - 2015-02-01 07:07:14 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:07:22 --> Config Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:07:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:07:22 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:07:22 --> URI Class Initialized
DEBUG - 2015-02-01 07:07:22 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:07:22 --> Router Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Output Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Security Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Input Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:07:22 --> Language Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Loader Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:07:22 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:07:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:07:22 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Session: Regenerate ID
DEBUG - 2015-02-01 07:07:22 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:07:22 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Controller Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Model Class Initialized
DEBUG - 2015-02-01 07:07:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:07:22 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:07:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:07:23 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:07:23 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:09:18 --> Config Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:09:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:09:18 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:09:18 --> URI Class Initialized
DEBUG - 2015-02-01 07:09:18 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:09:18 --> Router Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Output Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Security Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Input Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:09:18 --> Language Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Loader Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:09:18 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:09:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:09:18 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:09:18 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Controller Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:09:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:09:18 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:09:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:09:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:09:19 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:09:19 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:09:48 --> Config Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:09:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:09:48 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:09:48 --> URI Class Initialized
DEBUG - 2015-02-01 07:09:48 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:09:48 --> Router Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Output Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Security Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Input Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:09:48 --> Language Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Loader Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:09:48 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:09:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:09:48 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:09:48 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:09:48 --> Model Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Model Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Controller Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Model Class Initialized
DEBUG - 2015-02-01 07:09:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:09:48 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:09:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:09:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:09:48 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:09:48 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:10:12 --> Config Class Initialized
DEBUG - 2015-02-01 07:10:12 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:10:12 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:10:13 --> URI Class Initialized
DEBUG - 2015-02-01 07:10:13 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:10:13 --> Router Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Output Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Security Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Input Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:10:13 --> Language Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Loader Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:10:13 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:10:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:10:13 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:10:13 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:10:13 --> Model Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Model Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Controller Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Model Class Initialized
DEBUG - 2015-02-01 07:10:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:10:13 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:10:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:10:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:10:13 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:10:13 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:13:27 --> Config Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:13:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:13:27 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:13:27 --> URI Class Initialized
DEBUG - 2015-02-01 07:13:27 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:13:27 --> Router Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Output Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Security Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Input Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:13:27 --> Language Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Loader Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:13:27 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:13:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:13:27 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Session: Regenerate ID
DEBUG - 2015-02-01 07:13:27 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:13:27 --> Model Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Model Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Controller Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Model Class Initialized
DEBUG - 2015-02-01 07:13:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:13:27 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:13:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:13:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:13:28 --> Severity: Notice --> Undefined property: Entity\Articles::$getFile C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
ERROR - 2015-02-01 07:13:28 --> Severity: Error --> Call to a member function getFilePath() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:14:05 --> Config Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:14:05 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:14:05 --> URI Class Initialized
DEBUG - 2015-02-01 07:14:05 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:14:05 --> Router Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Output Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Security Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Input Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:14:05 --> Language Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Loader Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:14:05 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:14:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:14:05 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:14:05 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:14:05 --> Model Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Model Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Controller Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Model Class Initialized
DEBUG - 2015-02-01 07:14:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:14:05 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:14:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:14:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:14:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:14:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:14:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:14:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:14:05 --> Final output sent to browser
DEBUG - 2015-02-01 07:14:05 --> Total execution time: 0.5130
DEBUG - 2015-02-01 07:14:13 --> Config Class Initialized
DEBUG - 2015-02-01 07:14:13 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:14:13 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:14:13 --> URI Class Initialized
DEBUG - 2015-02-01 07:14:13 --> Router Class Initialized
DEBUG - 2015-02-01 07:14:13 --> Output Class Initialized
DEBUG - 2015-02-01 07:14:13 --> Security Class Initialized
DEBUG - 2015-02-01 07:14:13 --> Input Class Initialized
DEBUG - 2015-02-01 07:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:14:13 --> Language Class Initialized
ERROR - 2015-02-01 07:14:13 --> 404 Page Not Found: 0/index
DEBUG - 2015-02-01 07:14:16 --> Config Class Initialized
DEBUG - 2015-02-01 07:14:16 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:14:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:14:16 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:14:16 --> URI Class Initialized
DEBUG - 2015-02-01 07:14:16 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:14:16 --> Router Class Initialized
DEBUG - 2015-02-01 07:14:16 --> Output Class Initialized
DEBUG - 2015-02-01 07:14:16 --> Security Class Initialized
DEBUG - 2015-02-01 07:14:16 --> Input Class Initialized
DEBUG - 2015-02-01 07:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:14:16 --> Language Class Initialized
DEBUG - 2015-02-01 07:14:16 --> Loader Class Initialized
DEBUG - 2015-02-01 07:14:16 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:14:16 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:14:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:14:16 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:14:16 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:14:17 --> Model Class Initialized
DEBUG - 2015-02-01 07:14:17 --> Model Class Initialized
DEBUG - 2015-02-01 07:14:17 --> Controller Class Initialized
DEBUG - 2015-02-01 07:14:17 --> Model Class Initialized
DEBUG - 2015-02-01 07:14:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:14:17 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:14:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:14:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:14:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:14:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:14:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:14:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:14:17 --> Final output sent to browser
DEBUG - 2015-02-01 07:14:17 --> Total execution time: 0.6830
DEBUG - 2015-02-01 07:14:22 --> Config Class Initialized
DEBUG - 2015-02-01 07:14:22 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:14:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:14:22 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:14:22 --> URI Class Initialized
DEBUG - 2015-02-01 07:14:22 --> Router Class Initialized
DEBUG - 2015-02-01 07:14:22 --> Output Class Initialized
DEBUG - 2015-02-01 07:14:22 --> Security Class Initialized
DEBUG - 2015-02-01 07:14:22 --> Input Class Initialized
DEBUG - 2015-02-01 07:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:14:22 --> Language Class Initialized
ERROR - 2015-02-01 07:14:22 --> 404 Page Not Found: 1/index
DEBUG - 2015-02-01 07:15:03 --> Config Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:15:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:15:03 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:15:03 --> URI Class Initialized
DEBUG - 2015-02-01 07:15:03 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:15:03 --> Router Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Output Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Security Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Input Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:15:03 --> Language Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Loader Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:15:03 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:15:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:15:03 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:15:03 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:15:03 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Controller Class Initialized
DEBUG - 2015-02-01 07:15:03 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:15:04 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:15:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:15:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:15:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:15:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:15:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:15:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:15:04 --> Final output sent to browser
DEBUG - 2015-02-01 07:15:04 --> Total execution time: 0.6770
DEBUG - 2015-02-01 07:15:10 --> Config Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:15:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:15:10 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:15:10 --> URI Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Router Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Output Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Security Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Input Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:15:10 --> Language Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Loader Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:15:10 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:15:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:15:10 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:15:10 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:15:10 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Controller Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:15:10 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:15:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:15:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:15:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:15:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:15:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:15:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:15:10 --> Final output sent to browser
DEBUG - 2015-02-01 07:15:10 --> Total execution time: 0.7170
DEBUG - 2015-02-01 07:15:13 --> Config Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:15:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:15:13 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:15:13 --> URI Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Router Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Output Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Security Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Input Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:15:13 --> Language Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Loader Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:15:13 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:15:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:15:13 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:15:13 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:15:13 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Controller Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:15:13 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:15:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:15:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:15:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:15:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:15:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:15:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:15:13 --> Final output sent to browser
DEBUG - 2015-02-01 07:15:13 --> Total execution time: 0.5550
DEBUG - 2015-02-01 07:15:17 --> Config Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:15:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:15:17 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:15:17 --> URI Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Router Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Output Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Security Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Input Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:15:17 --> Language Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Loader Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:15:17 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:15:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:15:17 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:15:17 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:15:17 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Controller Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:15:17 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:15:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:15:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:15:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:15:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:15:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:15:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:15:17 --> Final output sent to browser
DEBUG - 2015-02-01 07:15:17 --> Total execution time: 0.7230
DEBUG - 2015-02-01 07:15:57 --> Config Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:15:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:15:57 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:15:57 --> URI Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Router Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Output Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Security Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Input Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:15:57 --> Language Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Loader Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:15:57 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:15:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:15:57 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:15:57 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:15:57 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Controller Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Model Class Initialized
DEBUG - 2015-02-01 07:15:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:15:57 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:15:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:15:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:15:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:15:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:15:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:15:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:15:58 --> Final output sent to browser
DEBUG - 2015-02-01 07:15:58 --> Total execution time: 0.7080
DEBUG - 2015-02-01 07:16:21 --> Config Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:16:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:16:21 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:16:21 --> URI Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Router Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Output Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Security Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Input Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:16:21 --> Language Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Loader Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:16:21 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:16:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:16:21 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:16:21 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:16:21 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Controller Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:16:21 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:16:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:16:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:16:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:16:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:16:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:16:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:16:22 --> Final output sent to browser
DEBUG - 2015-02-01 07:16:22 --> Total execution time: 0.6710
DEBUG - 2015-02-01 07:16:26 --> Config Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:16:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:16:26 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:16:26 --> URI Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Router Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Output Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Security Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Input Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:16:26 --> Language Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Loader Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:16:26 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:16:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:16:26 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:16:26 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:16:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Controller Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:16:26 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:16:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:16:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:16:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:16:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:16:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:16:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:16:26 --> Final output sent to browser
DEBUG - 2015-02-01 07:16:26 --> Total execution time: 0.4950
DEBUG - 2015-02-01 07:16:29 --> Config Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:16:29 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:16:29 --> URI Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Router Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Output Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Security Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Input Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:16:29 --> Language Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Loader Class Initialized
DEBUG - 2015-02-01 07:16:29 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:16:29 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:16:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:16:29 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:16:29 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:16:30 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:30 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:30 --> Controller Class Initialized
DEBUG - 2015-02-01 07:16:30 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:16:30 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:16:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:16:30 --> Final output sent to browser
DEBUG - 2015-02-01 07:16:30 --> Total execution time: 0.6340
DEBUG - 2015-02-01 07:16:44 --> Config Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:16:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:16:44 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:16:44 --> URI Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Router Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Output Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Security Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Input Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:16:44 --> Language Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Loader Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:16:44 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:16:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:16:44 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:16:44 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:16:44 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Controller Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Model Class Initialized
DEBUG - 2015-02-01 07:16:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:16:44 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:16:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:16:44 --> Final output sent to browser
DEBUG - 2015-02-01 07:16:44 --> Total execution time: 0.6680
DEBUG - 2015-02-01 07:17:42 --> Config Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:17:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:17:42 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:17:42 --> URI Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Router Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Output Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Security Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Input Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:17:42 --> Language Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Loader Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:17:42 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:17:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:17:42 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:17:42 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:17:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Controller Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:17:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:17:42 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:17:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:17:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:17:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:17:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:17:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:17:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:17:43 --> Final output sent to browser
DEBUG - 2015-02-01 07:17:43 --> Total execution time: 0.7810
DEBUG - 2015-02-01 07:17:50 --> Config Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:17:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:17:50 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:17:50 --> URI Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Router Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Output Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Security Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Input Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:17:50 --> Language Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Loader Class Initialized
DEBUG - 2015-02-01 07:17:50 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:17:50 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:17:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:17:50 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:17:50 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:17:51 --> Model Class Initialized
DEBUG - 2015-02-01 07:17:51 --> Model Class Initialized
DEBUG - 2015-02-01 07:17:51 --> Controller Class Initialized
DEBUG - 2015-02-01 07:17:51 --> Model Class Initialized
DEBUG - 2015-02-01 07:17:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:17:51 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:17:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:17:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:17:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:17:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:17:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:17:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:17:51 --> Final output sent to browser
DEBUG - 2015-02-01 07:17:51 --> Total execution time: 0.7000
DEBUG - 2015-02-01 07:18:38 --> Config Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:18:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:18:38 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:18:38 --> URI Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Router Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Output Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Security Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Input Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:18:38 --> Language Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Loader Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:18:38 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:18:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:18:38 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:18:38 --> Session: Regenerate ID
DEBUG - 2015-02-01 07:18:38 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:18:39 --> Model Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Model Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Controller Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Model Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:18:39 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:18:39 --> Final output sent to browser
DEBUG - 2015-02-01 07:18:39 --> Total execution time: 0.6820
DEBUG - 2015-02-01 07:18:39 --> Config Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:18:39 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:18:39 --> URI Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Router Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Output Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Security Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Input Class Initialized
DEBUG - 2015-02-01 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:18:39 --> Language Class Initialized
ERROR - 2015-02-01 07:18:39 --> 404 Page Not Found: Resources/file
DEBUG - 2015-02-01 07:19:00 --> Config Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:19:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:19:00 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:19:00 --> URI Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Router Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Output Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Security Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Input Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:19:00 --> Language Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Loader Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:19:00 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:19:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:19:00 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:19:00 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:19:00 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Controller Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:19:00 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:19:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:19:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:19:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:19:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:19:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:19:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:19:01 --> Final output sent to browser
DEBUG - 2015-02-01 07:19:01 --> Total execution time: 0.7770
DEBUG - 2015-02-01 07:19:01 --> Config Class Initialized
DEBUG - 2015-02-01 07:19:01 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:19:01 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:19:01 --> URI Class Initialized
DEBUG - 2015-02-01 07:19:01 --> Router Class Initialized
DEBUG - 2015-02-01 07:19:01 --> Output Class Initialized
DEBUG - 2015-02-01 07:19:01 --> Security Class Initialized
DEBUG - 2015-02-01 07:19:01 --> Input Class Initialized
DEBUG - 2015-02-01 07:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:19:01 --> Language Class Initialized
ERROR - 2015-02-01 07:19:01 --> 404 Page Not Found: Resources/file
DEBUG - 2015-02-01 07:19:11 --> Config Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:19:11 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:19:11 --> URI Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Router Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Output Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Security Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Input Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:19:11 --> Language Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Loader Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:19:11 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:19:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:19:11 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:19:11 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:19:11 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:11 --> Controller Class Initialized
DEBUG - 2015-02-01 07:19:12 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:19:12 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:19:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:19:12 --> Final output sent to browser
DEBUG - 2015-02-01 07:19:12 --> Total execution time: 0.7320
DEBUG - 2015-02-01 07:19:33 --> Config Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:19:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:19:33 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:19:33 --> URI Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Router Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Output Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Security Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Input Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:19:33 --> Language Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Loader Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:19:33 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:19:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:19:33 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:19:33 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:19:33 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Controller Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Model Class Initialized
DEBUG - 2015-02-01 07:19:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:19:33 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:19:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:19:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:19:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:19:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:19:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:19:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:19:33 --> Final output sent to browser
DEBUG - 2015-02-01 07:19:33 --> Total execution time: 0.7650
DEBUG - 2015-02-01 07:20:42 --> Config Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:20:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:20:42 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:20:42 --> URI Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Router Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Output Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Security Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Input Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:20:42 --> Language Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Loader Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:20:42 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:20:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:20:42 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:20:42 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:20:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Controller Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:20:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:20:42 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:20:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:20:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:20:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:20:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:20:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:20:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:20:42 --> Final output sent to browser
DEBUG - 2015-02-01 07:20:42 --> Total execution time: 0.6840
DEBUG - 2015-02-01 07:21:23 --> Config Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:21:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:21:23 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:21:23 --> URI Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Router Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Output Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Security Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Input Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:21:23 --> Language Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Loader Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:21:23 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:21:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:21:23 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:21:23 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:21:23 --> Model Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Model Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Controller Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Model Class Initialized
DEBUG - 2015-02-01 07:21:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:21:23 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:21:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:21:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:21:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:21:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:21:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:21:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:21:23 --> Final output sent to browser
DEBUG - 2015-02-01 07:21:23 --> Total execution time: 0.7160
DEBUG - 2015-02-01 07:21:26 --> Config Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:21:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:21:26 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:21:26 --> URI Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Router Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Output Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Security Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Input Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:21:26 --> Language Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Loader Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:21:26 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:21:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:21:26 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:21:26 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:21:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Controller Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:21:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:21:26 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:21:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:21:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:21:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:21:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:21:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:21:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:21:27 --> Final output sent to browser
DEBUG - 2015-02-01 07:21:27 --> Total execution time: 0.6710
DEBUG - 2015-02-01 07:24:49 --> Config Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:24:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:24:49 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:24:49 --> URI Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Router Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Output Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Security Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Input Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:24:49 --> Language Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Loader Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:24:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:24:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:24:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Session: Regenerate ID
DEBUG - 2015-02-01 07:24:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:24:49 --> Model Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Model Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Controller Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Model Class Initialized
DEBUG - 2015-02-01 07:24:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:24:49 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:24:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:24:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:24:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:24:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:24:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:24:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:24:50 --> Final output sent to browser
DEBUG - 2015-02-01 07:24:50 --> Total execution time: 0.7300
DEBUG - 2015-02-01 07:25:03 --> Config Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:25:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:25:03 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:25:03 --> URI Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Router Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Output Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Security Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Input Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:25:03 --> Language Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Loader Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:25:03 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:25:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:25:03 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:25:03 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:25:03 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:03 --> Controller Class Initialized
DEBUG - 2015-02-01 07:25:04 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:25:04 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:25:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:25:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:25:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:25:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:25:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:25:04 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:25:04 --> Final output sent to browser
DEBUG - 2015-02-01 07:25:04 --> Total execution time: 0.6900
DEBUG - 2015-02-01 07:25:09 --> Config Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:25:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:25:09 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:25:09 --> URI Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Router Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Output Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Security Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Input Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:25:09 --> Language Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Loader Class Initialized
DEBUG - 2015-02-01 07:25:09 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:25:09 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:25:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:25:09 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:25:10 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:25:10 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:10 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:10 --> Controller Class Initialized
DEBUG - 2015-02-01 07:25:10 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:25:10 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:25:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:25:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:25:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:25:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:25:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:25:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:25:10 --> Final output sent to browser
DEBUG - 2015-02-01 07:25:10 --> Total execution time: 0.6360
DEBUG - 2015-02-01 07:25:18 --> Config Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:25:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:25:18 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:25:18 --> URI Class Initialized
DEBUG - 2015-02-01 07:25:18 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:25:18 --> Router Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Output Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Security Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Input Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:25:18 --> Language Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Loader Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:25:18 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:25:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:25:18 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:25:18 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:25:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Controller Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:25:18 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:25:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:25:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:25:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:25:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:25:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:25:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:25:18 --> Final output sent to browser
DEBUG - 2015-02-01 07:25:18 --> Total execution time: 0.5490
DEBUG - 2015-02-01 07:25:23 --> Config Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:25:23 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:25:23 --> URI Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Router Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Output Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Security Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Input Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:25:23 --> Language Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Loader Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:25:23 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:25:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:25:23 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:25:23 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:25:23 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Controller Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Model Class Initialized
DEBUG - 2015-02-01 07:25:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:25:23 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:25:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:25:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:25:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:25:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:25:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:25:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:25:23 --> Final output sent to browser
DEBUG - 2015-02-01 07:25:23 --> Total execution time: 0.5610
DEBUG - 2015-02-01 07:26:07 --> Config Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:26:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:26:07 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:26:07 --> URI Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Router Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Output Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Security Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Input Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:26:07 --> Language Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Loader Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:26:07 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:26:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:26:07 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:26:07 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:26:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Controller Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:26:07 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:26:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:26:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:26:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:26:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:26:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:26:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:26:08 --> Final output sent to browser
DEBUG - 2015-02-01 07:26:08 --> Total execution time: 0.6580
DEBUG - 2015-02-01 07:26:25 --> Config Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:26:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:26:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:26:25 --> URI Class Initialized
DEBUG - 2015-02-01 07:26:25 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:26:25 --> Router Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Output Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Security Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Input Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:26:25 --> Language Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Loader Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:26:25 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:26:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:26:25 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:26:25 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:26:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Controller Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:26:25 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:26:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:26:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:26:25 --> Severity: error --> Exception: LIMIT argument offset=-2 is not valid C:\xampp\htdocs\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\Platforms\AbstractPlatform.php 2668
DEBUG - 2015-02-01 07:26:33 --> Config Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:26:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:26:33 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:26:33 --> URI Class Initialized
DEBUG - 2015-02-01 07:26:33 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:26:33 --> Router Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Output Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Security Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Input Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:26:33 --> Language Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Loader Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:26:33 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:26:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:26:33 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:26:33 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:26:33 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Controller Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Model Class Initialized
DEBUG - 2015-02-01 07:26:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:26:33 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:26:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:26:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:26:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:26:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:26:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:26:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:26:33 --> Final output sent to browser
DEBUG - 2015-02-01 07:26:33 --> Total execution time: 0.4830
DEBUG - 2015-02-01 07:27:14 --> Config Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:27:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:27:14 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:27:14 --> URI Class Initialized
DEBUG - 2015-02-01 07:27:14 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:27:14 --> Router Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Output Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Security Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Input Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:27:14 --> Language Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Loader Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:27:14 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:27:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:27:14 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:27:14 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:27:14 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Controller Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:27:14 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:27:14 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:27:14 --> Final output sent to browser
DEBUG - 2015-02-01 07:27:14 --> Total execution time: 0.8430
DEBUG - 2015-02-01 07:27:19 --> Config Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:27:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:27:19 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:27:19 --> URI Class Initialized
DEBUG - 2015-02-01 07:27:19 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:27:19 --> Router Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Output Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Security Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Input Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:27:19 --> Language Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Loader Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:27:19 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:27:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:27:19 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:27:19 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:27:19 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Controller Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:27:19 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:27:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:27:19 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:27:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:27:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:27:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:27:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:27:20 --> Final output sent to browser
DEBUG - 2015-02-01 07:27:20 --> Total execution time: 0.5280
DEBUG - 2015-02-01 07:27:25 --> Config Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:27:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:27:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:27:25 --> URI Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Router Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Output Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Security Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Input Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:27:25 --> Language Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Loader Class Initialized
DEBUG - 2015-02-01 07:27:25 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:27:25 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:27:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:27:25 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:27:25 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:26 --> Controller Class Initialized
DEBUG - 2015-02-01 07:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:27:26 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:27:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:27:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:27:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:27:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:27:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:27:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:27:26 --> Final output sent to browser
DEBUG - 2015-02-01 07:27:26 --> Total execution time: 0.6160
DEBUG - 2015-02-01 07:27:32 --> Config Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:27:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:27:32 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:27:32 --> URI Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Router Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Output Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Security Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Input Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:27:32 --> Language Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Loader Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:27:32 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:27:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:27:32 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:27:32 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:27:32 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:32 --> Controller Class Initialized
DEBUG - 2015-02-01 07:27:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\login.php
DEBUG - 2015-02-01 07:27:32 --> Final output sent to browser
DEBUG - 2015-02-01 07:27:32 --> Total execution time: 0.3120
DEBUG - 2015-02-01 07:27:35 --> Config Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:27:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:27:35 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:27:35 --> URI Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Router Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Output Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Security Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Input Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:27:35 --> Language Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Loader Class Initialized
DEBUG - 2015-02-01 07:27:35 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:27:35 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:27:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:27:35 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:27:35 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:27:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Controller Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Config Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:27:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:27:36 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:27:36 --> URI Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Router Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Output Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Security Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Input Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:27:36 --> Language Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Loader Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:27:36 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:27:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:27:36 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:27:36 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:27:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Controller Class Initialized
DEBUG - 2015-02-01 07:27:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:27:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:27:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-01 07:27:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:27:38 --> Final output sent to browser
DEBUG - 2015-02-01 07:27:38 --> Total execution time: 1.8361
DEBUG - 2015-02-01 07:27:41 --> Config Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:27:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:27:41 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:27:41 --> URI Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Router Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Output Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Security Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Input Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:27:41 --> Language Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Loader Class Initialized
DEBUG - 2015-02-01 07:27:41 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:27:41 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:27:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:27:41 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:27:41 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:27:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:42 --> Controller Class Initialized
DEBUG - 2015-02-01 07:27:42 --> Model Class Initialized
DEBUG - 2015-02-01 07:27:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:27:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:27:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 07:27:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:27:42 --> Final output sent to browser
DEBUG - 2015-02-01 07:27:42 --> Total execution time: 0.5190
DEBUG - 2015-02-01 07:28:49 --> Config Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:28:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:28:49 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:28:49 --> URI Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Router Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Output Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Security Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Input Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:28:49 --> Language Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Loader Class Initialized
DEBUG - 2015-02-01 07:28:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:28:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:28:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:28:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:28:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:28:50 --> Model Class Initialized
DEBUG - 2015-02-01 07:28:50 --> Model Class Initialized
DEBUG - 2015-02-01 07:28:50 --> Controller Class Initialized
DEBUG - 2015-02-01 07:28:50 --> Model Class Initialized
DEBUG - 2015-02-01 07:28:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:28:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:28:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 07:28:50 --> Upload Class Initialized
ERROR - 2015-02-01 07:28:51 --> Severity: Error --> Call to undefined method Entity\Articles::setFileId() C:\xampp\htdocs\myblog\application\models\Article_model.php 75
DEBUG - 2015-02-01 07:29:25 --> Config Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:29:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:29:25 --> URI Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Router Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Output Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Security Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Input Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:29:25 --> Language Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Loader Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:29:25 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:29:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:29:25 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:29:25 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:29:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Controller Class Initialized
DEBUG - 2015-02-01 07:29:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:29:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:29:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 07:29:25 --> Upload Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Config Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:29:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:29:27 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:29:27 --> URI Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Router Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Output Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Security Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Input Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:29:27 --> Language Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Loader Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:29:27 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:29:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:29:27 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:29:27 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:29:27 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Controller Class Initialized
DEBUG - 2015-02-01 07:29:27 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:29:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:29:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 07:29:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:29:28 --> Final output sent to browser
DEBUG - 2015-02-01 07:29:28 --> Total execution time: 0.6560
DEBUG - 2015-02-01 07:29:34 --> Config Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:29:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:29:34 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:29:34 --> URI Class Initialized
DEBUG - 2015-02-01 07:29:34 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:29:34 --> Router Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Output Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Security Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Input Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:29:34 --> Language Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Loader Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:29:34 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:29:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:29:34 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:29:34 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:29:34 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Controller Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:29:34 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:29:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:29:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:29:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:29:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:29:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:29:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:29:34 --> Final output sent to browser
DEBUG - 2015-02-01 07:29:34 --> Total execution time: 0.9281
DEBUG - 2015-02-01 07:29:38 --> Config Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:29:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:29:38 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:29:38 --> URI Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Router Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Output Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Security Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Input Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:29:38 --> Language Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Loader Class Initialized
DEBUG - 2015-02-01 07:29:38 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:29:38 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:29:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:29:38 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:29:38 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:29:39 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:39 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:39 --> Controller Class Initialized
DEBUG - 2015-02-01 07:29:39 --> Model Class Initialized
DEBUG - 2015-02-01 07:29:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:29:39 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:29:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:29:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:29:39 --> Severity: Error --> Call to a member function getFileName() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:29:39 --> Config Class Initialized
DEBUG - 2015-02-01 07:29:39 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:29:39 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:01 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:01 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:01 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:01 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:01 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:01 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:01 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:01 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:01 --> Language Class Initialized
ERROR - 2015-02-01 07:33:01 --> 404 Page Not Found: Welcome/login
DEBUG - 2015-02-01 07:33:04 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:04 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:04 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:04 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:04 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:04 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:04 --> Session: Regenerate ID
DEBUG - 2015-02-01 07:33:04 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:04 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:05 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:05 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\login.php
DEBUG - 2015-02-01 07:33:05 --> Final output sent to browser
DEBUG - 2015-02-01 07:33:05 --> Total execution time: 0.3300
DEBUG - 2015-02-01 07:33:07 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:07 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:07 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:07 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:07 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:07 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:07 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:07 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:07 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:07 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:07 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:07 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:07 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:07 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:33:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:33:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-01 07:33:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:33:07 --> Final output sent to browser
DEBUG - 2015-02-01 07:33:07 --> Total execution time: 0.3960
DEBUG - 2015-02-01 07:33:11 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:11 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:11 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:11 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:11 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:11 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:11 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:11 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:11 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:12 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:12 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:12 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:12 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:12 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:12 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:12 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:12 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:12 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:33:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:33:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 07:33:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:33:12 --> Final output sent to browser
DEBUG - 2015-02-01 07:33:12 --> Total execution time: 0.6200
DEBUG - 2015-02-01 07:33:18 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:18 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:18 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:18 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:18 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:18 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:18 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:18 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:33:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-02-01 07:33:18 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\myblog\application\views\admin\article\edit.php 6
ERROR - 2015-02-01 07:33:18 --> Severity: Error --> Call to a member function getName() on null C:\xampp\htdocs\myblog\application\views\admin\article\edit.php 6
DEBUG - 2015-02-01 07:33:24 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:24 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:24 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:24 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:24 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:24 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:24 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:24 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:24 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:24 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:24 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:25 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:25 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:25 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:25 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:25 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:25 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:25 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:33:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:33:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 07:33:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:33:25 --> Final output sent to browser
DEBUG - 2015-02-01 07:33:25 --> Total execution time: 0.6210
DEBUG - 2015-02-01 07:33:30 --> Config Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:33:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:33:30 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:33:30 --> URI Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Router Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Output Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Security Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Input Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:33:30 --> Language Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Loader Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:33:30 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:33:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:33:30 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:33:30 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:33:30 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Controller Class Initialized
DEBUG - 2015-02-01 07:33:30 --> Model Class Initialized
DEBUG - 2015-02-01 07:33:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:33:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:33:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 07:33:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:33:30 --> Final output sent to browser
DEBUG - 2015-02-01 07:33:30 --> Total execution time: 0.4090
DEBUG - 2015-02-01 07:35:34 --> Config Class Initialized
DEBUG - 2015-02-01 07:35:34 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:35:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:35:34 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:35:34 --> URI Class Initialized
DEBUG - 2015-02-01 07:35:34 --> Router Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Output Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Security Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Input Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:35:35 --> Language Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Loader Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:35:35 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:35:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:35:35 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:35:35 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:35:35 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Controller Class Initialized
DEBUG - 2015-02-01 07:35:35 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:35:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:35:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 07:35:35 --> Upload Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Config Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:35:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:35:36 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:35:36 --> URI Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Router Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Output Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Security Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Input Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:35:36 --> Language Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Loader Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:35:36 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:35:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:35:36 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:35:36 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:35:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Controller Class Initialized
DEBUG - 2015-02-01 07:35:36 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:35:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:35:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 07:35:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:35:36 --> Final output sent to browser
DEBUG - 2015-02-01 07:35:36 --> Total execution time: 0.7160
DEBUG - 2015-02-01 07:35:42 --> Config Class Initialized
DEBUG - 2015-02-01 07:35:42 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:35:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:35:42 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:35:42 --> URI Class Initialized
DEBUG - 2015-02-01 07:35:42 --> No URI present. Default controller set.
DEBUG - 2015-02-01 07:35:42 --> Router Class Initialized
DEBUG - 2015-02-01 07:35:42 --> Output Class Initialized
DEBUG - 2015-02-01 07:35:42 --> Security Class Initialized
DEBUG - 2015-02-01 07:35:42 --> Input Class Initialized
DEBUG - 2015-02-01 07:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:35:42 --> Language Class Initialized
DEBUG - 2015-02-01 07:35:42 --> Loader Class Initialized
DEBUG - 2015-02-01 07:35:42 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:35:42 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:35:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:35:42 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:35:42 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:35:43 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:43 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:43 --> Controller Class Initialized
DEBUG - 2015-02-01 07:35:43 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:35:43 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:35:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:35:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 07:35:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 07:35:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 07:35:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 07:35:43 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 07:35:43 --> Final output sent to browser
DEBUG - 2015-02-01 07:35:43 --> Total execution time: 0.4640
DEBUG - 2015-02-01 07:35:45 --> Config Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:35:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:35:45 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:35:45 --> URI Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Router Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Output Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Security Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Input Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:35:45 --> Language Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Loader Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:35:45 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:35:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:35:45 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:35:45 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:35:45 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Controller Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Model Class Initialized
DEBUG - 2015-02-01 07:35:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 07:35:45 --> Pagination Class Initialized
DEBUG - 2015-02-01 07:35:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 07:35:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 07:35:46 --> Severity: Error --> Call to a member function getFileName() on null C:\xampp\htdocs\myblog\application\views\welcome_message.php 14
DEBUG - 2015-02-01 07:35:46 --> Config Class Initialized
DEBUG - 2015-02-01 07:35:46 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:35:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:35:46 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:50:37 --> Config Class Initialized
DEBUG - 2015-02-01 07:50:37 --> Hooks Class Initialized
DEBUG - 2015-02-01 07:50:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 07:50:37 --> Utf8 Class Initialized
DEBUG - 2015-02-01 07:50:38 --> URI Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Router Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Output Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Security Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Input Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 07:50:38 --> Language Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Loader Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Helper loaded: url_helper
DEBUG - 2015-02-01 07:50:38 --> Helper loaded: link_helper
DEBUG - 2015-02-01 07:50:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 07:50:38 --> CI_Session Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Session: Regenerate ID
DEBUG - 2015-02-01 07:50:38 --> CI_Session routines successfully run
DEBUG - 2015-02-01 07:50:38 --> Model Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Model Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Controller Class Initialized
DEBUG - 2015-02-01 07:50:38 --> Model Class Initialized
DEBUG - 2015-02-01 07:50:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 07:50:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 07:50:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 07:50:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 07:50:39 --> Final output sent to browser
DEBUG - 2015-02-01 07:50:39 --> Total execution time: 2.3651
DEBUG - 2015-02-01 13:46:53 --> Config Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:46:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:46:53 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:46:53 --> URI Class Initialized
DEBUG - 2015-02-01 13:46:53 --> No URI present. Default controller set.
DEBUG - 2015-02-01 13:46:53 --> Router Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Output Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Security Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Input Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:46:53 --> Language Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Loader Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:46:53 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:46:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:46:53 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:46:53 --> A session cookie was not found.
DEBUG - 2015-02-01 13:46:53 --> Session: Creating new session (5c5996ef0ffc26efbe300f48c5cb1d4b)
DEBUG - 2015-02-01 13:46:53 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:46:53 --> Model Class Initialized
DEBUG - 2015-02-01 13:46:53 --> Model Class Initialized
DEBUG - 2015-02-01 13:46:54 --> Controller Class Initialized
DEBUG - 2015-02-01 13:46:54 --> Model Class Initialized
DEBUG - 2015-02-01 13:46:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 13:46:54 --> Pagination Class Initialized
DEBUG - 2015-02-01 13:46:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 13:46:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 13:46:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 13:46:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 13:46:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 13:46:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 13:46:58 --> Final output sent to browser
DEBUG - 2015-02-01 13:46:58 --> Total execution time: 5.0403
DEBUG - 2015-02-01 13:47:16 --> Config Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:47:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:47:16 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:47:16 --> URI Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Router Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Output Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Security Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Input Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:47:16 --> Language Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Loader Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:47:16 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:47:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:47:16 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:47:16 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:47:16 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:16 --> Controller Class Initialized
DEBUG - 2015-02-01 13:47:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\login.php
DEBUG - 2015-02-01 13:47:16 --> Final output sent to browser
DEBUG - 2015-02-01 13:47:16 --> Total execution time: 0.4920
DEBUG - 2015-02-01 13:47:22 --> Config Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:47:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:47:22 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:47:22 --> URI Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Router Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Output Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Security Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Input Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:47:22 --> Language Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Loader Class Initialized
DEBUG - 2015-02-01 13:47:22 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:47:22 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:47:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:47:22 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:47:22 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:47:23 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Controller Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Config Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:47:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:47:23 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:47:23 --> URI Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Router Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Output Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Security Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Input Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:47:23 --> Language Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Loader Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:47:23 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:47:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:47:23 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:47:23 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:47:23 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Controller Class Initialized
DEBUG - 2015-02-01 13:47:23 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:47:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:47:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-01 13:47:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 13:47:23 --> Final output sent to browser
DEBUG - 2015-02-01 13:47:23 --> Total execution time: 0.6030
DEBUG - 2015-02-01 13:47:43 --> Config Class Initialized
DEBUG - 2015-02-01 13:47:43 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:47:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:47:43 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:47:43 --> URI Class Initialized
DEBUG - 2015-02-01 13:47:43 --> Router Class Initialized
DEBUG - 2015-02-01 13:47:43 --> Output Class Initialized
DEBUG - 2015-02-01 13:47:43 --> Security Class Initialized
DEBUG - 2015-02-01 13:47:43 --> Input Class Initialized
DEBUG - 2015-02-01 13:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:47:43 --> Language Class Initialized
DEBUG - 2015-02-01 13:47:44 --> Loader Class Initialized
DEBUG - 2015-02-01 13:47:44 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:47:44 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:47:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:47:44 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:47:44 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:47:44 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:44 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:44 --> Controller Class Initialized
DEBUG - 2015-02-01 13:47:44 --> Model Class Initialized
DEBUG - 2015-02-01 13:47:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:47:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:47:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 13:47:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 13:47:44 --> Final output sent to browser
DEBUG - 2015-02-01 13:47:44 --> Total execution time: 0.5210
DEBUG - 2015-02-01 13:50:01 --> Config Class Initialized
DEBUG - 2015-02-01 13:50:01 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:50:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:50:02 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:50:02 --> URI Class Initialized
DEBUG - 2015-02-01 13:50:02 --> Router Class Initialized
DEBUG - 2015-02-01 13:50:02 --> Output Class Initialized
DEBUG - 2015-02-01 13:50:02 --> Security Class Initialized
DEBUG - 2015-02-01 13:50:02 --> Input Class Initialized
DEBUG - 2015-02-01 13:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:50:02 --> Language Class Initialized
DEBUG - 2015-02-01 13:50:02 --> Loader Class Initialized
DEBUG - 2015-02-01 13:50:02 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:50:02 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:50:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:50:02 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:50:02 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:50:03 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:03 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:03 --> Controller Class Initialized
DEBUG - 2015-02-01 13:50:03 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:50:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:50:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 13:50:03 --> Upload Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Config Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:50:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:50:39 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:50:39 --> URI Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Router Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Output Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Security Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Input Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:50:39 --> Language Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Loader Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:50:39 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:50:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:50:39 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:50:39 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:50:39 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Controller Class Initialized
DEBUG - 2015-02-01 13:50:39 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:50:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:50:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 13:50:39 --> Upload Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Config Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:50:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:50:40 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:50:40 --> URI Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Router Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Output Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Security Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Input Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:50:40 --> Language Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Loader Class Initialized
DEBUG - 2015-02-01 13:50:40 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:50:40 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:50:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:50:40 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:50:40 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:50:41 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:41 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:41 --> Controller Class Initialized
DEBUG - 2015-02-01 13:50:41 --> Model Class Initialized
DEBUG - 2015-02-01 13:50:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:50:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:50:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 13:50:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 13:50:41 --> Final output sent to browser
DEBUG - 2015-02-01 13:50:41 --> Total execution time: 0.8350
DEBUG - 2015-02-01 13:52:39 --> Config Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:52:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:52:39 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:52:39 --> URI Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Router Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Output Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Security Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Input Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:52:39 --> Language Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Loader Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:52:39 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:52:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:52:39 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Session: Regenerate ID
DEBUG - 2015-02-01 13:52:39 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:52:39 --> Model Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Model Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Controller Class Initialized
DEBUG - 2015-02-01 13:52:39 --> Model Class Initialized
DEBUG - 2015-02-01 13:52:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:52:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:52:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 13:52:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 13:52:40 --> Final output sent to browser
DEBUG - 2015-02-01 13:52:40 --> Total execution time: 0.4070
DEBUG - 2015-02-01 13:54:05 --> Config Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:54:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:54:05 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:54:05 --> URI Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Router Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Output Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Security Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Input Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:54:05 --> Language Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Loader Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:54:05 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:54:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:54:05 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:54:05 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:54:05 --> Model Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Model Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Controller Class Initialized
DEBUG - 2015-02-01 13:54:05 --> Model Class Initialized
DEBUG - 2015-02-01 13:54:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:54:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:54:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 13:54:05 --> Upload Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-02-01 13:54:06 --> You did not select a file to upload.
ERROR - 2015-02-01 13:54:06 --> Severity: Notice --> Undefined variable: image C:\xampp\htdocs\myblog\application\models\Article_model.php 74
DEBUG - 2015-02-01 13:54:06 --> Config Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:54:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:54:06 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:54:06 --> URI Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Router Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Output Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Security Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Input Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:54:06 --> Language Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Loader Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:54:06 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:54:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:54:06 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:54:06 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:54:06 --> Model Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Model Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Controller Class Initialized
DEBUG - 2015-02-01 13:54:06 --> Model Class Initialized
DEBUG - 2015-02-01 13:54:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 13:54:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 13:54:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 13:54:07 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 13:54:07 --> Final output sent to browser
DEBUG - 2015-02-01 13:54:07 --> Total execution time: 0.6650
DEBUG - 2015-02-01 13:56:49 --> Config Class Initialized
DEBUG - 2015-02-01 13:56:49 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:56:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:56:49 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:56:49 --> URI Class Initialized
DEBUG - 2015-02-01 13:56:49 --> No URI present. Default controller set.
DEBUG - 2015-02-01 13:56:49 --> Router Class Initialized
DEBUG - 2015-02-01 13:56:49 --> Output Class Initialized
DEBUG - 2015-02-01 13:56:49 --> Security Class Initialized
DEBUG - 2015-02-01 13:56:49 --> Input Class Initialized
DEBUG - 2015-02-01 13:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:56:49 --> Language Class Initialized
DEBUG - 2015-02-01 13:56:49 --> Loader Class Initialized
DEBUG - 2015-02-01 13:56:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:56:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:56:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:56:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:56:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:56:50 --> Model Class Initialized
DEBUG - 2015-02-01 13:56:50 --> Model Class Initialized
DEBUG - 2015-02-01 13:56:50 --> Controller Class Initialized
DEBUG - 2015-02-01 13:56:50 --> Model Class Initialized
DEBUG - 2015-02-01 13:56:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 13:56:50 --> Pagination Class Initialized
DEBUG - 2015-02-01 13:56:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 13:56:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 13:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 13:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 13:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 13:56:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 13:56:51 --> Final output sent to browser
DEBUG - 2015-02-01 13:56:51 --> Total execution time: 1.5631
DEBUG - 2015-02-01 13:56:57 --> Config Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:56:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:56:57 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:56:57 --> URI Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Router Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Output Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Security Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Input Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:56:57 --> Language Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Loader Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:56:57 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:56:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:56:57 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:56:57 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:56:57 --> Model Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Model Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Controller Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Model Class Initialized
DEBUG - 2015-02-01 13:56:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 13:56:57 --> Pagination Class Initialized
DEBUG - 2015-02-01 13:56:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 13:56:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
ERROR - 2015-02-01 13:56:57 --> Severity: Warning --> Missing argument 1 for getUpload(), called in C:\xampp\htdocs\myblog\application\views\welcome_message.php on line 14 and defined C:\xampp\htdocs\myblog\application\helpers\link_helper.php 15
ERROR - 2015-02-01 13:56:58 --> Severity: Notice --> Undefined variable: fileName C:\xampp\htdocs\myblog\application\helpers\link_helper.php 16
DEBUG - 2015-02-01 13:56:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 13:56:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 13:56:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 13:56:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 13:56:58 --> Final output sent to browser
DEBUG - 2015-02-01 13:56:58 --> Total execution time: 0.7490
DEBUG - 2015-02-01 13:56:58 --> Config Class Initialized
DEBUG - 2015-02-01 13:56:58 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:56:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:56:58 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Config Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:57:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:57:21 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:57:21 --> URI Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Router Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Output Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Security Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Input Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:57:21 --> Language Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Loader Class Initialized
DEBUG - 2015-02-01 13:57:21 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:57:21 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:57:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:57:21 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:57:21 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:57:22 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:22 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:22 --> Controller Class Initialized
DEBUG - 2015-02-01 13:57:22 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 13:57:22 --> Pagination Class Initialized
DEBUG - 2015-02-01 13:57:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 13:57:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 13:57:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 13:57:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 13:57:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 13:57:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 13:57:22 --> Final output sent to browser
DEBUG - 2015-02-01 13:57:22 --> Total execution time: 0.6860
DEBUG - 2015-02-01 13:57:27 --> Config Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:57:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:57:27 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:57:27 --> URI Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Router Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Output Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Security Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Input Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:57:27 --> Language Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Loader Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:57:27 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:57:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:57:27 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:57:27 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:57:27 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Controller Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 13:57:27 --> Pagination Class Initialized
DEBUG - 2015-02-01 13:57:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 13:57:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 13:57:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 13:57:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 13:57:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 13:57:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 13:57:28 --> Final output sent to browser
DEBUG - 2015-02-01 13:57:28 --> Total execution time: 0.6680
DEBUG - 2015-02-01 13:57:46 --> Config Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:57:46 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:57:46 --> URI Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Router Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Output Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Security Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Input Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:57:46 --> Language Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Loader Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:57:46 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:57:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:57:46 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Session: Regenerate ID
DEBUG - 2015-02-01 13:57:46 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:57:46 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Controller Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Model Class Initialized
DEBUG - 2015-02-01 13:57:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 13:57:46 --> Pagination Class Initialized
DEBUG - 2015-02-01 13:57:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 13:57:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 13:57:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 13:57:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 13:57:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 13:57:46 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 13:57:46 --> Final output sent to browser
DEBUG - 2015-02-01 13:57:46 --> Total execution time: 0.5630
DEBUG - 2015-02-01 13:58:11 --> Config Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Hooks Class Initialized
DEBUG - 2015-02-01 13:58:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 13:58:11 --> Utf8 Class Initialized
DEBUG - 2015-02-01 13:58:11 --> URI Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Router Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Output Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Security Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Input Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 13:58:11 --> Language Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Loader Class Initialized
DEBUG - 2015-02-01 13:58:11 --> Helper loaded: url_helper
DEBUG - 2015-02-01 13:58:11 --> Helper loaded: link_helper
DEBUG - 2015-02-01 13:58:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 13:58:11 --> CI_Session Class Initialized
DEBUG - 2015-02-01 13:58:11 --> CI_Session routines successfully run
DEBUG - 2015-02-01 13:58:12 --> Model Class Initialized
DEBUG - 2015-02-01 13:58:12 --> Model Class Initialized
DEBUG - 2015-02-01 13:58:12 --> Controller Class Initialized
DEBUG - 2015-02-01 13:58:12 --> Model Class Initialized
DEBUG - 2015-02-01 13:58:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 13:58:12 --> Pagination Class Initialized
DEBUG - 2015-02-01 13:58:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 13:58:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 13:58:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 13:58:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 13:58:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 13:58:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 13:58:12 --> Final output sent to browser
DEBUG - 2015-02-01 13:58:12 --> Total execution time: 0.6820
DEBUG - 2015-02-01 14:00:49 --> Config Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:00:49 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:00:49 --> URI Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Router Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Output Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Security Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Input Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:00:49 --> Language Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Loader Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:00:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:00:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:00:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:00:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:00:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Controller Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:00:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 14:00:49 --> Pagination Class Initialized
DEBUG - 2015-02-01 14:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 14:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 14:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 14:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 14:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 14:00:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 14:00:49 --> Final output sent to browser
DEBUG - 2015-02-01 14:00:49 --> Total execution time: 0.6360
DEBUG - 2015-02-01 14:01:11 --> Config Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:01:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:01:11 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:01:11 --> URI Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Router Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Output Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Security Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Input Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:01:11 --> Language Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Loader Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:01:11 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:01:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:01:11 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:01:11 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:01:11 --> Model Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Model Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Controller Class Initialized
DEBUG - 2015-02-01 14:01:11 --> Model Class Initialized
DEBUG - 2015-02-01 14:01:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 14:01:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 14:01:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 14:01:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 14:01:11 --> Final output sent to browser
DEBUG - 2015-02-01 14:01:11 --> Total execution time: 0.4390
DEBUG - 2015-02-01 14:03:49 --> Config Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:03:49 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:03:49 --> URI Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Router Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Output Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Security Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Input Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:03:49 --> Language Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Loader Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:03:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:03:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:03:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:03:49 --> Session: Regenerate ID
DEBUG - 2015-02-01 14:03:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:03:50 --> Model Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Model Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Controller Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Model Class Initialized
DEBUG - 2015-02-01 14:03:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 14:03:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 14:03:50 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-01 14:03:50 --> Upload Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Config Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:03:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:03:50 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:03:50 --> URI Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Router Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Output Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Security Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Input Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:03:50 --> Language Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Loader Class Initialized
DEBUG - 2015-02-01 14:03:50 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:03:50 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:03:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:03:50 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:03:50 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:03:51 --> Model Class Initialized
DEBUG - 2015-02-01 14:03:51 --> Model Class Initialized
DEBUG - 2015-02-01 14:03:51 --> Controller Class Initialized
DEBUG - 2015-02-01 14:03:51 --> Model Class Initialized
DEBUG - 2015-02-01 14:03:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-01 14:03:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-01 14:03:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-01 14:03:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-01 14:03:51 --> Final output sent to browser
DEBUG - 2015-02-01 14:03:51 --> Total execution time: 0.5580
DEBUG - 2015-02-01 14:04:30 --> Config Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:04:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:04:30 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:04:30 --> URI Class Initialized
DEBUG - 2015-02-01 14:04:30 --> No URI present. Default controller set.
DEBUG - 2015-02-01 14:04:30 --> Router Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Output Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Security Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Input Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:04:30 --> Language Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Loader Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:04:30 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:04:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:04:30 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:04:30 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:04:30 --> Model Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Model Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Controller Class Initialized
DEBUG - 2015-02-01 14:04:30 --> Model Class Initialized
DEBUG - 2015-02-01 14:04:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 14:04:31 --> Pagination Class Initialized
DEBUG - 2015-02-01 14:04:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 14:04:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 14:04:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 14:04:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 14:04:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 14:04:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 14:04:31 --> Final output sent to browser
DEBUG - 2015-02-01 14:04:31 --> Total execution time: 0.9451
DEBUG - 2015-02-01 14:04:33 --> Config Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:04:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:04:33 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:04:33 --> URI Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Router Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Output Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Security Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Input Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:04:33 --> Language Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Loader Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:04:33 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:04:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:04:33 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:04:33 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:04:33 --> Model Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Model Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Controller Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Model Class Initialized
DEBUG - 2015-02-01 14:04:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 14:04:33 --> Pagination Class Initialized
DEBUG - 2015-02-01 14:04:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 14:04:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 14:04:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 14:04:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 14:04:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 14:04:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 14:04:34 --> Final output sent to browser
DEBUG - 2015-02-01 14:04:34 --> Total execution time: 0.7120
DEBUG - 2015-02-01 14:19:34 --> Config Class Initialized
DEBUG - 2015-02-01 14:19:34 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:19:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:19:34 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:19:34 --> URI Class Initialized
DEBUG - 2015-02-01 14:19:34 --> Router Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Output Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Security Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Input Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:19:35 --> Language Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Loader Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:19:35 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:19:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:19:35 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Session: Regenerate ID
DEBUG - 2015-02-01 14:19:35 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:19:35 --> Model Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Model Class Initialized
DEBUG - 2015-02-01 14:19:35 --> Controller Class Initialized
DEBUG - 2015-02-01 14:19:36 --> Model Class Initialized
DEBUG - 2015-02-01 14:19:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 14:19:36 --> Pagination Class Initialized
DEBUG - 2015-02-01 14:19:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 14:19:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 14:19:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 14:19:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 14:19:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 14:19:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 14:19:36 --> Final output sent to browser
DEBUG - 2015-02-01 14:19:36 --> Total execution time: 1.9271
DEBUG - 2015-02-01 14:26:13 --> Config Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:26:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:26:13 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:26:13 --> URI Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Router Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Output Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Security Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Input Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:26:13 --> Language Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Loader Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:26:13 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:26:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:26:13 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Session: Regenerate ID
DEBUG - 2015-02-01 14:26:13 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:26:13 --> Model Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Model Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Controller Class Initialized
DEBUG - 2015-02-01 14:26:13 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:26:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:26:14 --> Email Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Config Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:27:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:27:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:27:25 --> URI Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Router Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Output Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Security Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Input Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:27:25 --> Language Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Loader Class Initialized
DEBUG - 2015-02-01 14:27:25 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:27:25 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:27:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:27:25 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:27:25 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Controller Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:27:26 --> Email Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:27:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:27:26 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:27:26 --> Config Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:27:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:27:26 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:27:26 --> URI Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Router Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Output Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Security Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Input Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:27:26 --> Language Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Loader Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:27:26 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:27:26 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Controller Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:27:26 --> Email Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:27:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:27:26 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:27:26 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:27:26 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:27:26 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:27:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-01 14:27:26 --> Final output sent to browser
DEBUG - 2015-02-01 14:27:26 --> Total execution time: 0.3780
DEBUG - 2015-02-01 14:27:52 --> Config Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:27:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:27:52 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:27:52 --> URI Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Router Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Output Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Security Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Input Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:27:52 --> Language Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Loader Class Initialized
DEBUG - 2015-02-01 14:27:52 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:27:52 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:27:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:27:52 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:27:52 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:27:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Controller Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:27:53 --> Email Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:27:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:27:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:27:53 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:27:53 --> Config Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:27:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:27:53 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:27:53 --> URI Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Router Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Output Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Security Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Input Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:27:53 --> Language Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Loader Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:27:53 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:27:53 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:27:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Controller Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:27:53 --> Email Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:27:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:27:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:27:53 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:27:53 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:27:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:27:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-01 14:27:53 --> Final output sent to browser
DEBUG - 2015-02-01 14:27:53 --> Total execution time: 0.3620
DEBUG - 2015-02-01 14:28:07 --> Config Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:28:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:28:07 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:28:07 --> URI Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Router Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Output Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Security Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Input Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:28:07 --> Language Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Loader Class Initialized
DEBUG - 2015-02-01 14:28:07 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:28:07 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:28:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:28:07 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:28:07 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:28:08 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Controller Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:28:08 --> Email Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:28:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:28:08 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:28:08 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:28:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-01 14:28:08 --> Config Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:28:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:28:08 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:28:08 --> URI Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Router Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Output Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Security Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Input Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:28:08 --> Language Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Loader Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:28:08 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:28:08 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:28:08 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Controller Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:28:08 --> Email Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:28:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:28:08 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:28:08 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:28:08 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:28:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:28:08 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-01 14:28:08 --> Final output sent to browser
DEBUG - 2015-02-01 14:28:08 --> Total execution time: 0.3680
DEBUG - 2015-02-01 14:28:48 --> Config Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:28:48 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:28:48 --> URI Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Router Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Output Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Security Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Input Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:28:48 --> Language Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Loader Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:28:48 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:28:48 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:28:48 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Controller Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:28:48 --> Email Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:28:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:28:48 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:28:48 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:28:48 --> Config Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:28:48 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:28:48 --> URI Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Router Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Output Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Security Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Input Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:28:48 --> Language Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Loader Class Initialized
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:28:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:28:48 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:28:48 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:28:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:49 --> Controller Class Initialized
DEBUG - 2015-02-01 14:28:49 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:28:49 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:28:49 --> Email Class Initialized
DEBUG - 2015-02-01 14:28:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:28:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:28:49 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:28:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:28:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:28:49 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:28:49 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:28:49 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:28:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:28:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-01 14:28:49 --> Final output sent to browser
DEBUG - 2015-02-01 14:28:49 --> Total execution time: 0.4230
DEBUG - 2015-02-01 14:29:02 --> Config Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:29:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:29:02 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:29:02 --> URI Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Router Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Output Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Security Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Input Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:29:02 --> Language Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Loader Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:29:02 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:29:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:29:02 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:29:02 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:29:02 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Controller Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:29:02 --> Email Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:29:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:29:02 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:29:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:29:02 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:29:02 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:29:02 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:29:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:29:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-01 14:29:03 --> Config Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:29:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:29:03 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:29:03 --> URI Class Initialized
DEBUG - 2015-02-01 14:29:03 --> No URI present. Default controller set.
DEBUG - 2015-02-01 14:29:03 --> Router Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Output Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Security Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Input Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:29:03 --> Language Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Loader Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:29:03 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:29:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:29:03 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:29:03 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:29:03 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Controller Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 14:29:03 --> Pagination Class Initialized
DEBUG - 2015-02-01 14:29:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 14:29:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 14:29:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 14:29:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 14:29:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 14:29:03 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 14:29:03 --> Final output sent to browser
DEBUG - 2015-02-01 14:29:03 --> Total execution time: 0.6920
DEBUG - 2015-02-01 14:29:51 --> Config Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:29:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:29:51 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:29:51 --> URI Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Router Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Output Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Security Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Input Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:29:51 --> Language Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Loader Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:29:51 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:29:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:29:51 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:29:51 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:29:51 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Controller Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:29:51 --> Email Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:29:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:29:51 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:29:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:29:51 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:29:51 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:29:51 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:29:51 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-01 14:29:51 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-01 14:29:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-01 14:29:51 --> Final output sent to browser
DEBUG - 2015-02-01 14:29:51 --> Total execution time: 0.6190
DEBUG - 2015-02-01 14:29:53 --> Config Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:29:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:29:53 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:29:53 --> URI Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Router Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Output Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Security Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Input Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:29:53 --> Language Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Loader Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:29:53 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:29:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:29:53 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:29:53 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:29:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Controller Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:29:53 --> Email Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:29:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:29:53 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:29:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:29:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:29:53 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:29:53 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:29:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:29:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/index.php
DEBUG - 2015-02-01 14:29:53 --> Final output sent to browser
DEBUG - 2015-02-01 14:29:53 --> Total execution time: 0.4050
DEBUG - 2015-02-01 14:30:25 --> Config Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:30:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:30:25 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:30:25 --> URI Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Router Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Output Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Security Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Input Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:30:25 --> Language Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Loader Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:30:25 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:30:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:30:25 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:30:25 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:30:25 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Controller Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:30:25 --> Email Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:30:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:30:25 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:30:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:30:25 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:30:25 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:30:25 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:30:25 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-01 14:30:25 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-01 14:30:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-01 14:30:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-01 14:30:25 --> Final output sent to browser
DEBUG - 2015-02-01 14:30:25 --> Total execution time: 0.4690
DEBUG - 2015-02-01 14:30:48 --> Config Class Initialized
DEBUG - 2015-02-01 14:30:48 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:30:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:30:48 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:30:48 --> URI Class Initialized
DEBUG - 2015-02-01 14:30:48 --> Router Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Output Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Security Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Input Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:30:49 --> Language Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Loader Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:30:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:30:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:30:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:30:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:30:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Controller Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:30:49 --> Email Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:30:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:30:49 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:30:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:30:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:30:49 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:30:49 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:30:49 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-01 14:30:49 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-01 14:30:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-01 14:30:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-01 14:30:49 --> Final output sent to browser
DEBUG - 2015-02-01 14:30:49 --> Total execution time: 0.4850
DEBUG - 2015-02-01 14:30:58 --> Config Class Initialized
DEBUG - 2015-02-01 14:30:58 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:30:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:30:58 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:30:58 --> URI Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Router Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Output Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Security Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Input Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:30:59 --> Language Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Loader Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:30:59 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:30:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:30:59 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:30:59 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:30:59 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Controller Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:30:59 --> Email Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:30:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:30:59 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:30:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:30:59 --> Model Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:30:59 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:30:59 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:30:59 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-01 14:30:59 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-01 14:30:59 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-02-01 14:30:59 --> Query error: Unknown column 'created_on' in 'field list' - Invalid query: INSERT INTO `users` (`company`, `first_name`, `last_name`, `phone`, `username`, `password`, `email`, `ip_address`, `created_on`, `active`) VALUES ('VSII', 'Phu', 'Tran', '0979930752', 'phu tran', '$2y$08$9nMMSgCbv6Jdo1fEO5RUkeHdVfrry24UOaCdH.883J8UoFBwwdMg6', 'sujupro@gmail.com', '::1', 1422797459, 1)
DEBUG - 2015-02-01 14:30:59 --> Language file loaded: language/english/db_lang.php
DEBUG - 2015-02-01 14:31:22 --> Config Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:31:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:31:22 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:31:22 --> URI Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Router Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Output Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Security Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Input Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:31:22 --> Language Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Loader Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:31:22 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:31:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:31:22 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Session: Regenerate ID
DEBUG - 2015-02-01 14:31:22 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:31:22 --> Model Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Model Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Controller Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:31:22 --> Email Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:31:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:31:22 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:31:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:31:22 --> Model Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:31:22 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:31:22 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-01 14:31:22 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-01 14:31:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-01 14:31:22 --> Config Class Initialized
DEBUG - 2015-02-01 14:31:22 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:31:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:31:22 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:31:22 --> URI Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Router Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Output Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Security Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Input Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:31:23 --> Language Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Loader Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:31:23 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:31:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:31:23 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:31:23 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:31:23 --> Model Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Model Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Controller Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:31:23 --> Email Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:31:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:31:23 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:31:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:31:23 --> Model Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:31:23 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:31:23 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:31:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:31:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/index.php
DEBUG - 2015-02-01 14:31:23 --> Final output sent to browser
DEBUG - 2015-02-01 14:31:23 --> Total execution time: 0.3760
DEBUG - 2015-02-01 14:57:52 --> Config Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:57:52 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:57:52 --> URI Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Router Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Output Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Security Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Input Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:57:52 --> Language Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Loader Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:57:52 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:57:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:57:52 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Session: Regenerate ID
DEBUG - 2015-02-01 14:57:52 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:57:52 --> Model Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Model Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Controller Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:57:52 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:57:52 --> Email Class Initialized
DEBUG - 2015-02-01 14:57:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:57:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:57:53 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:57:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:57:53 --> Model Class Initialized
DEBUG - 2015-02-01 14:57:53 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:57:53 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:57:53 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:57:53 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-01 14:57:53 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-01 14:57:53 --> Helper loaded: string_helper
DEBUG - 2015-02-01 14:57:53 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-01 14:57:53 --> Final output sent to browser
DEBUG - 2015-02-01 14:57:53 --> Total execution time: 0.8650
DEBUG - 2015-02-01 14:58:17 --> Config Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:58:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:58:17 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:58:17 --> URI Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Router Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Output Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Security Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Input Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:58:17 --> Language Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Loader Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:58:17 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:58:17 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:58:17 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Controller Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:58:17 --> Email Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:58:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:58:17 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:58:17 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:58:17 --> Session: Creating new session (f088a02762ddac0ac5a68565e18559d5)
DEBUG - 2015-02-01 14:58:17 --> Config Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:58:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:58:17 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:58:17 --> URI Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Router Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Output Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Security Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Input Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:58:17 --> Language Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Loader Class Initialized
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:58:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:58:17 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:58:17 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:58:18 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:18 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:18 --> Controller Class Initialized
DEBUG - 2015-02-01 14:58:18 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:58:18 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:58:18 --> Email Class Initialized
DEBUG - 2015-02-01 14:58:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:58:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:58:18 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:58:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:58:18 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:18 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:58:18 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:58:18 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:58:18 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:58:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-01 14:58:18 --> Final output sent to browser
DEBUG - 2015-02-01 14:58:18 --> Total execution time: 0.4690
DEBUG - 2015-02-01 14:58:32 --> Config Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:58:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:58:32 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:58:32 --> URI Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Router Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Output Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Security Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Input Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:58:32 --> Language Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Loader Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:58:32 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:58:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:58:32 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:58:32 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:58:32 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:32 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Controller Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:58:33 --> Email Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:58:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:58:33 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:58:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:58:33 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:58:33 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:58:33 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:58:33 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-01 14:58:33 --> Config Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:58:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:58:33 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:58:33 --> URI Class Initialized
DEBUG - 2015-02-01 14:58:33 --> No URI present. Default controller set.
DEBUG - 2015-02-01 14:58:33 --> Router Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Output Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Security Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Input Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:58:33 --> Language Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Loader Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:58:33 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:58:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:58:33 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:58:33 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:58:33 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Controller Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 14:58:33 --> Pagination Class Initialized
DEBUG - 2015-02-01 14:58:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 14:58:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 14:58:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 14:58:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 14:58:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 14:58:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 14:58:35 --> Final output sent to browser
DEBUG - 2015-02-01 14:58:35 --> Total execution time: 1.7541
DEBUG - 2015-02-01 14:58:43 --> Config Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:58:43 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:58:43 --> URI Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Router Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Output Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Security Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Input Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:58:43 --> Language Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Loader Class Initialized
DEBUG - 2015-02-01 14:58:43 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:58:43 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:58:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:58:44 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:58:44 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:58:44 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Controller Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:58:44 --> Email Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:58:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:58:44 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:58:44 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:58:44 --> Config Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:58:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:58:44 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:58:44 --> URI Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Router Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Output Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Security Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Input Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:58:44 --> Language Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Loader Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:58:44 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:58:44 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:58:44 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Controller Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Database Driver Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-01 14:58:44 --> Email Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: language_helper
DEBUG - 2015-02-01 14:58:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-01 14:58:44 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: date_helper
DEBUG - 2015-02-01 14:58:44 --> Helper loaded: form_helper
DEBUG - 2015-02-01 14:58:44 --> Form Validation Class Initialized
DEBUG - 2015-02-01 14:58:44 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-01 14:58:49 --> Config Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Hooks Class Initialized
DEBUG - 2015-02-01 14:58:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 14:58:49 --> Utf8 Class Initialized
DEBUG - 2015-02-01 14:58:49 --> URI Class Initialized
DEBUG - 2015-02-01 14:58:49 --> No URI present. Default controller set.
DEBUG - 2015-02-01 14:58:49 --> Router Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Output Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Security Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Input Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 14:58:49 --> Language Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Loader Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Helper loaded: url_helper
DEBUG - 2015-02-01 14:58:49 --> Helper loaded: link_helper
DEBUG - 2015-02-01 14:58:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 14:58:49 --> CI_Session Class Initialized
DEBUG - 2015-02-01 14:58:49 --> CI_Session routines successfully run
DEBUG - 2015-02-01 14:58:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Controller Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Model Class Initialized
DEBUG - 2015-02-01 14:58:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 14:58:49 --> Pagination Class Initialized
DEBUG - 2015-02-01 14:58:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 14:58:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 14:58:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 14:58:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 14:58:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 14:58:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 14:58:49 --> Final output sent to browser
DEBUG - 2015-02-01 14:58:49 --> Total execution time: 0.7250
DEBUG - 2015-02-01 15:13:50 --> Config Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Hooks Class Initialized
DEBUG - 2015-02-01 15:13:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 15:13:50 --> Utf8 Class Initialized
DEBUG - 2015-02-01 15:13:50 --> URI Class Initialized
DEBUG - 2015-02-01 15:13:50 --> No URI present. Default controller set.
DEBUG - 2015-02-01 15:13:50 --> Router Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Output Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Security Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Input Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 15:13:50 --> Language Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Loader Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Helper loaded: url_helper
DEBUG - 2015-02-01 15:13:50 --> Helper loaded: link_helper
DEBUG - 2015-02-01 15:13:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 15:13:50 --> CI_Session Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Session: Regenerate ID
DEBUG - 2015-02-01 15:13:50 --> CI_Session routines successfully run
DEBUG - 2015-02-01 15:13:50 --> Model Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Model Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Controller Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Model Class Initialized
DEBUG - 2015-02-01 15:13:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 15:13:50 --> Pagination Class Initialized
DEBUG - 2015-02-01 15:13:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 15:13:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 15:13:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 15:13:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 15:13:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 15:13:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 15:13:51 --> Final output sent to browser
DEBUG - 2015-02-01 15:13:51 --> Total execution time: 0.8120
DEBUG - 2015-02-01 15:28:55 --> Config Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Hooks Class Initialized
DEBUG - 2015-02-01 15:28:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-01 15:28:56 --> Utf8 Class Initialized
DEBUG - 2015-02-01 15:28:56 --> URI Class Initialized
DEBUG - 2015-02-01 15:28:56 --> No URI present. Default controller set.
DEBUG - 2015-02-01 15:28:56 --> Router Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Output Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Security Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Input Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-01 15:28:56 --> Language Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Loader Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Helper loaded: url_helper
DEBUG - 2015-02-01 15:28:56 --> Helper loaded: link_helper
DEBUG - 2015-02-01 15:28:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-01 15:28:56 --> CI_Session Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Session: Regenerate ID
DEBUG - 2015-02-01 15:28:56 --> CI_Session routines successfully run
DEBUG - 2015-02-01 15:28:56 --> Model Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Model Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Controller Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Model Class Initialized
DEBUG - 2015-02-01 15:28:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-01 15:28:56 --> Pagination Class Initialized
DEBUG - 2015-02-01 15:28:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-01 15:28:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-01 15:28:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-01 15:28:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-01 15:28:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-01 15:28:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-01 15:28:56 --> Final output sent to browser
DEBUG - 2015-02-01 15:28:56 --> Total execution time: 0.7780
