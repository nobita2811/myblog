<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-12 00:06:49 --> Config Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:06:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:06:49 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:06:49 --> URI Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Router Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Output Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Security Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Input Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:06:49 --> Language Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Loader Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:06:49 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Session: Regenerate ID
DEBUG - 2015-02-12 00:06:49 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:06:49 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Controller Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:06:49 --> Email Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:06:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:06:49 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:06:49 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:06:49 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:06:49 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:50 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:50 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 00:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 00:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 00:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 00:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 00:06:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 00:06:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 00:06:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 00:06:51 --> Final output sent to browser
DEBUG - 2015-02-12 00:06:51 --> Total execution time: 1.4781
DEBUG - 2015-02-12 00:06:52 --> Config Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:06:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:06:52 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:06:52 --> URI Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Router Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Output Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Security Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Input Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:06:52 --> Language Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Loader Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:06:52 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:06:52 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:06:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Controller Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:06:52 --> Email Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:06:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:06:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:06:52 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:06:52 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:06:52 --> Final output sent to browser
DEBUG - 2015-02-12 00:06:52 --> Total execution time: 0.8681
DEBUG - 2015-02-12 00:21:52 --> Config Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:21:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:21:52 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:21:52 --> URI Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Router Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Output Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Security Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Input Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:21:52 --> Language Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Loader Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:21:52 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Session: Regenerate ID
DEBUG - 2015-02-12 00:21:52 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:21:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Controller Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:21:52 --> Email Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:21:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:21:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:21:52 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:21:52 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:21:52 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:53 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:53 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 00:21:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 00:21:53 --> Final output sent to browser
DEBUG - 2015-02-12 00:21:53 --> Total execution time: 1.3471
DEBUG - 2015-02-12 00:21:54 --> Config Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:21:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:21:54 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:21:54 --> URI Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Router Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Output Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Security Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Input Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:21:54 --> Language Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Loader Class Initialized
DEBUG - 2015-02-12 00:21:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:21:54 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:21:54 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:21:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:21:54 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:21:54 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:21:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Controller Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:21:55 --> Email Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:21:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:21:55 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:21:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:21:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:21:55 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:21:55 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:21:55 --> Final output sent to browser
DEBUG - 2015-02-12 00:21:55 --> Total execution time: 0.8971
DEBUG - 2015-02-12 00:36:55 --> Config Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:36:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:36:55 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:36:55 --> URI Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Router Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Output Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Security Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Input Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:36:55 --> Language Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Loader Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:36:55 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Session: Regenerate ID
DEBUG - 2015-02-12 00:36:55 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:36:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Controller Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:36:55 --> Email Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:36:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:36:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:36:55 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:36:55 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:36:55 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:56 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:56 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 00:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 00:36:56 --> Final output sent to browser
DEBUG - 2015-02-12 00:36:56 --> Total execution time: 1.3561
DEBUG - 2015-02-12 00:36:57 --> Config Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:36:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:36:57 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:36:57 --> URI Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Router Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Output Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Security Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Input Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:36:57 --> Language Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Loader Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:36:57 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:36:57 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:36:57 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Controller Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:36:57 --> Email Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:36:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:36:57 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:36:57 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:36:57 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:57 --> Model Class Initialized
DEBUG - 2015-02-12 00:36:58 --> Final output sent to browser
DEBUG - 2015-02-12 00:36:58 --> Total execution time: 0.8941
DEBUG - 2015-02-12 00:51:58 --> Config Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:51:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:51:58 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:51:58 --> URI Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Router Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Output Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Security Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Input Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:51:58 --> Language Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Loader Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:51:58 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Session: Regenerate ID
DEBUG - 2015-02-12 00:51:58 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:51:58 --> Model Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Model Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Controller Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:51:58 --> Email Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:51:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:51:58 --> Model Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:51:58 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:51:58 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:51:58 --> Model Class Initialized
DEBUG - 2015-02-12 00:51:59 --> Model Class Initialized
DEBUG - 2015-02-12 00:51:59 --> Model Class Initialized
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 00:51:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 00:51:59 --> Final output sent to browser
DEBUG - 2015-02-12 00:51:59 --> Total execution time: 1.3461
DEBUG - 2015-02-12 00:52:00 --> Config Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Hooks Class Initialized
DEBUG - 2015-02-12 00:52:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 00:52:00 --> Utf8 Class Initialized
DEBUG - 2015-02-12 00:52:00 --> URI Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Router Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Output Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Security Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Input Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 00:52:00 --> Language Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Loader Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: url_helper
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: link_helper
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 00:52:00 --> CI_Session Class Initialized
DEBUG - 2015-02-12 00:52:00 --> CI_Session routines successfully run
DEBUG - 2015-02-12 00:52:00 --> Model Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Model Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Controller Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 00:52:00 --> Email Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: language_helper
DEBUG - 2015-02-12 00:52:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 00:52:00 --> Model Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Database Driver Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: date_helper
DEBUG - 2015-02-12 00:52:00 --> Helper loaded: form_helper
DEBUG - 2015-02-12 00:52:00 --> Form Validation Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Model Class Initialized
DEBUG - 2015-02-12 00:52:00 --> Model Class Initialized
DEBUG - 2015-02-12 00:52:01 --> Final output sent to browser
DEBUG - 2015-02-12 00:52:01 --> Total execution time: 0.9651
DEBUG - 2015-02-12 01:07:00 --> Config Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:07:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:07:00 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:07:00 --> URI Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Router Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Output Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Security Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Input Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:07:00 --> Language Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Loader Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:07:00 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Session: Regenerate ID
DEBUG - 2015-02-12 01:07:00 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:07:00 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Controller Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:07:00 --> Email Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:07:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:07:00 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:07:00 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:07:00 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:07:00 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:02 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:02 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 01:07:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 01:07:02 --> Final output sent to browser
DEBUG - 2015-02-12 01:07:02 --> Total execution time: 1.6992
DEBUG - 2015-02-12 01:07:04 --> Config Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:07:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:07:04 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:07:04 --> URI Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Router Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Output Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Security Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Input Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:07:04 --> Language Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Loader Class Initialized
DEBUG - 2015-02-12 01:07:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:07:04 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:07:04 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:07:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:07:04 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:07:04 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:07:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Controller Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:07:05 --> Email Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:07:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:07:05 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:07:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:07:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:07:05 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:07:05 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:07:05 --> Final output sent to browser
DEBUG - 2015-02-12 01:07:05 --> Total execution time: 0.9661
DEBUG - 2015-02-12 01:22:05 --> Config Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:22:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:22:05 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:22:05 --> URI Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Router Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Output Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Security Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Input Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:22:05 --> Language Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Loader Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:22:05 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Session: Regenerate ID
DEBUG - 2015-02-12 01:22:05 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:22:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Controller Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:22:05 --> Email Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:22:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:22:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:22:05 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:22:05 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:22:05 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:07 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:07 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 01:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 01:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 01:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 01:22:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 01:22:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 01:22:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 01:22:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 01:22:08 --> Final output sent to browser
DEBUG - 2015-02-12 01:22:08 --> Total execution time: 2.9023
DEBUG - 2015-02-12 01:22:09 --> Config Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:22:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:22:09 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:22:09 --> URI Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Router Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Output Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Security Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Input Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:22:09 --> Language Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Loader Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:22:09 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:22:09 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:22:09 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Controller Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:22:09 --> Email Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:22:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:22:09 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:22:09 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:22:09 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:09 --> Model Class Initialized
DEBUG - 2015-02-12 01:22:10 --> Final output sent to browser
DEBUG - 2015-02-12 01:22:10 --> Total execution time: 0.9721
DEBUG - 2015-02-12 01:37:09 --> Config Class Initialized
DEBUG - 2015-02-12 01:37:09 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:37:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:37:09 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:37:09 --> URI Class Initialized
DEBUG - 2015-02-12 01:37:09 --> Router Class Initialized
DEBUG - 2015-02-12 01:37:09 --> Output Class Initialized
DEBUG - 2015-02-12 01:37:09 --> Security Class Initialized
DEBUG - 2015-02-12 01:37:09 --> Input Class Initialized
DEBUG - 2015-02-12 01:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:37:09 --> Language Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Loader Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:37:10 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Session: Regenerate ID
DEBUG - 2015-02-12 01:37:10 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:37:10 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Controller Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:37:10 --> Email Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:37:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:37:10 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:37:10 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:37:10 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:37:10 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:11 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:11 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 01:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 01:37:11 --> Final output sent to browser
DEBUG - 2015-02-12 01:37:11 --> Total execution time: 1.4371
DEBUG - 2015-02-12 01:37:12 --> Config Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:37:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:37:12 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:37:12 --> URI Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Router Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Output Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Security Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Input Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:37:12 --> Language Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Loader Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:37:12 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:37:12 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:37:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Controller Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:37:12 --> Email Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:37:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:37:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:37:12 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:37:12 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:37:13 --> Final output sent to browser
DEBUG - 2015-02-12 01:37:13 --> Total execution time: 0.9301
DEBUG - 2015-02-12 01:52:12 --> Config Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:52:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:52:12 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:52:12 --> URI Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Router Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Output Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Security Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Input Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:52:12 --> Language Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Loader Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:52:12 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Session: Regenerate ID
DEBUG - 2015-02-12 01:52:12 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:52:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Controller Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:52:12 --> Email Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:52:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:52:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:52:12 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:52:12 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:52:12 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:13 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:13 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 01:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 01:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 01:52:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 01:52:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 01:52:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 01:52:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 01:52:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 01:52:14 --> Final output sent to browser
DEBUG - 2015-02-12 01:52:14 --> Total execution time: 1.9752
DEBUG - 2015-02-12 01:52:15 --> Config Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Hooks Class Initialized
DEBUG - 2015-02-12 01:52:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 01:52:15 --> Utf8 Class Initialized
DEBUG - 2015-02-12 01:52:15 --> URI Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Router Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Output Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Security Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Input Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 01:52:15 --> Language Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Loader Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: url_helper
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: link_helper
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 01:52:15 --> CI_Session Class Initialized
DEBUG - 2015-02-12 01:52:15 --> CI_Session routines successfully run
DEBUG - 2015-02-12 01:52:15 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Controller Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 01:52:15 --> Email Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: language_helper
DEBUG - 2015-02-12 01:52:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 01:52:15 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Database Driver Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: date_helper
DEBUG - 2015-02-12 01:52:15 --> Helper loaded: form_helper
DEBUG - 2015-02-12 01:52:15 --> Form Validation Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:15 --> Model Class Initialized
DEBUG - 2015-02-12 01:52:16 --> Final output sent to browser
DEBUG - 2015-02-12 01:52:16 --> Total execution time: 1.0291
DEBUG - 2015-02-12 02:07:15 --> Config Class Initialized
DEBUG - 2015-02-12 02:07:15 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:07:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:07:15 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:07:15 --> URI Class Initialized
DEBUG - 2015-02-12 02:07:15 --> Router Class Initialized
DEBUG - 2015-02-12 02:07:15 --> Output Class Initialized
DEBUG - 2015-02-12 02:07:15 --> Security Class Initialized
DEBUG - 2015-02-12 02:07:15 --> Input Class Initialized
DEBUG - 2015-02-12 02:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:07:15 --> Language Class Initialized
DEBUG - 2015-02-12 02:07:15 --> Loader Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:07:16 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Session: Regenerate ID
DEBUG - 2015-02-12 02:07:16 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:07:16 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Controller Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:07:16 --> Email Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:07:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:07:16 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:07:16 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:07:16 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:07:16 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:17 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:17 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 02:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 02:07:17 --> Final output sent to browser
DEBUG - 2015-02-12 02:07:17 --> Total execution time: 1.6132
DEBUG - 2015-02-12 02:07:18 --> Config Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:07:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:07:18 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:07:18 --> URI Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Router Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Output Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Security Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Input Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:07:18 --> Language Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Loader Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:07:18 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:07:18 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:07:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Controller Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:07:18 --> Email Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:07:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:07:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:07:18 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:07:18 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:07:19 --> Final output sent to browser
DEBUG - 2015-02-12 02:07:19 --> Total execution time: 1.0291
DEBUG - 2015-02-12 02:22:18 --> Config Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:22:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:22:18 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:22:18 --> URI Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Router Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Output Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Security Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Input Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:22:18 --> Language Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Loader Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:22:18 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Session: Regenerate ID
DEBUG - 2015-02-12 02:22:18 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:22:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Controller Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:22:18 --> Email Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:22:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:22:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:22:18 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:22:18 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:22:18 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:19 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:19 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 02:22:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 02:22:19 --> Final output sent to browser
DEBUG - 2015-02-12 02:22:19 --> Total execution time: 1.3783
DEBUG - 2015-02-12 02:22:20 --> Config Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:22:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:22:20 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:22:20 --> URI Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Router Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Output Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Security Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Input Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:22:20 --> Language Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Loader Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:22:20 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:22:20 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:22:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Controller Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:22:20 --> Email Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:22:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:22:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:22:20 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:22:20 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:22:21 --> Final output sent to browser
DEBUG - 2015-02-12 02:22:21 --> Total execution time: 0.9155
DEBUG - 2015-02-12 02:37:20 --> Config Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:37:20 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:37:20 --> URI Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Router Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Output Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Security Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Input Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:37:20 --> Language Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Loader Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:37:20 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Session: Regenerate ID
DEBUG - 2015-02-12 02:37:20 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:37:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Controller Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:37:20 --> Email Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:37:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:37:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:37:20 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:37:20 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:37:20 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:21 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:21 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 02:37:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 02:37:21 --> Final output sent to browser
DEBUG - 2015-02-12 02:37:21 --> Total execution time: 1.3800
DEBUG - 2015-02-12 02:37:22 --> Config Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:37:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:37:22 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:37:22 --> URI Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Router Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Output Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Security Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Input Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:37:22 --> Language Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Loader Class Initialized
DEBUG - 2015-02-12 02:37:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:37:22 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:37:22 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:37:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:37:22 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:37:22 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:37:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Controller Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:37:23 --> Email Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:37:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:37:23 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:37:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:37:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:37:23 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:37:23 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:37:23 --> Final output sent to browser
DEBUG - 2015-02-12 02:37:23 --> Total execution time: 0.9890
DEBUG - 2015-02-12 02:52:23 --> Config Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:52:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:52:23 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:52:23 --> URI Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Router Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Output Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Security Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Input Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:52:23 --> Language Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Loader Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:52:23 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Session: Regenerate ID
DEBUG - 2015-02-12 02:52:23 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:52:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Controller Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:52:23 --> Email Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:52:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:52:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:52:23 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:52:23 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:52:23 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:24 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:24 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 02:52:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 02:52:24 --> Final output sent to browser
DEBUG - 2015-02-12 02:52:24 --> Total execution time: 1.7662
DEBUG - 2015-02-12 02:52:25 --> Config Class Initialized
DEBUG - 2015-02-12 02:52:25 --> Hooks Class Initialized
DEBUG - 2015-02-12 02:52:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 02:52:25 --> Utf8 Class Initialized
DEBUG - 2015-02-12 02:52:26 --> URI Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Router Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Output Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Security Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Input Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 02:52:26 --> Language Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Loader Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: url_helper
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: link_helper
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 02:52:26 --> CI_Session Class Initialized
DEBUG - 2015-02-12 02:52:26 --> CI_Session routines successfully run
DEBUG - 2015-02-12 02:52:26 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Controller Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 02:52:26 --> Email Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: language_helper
DEBUG - 2015-02-12 02:52:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 02:52:26 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Database Driver Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: date_helper
DEBUG - 2015-02-12 02:52:26 --> Helper loaded: form_helper
DEBUG - 2015-02-12 02:52:26 --> Form Validation Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:26 --> Model Class Initialized
DEBUG - 2015-02-12 02:52:27 --> Final output sent to browser
DEBUG - 2015-02-12 02:52:27 --> Total execution time: 1.0341
DEBUG - 2015-02-12 03:07:26 --> Config Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:07:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:07:26 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:07:26 --> URI Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Router Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Output Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Security Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Input Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:07:26 --> Language Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Loader Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:07:26 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Session: Regenerate ID
DEBUG - 2015-02-12 03:07:26 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:07:26 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Controller Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:07:26 --> Email Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:07:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:07:26 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:07:26 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:07:26 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:07:26 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:27 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:27 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 03:07:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 03:07:27 --> Final output sent to browser
DEBUG - 2015-02-12 03:07:27 --> Total execution time: 1.4191
DEBUG - 2015-02-12 03:07:28 --> Config Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:07:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:07:28 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:07:28 --> URI Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Router Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Output Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Security Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Input Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:07:28 --> Language Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Loader Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:07:28 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:07:28 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:07:28 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Controller Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:07:28 --> Email Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:07:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:07:28 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:07:28 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:07:28 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:28 --> Model Class Initialized
DEBUG - 2015-02-12 03:07:29 --> Final output sent to browser
DEBUG - 2015-02-12 03:07:29 --> Total execution time: 0.8771
DEBUG - 2015-02-12 03:22:28 --> Config Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:22:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:22:28 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:22:28 --> URI Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Router Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Output Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Security Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Input Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:22:28 --> Language Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Loader Class Initialized
DEBUG - 2015-02-12 03:22:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:22:28 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:22:28 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:22:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:22:28 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Session: Regenerate ID
DEBUG - 2015-02-12 03:22:29 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:22:29 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Controller Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:22:29 --> Email Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:22:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:22:29 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:22:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:22:29 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:22:29 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:22:29 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:22:29 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:30 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:30 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 03:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 03:22:30 --> Final output sent to browser
DEBUG - 2015-02-12 03:22:30 --> Total execution time: 1.5442
DEBUG - 2015-02-12 03:22:31 --> Config Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:22:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:22:31 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:22:31 --> URI Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Router Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Output Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Security Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Input Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:22:31 --> Language Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Loader Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:22:31 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:22:31 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:22:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Controller Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:22:31 --> Email Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:22:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:22:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:22:31 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:22:31 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:22:32 --> Final output sent to browser
DEBUG - 2015-02-12 03:22:32 --> Total execution time: 0.9641
DEBUG - 2015-02-12 03:37:31 --> Config Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:37:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:37:31 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:37:31 --> URI Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Router Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Output Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Security Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Input Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:37:31 --> Language Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Loader Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:37:31 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Session: Regenerate ID
DEBUG - 2015-02-12 03:37:31 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:37:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Controller Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:37:31 --> Email Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:37:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:37:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:37:31 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:37:31 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:37:31 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:32 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:32 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 03:37:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 03:37:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 03:37:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 03:37:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 03:37:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 03:37:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 03:37:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 03:37:33 --> Final output sent to browser
DEBUG - 2015-02-12 03:37:33 --> Total execution time: 1.3891
DEBUG - 2015-02-12 03:37:34 --> Config Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:37:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:37:34 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:37:34 --> URI Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Router Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Output Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Security Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Input Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:37:34 --> Language Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Loader Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:37:34 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:37:34 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:37:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Controller Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:37:34 --> Email Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:37:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:37:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:37:34 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:37:34 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:37:35 --> Final output sent to browser
DEBUG - 2015-02-12 03:37:35 --> Total execution time: 0.8701
DEBUG - 2015-02-12 03:52:34 --> Config Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:52:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:52:34 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:52:34 --> URI Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Router Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Output Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Security Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Input Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:52:34 --> Language Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Loader Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:52:34 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Session: Regenerate ID
DEBUG - 2015-02-12 03:52:34 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:52:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Controller Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:52:34 --> Email Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:52:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:52:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:52:34 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:52:34 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:52:34 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:35 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:35 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 03:52:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 03:52:35 --> Final output sent to browser
DEBUG - 2015-02-12 03:52:35 --> Total execution time: 1.3681
DEBUG - 2015-02-12 03:52:36 --> Config Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Hooks Class Initialized
DEBUG - 2015-02-12 03:52:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 03:52:36 --> Utf8 Class Initialized
DEBUG - 2015-02-12 03:52:36 --> URI Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Router Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Output Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Security Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Input Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 03:52:36 --> Language Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Loader Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: url_helper
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: link_helper
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 03:52:36 --> CI_Session Class Initialized
DEBUG - 2015-02-12 03:52:36 --> CI_Session routines successfully run
DEBUG - 2015-02-12 03:52:36 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Controller Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 03:52:36 --> Email Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: language_helper
DEBUG - 2015-02-12 03:52:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 03:52:36 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Database Driver Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: date_helper
DEBUG - 2015-02-12 03:52:36 --> Helper loaded: form_helper
DEBUG - 2015-02-12 03:52:36 --> Form Validation Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:36 --> Model Class Initialized
DEBUG - 2015-02-12 03:52:37 --> Final output sent to browser
DEBUG - 2015-02-12 03:52:37 --> Total execution time: 1.1251
DEBUG - 2015-02-12 04:07:40 --> Config Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:07:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:07:40 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:07:40 --> URI Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Router Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Output Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Security Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Input Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:07:40 --> Language Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Loader Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:07:40 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Session: Regenerate ID
DEBUG - 2015-02-12 04:07:40 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:07:40 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Controller Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:07:40 --> Email Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:07:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:07:40 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:07:40 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:07:40 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:07:40 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:41 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:41 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 04:07:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 04:07:41 --> Final output sent to browser
DEBUG - 2015-02-12 04:07:41 --> Total execution time: 1.3331
DEBUG - 2015-02-12 04:07:42 --> Config Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:07:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:07:42 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:07:42 --> URI Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Router Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Output Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Security Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Input Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:07:42 --> Language Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Loader Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:07:42 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:07:42 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:07:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Controller Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:07:42 --> Email Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:07:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:07:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:07:42 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:07:42 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:07:43 --> Final output sent to browser
DEBUG - 2015-02-12 04:07:43 --> Total execution time: 0.8871
DEBUG - 2015-02-12 04:22:42 --> Config Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:22:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:22:42 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:22:42 --> URI Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Router Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Output Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Security Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Input Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:22:42 --> Language Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Loader Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:22:42 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Session: Regenerate ID
DEBUG - 2015-02-12 04:22:42 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:22:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Controller Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:22:42 --> Email Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:22:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:22:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:22:42 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:22:42 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:22:42 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:43 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:43 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 04:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 04:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 04:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 04:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 04:22:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 04:22:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 04:22:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 04:22:44 --> Final output sent to browser
DEBUG - 2015-02-12 04:22:44 --> Total execution time: 1.3691
DEBUG - 2015-02-12 04:22:45 --> Config Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:22:45 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:22:45 --> URI Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Router Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Output Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Security Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Input Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:22:45 --> Language Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Loader Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:22:45 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:22:45 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:22:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Controller Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:22:45 --> Email Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:22:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:22:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:22:45 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:22:45 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:22:46 --> Final output sent to browser
DEBUG - 2015-02-12 04:22:46 --> Total execution time: 0.8731
DEBUG - 2015-02-12 04:37:45 --> Config Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:37:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:37:45 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:37:45 --> URI Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Router Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Output Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Security Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Input Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:37:45 --> Language Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Loader Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:37:45 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Session: Regenerate ID
DEBUG - 2015-02-12 04:37:45 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:37:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Controller Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:37:45 --> Email Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:37:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:37:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:37:45 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:37:45 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:37:45 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:46 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:46 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 04:37:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 04:37:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 04:37:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 04:37:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 04:37:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 04:37:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 04:37:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 04:37:47 --> Final output sent to browser
DEBUG - 2015-02-12 04:37:47 --> Total execution time: 1.6242
DEBUG - 2015-02-12 04:37:48 --> Config Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:37:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:37:48 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:37:48 --> URI Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Router Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Output Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Security Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Input Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:37:48 --> Language Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Loader Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:37:48 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:37:48 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:37:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Controller Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:37:48 --> Email Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:37:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:37:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:37:48 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:37:48 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:37:49 --> Final output sent to browser
DEBUG - 2015-02-12 04:37:49 --> Total execution time: 0.9011
DEBUG - 2015-02-12 04:52:48 --> Config Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:52:48 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:52:48 --> URI Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Router Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Output Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Security Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Input Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:52:48 --> Language Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Loader Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:52:48 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Session: Regenerate ID
DEBUG - 2015-02-12 04:52:48 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:52:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Controller Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:52:48 --> Email Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:52:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:52:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:52:48 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:52:48 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:52:48 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:49 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:49 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 04:52:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 04:52:49 --> Final output sent to browser
DEBUG - 2015-02-12 04:52:49 --> Total execution time: 1.3691
DEBUG - 2015-02-12 04:52:50 --> Config Class Initialized
DEBUG - 2015-02-12 04:52:50 --> Hooks Class Initialized
DEBUG - 2015-02-12 04:52:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 04:52:50 --> Utf8 Class Initialized
DEBUG - 2015-02-12 04:52:50 --> URI Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Router Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Output Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Security Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Input Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 04:52:51 --> Language Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Loader Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: url_helper
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: link_helper
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 04:52:51 --> CI_Session Class Initialized
DEBUG - 2015-02-12 04:52:51 --> CI_Session routines successfully run
DEBUG - 2015-02-12 04:52:51 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Controller Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 04:52:51 --> Email Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: language_helper
DEBUG - 2015-02-12 04:52:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 04:52:51 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Database Driver Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: date_helper
DEBUG - 2015-02-12 04:52:51 --> Helper loaded: form_helper
DEBUG - 2015-02-12 04:52:51 --> Form Validation Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Model Class Initialized
DEBUG - 2015-02-12 04:52:51 --> Final output sent to browser
DEBUG - 2015-02-12 04:52:51 --> Total execution time: 0.8721
DEBUG - 2015-02-12 05:07:51 --> Config Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:07:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:07:51 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:07:51 --> URI Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Router Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Output Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Security Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Input Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:07:51 --> Language Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Loader Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:07:51 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Session: Regenerate ID
DEBUG - 2015-02-12 05:07:51 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:07:51 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Controller Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:07:51 --> Email Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:07:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:07:51 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:07:51 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:07:51 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:07:51 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:52 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:52 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 05:07:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 05:07:52 --> Final output sent to browser
DEBUG - 2015-02-12 05:07:52 --> Total execution time: 1.3451
DEBUG - 2015-02-12 05:07:53 --> Config Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:07:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:07:53 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:07:53 --> URI Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Router Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Output Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Security Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Input Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:07:53 --> Language Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Loader Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:07:53 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:07:53 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:07:53 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Controller Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:07:53 --> Email Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:07:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:07:53 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:07:53 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:07:53 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:53 --> Model Class Initialized
DEBUG - 2015-02-12 05:07:54 --> Final output sent to browser
DEBUG - 2015-02-12 05:07:54 --> Total execution time: 0.8641
DEBUG - 2015-02-12 05:22:53 --> Config Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:22:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:22:53 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:22:53 --> URI Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Router Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Output Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Security Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Input Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:22:53 --> Language Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Loader Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:22:53 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:22:53 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:22:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:22:53 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:22:53 --> Session: Regenerate ID
DEBUG - 2015-02-12 05:22:53 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:22:54 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Controller Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:22:54 --> Email Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:22:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:22:54 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:22:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:22:54 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:22:54 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:22:54 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:54 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:55 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 05:22:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 05:22:55 --> Final output sent to browser
DEBUG - 2015-02-12 05:22:55 --> Total execution time: 1.3681
DEBUG - 2015-02-12 05:22:56 --> Config Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:22:56 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:22:56 --> URI Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Router Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Output Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Security Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Input Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:22:56 --> Language Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Loader Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:22:56 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:22:56 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:22:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Controller Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:22:56 --> Email Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:22:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:22:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:22:56 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:22:56 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:22:57 --> Final output sent to browser
DEBUG - 2015-02-12 05:22:57 --> Total execution time: 0.9451
DEBUG - 2015-02-12 05:37:56 --> Config Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:37:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:37:56 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:37:56 --> URI Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Router Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Output Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Security Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Input Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:37:56 --> Language Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Loader Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:37:56 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Session: Regenerate ID
DEBUG - 2015-02-12 05:37:56 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:37:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Controller Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:37:56 --> Email Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:37:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:37:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:37:56 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:37:56 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:37:56 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:57 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:57 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 05:37:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 05:37:57 --> Final output sent to browser
DEBUG - 2015-02-12 05:37:57 --> Total execution time: 1.3711
DEBUG - 2015-02-12 05:37:58 --> Config Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:37:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:37:58 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:37:58 --> URI Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Router Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Output Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Security Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Input Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:37:58 --> Language Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Loader Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:37:58 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:37:58 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:37:58 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Controller Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:37:58 --> Email Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:37:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:37:58 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:37:58 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:37:58 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:58 --> Model Class Initialized
DEBUG - 2015-02-12 05:37:59 --> Final output sent to browser
DEBUG - 2015-02-12 05:37:59 --> Total execution time: 0.8841
DEBUG - 2015-02-12 05:52:59 --> Config Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:52:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:52:59 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:52:59 --> URI Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Router Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Output Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Security Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Input Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:52:59 --> Language Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Loader Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:52:59 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Session: Regenerate ID
DEBUG - 2015-02-12 05:52:59 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:52:59 --> Model Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Model Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Controller Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:52:59 --> Email Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:52:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:52:59 --> Model Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:52:59 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:52:59 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:52:59 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:01 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:01 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 05:53:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 05:53:01 --> Final output sent to browser
DEBUG - 2015-02-12 05:53:01 --> Total execution time: 2.7473
DEBUG - 2015-02-12 05:53:02 --> Config Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Hooks Class Initialized
DEBUG - 2015-02-12 05:53:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 05:53:02 --> Utf8 Class Initialized
DEBUG - 2015-02-12 05:53:02 --> URI Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Router Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Output Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Security Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Input Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 05:53:02 --> Language Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Loader Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: url_helper
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: link_helper
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 05:53:02 --> CI_Session Class Initialized
DEBUG - 2015-02-12 05:53:02 --> CI_Session routines successfully run
DEBUG - 2015-02-12 05:53:02 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Controller Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 05:53:02 --> Email Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: language_helper
DEBUG - 2015-02-12 05:53:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 05:53:02 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Database Driver Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: date_helper
DEBUG - 2015-02-12 05:53:02 --> Helper loaded: form_helper
DEBUG - 2015-02-12 05:53:02 --> Form Validation Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:02 --> Model Class Initialized
DEBUG - 2015-02-12 05:53:03 --> Final output sent to browser
DEBUG - 2015-02-12 05:53:03 --> Total execution time: 0.8551
DEBUG - 2015-02-12 06:08:03 --> Config Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:08:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:08:03 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:08:03 --> URI Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Router Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Output Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Security Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Input Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:08:03 --> Language Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Loader Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:08:03 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Session: Regenerate ID
DEBUG - 2015-02-12 06:08:03 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:08:03 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Controller Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:08:03 --> Email Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:08:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:08:03 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:08:03 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:08:03 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:08:03 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:04 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:04 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 06:08:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 06:08:04 --> Final output sent to browser
DEBUG - 2015-02-12 06:08:04 --> Total execution time: 1.4081
DEBUG - 2015-02-12 06:08:05 --> Config Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:08:05 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:08:05 --> URI Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Router Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Output Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Security Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Input Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:08:05 --> Language Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Loader Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:08:05 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:08:05 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:08:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Controller Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:08:05 --> Email Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:08:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:08:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:08:05 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:08:05 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:08:06 --> Final output sent to browser
DEBUG - 2015-02-12 06:08:06 --> Total execution time: 0.9021
DEBUG - 2015-02-12 06:23:05 --> Config Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:23:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:23:05 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:23:05 --> URI Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Router Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Output Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Security Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Input Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:23:05 --> Language Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Loader Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:23:05 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:23:05 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:23:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:23:05 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Session: Regenerate ID
DEBUG - 2015-02-12 06:23:05 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:23:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Controller Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:23:05 --> Email Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:23:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:23:05 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:23:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:23:05 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:23:05 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:23:06 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:23:06 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:23:06 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:06 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:07 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 06:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 06:23:07 --> Final output sent to browser
DEBUG - 2015-02-12 06:23:07 --> Total execution time: 1.5052
DEBUG - 2015-02-12 06:23:08 --> Config Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:23:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:23:08 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:23:08 --> URI Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Router Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Output Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Security Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Input Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:23:08 --> Language Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Loader Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:23:08 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:23:08 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:23:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Controller Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:23:08 --> Email Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:23:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:23:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:23:08 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:23:08 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:23:08 --> Final output sent to browser
DEBUG - 2015-02-12 06:23:08 --> Total execution time: 0.9061
DEBUG - 2015-02-12 06:38:08 --> Config Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:38:08 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:38:08 --> URI Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Router Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Output Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Security Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Input Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:38:08 --> Language Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Loader Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:38:08 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Session: Regenerate ID
DEBUG - 2015-02-12 06:38:08 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:38:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Controller Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:38:08 --> Email Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:38:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:38:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:38:08 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:38:08 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:38:08 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:09 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:09 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 06:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 06:38:09 --> Final output sent to browser
DEBUG - 2015-02-12 06:38:09 --> Total execution time: 1.3561
DEBUG - 2015-02-12 06:38:10 --> Config Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:38:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:38:10 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:38:10 --> URI Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Router Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Output Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Security Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Input Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:38:10 --> Language Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Loader Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:38:10 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:38:10 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:38:10 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Controller Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:38:10 --> Email Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:38:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:38:10 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:38:10 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:38:10 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:10 --> Model Class Initialized
DEBUG - 2015-02-12 06:38:11 --> Final output sent to browser
DEBUG - 2015-02-12 06:38:11 --> Total execution time: 0.9941
DEBUG - 2015-02-12 06:53:11 --> Config Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:53:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:53:11 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:53:11 --> URI Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Router Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Output Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Security Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Input Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:53:11 --> Language Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Loader Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:53:11 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Session: Regenerate ID
DEBUG - 2015-02-12 06:53:11 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:53:11 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Controller Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:53:11 --> Email Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:53:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:53:11 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:53:11 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:53:11 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:53:11 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:12 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:12 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 06:53:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 06:53:12 --> Final output sent to browser
DEBUG - 2015-02-12 06:53:12 --> Total execution time: 1.3981
DEBUG - 2015-02-12 06:53:13 --> Config Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Hooks Class Initialized
DEBUG - 2015-02-12 06:53:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 06:53:13 --> Utf8 Class Initialized
DEBUG - 2015-02-12 06:53:13 --> URI Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Router Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Output Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Security Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Input Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 06:53:13 --> Language Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Loader Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: url_helper
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: link_helper
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 06:53:13 --> CI_Session Class Initialized
DEBUG - 2015-02-12 06:53:13 --> CI_Session routines successfully run
DEBUG - 2015-02-12 06:53:13 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Controller Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 06:53:13 --> Email Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: language_helper
DEBUG - 2015-02-12 06:53:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 06:53:13 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Database Driver Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: date_helper
DEBUG - 2015-02-12 06:53:13 --> Helper loaded: form_helper
DEBUG - 2015-02-12 06:53:13 --> Form Validation Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:13 --> Model Class Initialized
DEBUG - 2015-02-12 06:53:14 --> Final output sent to browser
DEBUG - 2015-02-12 06:53:14 --> Total execution time: 0.8801
DEBUG - 2015-02-12 07:08:14 --> Config Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:08:14 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:08:14 --> URI Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Router Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Output Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Security Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Input Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:08:14 --> Language Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Loader Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:08:14 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Session: Regenerate ID
DEBUG - 2015-02-12 07:08:14 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:08:14 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Controller Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:08:14 --> Email Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:08:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:08:14 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:08:14 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:08:14 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:08:14 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:15 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:15 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 07:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 07:08:15 --> Final output sent to browser
DEBUG - 2015-02-12 07:08:15 --> Total execution time: 1.3471
DEBUG - 2015-02-12 07:08:16 --> Config Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:08:16 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:08:16 --> URI Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Router Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Output Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Security Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Input Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:08:16 --> Language Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Loader Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:08:16 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:08:16 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:08:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Controller Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:08:16 --> Email Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:08:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:08:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:08:16 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:08:16 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:08:17 --> Final output sent to browser
DEBUG - 2015-02-12 07:08:17 --> Total execution time: 0.8851
DEBUG - 2015-02-12 07:23:16 --> Config Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:23:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:23:16 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:23:16 --> URI Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Router Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Output Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Security Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Input Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:23:16 --> Language Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Loader Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:23:16 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Session: Regenerate ID
DEBUG - 2015-02-12 07:23:16 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:23:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Controller Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:23:16 --> Email Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:23:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:23:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:23:16 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:23:16 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:23:16 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:17 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:17 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 07:23:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 07:23:17 --> Final output sent to browser
DEBUG - 2015-02-12 07:23:17 --> Total execution time: 1.3911
DEBUG - 2015-02-12 07:23:18 --> Config Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:23:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:23:18 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:23:18 --> URI Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Router Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Output Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Security Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Input Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:23:18 --> Language Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Loader Class Initialized
DEBUG - 2015-02-12 07:23:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:23:18 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:23:18 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:23:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:23:18 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:23:18 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:23:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Controller Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:23:19 --> Email Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:23:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:23:19 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:23:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:23:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:23:19 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:23:19 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:23:19 --> Final output sent to browser
DEBUG - 2015-02-12 07:23:19 --> Total execution time: 1.0131
DEBUG - 2015-02-12 07:38:19 --> Config Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:38:19 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:38:19 --> URI Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Router Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Output Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Security Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Input Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:38:19 --> Language Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Loader Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:38:19 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Session: Regenerate ID
DEBUG - 2015-02-12 07:38:19 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:38:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Controller Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:38:19 --> Email Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:38:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:38:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:38:19 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:38:19 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:38:19 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:20 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:20 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 07:38:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 07:38:20 --> Final output sent to browser
DEBUG - 2015-02-12 07:38:20 --> Total execution time: 1.5622
DEBUG - 2015-02-12 07:38:21 --> Config Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:38:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:38:21 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:38:21 --> URI Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Router Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Output Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Security Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Input Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:38:21 --> Language Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Loader Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:38:21 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:38:21 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:38:21 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Controller Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:38:21 --> Email Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:38:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:38:21 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:38:21 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:38:21 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:21 --> Model Class Initialized
DEBUG - 2015-02-12 07:38:22 --> Final output sent to browser
DEBUG - 2015-02-12 07:38:22 --> Total execution time: 0.9471
DEBUG - 2015-02-12 07:53:22 --> Config Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:53:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:53:22 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:53:22 --> URI Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Router Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Output Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Security Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Input Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:53:22 --> Language Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Loader Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:53:22 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Session: Regenerate ID
DEBUG - 2015-02-12 07:53:22 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:53:22 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Controller Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:53:22 --> Email Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:53:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:53:22 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:53:22 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:53:22 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:53:22 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:23 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:23 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 07:53:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 07:53:23 --> Final output sent to browser
DEBUG - 2015-02-12 07:53:23 --> Total execution time: 1.3421
DEBUG - 2015-02-12 07:53:24 --> Config Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Hooks Class Initialized
DEBUG - 2015-02-12 07:53:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 07:53:24 --> Utf8 Class Initialized
DEBUG - 2015-02-12 07:53:24 --> URI Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Router Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Output Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Security Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Input Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 07:53:24 --> Language Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Loader Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: url_helper
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: link_helper
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 07:53:24 --> CI_Session Class Initialized
DEBUG - 2015-02-12 07:53:24 --> CI_Session routines successfully run
DEBUG - 2015-02-12 07:53:24 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Controller Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 07:53:24 --> Email Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: language_helper
DEBUG - 2015-02-12 07:53:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 07:53:24 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Database Driver Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: date_helper
DEBUG - 2015-02-12 07:53:24 --> Helper loaded: form_helper
DEBUG - 2015-02-12 07:53:24 --> Form Validation Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:24 --> Model Class Initialized
DEBUG - 2015-02-12 07:53:25 --> Final output sent to browser
DEBUG - 2015-02-12 07:53:25 --> Total execution time: 0.9081
DEBUG - 2015-02-12 08:08:24 --> Config Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:08:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:08:24 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:08:24 --> URI Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Router Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Output Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Security Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Input Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:08:24 --> Language Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Loader Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:08:24 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Session: Regenerate ID
DEBUG - 2015-02-12 08:08:24 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:08:24 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Controller Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:08:24 --> Email Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:08:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:08:24 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:08:24 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:08:24 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:08:24 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:25 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:26 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 08:08:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 08:08:26 --> Final output sent to browser
DEBUG - 2015-02-12 08:08:26 --> Total execution time: 1.8352
DEBUG - 2015-02-12 08:08:27 --> Config Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:08:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:08:27 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:08:27 --> URI Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Router Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Output Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Security Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Input Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:08:27 --> Language Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Loader Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:08:27 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:08:27 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:08:27 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Controller Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:08:27 --> Email Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:08:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:08:27 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:08:27 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:08:27 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:27 --> Model Class Initialized
DEBUG - 2015-02-12 08:08:28 --> Final output sent to browser
DEBUG - 2015-02-12 08:08:28 --> Total execution time: 0.9801
DEBUG - 2015-02-12 08:23:29 --> Config Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:23:29 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:23:29 --> URI Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Router Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Output Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Security Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Input Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:23:29 --> Language Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Loader Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:23:29 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Session: Regenerate ID
DEBUG - 2015-02-12 08:23:29 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:23:29 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Controller Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:23:29 --> Email Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:23:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:23:29 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:23:29 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:23:29 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:23:29 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:30 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:30 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 08:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 08:23:30 --> Final output sent to browser
DEBUG - 2015-02-12 08:23:30 --> Total execution time: 1.4821
DEBUG - 2015-02-12 08:23:31 --> Config Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:23:31 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:23:31 --> URI Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Router Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Output Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Security Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Input Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:23:31 --> Language Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Loader Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:23:31 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:23:31 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:23:31 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Controller Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:23:31 --> Email Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:23:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:23:31 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:23:31 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:23:31 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:31 --> Model Class Initialized
DEBUG - 2015-02-12 08:23:32 --> Final output sent to browser
DEBUG - 2015-02-12 08:23:32 --> Total execution time: 1.0041
DEBUG - 2015-02-12 08:38:31 --> Config Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:38:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:38:31 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:38:31 --> URI Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Router Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Output Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Security Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Input Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:38:31 --> Language Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Loader Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:38:31 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:38:31 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:38:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:38:31 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:38:31 --> Session: Regenerate ID
DEBUG - 2015-02-12 08:38:31 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:38:32 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:32 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:32 --> Controller Class Initialized
DEBUG - 2015-02-12 08:38:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:38:32 --> Email Class Initialized
DEBUG - 2015-02-12 08:38:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:38:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:38:32 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:38:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:38:32 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:32 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:38:32 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:38:32 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:38:32 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:38:32 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:33 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:33 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 08:38:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 08:38:33 --> Final output sent to browser
DEBUG - 2015-02-12 08:38:33 --> Total execution time: 1.4271
DEBUG - 2015-02-12 08:38:34 --> Config Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:38:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:38:34 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:38:34 --> URI Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Router Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Output Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Security Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Input Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:38:34 --> Language Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Loader Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:38:34 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:38:34 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:38:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Controller Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:38:34 --> Email Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:38:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:38:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:38:34 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:38:34 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:38:35 --> Final output sent to browser
DEBUG - 2015-02-12 08:38:35 --> Total execution time: 0.8731
DEBUG - 2015-02-12 08:53:34 --> Config Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:53:34 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:53:34 --> URI Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Router Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Output Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Security Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Input Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:53:34 --> Language Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Loader Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:53:34 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Session: Regenerate ID
DEBUG - 2015-02-12 08:53:34 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:53:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Controller Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:53:34 --> Email Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:53:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:53:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:53:34 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:53:34 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:53:34 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:35 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:35 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 08:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 08:53:35 --> Final output sent to browser
DEBUG - 2015-02-12 08:53:35 --> Total execution time: 1.3411
DEBUG - 2015-02-12 08:53:36 --> Config Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Hooks Class Initialized
DEBUG - 2015-02-12 08:53:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 08:53:36 --> Utf8 Class Initialized
DEBUG - 2015-02-12 08:53:36 --> URI Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Router Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Output Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Security Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Input Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 08:53:36 --> Language Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Loader Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: url_helper
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: link_helper
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 08:53:36 --> CI_Session Class Initialized
DEBUG - 2015-02-12 08:53:36 --> CI_Session routines successfully run
DEBUG - 2015-02-12 08:53:36 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Controller Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 08:53:36 --> Email Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: language_helper
DEBUG - 2015-02-12 08:53:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 08:53:36 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Database Driver Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: date_helper
DEBUG - 2015-02-12 08:53:36 --> Helper loaded: form_helper
DEBUG - 2015-02-12 08:53:36 --> Form Validation Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:36 --> Model Class Initialized
DEBUG - 2015-02-12 08:53:37 --> Final output sent to browser
DEBUG - 2015-02-12 08:53:37 --> Total execution time: 0.9171
DEBUG - 2015-02-12 09:08:37 --> Config Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:08:37 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:08:37 --> URI Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Router Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Output Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Security Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Input Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:08:37 --> Language Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Loader Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:08:37 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Session: Regenerate ID
DEBUG - 2015-02-12 09:08:37 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:08:37 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Controller Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:08:37 --> Email Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:08:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:08:37 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:08:37 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:08:37 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:08:37 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:38 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:38 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 09:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 09:08:38 --> Final output sent to browser
DEBUG - 2015-02-12 09:08:38 --> Total execution time: 1.4521
DEBUG - 2015-02-12 09:08:39 --> Config Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:08:39 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:08:39 --> URI Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Router Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Output Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Security Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Input Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:08:39 --> Language Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Loader Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:08:39 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:08:39 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:08:39 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Controller Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:08:39 --> Email Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:08:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:08:39 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:08:39 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:08:39 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:39 --> Model Class Initialized
DEBUG - 2015-02-12 09:08:40 --> Final output sent to browser
DEBUG - 2015-02-12 09:08:40 --> Total execution time: 0.9281
DEBUG - 2015-02-12 09:23:40 --> Config Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:23:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:23:40 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:23:40 --> URI Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Router Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Output Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Security Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Input Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:23:40 --> Language Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Loader Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:23:40 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Session: Regenerate ID
DEBUG - 2015-02-12 09:23:40 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:23:40 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Controller Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:23:40 --> Email Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:23:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:23:40 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:23:40 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:23:40 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:23:40 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:41 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:41 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 09:23:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 09:23:41 --> Final output sent to browser
DEBUG - 2015-02-12 09:23:41 --> Total execution time: 1.6512
DEBUG - 2015-02-12 09:23:42 --> Config Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:23:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:23:42 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:23:42 --> URI Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Router Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Output Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Security Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Input Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:23:42 --> Language Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Loader Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:23:42 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:23:42 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:23:42 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Controller Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:23:42 --> Email Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:23:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:23:42 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:23:42 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:23:42 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:42 --> Model Class Initialized
DEBUG - 2015-02-12 09:23:43 --> Final output sent to browser
DEBUG - 2015-02-12 09:23:43 --> Total execution time: 0.9501
DEBUG - 2015-02-12 09:38:42 --> Config Class Initialized
DEBUG - 2015-02-12 09:38:42 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:38:43 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:38:43 --> URI Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Router Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Output Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Security Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Input Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:38:43 --> Language Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Loader Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:38:43 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Session: Regenerate ID
DEBUG - 2015-02-12 09:38:43 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:38:43 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Controller Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:38:43 --> Email Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:38:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:38:43 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:38:43 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:38:43 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:38:43 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:44 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:44 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 09:38:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 09:38:44 --> Final output sent to browser
DEBUG - 2015-02-12 09:38:44 --> Total execution time: 1.6222
DEBUG - 2015-02-12 09:38:45 --> Config Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:38:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:38:45 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:38:45 --> URI Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Router Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Output Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Security Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Input Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:38:45 --> Language Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Loader Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:38:45 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:38:45 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:38:45 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Controller Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:38:45 --> Email Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:38:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:38:45 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:38:45 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:38:45 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:45 --> Model Class Initialized
DEBUG - 2015-02-12 09:38:46 --> Final output sent to browser
DEBUG - 2015-02-12 09:38:46 --> Total execution time: 1.0141
DEBUG - 2015-02-12 09:53:45 --> Config Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:53:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:53:45 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:53:45 --> URI Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Router Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Output Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Security Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Input Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:53:45 --> Language Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Loader Class Initialized
DEBUG - 2015-02-12 09:53:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:53:46 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:53:46 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:53:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:53:46 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Session: Regenerate ID
DEBUG - 2015-02-12 09:53:46 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:53:46 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Controller Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:53:46 --> Email Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:53:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:53:46 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:53:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:53:46 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:53:46 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:53:46 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:53:46 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:47 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:47 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 09:53:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 09:53:47 --> Final output sent to browser
DEBUG - 2015-02-12 09:53:47 --> Total execution time: 1.4811
DEBUG - 2015-02-12 09:53:48 --> Config Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Hooks Class Initialized
DEBUG - 2015-02-12 09:53:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 09:53:48 --> Utf8 Class Initialized
DEBUG - 2015-02-12 09:53:48 --> URI Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Router Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Output Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Security Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Input Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 09:53:48 --> Language Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Loader Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: url_helper
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: link_helper
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 09:53:48 --> CI_Session Class Initialized
DEBUG - 2015-02-12 09:53:48 --> CI_Session routines successfully run
DEBUG - 2015-02-12 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Controller Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 09:53:48 --> Email Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: language_helper
DEBUG - 2015-02-12 09:53:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Database Driver Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: date_helper
DEBUG - 2015-02-12 09:53:48 --> Helper loaded: form_helper
DEBUG - 2015-02-12 09:53:48 --> Form Validation Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-12 09:53:49 --> Final output sent to browser
DEBUG - 2015-02-12 09:53:49 --> Total execution time: 0.9371
DEBUG - 2015-02-12 10:08:48 --> Config Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:08:48 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:08:48 --> URI Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Router Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Output Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Security Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Input Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:08:48 --> Language Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Loader Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:08:48 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Session: Regenerate ID
DEBUG - 2015-02-12 10:08:48 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:08:48 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Controller Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:08:48 --> Email Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:08:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:08:48 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:08:48 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:08:48 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:08:48 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:50 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:50 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 10:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 10:08:50 --> Final output sent to browser
DEBUG - 2015-02-12 10:08:50 --> Total execution time: 1.6382
DEBUG - 2015-02-12 10:08:51 --> Config Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:08:51 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:08:51 --> URI Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Router Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Output Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Security Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Input Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:08:51 --> Language Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Loader Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:08:51 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:08:51 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:08:51 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Controller Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:08:51 --> Email Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:08:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:08:51 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:08:51 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:08:51 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:51 --> Model Class Initialized
DEBUG - 2015-02-12 10:08:52 --> Final output sent to browser
DEBUG - 2015-02-12 10:08:52 --> Total execution time: 1.1001
DEBUG - 2015-02-12 10:23:51 --> Config Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:23:51 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:23:51 --> URI Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Router Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Output Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Security Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Input Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:23:51 --> Language Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Loader Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:23:51 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:23:51 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:23:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:23:51 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Session: Regenerate ID
DEBUG - 2015-02-12 10:23:51 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:23:51 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Controller Class Initialized
DEBUG - 2015-02-12 10:23:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:23:52 --> Email Class Initialized
DEBUG - 2015-02-12 10:23:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:23:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:23:52 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:23:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:23:52 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:52 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:23:52 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:23:52 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:23:52 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:23:52 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:52 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:53 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 10:23:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 10:23:53 --> Final output sent to browser
DEBUG - 2015-02-12 10:23:53 --> Total execution time: 1.5212
DEBUG - 2015-02-12 10:23:54 --> Config Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:23:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:23:54 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:23:54 --> URI Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Router Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Output Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Security Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Input Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:23:54 --> Language Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Loader Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:23:54 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:23:54 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:23:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Controller Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:23:54 --> Email Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:23:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:23:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:23:54 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:23:54 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:23:55 --> Final output sent to browser
DEBUG - 2015-02-12 10:23:55 --> Total execution time: 0.9861
DEBUG - 2015-02-12 10:38:54 --> Config Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:38:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:38:54 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:38:54 --> URI Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Router Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Output Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Security Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Input Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:38:54 --> Language Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Loader Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:38:54 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Session: Regenerate ID
DEBUG - 2015-02-12 10:38:54 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:38:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Controller Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:38:54 --> Email Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:38:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:38:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:38:54 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:38:54 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:38:54 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:55 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:55 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 10:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 10:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 10:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 10:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 10:38:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 10:38:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 10:38:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 10:38:56 --> Final output sent to browser
DEBUG - 2015-02-12 10:38:56 --> Total execution time: 1.5402
DEBUG - 2015-02-12 10:38:57 --> Config Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:38:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:38:57 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:38:57 --> URI Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Router Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Output Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Security Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Input Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:38:57 --> Language Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Loader Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:38:57 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:38:57 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:38:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Controller Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:38:57 --> Email Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:38:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:38:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:38:57 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:38:57 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:38:58 --> Final output sent to browser
DEBUG - 2015-02-12 10:38:58 --> Total execution time: 1.0401
DEBUG - 2015-02-12 10:53:57 --> Config Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:53:57 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:53:57 --> URI Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Router Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Output Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Security Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Input Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:53:57 --> Language Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Loader Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:53:57 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Session: Regenerate ID
DEBUG - 2015-02-12 10:53:57 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:53:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Controller Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:53:57 --> Email Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:53:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:53:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:53:57 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:53:57 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:53:57 --> Model Class Initialized
DEBUG - 2015-02-12 10:53:59 --> Model Class Initialized
DEBUG - 2015-02-12 10:53:59 --> Model Class Initialized
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 10:53:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 10:53:59 --> Final output sent to browser
DEBUG - 2015-02-12 10:53:59 --> Total execution time: 1.9762
DEBUG - 2015-02-12 10:54:01 --> Config Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Hooks Class Initialized
DEBUG - 2015-02-12 10:54:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 10:54:01 --> Utf8 Class Initialized
DEBUG - 2015-02-12 10:54:01 --> URI Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Router Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Output Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Security Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Input Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 10:54:01 --> Language Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Loader Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: url_helper
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: link_helper
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 10:54:01 --> CI_Session Class Initialized
DEBUG - 2015-02-12 10:54:01 --> CI_Session routines successfully run
DEBUG - 2015-02-12 10:54:01 --> Model Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Model Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Controller Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 10:54:01 --> Email Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: language_helper
DEBUG - 2015-02-12 10:54:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 10:54:01 --> Model Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Database Driver Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: date_helper
DEBUG - 2015-02-12 10:54:01 --> Helper loaded: form_helper
DEBUG - 2015-02-12 10:54:01 --> Form Validation Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Model Class Initialized
DEBUG - 2015-02-12 10:54:01 --> Model Class Initialized
DEBUG - 2015-02-12 10:54:02 --> Final output sent to browser
DEBUG - 2015-02-12 10:54:02 --> Total execution time: 1.0241
DEBUG - 2015-02-12 11:09:01 --> Config Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:09:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:09:01 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:09:01 --> URI Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Router Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Output Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Security Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Input Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:09:01 --> Language Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Loader Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:09:01 --> CI_Session Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Session: Regenerate ID
DEBUG - 2015-02-12 11:09:01 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:09:01 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Controller Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:09:01 --> Email Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:09:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:09:01 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:09:01 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:09:01 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:09:01 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:02 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:02 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 11:09:02 --> Final output sent to browser
DEBUG - 2015-02-12 11:09:02 --> Total execution time: 1.4901
DEBUG - 2015-02-12 11:09:03 --> Config Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:09:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:09:03 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:09:03 --> URI Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Router Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Output Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Security Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Input Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:09:03 --> Language Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Loader Class Initialized
DEBUG - 2015-02-12 11:09:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:09:03 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:09:03 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:09:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:09:03 --> CI_Session Class Initialized
DEBUG - 2015-02-12 11:09:03 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Controller Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:09:04 --> Email Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:09:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:09:04 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:09:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:09:04 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:09:04 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:09:04 --> Final output sent to browser
DEBUG - 2015-02-12 11:09:04 --> Total execution time: 1.0341
DEBUG - 2015-02-12 11:24:04 --> Config Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:24:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:24:04 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:24:04 --> URI Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Router Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Output Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Security Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Input Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:24:04 --> Language Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Loader Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:24:04 --> CI_Session Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Session: Regenerate ID
DEBUG - 2015-02-12 11:24:04 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Controller Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:24:04 --> Email Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:24:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:24:04 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:24:04 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:05 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:05 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 11:24:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 11:24:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 11:24:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 11:24:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 11:24:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 11:24:06 --> Final output sent to browser
DEBUG - 2015-02-12 11:24:06 --> Total execution time: 1.8264
DEBUG - 2015-02-12 11:24:10 --> Config Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:24:10 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:24:10 --> URI Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Router Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Output Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Security Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Input Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:24:10 --> Language Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Loader Class Initialized
DEBUG - 2015-02-12 11:24:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:24:10 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:24:10 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:24:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:24:10 --> CI_Session Class Initialized
DEBUG - 2015-02-12 11:24:10 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:24:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Controller Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:24:11 --> Email Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:24:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:24:11 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:24:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:24:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:24:11 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:24:11 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:24:11 --> Final output sent to browser
DEBUG - 2015-02-12 11:24:11 --> Total execution time: 1.0046
DEBUG - 2015-02-12 11:39:10 --> Config Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:39:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:39:10 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:39:10 --> URI Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Router Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Output Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Security Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Input Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:39:10 --> Language Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Loader Class Initialized
DEBUG - 2015-02-12 11:39:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:39:10 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:39:10 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:39:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:39:10 --> CI_Session Class Initialized
ERROR - 2015-02-12 11:39:10 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-12 11:39:10 --> Session: Creating new session (c64dab344ebc14d39f924f04b759783f)
DEBUG - 2015-02-12 11:39:10 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:39:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:11 --> Controller Class Initialized
DEBUG - 2015-02-12 11:39:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:39:11 --> Email Class Initialized
DEBUG - 2015-02-12 11:39:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:39:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:39:11 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:39:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:39:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:11 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:39:11 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:39:11 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:39:11 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:39:11 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:12 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:12 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 11:39:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 11:39:12 --> Final output sent to browser
DEBUG - 2015-02-12 11:39:12 --> Total execution time: 1.4810
DEBUG - 2015-02-12 11:39:13 --> Config Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:39:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:39:13 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:39:13 --> URI Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Router Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Output Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Security Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Input Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:39:13 --> Language Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Loader Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:39:13 --> CI_Session Class Initialized
DEBUG - 2015-02-12 11:39:13 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:39:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Controller Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:39:13 --> Email Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:39:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:39:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:39:13 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:39:13 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:39:14 --> Final output sent to browser
DEBUG - 2015-02-12 11:39:14 --> Total execution time: 0.9970
DEBUG - 2015-02-12 11:54:13 --> Config Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:54:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:54:13 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:54:13 --> URI Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Router Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Output Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Security Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Input Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:54:13 --> Language Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Loader Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:54:13 --> CI_Session Class Initialized
ERROR - 2015-02-12 11:54:13 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-12 11:54:13 --> Session: Creating new session (8581752a1b3ee4c0d523980b4249d80f)
DEBUG - 2015-02-12 11:54:13 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:54:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Controller Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:54:13 --> Email Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:54:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:54:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:54:13 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:54:13 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:54:13 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:14 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:14 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 11:54:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 11:54:14 --> Final output sent to browser
DEBUG - 2015-02-12 11:54:14 --> Total execution time: 1.2811
DEBUG - 2015-02-12 11:54:15 --> Config Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Hooks Class Initialized
DEBUG - 2015-02-12 11:54:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 11:54:15 --> Utf8 Class Initialized
DEBUG - 2015-02-12 11:54:15 --> URI Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Router Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Output Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Security Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Input Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 11:54:15 --> Language Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Loader Class Initialized
DEBUG - 2015-02-12 11:54:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 11:54:15 --> Helper loaded: url_helper
DEBUG - 2015-02-12 11:54:15 --> Helper loaded: link_helper
DEBUG - 2015-02-12 11:54:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 11:54:15 --> CI_Session Class Initialized
DEBUG - 2015-02-12 11:54:15 --> CI_Session routines successfully run
DEBUG - 2015-02-12 11:54:15 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Controller Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 11:54:16 --> Email Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 11:54:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 11:54:16 --> Helper loaded: language_helper
DEBUG - 2015-02-12 11:54:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 11:54:16 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Database Driver Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Helper loaded: date_helper
DEBUG - 2015-02-12 11:54:16 --> Helper loaded: form_helper
DEBUG - 2015-02-12 11:54:16 --> Form Validation Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Model Class Initialized
DEBUG - 2015-02-12 11:54:16 --> Final output sent to browser
DEBUG - 2015-02-12 11:54:16 --> Total execution time: 1.0071
DEBUG - 2015-02-12 12:09:16 --> Config Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Hooks Class Initialized
DEBUG - 2015-02-12 12:09:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 12:09:16 --> Utf8 Class Initialized
DEBUG - 2015-02-12 12:09:16 --> URI Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Router Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Output Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Security Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Input Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 12:09:16 --> Language Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Loader Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: url_helper
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: link_helper
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 12:09:16 --> CI_Session Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Session: Regenerate ID
DEBUG - 2015-02-12 12:09:16 --> CI_Session routines successfully run
DEBUG - 2015-02-12 12:09:16 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Controller Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 12:09:16 --> Email Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: language_helper
DEBUG - 2015-02-12 12:09:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 12:09:16 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Database Driver Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: date_helper
DEBUG - 2015-02-12 12:09:16 --> Helper loaded: form_helper
DEBUG - 2015-02-12 12:09:16 --> Form Validation Class Initialized
DEBUG - 2015-02-12 12:09:16 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:17 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:17 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 12:09:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 12:09:17 --> Final output sent to browser
DEBUG - 2015-02-12 12:09:17 --> Total execution time: 1.2411
DEBUG - 2015-02-12 12:09:18 --> Config Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Hooks Class Initialized
DEBUG - 2015-02-12 12:09:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 12:09:18 --> Utf8 Class Initialized
DEBUG - 2015-02-12 12:09:18 --> URI Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Router Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Output Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Security Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Input Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 12:09:18 --> Language Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Loader Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: url_helper
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: link_helper
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 12:09:18 --> CI_Session Class Initialized
DEBUG - 2015-02-12 12:09:18 --> CI_Session routines successfully run
DEBUG - 2015-02-12 12:09:18 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Controller Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 12:09:18 --> Email Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: language_helper
DEBUG - 2015-02-12 12:09:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 12:09:18 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Database Driver Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: date_helper
DEBUG - 2015-02-12 12:09:18 --> Helper loaded: form_helper
DEBUG - 2015-02-12 12:09:18 --> Form Validation Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:18 --> Model Class Initialized
DEBUG - 2015-02-12 12:09:19 --> Final output sent to browser
DEBUG - 2015-02-12 12:09:19 --> Total execution time: 1.2111
DEBUG - 2015-02-12 12:24:19 --> Config Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Hooks Class Initialized
DEBUG - 2015-02-12 12:24:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 12:24:19 --> Utf8 Class Initialized
DEBUG - 2015-02-12 12:24:19 --> URI Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Router Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Output Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Security Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Input Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 12:24:19 --> Language Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Loader Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: url_helper
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: link_helper
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 12:24:19 --> CI_Session Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Session: Regenerate ID
DEBUG - 2015-02-12 12:24:19 --> CI_Session routines successfully run
DEBUG - 2015-02-12 12:24:19 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Controller Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 12:24:19 --> Email Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: language_helper
DEBUG - 2015-02-12 12:24:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 12:24:19 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Database Driver Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: date_helper
DEBUG - 2015-02-12 12:24:19 --> Helper loaded: form_helper
DEBUG - 2015-02-12 12:24:19 --> Form Validation Class Initialized
DEBUG - 2015-02-12 12:24:19 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:20 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:20 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-12 12:24:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-12 12:24:20 --> Final output sent to browser
DEBUG - 2015-02-12 12:24:20 --> Total execution time: 1.4741
DEBUG - 2015-02-12 12:24:21 --> Config Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Hooks Class Initialized
DEBUG - 2015-02-12 12:24:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-12 12:24:21 --> Utf8 Class Initialized
DEBUG - 2015-02-12 12:24:21 --> URI Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Router Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Output Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Security Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Input Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-12 12:24:21 --> Language Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Loader Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: url_helper
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: link_helper
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-12 12:24:21 --> CI_Session Class Initialized
DEBUG - 2015-02-12 12:24:21 --> CI_Session routines successfully run
DEBUG - 2015-02-12 12:24:21 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Controller Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-12 12:24:21 --> Email Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: language_helper
DEBUG - 2015-02-12 12:24:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-12 12:24:21 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Database Driver Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: date_helper
DEBUG - 2015-02-12 12:24:21 --> Helper loaded: form_helper
DEBUG - 2015-02-12 12:24:21 --> Form Validation Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:21 --> Model Class Initialized
DEBUG - 2015-02-12 12:24:22 --> Final output sent to browser
DEBUG - 2015-02-12 12:24:22 --> Total execution time: 0.9841
