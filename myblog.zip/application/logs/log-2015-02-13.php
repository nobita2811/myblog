<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-13 13:42:24 --> Config Class Initialized
DEBUG - 2015-02-13 13:42:24 --> Hooks Class Initialized
DEBUG - 2015-02-13 13:42:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 13:42:25 --> Utf8 Class Initialized
DEBUG - 2015-02-13 13:42:25 --> URI Class Initialized
DEBUG - 2015-02-13 13:42:25 --> No URI present. Default controller set.
DEBUG - 2015-02-13 13:42:25 --> Router Class Initialized
DEBUG - 2015-02-13 13:42:25 --> Output Class Initialized
DEBUG - 2015-02-13 13:42:25 --> Security Class Initialized
DEBUG - 2015-02-13 13:42:25 --> Input Class Initialized
DEBUG - 2015-02-13 13:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 13:42:25 --> Language Class Initialized
DEBUG - 2015-02-13 13:42:25 --> Loader Class Initialized
DEBUG - 2015-02-13 13:42:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 13:42:25 --> Helper loaded: url_helper
DEBUG - 2015-02-13 13:42:25 --> Helper loaded: link_helper
DEBUG - 2015-02-13 13:42:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 13:42:25 --> CI_Session Class Initialized
ERROR - 2015-02-13 13:42:29 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-13 13:42:29 --> Session: Creating new session (2ffd90d14437329ca0c661338bca73d6)
DEBUG - 2015-02-13 13:42:29 --> CI_Session routines successfully run
DEBUG - 2015-02-13 13:42:31 --> Model Class Initialized
DEBUG - 2015-02-13 13:42:31 --> Model Class Initialized
DEBUG - 2015-02-13 13:42:31 --> Controller Class Initialized
DEBUG - 2015-02-13 13:42:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 13:42:32 --> Email Class Initialized
DEBUG - 2015-02-13 13:42:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 13:42:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 13:42:32 --> Helper loaded: language_helper
DEBUG - 2015-02-13 13:42:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 13:42:32 --> Model Class Initialized
DEBUG - 2015-02-13 13:42:32 --> Database Driver Class Initialized
DEBUG - 2015-02-13 13:42:34 --> Helper loaded: date_helper
DEBUG - 2015-02-13 13:42:34 --> Helper loaded: form_helper
DEBUG - 2015-02-13 13:42:34 --> Form Validation Class Initialized
DEBUG - 2015-02-13 13:42:34 --> Model Class Initialized
DEBUG - 2015-02-13 13:42:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-13 13:42:34 --> Pagination Class Initialized
DEBUG - 2015-02-13 13:42:43 --> Model Class Initialized
DEBUG - 2015-02-13 13:42:46 --> Model Class Initialized
DEBUG - 2015-02-13 13:42:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-13 13:42:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-13 13:42:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-13 13:42:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-13 13:42:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-13 13:42:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-13 13:42:50 --> Final output sent to browser
DEBUG - 2015-02-13 13:42:50 --> Total execution time: 26.7117
DEBUG - 2015-02-13 13:45:09 --> Config Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Hooks Class Initialized
DEBUG - 2015-02-13 13:45:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 13:45:09 --> Utf8 Class Initialized
DEBUG - 2015-02-13 13:45:09 --> URI Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Router Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Output Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Security Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Input Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 13:45:09 --> Language Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Loader Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 13:45:09 --> Helper loaded: url_helper
DEBUG - 2015-02-13 13:45:09 --> Helper loaded: link_helper
DEBUG - 2015-02-13 13:45:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 13:45:09 --> CI_Session Class Initialized
DEBUG - 2015-02-13 13:45:09 --> CI_Session routines successfully run
DEBUG - 2015-02-13 13:45:09 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Controller Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 13:45:09 --> Email Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 13:45:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 13:45:09 --> Helper loaded: language_helper
DEBUG - 2015-02-13 13:45:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 13:45:09 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:09 --> Database Driver Class Initialized
DEBUG - 2015-02-13 13:45:10 --> Helper loaded: date_helper
DEBUG - 2015-02-13 13:45:10 --> Helper loaded: form_helper
DEBUG - 2015-02-13 13:45:10 --> Form Validation Class Initialized
DEBUG - 2015-02-13 13:45:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-13 13:45:10 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-13 13:45:10 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-13 13:45:10 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:10 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:11 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-13 13:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-13 13:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-13 13:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-13 13:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-13 13:45:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-13 13:45:11 --> Final output sent to browser
DEBUG - 2015-02-13 13:45:11 --> Total execution time: 1.9812
DEBUG - 2015-02-13 13:45:25 --> Config Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Hooks Class Initialized
DEBUG - 2015-02-13 13:45:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 13:45:25 --> Utf8 Class Initialized
DEBUG - 2015-02-13 13:45:25 --> URI Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Router Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Output Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Security Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Input Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 13:45:25 --> Language Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Loader Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: url_helper
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: link_helper
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 13:45:25 --> CI_Session Class Initialized
DEBUG - 2015-02-13 13:45:25 --> CI_Session routines successfully run
DEBUG - 2015-02-13 13:45:25 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Controller Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 13:45:25 --> Email Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: language_helper
DEBUG - 2015-02-13 13:45:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 13:45:25 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Database Driver Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: date_helper
DEBUG - 2015-02-13 13:45:25 --> Helper loaded: form_helper
DEBUG - 2015-02-13 13:45:25 --> Form Validation Class Initialized
DEBUG - 2015-02-13 13:45:25 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-13 13:45:25 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-13 13:45:25 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-13 13:45:25 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-13 13:45:27 --> Config Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Hooks Class Initialized
DEBUG - 2015-02-13 13:45:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 13:45:27 --> Utf8 Class Initialized
DEBUG - 2015-02-13 13:45:27 --> URI Class Initialized
DEBUG - 2015-02-13 13:45:27 --> No URI present. Default controller set.
DEBUG - 2015-02-13 13:45:27 --> Router Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Output Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Security Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Input Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 13:45:27 --> Language Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Loader Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: url_helper
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: link_helper
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 13:45:27 --> CI_Session Class Initialized
DEBUG - 2015-02-13 13:45:27 --> CI_Session routines successfully run
DEBUG - 2015-02-13 13:45:27 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Controller Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 13:45:27 --> Email Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: language_helper
DEBUG - 2015-02-13 13:45:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 13:45:27 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Database Driver Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: date_helper
DEBUG - 2015-02-13 13:45:27 --> Helper loaded: form_helper
DEBUG - 2015-02-13 13:45:27 --> Form Validation Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-13 13:45:27 --> Pagination Class Initialized
DEBUG - 2015-02-13 13:45:27 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:28 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-13 13:45:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-13 13:45:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-13 13:45:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-13 13:45:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-13 13:45:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-13 13:45:29 --> Final output sent to browser
DEBUG - 2015-02-13 13:45:29 --> Total execution time: 2.5903
DEBUG - 2015-02-13 13:45:33 --> Config Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Hooks Class Initialized
DEBUG - 2015-02-13 13:45:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 13:45:33 --> Utf8 Class Initialized
DEBUG - 2015-02-13 13:45:33 --> URI Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Router Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Output Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Security Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Input Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 13:45:33 --> Language Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Loader Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: url_helper
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: link_helper
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 13:45:33 --> CI_Session Class Initialized
DEBUG - 2015-02-13 13:45:33 --> CI_Session routines successfully run
DEBUG - 2015-02-13 13:45:33 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Controller Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 13:45:33 --> Email Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: language_helper
DEBUG - 2015-02-13 13:45:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 13:45:33 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Database Driver Class Initialized
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: date_helper
DEBUG - 2015-02-13 13:45:33 --> Helper loaded: form_helper
DEBUG - 2015-02-13 13:45:33 --> Form Validation Class Initialized
DEBUG - 2015-02-13 13:45:34 --> Model Class Initialized
DEBUG - 2015-02-13 13:45:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 13:45:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 13:45:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-13 13:45:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 13:45:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 13:45:34 --> Final output sent to browser
DEBUG - 2015-02-13 13:45:34 --> Total execution time: 0.7481
DEBUG - 2015-02-13 13:47:20 --> Config Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Hooks Class Initialized
DEBUG - 2015-02-13 13:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 13:47:20 --> Utf8 Class Initialized
DEBUG - 2015-02-13 13:47:20 --> URI Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Router Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Output Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Security Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Input Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 13:47:20 --> Language Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Loader Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: url_helper
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: link_helper
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 13:47:20 --> CI_Session Class Initialized
DEBUG - 2015-02-13 13:47:20 --> CI_Session routines successfully run
DEBUG - 2015-02-13 13:47:20 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Controller Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 13:47:20 --> Email Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: language_helper
DEBUG - 2015-02-13 13:47:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 13:47:20 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Database Driver Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: date_helper
DEBUG - 2015-02-13 13:47:20 --> Helper loaded: form_helper
DEBUG - 2015-02-13 13:47:20 --> Form Validation Class Initialized
DEBUG - 2015-02-13 13:47:20 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 13:47:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 13:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-13 13:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 13:47:21 --> Final output sent to browser
DEBUG - 2015-02-13 13:47:21 --> Total execution time: 0.5731
DEBUG - 2015-02-13 13:47:36 --> Config Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Hooks Class Initialized
DEBUG - 2015-02-13 13:47:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 13:47:36 --> Utf8 Class Initialized
DEBUG - 2015-02-13 13:47:36 --> URI Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Router Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Output Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Security Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Input Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 13:47:36 --> Language Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Loader Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: url_helper
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: link_helper
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 13:47:36 --> CI_Session Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Session: Regenerate ID
DEBUG - 2015-02-13 13:47:36 --> CI_Session routines successfully run
DEBUG - 2015-02-13 13:47:36 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Controller Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 13:47:36 --> Email Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: language_helper
DEBUG - 2015-02-13 13:47:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 13:47:36 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Database Driver Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: date_helper
DEBUG - 2015-02-13 13:47:36 --> Helper loaded: form_helper
DEBUG - 2015-02-13 13:47:36 --> Form Validation Class Initialized
DEBUG - 2015-02-13 13:47:36 --> Model Class Initialized
DEBUG - 2015-02-13 13:47:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 13:47:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 13:47:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-13 13:47:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 13:47:49 --> Final output sent to browser
DEBUG - 2015-02-13 13:47:49 --> Total execution time: 12.6863
DEBUG - 2015-02-13 14:50:11 --> Config Class Initialized
DEBUG - 2015-02-13 14:50:11 --> Hooks Class Initialized
DEBUG - 2015-02-13 14:50:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 14:50:11 --> Utf8 Class Initialized
DEBUG - 2015-02-13 14:50:11 --> URI Class Initialized
DEBUG - 2015-02-13 14:50:11 --> No URI present. Default controller set.
DEBUG - 2015-02-13 14:50:11 --> Router Class Initialized
DEBUG - 2015-02-13 14:50:11 --> Output Class Initialized
DEBUG - 2015-02-13 14:50:11 --> Security Class Initialized
DEBUG - 2015-02-13 14:50:11 --> Input Class Initialized
DEBUG - 2015-02-13 14:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 14:50:11 --> Language Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Loader Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: url_helper
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: link_helper
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 14:50:12 --> CI_Session Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Session: Regenerate ID
DEBUG - 2015-02-13 14:50:12 --> CI_Session routines successfully run
DEBUG - 2015-02-13 14:50:12 --> Model Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Model Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Controller Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 14:50:12 --> Email Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: language_helper
DEBUG - 2015-02-13 14:50:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 14:50:12 --> Model Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Database Driver Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: date_helper
DEBUG - 2015-02-13 14:50:12 --> Helper loaded: form_helper
DEBUG - 2015-02-13 14:50:12 --> Form Validation Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Model Class Initialized
DEBUG - 2015-02-13 14:50:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-13 14:50:12 --> Pagination Class Initialized
DEBUG - 2015-02-13 14:50:13 --> Model Class Initialized
DEBUG - 2015-02-13 14:50:13 --> Model Class Initialized
DEBUG - 2015-02-13 14:50:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-13 14:50:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-13 14:50:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-13 14:50:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-13 14:50:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-13 14:50:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-13 14:50:14 --> Final output sent to browser
DEBUG - 2015-02-13 14:50:14 --> Total execution time: 3.0445
DEBUG - 2015-02-13 14:59:14 --> Config Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Hooks Class Initialized
DEBUG - 2015-02-13 14:59:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 14:59:14 --> Utf8 Class Initialized
DEBUG - 2015-02-13 14:59:14 --> URI Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Router Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Output Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Security Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Input Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 14:59:14 --> Language Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Loader Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: url_helper
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: link_helper
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 14:59:14 --> CI_Session Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Session: Regenerate ID
DEBUG - 2015-02-13 14:59:14 --> CI_Session routines successfully run
DEBUG - 2015-02-13 14:59:14 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Controller Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 14:59:14 --> Email Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: language_helper
DEBUG - 2015-02-13 14:59:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 14:59:14 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Database Driver Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: date_helper
DEBUG - 2015-02-13 14:59:14 --> Helper loaded: form_helper
DEBUG - 2015-02-13 14:59:14 --> Form Validation Class Initialized
DEBUG - 2015-02-13 14:59:14 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 14:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 14:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-13 14:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 14:59:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 14:59:15 --> Final output sent to browser
DEBUG - 2015-02-13 14:59:15 --> Total execution time: 0.5731
DEBUG - 2015-02-13 14:59:23 --> Config Class Initialized
DEBUG - 2015-02-13 14:59:23 --> Hooks Class Initialized
DEBUG - 2015-02-13 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 14:59:23 --> Utf8 Class Initialized
DEBUG - 2015-02-13 14:59:23 --> URI Class Initialized
DEBUG - 2015-02-13 14:59:23 --> Router Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Output Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Security Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Input Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 14:59:24 --> Language Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Loader Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: url_helper
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: link_helper
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 14:59:24 --> CI_Session Class Initialized
DEBUG - 2015-02-13 14:59:24 --> CI_Session routines successfully run
DEBUG - 2015-02-13 14:59:24 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Controller Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 14:59:24 --> Email Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: language_helper
DEBUG - 2015-02-13 14:59:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 14:59:24 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Database Driver Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: date_helper
DEBUG - 2015-02-13 14:59:24 --> Helper loaded: form_helper
DEBUG - 2015-02-13 14:59:24 --> Form Validation Class Initialized
DEBUG - 2015-02-13 14:59:24 --> Model Class Initialized
DEBUG - 2015-02-13 14:59:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 14:59:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 14:59:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-13 14:59:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 14:59:25 --> Final output sent to browser
DEBUG - 2015-02-13 14:59:25 --> Total execution time: 1.4411
DEBUG - 2015-02-13 15:00:22 --> Config Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:00:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:00:22 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:00:22 --> URI Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Router Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Output Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Security Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Input Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:00:22 --> Language Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Loader Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:00:22 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:00:22 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:00:22 --> Model Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Model Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Controller Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:00:22 --> Email Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:00:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:00:22 --> Model Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:00:22 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:00:22 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:00:22 --> Model Class Initialized
DEBUG - 2015-02-13 15:00:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:00:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:00:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-13 15:00:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:00:24 --> Final output sent to browser
DEBUG - 2015-02-13 15:00:24 --> Total execution time: 1.5272
DEBUG - 2015-02-13 15:14:43 --> Config Class Initialized
DEBUG - 2015-02-13 15:14:43 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:14:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:14:43 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:14:43 --> URI Class Initialized
DEBUG - 2015-02-13 15:14:43 --> Router Class Initialized
DEBUG - 2015-02-13 15:14:43 --> Output Class Initialized
DEBUG - 2015-02-13 15:14:43 --> Security Class Initialized
DEBUG - 2015-02-13 15:14:43 --> Input Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:14:44 --> Language Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Loader Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:14:44 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Session: Regenerate ID
DEBUG - 2015-02-13 15:14:44 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:14:44 --> Model Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Model Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Controller Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:14:44 --> Email Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:14:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:14:44 --> Model Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:14:44 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:14:44 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:14:44 --> Model Class Initialized
DEBUG - 2015-02-13 15:14:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:14:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:14:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-13 15:14:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:14:46 --> Final output sent to browser
DEBUG - 2015-02-13 15:14:46 --> Total execution time: 2.9313
DEBUG - 2015-02-13 15:22:29 --> Config Class Initialized
DEBUG - 2015-02-13 15:22:29 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:22:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:22:30 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:22:30 --> URI Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Router Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Output Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Security Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Input Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:22:30 --> Language Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Loader Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:22:30 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Session: Regenerate ID
DEBUG - 2015-02-13 15:22:30 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:22:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Controller Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:22:30 --> Email Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:22:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:22:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:22:30 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:22:30 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:22:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:22:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:22:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:22:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:22:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 15:22:31 --> Final output sent to browser
DEBUG - 2015-02-13 15:22:31 --> Total execution time: 1.8362
DEBUG - 2015-02-13 15:23:32 --> Config Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:23:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:23:32 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:23:32 --> URI Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Router Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Output Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Security Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Input Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:23:32 --> Language Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Loader Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:23:32 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:23:32 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:23:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:23:32 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:23:32 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:23:32 --> Model Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Model Class Initialized
DEBUG - 2015-02-13 15:23:32 --> Controller Class Initialized
DEBUG - 2015-02-13 15:23:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:23:33 --> Email Class Initialized
DEBUG - 2015-02-13 15:23:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:23:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:23:33 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:23:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:23:33 --> Model Class Initialized
DEBUG - 2015-02-13 15:23:33 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:23:33 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:23:33 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:23:33 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:23:33 --> Model Class Initialized
DEBUG - 2015-02-13 15:23:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:23:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 15:23:34 --> Final output sent to browser
DEBUG - 2015-02-13 15:23:34 --> Total execution time: 2.1642
DEBUG - 2015-02-13 15:24:58 --> Config Class Initialized
DEBUG - 2015-02-13 15:24:58 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:24:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:24:58 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:24:58 --> URI Class Initialized
DEBUG - 2015-02-13 15:24:58 --> Router Class Initialized
DEBUG - 2015-02-13 15:24:58 --> Output Class Initialized
DEBUG - 2015-02-13 15:24:58 --> Security Class Initialized
DEBUG - 2015-02-13 15:24:58 --> Input Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:24:59 --> Language Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Loader Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:24:59 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:24:59 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:24:59 --> Model Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Model Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Controller Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:24:59 --> Email Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:24:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:24:59 --> Model Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:24:59 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:24:59 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:24:59 --> Model Class Initialized
DEBUG - 2015-02-13 15:24:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:24:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:25:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:25:00 --> Upload Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-02-13 15:25:00 --> You did not select a file to upload.
DEBUG - 2015-02-13 15:25:00 --> Config Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:25:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:25:00 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:25:00 --> URI Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Router Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Output Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Security Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Input Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:25:00 --> Language Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Loader Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:25:00 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:25:00 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:25:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:25:00 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:25:00 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:25:00 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Controller Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:25:00 --> Email Class Initialized
DEBUG - 2015-02-13 15:25:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:25:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:25:00 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:25:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:25:01 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:01 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:25:01 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:25:01 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:25:01 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:25:01 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:25:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:25:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-13 15:25:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:25:02 --> Final output sent to browser
DEBUG - 2015-02-13 15:25:02 --> Total execution time: 1.8612
DEBUG - 2015-02-13 15:25:05 --> Config Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:25:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:25:05 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:25:05 --> URI Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Router Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Output Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Security Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Input Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:25:05 --> Language Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Loader Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:25:05 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:25:05 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:25:05 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Controller Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:25:05 --> Email Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:25:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:25:05 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:25:05 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:25:05 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:25:05 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-13 15:25:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-13 15:25:08 --> Final output sent to browser
DEBUG - 2015-02-13 15:25:08 --> Total execution time: 2.6653
DEBUG - 2015-02-13 15:25:08 --> Config Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:25:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:25:08 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:25:08 --> URI Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Router Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Output Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Security Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Input Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:25:08 --> Language Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Loader Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:25:08 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:25:08 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:25:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:25:08 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:25:08 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:25:08 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Controller Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:25:08 --> Email Class Initialized
DEBUG - 2015-02-13 15:25:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:25:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:25:08 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:25:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:25:09 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:09 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:25:09 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:25:09 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:25:09 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:25:09 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:09 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:10 --> Final output sent to browser
DEBUG - 2015-02-13 15:25:10 --> Total execution time: 2.1922
DEBUG - 2015-02-13 15:25:19 --> Config Class Initialized
DEBUG - 2015-02-13 15:25:19 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:25:19 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:25:19 --> URI Class Initialized
DEBUG - 2015-02-13 15:25:19 --> Router Class Initialized
DEBUG - 2015-02-13 15:25:19 --> Output Class Initialized
DEBUG - 2015-02-13 15:25:19 --> Security Class Initialized
DEBUG - 2015-02-13 15:25:19 --> Input Class Initialized
DEBUG - 2015-02-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:25:19 --> Language Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Loader Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:25:20 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:25:20 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:25:20 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Controller Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:25:20 --> Email Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:25:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:25:20 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:25:20 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:25:20 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:25:20 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:25:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:25:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:25:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:25:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 15:25:21 --> Final output sent to browser
DEBUG - 2015-02-13 15:25:21 --> Total execution time: 1.0721
DEBUG - 2015-02-13 15:25:51 --> Config Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:25:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:25:51 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:25:51 --> URI Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Router Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Output Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Security Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Input Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:25:51 --> Language Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Loader Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:25:51 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:25:51 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:25:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:25:51 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:25:51 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:25:51 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Controller Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:25:51 --> Email Class Initialized
DEBUG - 2015-02-13 15:25:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:25:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:25:51 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:25:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:25:52 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:52 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:25:52 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:25:52 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:25:52 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:25:52 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:25:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:25:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:25:52 --> Upload Class Initialized
DEBUG - 2015-02-13 15:25:52 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-02-13 15:25:52 --> You did not select a file to upload.
DEBUG - 2015-02-13 15:25:53 --> Config Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:25:53 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:25:53 --> URI Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Router Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Output Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Security Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Input Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:25:53 --> Language Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Loader Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:25:53 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:25:53 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Controller Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:25:53 --> Email Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:25:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:25:53 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:25:53 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-13 15:25:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:25:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:25:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-13 15:25:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:25:55 --> Final output sent to browser
DEBUG - 2015-02-13 15:25:55 --> Total execution time: 1.8842
DEBUG - 2015-02-13 15:27:50 --> Config Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:27:50 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:27:50 --> URI Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Router Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Output Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Security Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Input Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:27:50 --> Language Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Loader Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:27:50 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Session: Regenerate ID
DEBUG - 2015-02-13 15:27:50 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:27:50 --> Model Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Model Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Controller Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:27:50 --> Email Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:27:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:27:50 --> Model Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:27:50 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:27:50 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:27:50 --> Model Class Initialized
DEBUG - 2015-02-13 15:27:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:27:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:27:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:27:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:27:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 15:27:51 --> Final output sent to browser
DEBUG - 2015-02-13 15:27:51 --> Total execution time: 1.0911
DEBUG - 2015-02-13 15:28:27 --> Config Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:28:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:28:27 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:28:27 --> URI Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Router Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Output Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Security Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Input Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:28:27 --> Language Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Loader Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:28:27 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:28:27 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:28:27 --> Model Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Model Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Controller Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:28:27 --> Email Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:28:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:28:27 --> Model Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:28:27 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:28:27 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:28:27 --> Model Class Initialized
DEBUG - 2015-02-13 15:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:28:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:28:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 15:28:28 --> Final output sent to browser
DEBUG - 2015-02-13 15:28:28 --> Total execution time: 1.1541
DEBUG - 2015-02-13 15:40:09 --> Config Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:40:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:40:09 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:40:09 --> URI Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Router Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Output Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Security Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Input Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:40:09 --> Language Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Loader Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:40:09 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Session: Regenerate ID
DEBUG - 2015-02-13 15:40:09 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:40:09 --> Model Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Model Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Controller Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:40:09 --> Email Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:40:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:40:09 --> Model Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:40:09 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:40:09 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:40:09 --> Model Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Config Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:43:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:43:28 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:43:28 --> URI Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Router Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Output Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Security Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Input Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:43:28 --> Language Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Loader Class Initialized
DEBUG - 2015-02-13 15:43:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:43:28 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:43:28 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:43:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:43:28 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:43:28 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:43:29 --> Model Class Initialized
DEBUG - 2015-02-13 15:43:29 --> Model Class Initialized
DEBUG - 2015-02-13 15:43:29 --> Controller Class Initialized
DEBUG - 2015-02-13 15:43:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:43:29 --> Email Class Initialized
DEBUG - 2015-02-13 15:43:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:43:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:43:29 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:43:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:43:29 --> Model Class Initialized
DEBUG - 2015-02-13 15:43:29 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:43:29 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:43:29 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:43:29 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:43:29 --> Model Class Initialized
DEBUG - 2015-02-13 15:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:43:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 15:43:30 --> Final output sent to browser
DEBUG - 2015-02-13 15:43:30 --> Total execution time: 1.2091
DEBUG - 2015-02-13 15:58:30 --> Config Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Hooks Class Initialized
DEBUG - 2015-02-13 15:58:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 15:58:30 --> Utf8 Class Initialized
DEBUG - 2015-02-13 15:58:30 --> URI Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Router Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Output Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Security Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Input Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 15:58:30 --> Language Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Loader Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: url_helper
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: link_helper
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 15:58:30 --> CI_Session Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Session: Regenerate ID
DEBUG - 2015-02-13 15:58:30 --> CI_Session routines successfully run
DEBUG - 2015-02-13 15:58:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Controller Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 15:58:30 --> Email Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: language_helper
DEBUG - 2015-02-13 15:58:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 15:58:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Database Driver Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: date_helper
DEBUG - 2015-02-13 15:58:30 --> Helper loaded: form_helper
DEBUG - 2015-02-13 15:58:30 --> Form Validation Class Initialized
DEBUG - 2015-02-13 15:58:30 --> Model Class Initialized
DEBUG - 2015-02-13 15:58:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 15:58:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 15:58:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 15:58:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 15:58:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 15:58:31 --> Final output sent to browser
DEBUG - 2015-02-13 15:58:31 --> Total execution time: 1.2051
DEBUG - 2015-02-13 16:13:32 --> Config Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Hooks Class Initialized
DEBUG - 2015-02-13 16:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 16:13:32 --> Utf8 Class Initialized
DEBUG - 2015-02-13 16:13:32 --> URI Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Router Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Output Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Security Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Input Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 16:13:32 --> Language Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Loader Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: url_helper
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: link_helper
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 16:13:32 --> CI_Session Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Session: Regenerate ID
DEBUG - 2015-02-13 16:13:32 --> CI_Session routines successfully run
DEBUG - 2015-02-13 16:13:32 --> Model Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Model Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Controller Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 16:13:32 --> Email Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: language_helper
DEBUG - 2015-02-13 16:13:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 16:13:32 --> Model Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Database Driver Class Initialized
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: date_helper
DEBUG - 2015-02-13 16:13:32 --> Helper loaded: form_helper
DEBUG - 2015-02-13 16:13:32 --> Form Validation Class Initialized
DEBUG - 2015-02-13 16:13:33 --> Model Class Initialized
DEBUG - 2015-02-13 16:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 16:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 16:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 16:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 16:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 16:13:33 --> Final output sent to browser
DEBUG - 2015-02-13 16:13:33 --> Total execution time: 1.5262
DEBUG - 2015-02-13 16:28:34 --> Config Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Hooks Class Initialized
DEBUG - 2015-02-13 16:28:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 16:28:34 --> Utf8 Class Initialized
DEBUG - 2015-02-13 16:28:34 --> URI Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Router Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Output Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Security Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Input Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 16:28:34 --> Language Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Loader Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: url_helper
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: link_helper
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 16:28:34 --> CI_Session Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Session: Regenerate ID
DEBUG - 2015-02-13 16:28:34 --> CI_Session routines successfully run
DEBUG - 2015-02-13 16:28:34 --> Model Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Model Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Controller Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 16:28:34 --> Email Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: language_helper
DEBUG - 2015-02-13 16:28:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 16:28:34 --> Model Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Database Driver Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: date_helper
DEBUG - 2015-02-13 16:28:34 --> Helper loaded: form_helper
DEBUG - 2015-02-13 16:28:34 --> Form Validation Class Initialized
DEBUG - 2015-02-13 16:28:34 --> Model Class Initialized
DEBUG - 2015-02-13 16:28:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 16:28:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 16:28:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 16:28:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 16:28:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 16:28:35 --> Final output sent to browser
DEBUG - 2015-02-13 16:28:35 --> Total execution time: 1.1871
DEBUG - 2015-02-13 16:43:36 --> Config Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Hooks Class Initialized
DEBUG - 2015-02-13 16:43:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 16:43:36 --> Utf8 Class Initialized
DEBUG - 2015-02-13 16:43:36 --> URI Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Router Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Output Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Security Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Input Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 16:43:36 --> Language Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Loader Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: url_helper
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: link_helper
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 16:43:36 --> CI_Session Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Session: Regenerate ID
DEBUG - 2015-02-13 16:43:36 --> CI_Session routines successfully run
DEBUG - 2015-02-13 16:43:36 --> Model Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Model Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Controller Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 16:43:36 --> Email Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: language_helper
DEBUG - 2015-02-13 16:43:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 16:43:36 --> Model Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Database Driver Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: date_helper
DEBUG - 2015-02-13 16:43:36 --> Helper loaded: form_helper
DEBUG - 2015-02-13 16:43:36 --> Form Validation Class Initialized
DEBUG - 2015-02-13 16:43:36 --> Model Class Initialized
DEBUG - 2015-02-13 16:43:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 16:43:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 16:43:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 16:43:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 16:43:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 16:43:37 --> Final output sent to browser
DEBUG - 2015-02-13 16:43:37 --> Total execution time: 1.1131
DEBUG - 2015-02-13 16:58:37 --> Config Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Hooks Class Initialized
DEBUG - 2015-02-13 16:58:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 16:58:37 --> Utf8 Class Initialized
DEBUG - 2015-02-13 16:58:37 --> URI Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Router Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Output Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Security Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Input Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 16:58:37 --> Language Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Loader Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: url_helper
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: link_helper
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 16:58:37 --> CI_Session Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Session: Regenerate ID
DEBUG - 2015-02-13 16:58:37 --> CI_Session routines successfully run
DEBUG - 2015-02-13 16:58:37 --> Model Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Model Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Controller Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 16:58:37 --> Email Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: language_helper
DEBUG - 2015-02-13 16:58:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 16:58:37 --> Model Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Database Driver Class Initialized
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: date_helper
DEBUG - 2015-02-13 16:58:37 --> Helper loaded: form_helper
DEBUG - 2015-02-13 16:58:37 --> Form Validation Class Initialized
DEBUG - 2015-02-13 16:58:38 --> Model Class Initialized
DEBUG - 2015-02-13 16:58:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 16:58:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 16:58:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 16:58:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 16:58:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 16:58:38 --> Final output sent to browser
DEBUG - 2015-02-13 16:58:38 --> Total execution time: 1.1281
DEBUG - 2015-02-13 17:13:39 --> Config Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Hooks Class Initialized
DEBUG - 2015-02-13 17:13:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 17:13:39 --> Utf8 Class Initialized
DEBUG - 2015-02-13 17:13:39 --> URI Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Router Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Output Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Security Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Input Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 17:13:39 --> Language Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Loader Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: url_helper
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: link_helper
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 17:13:39 --> CI_Session Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Session: Regenerate ID
DEBUG - 2015-02-13 17:13:39 --> CI_Session routines successfully run
DEBUG - 2015-02-13 17:13:39 --> Model Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Model Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Controller Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 17:13:39 --> Email Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: language_helper
DEBUG - 2015-02-13 17:13:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 17:13:39 --> Model Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Database Driver Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: date_helper
DEBUG - 2015-02-13 17:13:39 --> Helper loaded: form_helper
DEBUG - 2015-02-13 17:13:39 --> Form Validation Class Initialized
DEBUG - 2015-02-13 17:13:39 --> Model Class Initialized
DEBUG - 2015-02-13 17:13:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 17:13:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 17:13:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 17:13:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 17:13:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 17:13:40 --> Final output sent to browser
DEBUG - 2015-02-13 17:13:40 --> Total execution time: 1.1141
DEBUG - 2015-02-13 17:28:41 --> Config Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Hooks Class Initialized
DEBUG - 2015-02-13 17:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 17:28:41 --> Utf8 Class Initialized
DEBUG - 2015-02-13 17:28:41 --> URI Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Router Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Output Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Security Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Input Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 17:28:41 --> Language Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Loader Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: url_helper
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: link_helper
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 17:28:41 --> CI_Session Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Session: Regenerate ID
DEBUG - 2015-02-13 17:28:41 --> CI_Session routines successfully run
DEBUG - 2015-02-13 17:28:41 --> Model Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Model Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Controller Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 17:28:41 --> Email Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: language_helper
DEBUG - 2015-02-13 17:28:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 17:28:41 --> Model Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Database Driver Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: date_helper
DEBUG - 2015-02-13 17:28:41 --> Helper loaded: form_helper
DEBUG - 2015-02-13 17:28:41 --> Form Validation Class Initialized
DEBUG - 2015-02-13 17:28:41 --> Model Class Initialized
DEBUG - 2015-02-13 17:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 17:28:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 17:28:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 17:28:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 17:28:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 17:28:42 --> Final output sent to browser
DEBUG - 2015-02-13 17:28:42 --> Total execution time: 1.4381
DEBUG - 2015-02-13 17:43:42 --> Config Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Hooks Class Initialized
DEBUG - 2015-02-13 17:43:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 17:43:43 --> Utf8 Class Initialized
DEBUG - 2015-02-13 17:43:43 --> URI Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Router Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Output Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Security Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Input Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 17:43:43 --> Language Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Loader Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: url_helper
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: link_helper
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 17:43:43 --> CI_Session Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Session: Regenerate ID
DEBUG - 2015-02-13 17:43:43 --> CI_Session routines successfully run
DEBUG - 2015-02-13 17:43:43 --> Model Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Model Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Controller Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 17:43:43 --> Email Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: language_helper
DEBUG - 2015-02-13 17:43:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 17:43:43 --> Model Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Database Driver Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: date_helper
DEBUG - 2015-02-13 17:43:43 --> Helper loaded: form_helper
DEBUG - 2015-02-13 17:43:43 --> Form Validation Class Initialized
DEBUG - 2015-02-13 17:43:43 --> Model Class Initialized
DEBUG - 2015-02-13 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 17:43:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 17:43:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 17:43:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 17:43:44 --> Final output sent to browser
DEBUG - 2015-02-13 17:43:44 --> Total execution time: 1.1621
DEBUG - 2015-02-13 17:58:44 --> Config Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Hooks Class Initialized
DEBUG - 2015-02-13 17:58:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 17:58:44 --> Utf8 Class Initialized
DEBUG - 2015-02-13 17:58:44 --> URI Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Router Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Output Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Security Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Input Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 17:58:44 --> Language Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Loader Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: url_helper
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: link_helper
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 17:58:44 --> CI_Session Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Session: Regenerate ID
DEBUG - 2015-02-13 17:58:44 --> CI_Session routines successfully run
DEBUG - 2015-02-13 17:58:44 --> Model Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Model Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Controller Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 17:58:44 --> Email Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: language_helper
DEBUG - 2015-02-13 17:58:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 17:58:44 --> Model Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Database Driver Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: date_helper
DEBUG - 2015-02-13 17:58:44 --> Helper loaded: form_helper
DEBUG - 2015-02-13 17:58:44 --> Form Validation Class Initialized
DEBUG - 2015-02-13 17:58:44 --> Model Class Initialized
DEBUG - 2015-02-13 17:58:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 17:58:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 17:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 17:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 17:58:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 17:58:45 --> Final output sent to browser
DEBUG - 2015-02-13 17:58:45 --> Total execution time: 1.1201
DEBUG - 2015-02-13 18:13:46 --> Config Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Hooks Class Initialized
DEBUG - 2015-02-13 18:13:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 18:13:46 --> Utf8 Class Initialized
DEBUG - 2015-02-13 18:13:46 --> URI Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Router Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Output Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Security Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Input Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 18:13:46 --> Language Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Loader Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: url_helper
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: link_helper
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 18:13:46 --> CI_Session Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Session: Regenerate ID
DEBUG - 2015-02-13 18:13:46 --> CI_Session routines successfully run
DEBUG - 2015-02-13 18:13:46 --> Model Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Model Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Controller Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 18:13:46 --> Email Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: language_helper
DEBUG - 2015-02-13 18:13:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 18:13:46 --> Model Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Database Driver Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: date_helper
DEBUG - 2015-02-13 18:13:46 --> Helper loaded: form_helper
DEBUG - 2015-02-13 18:13:46 --> Form Validation Class Initialized
DEBUG - 2015-02-13 18:13:46 --> Model Class Initialized
DEBUG - 2015-02-13 18:13:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 18:13:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 18:13:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 18:13:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 18:13:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 18:13:47 --> Final output sent to browser
DEBUG - 2015-02-13 18:13:47 --> Total execution time: 1.1261
DEBUG - 2015-02-13 18:28:47 --> Config Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Hooks Class Initialized
DEBUG - 2015-02-13 18:28:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 18:28:47 --> Utf8 Class Initialized
DEBUG - 2015-02-13 18:28:47 --> URI Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Router Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Output Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Security Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Input Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 18:28:47 --> Language Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Loader Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: url_helper
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: link_helper
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 18:28:47 --> CI_Session Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Session: Regenerate ID
DEBUG - 2015-02-13 18:28:47 --> CI_Session routines successfully run
DEBUG - 2015-02-13 18:28:47 --> Model Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Model Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Controller Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 18:28:47 --> Email Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: language_helper
DEBUG - 2015-02-13 18:28:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 18:28:47 --> Model Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Database Driver Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: date_helper
DEBUG - 2015-02-13 18:28:47 --> Helper loaded: form_helper
DEBUG - 2015-02-13 18:28:47 --> Form Validation Class Initialized
DEBUG - 2015-02-13 18:28:47 --> Model Class Initialized
DEBUG - 2015-02-13 18:28:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 18:28:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 18:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 18:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 18:28:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 18:28:48 --> Final output sent to browser
DEBUG - 2015-02-13 18:28:48 --> Total execution time: 1.2321
DEBUG - 2015-02-13 18:43:49 --> Config Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Hooks Class Initialized
DEBUG - 2015-02-13 18:43:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 18:43:49 --> Utf8 Class Initialized
DEBUG - 2015-02-13 18:43:49 --> URI Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Router Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Output Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Security Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Input Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 18:43:49 --> Language Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Loader Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: url_helper
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: link_helper
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 18:43:49 --> CI_Session Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Session: Regenerate ID
DEBUG - 2015-02-13 18:43:49 --> CI_Session routines successfully run
DEBUG - 2015-02-13 18:43:49 --> Model Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Model Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Controller Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 18:43:49 --> Email Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: language_helper
DEBUG - 2015-02-13 18:43:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 18:43:49 --> Model Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Database Driver Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: date_helper
DEBUG - 2015-02-13 18:43:49 --> Helper loaded: form_helper
DEBUG - 2015-02-13 18:43:49 --> Form Validation Class Initialized
DEBUG - 2015-02-13 18:43:49 --> Model Class Initialized
DEBUG - 2015-02-13 18:43:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 18:43:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 18:43:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 18:43:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 18:43:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 18:43:50 --> Final output sent to browser
DEBUG - 2015-02-13 18:43:50 --> Total execution time: 1.1821
DEBUG - 2015-02-13 18:58:51 --> Config Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Hooks Class Initialized
DEBUG - 2015-02-13 18:58:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 18:58:51 --> Utf8 Class Initialized
DEBUG - 2015-02-13 18:58:51 --> URI Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Router Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Output Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Security Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Input Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 18:58:51 --> Language Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Loader Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: url_helper
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: link_helper
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 18:58:51 --> CI_Session Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Session: Regenerate ID
DEBUG - 2015-02-13 18:58:51 --> CI_Session routines successfully run
DEBUG - 2015-02-13 18:58:51 --> Model Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Model Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Controller Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 18:58:51 --> Email Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: language_helper
DEBUG - 2015-02-13 18:58:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 18:58:51 --> Model Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Database Driver Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: date_helper
DEBUG - 2015-02-13 18:58:51 --> Helper loaded: form_helper
DEBUG - 2015-02-13 18:58:51 --> Form Validation Class Initialized
DEBUG - 2015-02-13 18:58:51 --> Model Class Initialized
DEBUG - 2015-02-13 18:58:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 18:58:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 18:58:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 18:58:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 18:58:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 18:58:52 --> Final output sent to browser
DEBUG - 2015-02-13 18:58:52 --> Total execution time: 1.1061
DEBUG - 2015-02-13 19:13:52 --> Config Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Hooks Class Initialized
DEBUG - 2015-02-13 19:13:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 19:13:52 --> Utf8 Class Initialized
DEBUG - 2015-02-13 19:13:52 --> URI Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Router Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Output Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Security Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Input Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 19:13:52 --> Language Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Loader Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: url_helper
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: link_helper
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 19:13:52 --> CI_Session Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Session: Regenerate ID
DEBUG - 2015-02-13 19:13:52 --> CI_Session routines successfully run
DEBUG - 2015-02-13 19:13:52 --> Model Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Model Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Controller Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 19:13:52 --> Email Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: language_helper
DEBUG - 2015-02-13 19:13:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 19:13:52 --> Model Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Database Driver Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: date_helper
DEBUG - 2015-02-13 19:13:52 --> Helper loaded: form_helper
DEBUG - 2015-02-13 19:13:52 --> Form Validation Class Initialized
DEBUG - 2015-02-13 19:13:52 --> Model Class Initialized
DEBUG - 2015-02-13 19:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 19:13:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 19:13:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 19:13:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 19:13:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 19:13:53 --> Final output sent to browser
DEBUG - 2015-02-13 19:13:53 --> Total execution time: 1.1091
DEBUG - 2015-02-13 19:28:54 --> Config Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Hooks Class Initialized
DEBUG - 2015-02-13 19:28:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 19:28:54 --> Utf8 Class Initialized
DEBUG - 2015-02-13 19:28:54 --> URI Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Router Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Output Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Security Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Input Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 19:28:54 --> Language Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Loader Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: url_helper
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: link_helper
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 19:28:54 --> CI_Session Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Session: Regenerate ID
DEBUG - 2015-02-13 19:28:54 --> CI_Session routines successfully run
DEBUG - 2015-02-13 19:28:54 --> Model Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Model Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Controller Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 19:28:54 --> Email Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: language_helper
DEBUG - 2015-02-13 19:28:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 19:28:54 --> Model Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Database Driver Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: date_helper
DEBUG - 2015-02-13 19:28:54 --> Helper loaded: form_helper
DEBUG - 2015-02-13 19:28:54 --> Form Validation Class Initialized
DEBUG - 2015-02-13 19:28:54 --> Model Class Initialized
DEBUG - 2015-02-13 19:28:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 19:28:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 19:28:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 19:28:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 19:28:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 19:28:55 --> Final output sent to browser
DEBUG - 2015-02-13 19:28:55 --> Total execution time: 1.2551
DEBUG - 2015-02-13 19:43:55 --> Config Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Hooks Class Initialized
DEBUG - 2015-02-13 19:43:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 19:43:55 --> Utf8 Class Initialized
DEBUG - 2015-02-13 19:43:55 --> URI Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Router Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Output Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Security Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Input Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 19:43:55 --> Language Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Loader Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 19:43:55 --> Helper loaded: url_helper
DEBUG - 2015-02-13 19:43:55 --> Helper loaded: link_helper
DEBUG - 2015-02-13 19:43:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 19:43:55 --> CI_Session Class Initialized
DEBUG - 2015-02-13 19:43:55 --> Session: Regenerate ID
DEBUG - 2015-02-13 19:43:55 --> CI_Session routines successfully run
DEBUG - 2015-02-13 19:43:56 --> Model Class Initialized
DEBUG - 2015-02-13 19:43:56 --> Model Class Initialized
DEBUG - 2015-02-13 19:43:56 --> Controller Class Initialized
DEBUG - 2015-02-13 19:43:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 19:43:56 --> Email Class Initialized
DEBUG - 2015-02-13 19:43:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 19:43:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 19:43:56 --> Helper loaded: language_helper
DEBUG - 2015-02-13 19:43:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 19:43:56 --> Model Class Initialized
DEBUG - 2015-02-13 19:43:56 --> Database Driver Class Initialized
DEBUG - 2015-02-13 19:43:56 --> Helper loaded: date_helper
DEBUG - 2015-02-13 19:43:56 --> Helper loaded: form_helper
DEBUG - 2015-02-13 19:43:56 --> Form Validation Class Initialized
DEBUG - 2015-02-13 19:43:56 --> Model Class Initialized
DEBUG - 2015-02-13 19:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 19:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 19:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 19:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 19:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 19:43:56 --> Final output sent to browser
DEBUG - 2015-02-13 19:43:56 --> Total execution time: 1.0721
DEBUG - 2015-02-13 19:58:57 --> Config Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Hooks Class Initialized
DEBUG - 2015-02-13 19:58:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 19:58:57 --> Utf8 Class Initialized
DEBUG - 2015-02-13 19:58:57 --> URI Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Router Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Output Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Security Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Input Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 19:58:57 --> Language Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Loader Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: url_helper
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: link_helper
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 19:58:57 --> CI_Session Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Session: Regenerate ID
DEBUG - 2015-02-13 19:58:57 --> CI_Session routines successfully run
DEBUG - 2015-02-13 19:58:57 --> Model Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Model Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Controller Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 19:58:57 --> Email Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: language_helper
DEBUG - 2015-02-13 19:58:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 19:58:57 --> Model Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Database Driver Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: date_helper
DEBUG - 2015-02-13 19:58:57 --> Helper loaded: form_helper
DEBUG - 2015-02-13 19:58:57 --> Form Validation Class Initialized
DEBUG - 2015-02-13 19:58:57 --> Model Class Initialized
DEBUG - 2015-02-13 19:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 19:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 19:58:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 19:58:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 19:58:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 19:58:58 --> Final output sent to browser
DEBUG - 2015-02-13 19:58:58 --> Total execution time: 1.1631
DEBUG - 2015-02-13 20:13:59 --> Config Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Hooks Class Initialized
DEBUG - 2015-02-13 20:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 20:13:59 --> Utf8 Class Initialized
DEBUG - 2015-02-13 20:13:59 --> URI Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Router Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Output Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Security Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Input Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 20:13:59 --> Language Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Loader Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: url_helper
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: link_helper
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 20:13:59 --> CI_Session Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Session: Regenerate ID
DEBUG - 2015-02-13 20:13:59 --> CI_Session routines successfully run
DEBUG - 2015-02-13 20:13:59 --> Model Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Model Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Controller Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 20:13:59 --> Email Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: language_helper
DEBUG - 2015-02-13 20:13:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 20:13:59 --> Model Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Database Driver Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: date_helper
DEBUG - 2015-02-13 20:13:59 --> Helper loaded: form_helper
DEBUG - 2015-02-13 20:13:59 --> Form Validation Class Initialized
DEBUG - 2015-02-13 20:13:59 --> Model Class Initialized
DEBUG - 2015-02-13 20:13:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 20:13:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 20:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 20:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 20:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 20:14:00 --> Final output sent to browser
DEBUG - 2015-02-13 20:14:00 --> Total execution time: 1.1491
DEBUG - 2015-02-13 20:29:00 --> Config Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Hooks Class Initialized
DEBUG - 2015-02-13 20:29:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 20:29:00 --> Utf8 Class Initialized
DEBUG - 2015-02-13 20:29:00 --> URI Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Router Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Output Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Security Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Input Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 20:29:00 --> Language Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Loader Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: url_helper
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: link_helper
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 20:29:00 --> CI_Session Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Session: Regenerate ID
DEBUG - 2015-02-13 20:29:00 --> CI_Session routines successfully run
DEBUG - 2015-02-13 20:29:00 --> Model Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Model Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Controller Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 20:29:00 --> Email Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: language_helper
DEBUG - 2015-02-13 20:29:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 20:29:00 --> Model Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Database Driver Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: date_helper
DEBUG - 2015-02-13 20:29:00 --> Helper loaded: form_helper
DEBUG - 2015-02-13 20:29:00 --> Form Validation Class Initialized
DEBUG - 2015-02-13 20:29:00 --> Model Class Initialized
DEBUG - 2015-02-13 20:29:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 20:29:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 20:29:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 20:29:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 20:29:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 20:29:01 --> Final output sent to browser
DEBUG - 2015-02-13 20:29:01 --> Total execution time: 1.1361
DEBUG - 2015-02-13 20:44:02 --> Config Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Hooks Class Initialized
DEBUG - 2015-02-13 20:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 20:44:02 --> Utf8 Class Initialized
DEBUG - 2015-02-13 20:44:02 --> URI Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Router Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Output Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Security Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Input Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 20:44:02 --> Language Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Loader Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: url_helper
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: link_helper
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 20:44:02 --> CI_Session Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Session: Regenerate ID
DEBUG - 2015-02-13 20:44:02 --> CI_Session routines successfully run
DEBUG - 2015-02-13 20:44:02 --> Model Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Model Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Controller Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 20:44:02 --> Email Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: language_helper
DEBUG - 2015-02-13 20:44:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 20:44:02 --> Model Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Database Driver Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: date_helper
DEBUG - 2015-02-13 20:44:02 --> Helper loaded: form_helper
DEBUG - 2015-02-13 20:44:02 --> Form Validation Class Initialized
DEBUG - 2015-02-13 20:44:02 --> Model Class Initialized
DEBUG - 2015-02-13 20:44:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 20:44:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 20:44:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 20:44:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 20:44:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 20:44:03 --> Final output sent to browser
DEBUG - 2015-02-13 20:44:03 --> Total execution time: 1.1341
DEBUG - 2015-02-13 20:59:03 --> Config Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Hooks Class Initialized
DEBUG - 2015-02-13 20:59:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 20:59:03 --> Utf8 Class Initialized
DEBUG - 2015-02-13 20:59:03 --> URI Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Router Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Output Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Security Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Input Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 20:59:03 --> Language Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Loader Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: url_helper
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: link_helper
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 20:59:03 --> CI_Session Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Session: Regenerate ID
DEBUG - 2015-02-13 20:59:03 --> CI_Session routines successfully run
DEBUG - 2015-02-13 20:59:03 --> Model Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Model Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Controller Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 20:59:03 --> Email Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: language_helper
DEBUG - 2015-02-13 20:59:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 20:59:03 --> Model Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Database Driver Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: date_helper
DEBUG - 2015-02-13 20:59:03 --> Helper loaded: form_helper
DEBUG - 2015-02-13 20:59:03 --> Form Validation Class Initialized
DEBUG - 2015-02-13 20:59:03 --> Model Class Initialized
DEBUG - 2015-02-13 20:59:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 20:59:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 20:59:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 20:59:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 20:59:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 20:59:04 --> Final output sent to browser
DEBUG - 2015-02-13 20:59:04 --> Total execution time: 1.1681
DEBUG - 2015-02-13 21:14:05 --> Config Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Hooks Class Initialized
DEBUG - 2015-02-13 21:14:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 21:14:05 --> Utf8 Class Initialized
DEBUG - 2015-02-13 21:14:05 --> URI Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Router Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Output Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Security Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Input Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 21:14:05 --> Language Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Loader Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: url_helper
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: link_helper
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 21:14:05 --> CI_Session Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Session: Regenerate ID
DEBUG - 2015-02-13 21:14:05 --> CI_Session routines successfully run
DEBUG - 2015-02-13 21:14:05 --> Model Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Model Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Controller Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 21:14:05 --> Email Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: language_helper
DEBUG - 2015-02-13 21:14:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 21:14:05 --> Model Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Database Driver Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: date_helper
DEBUG - 2015-02-13 21:14:05 --> Helper loaded: form_helper
DEBUG - 2015-02-13 21:14:05 --> Form Validation Class Initialized
DEBUG - 2015-02-13 21:14:05 --> Model Class Initialized
DEBUG - 2015-02-13 21:14:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 21:14:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 21:14:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 21:14:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 21:14:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 21:14:06 --> Final output sent to browser
DEBUG - 2015-02-13 21:14:06 --> Total execution time: 1.1441
DEBUG - 2015-02-13 21:29:06 --> Config Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Hooks Class Initialized
DEBUG - 2015-02-13 21:29:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 21:29:06 --> Utf8 Class Initialized
DEBUG - 2015-02-13 21:29:06 --> URI Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Router Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Output Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Security Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Input Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 21:29:06 --> Language Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Loader Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 21:29:06 --> Helper loaded: url_helper
DEBUG - 2015-02-13 21:29:06 --> Helper loaded: link_helper
DEBUG - 2015-02-13 21:29:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 21:29:06 --> CI_Session Class Initialized
DEBUG - 2015-02-13 21:29:06 --> Session: Regenerate ID
DEBUG - 2015-02-13 21:29:06 --> CI_Session routines successfully run
DEBUG - 2015-02-13 21:29:07 --> Model Class Initialized
DEBUG - 2015-02-13 21:29:07 --> Model Class Initialized
DEBUG - 2015-02-13 21:29:07 --> Controller Class Initialized
DEBUG - 2015-02-13 21:29:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 21:29:07 --> Email Class Initialized
DEBUG - 2015-02-13 21:29:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 21:29:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 21:29:07 --> Helper loaded: language_helper
DEBUG - 2015-02-13 21:29:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 21:29:07 --> Model Class Initialized
DEBUG - 2015-02-13 21:29:07 --> Database Driver Class Initialized
DEBUG - 2015-02-13 21:29:07 --> Helper loaded: date_helper
DEBUG - 2015-02-13 21:29:07 --> Helper loaded: form_helper
DEBUG - 2015-02-13 21:29:07 --> Form Validation Class Initialized
DEBUG - 2015-02-13 21:29:07 --> Model Class Initialized
DEBUG - 2015-02-13 21:29:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 21:29:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 21:29:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 21:29:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 21:29:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 21:29:07 --> Final output sent to browser
DEBUG - 2015-02-13 21:29:07 --> Total execution time: 1.0421
DEBUG - 2015-02-13 21:44:08 --> Config Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Hooks Class Initialized
DEBUG - 2015-02-13 21:44:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 21:44:08 --> Utf8 Class Initialized
DEBUG - 2015-02-13 21:44:08 --> URI Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Router Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Output Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Security Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Input Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 21:44:08 --> Language Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Loader Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: url_helper
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: link_helper
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 21:44:08 --> CI_Session Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Session: Regenerate ID
DEBUG - 2015-02-13 21:44:08 --> CI_Session routines successfully run
DEBUG - 2015-02-13 21:44:08 --> Model Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Model Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Controller Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 21:44:08 --> Email Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: language_helper
DEBUG - 2015-02-13 21:44:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 21:44:08 --> Model Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Database Driver Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: date_helper
DEBUG - 2015-02-13 21:44:08 --> Helper loaded: form_helper
DEBUG - 2015-02-13 21:44:08 --> Form Validation Class Initialized
DEBUG - 2015-02-13 21:44:08 --> Model Class Initialized
DEBUG - 2015-02-13 21:44:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 21:44:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 21:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 21:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 21:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 21:44:09 --> Final output sent to browser
DEBUG - 2015-02-13 21:44:09 --> Total execution time: 1.1761
DEBUG - 2015-02-13 21:59:09 --> Config Class Initialized
DEBUG - 2015-02-13 21:59:09 --> Hooks Class Initialized
DEBUG - 2015-02-13 21:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 21:59:09 --> Utf8 Class Initialized
DEBUG - 2015-02-13 21:59:09 --> URI Class Initialized
DEBUG - 2015-02-13 21:59:09 --> Router Class Initialized
DEBUG - 2015-02-13 21:59:09 --> Output Class Initialized
DEBUG - 2015-02-13 21:59:09 --> Security Class Initialized
DEBUG - 2015-02-13 21:59:09 --> Input Class Initialized
DEBUG - 2015-02-13 21:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 21:59:09 --> Language Class Initialized
DEBUG - 2015-02-13 21:59:09 --> Loader Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: url_helper
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: link_helper
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 21:59:10 --> CI_Session Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Session: Regenerate ID
DEBUG - 2015-02-13 21:59:10 --> CI_Session routines successfully run
DEBUG - 2015-02-13 21:59:10 --> Model Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Model Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Controller Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 21:59:10 --> Email Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: language_helper
DEBUG - 2015-02-13 21:59:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 21:59:10 --> Model Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Database Driver Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: date_helper
DEBUG - 2015-02-13 21:59:10 --> Helper loaded: form_helper
DEBUG - 2015-02-13 21:59:10 --> Form Validation Class Initialized
DEBUG - 2015-02-13 21:59:10 --> Model Class Initialized
DEBUG - 2015-02-13 21:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 21:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 21:59:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 21:59:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 21:59:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 21:59:11 --> Final output sent to browser
DEBUG - 2015-02-13 21:59:11 --> Total execution time: 1.1501
DEBUG - 2015-02-13 22:14:11 --> Config Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Hooks Class Initialized
DEBUG - 2015-02-13 22:14:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 22:14:11 --> Utf8 Class Initialized
DEBUG - 2015-02-13 22:14:11 --> URI Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Router Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Output Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Security Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Input Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 22:14:11 --> Language Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Loader Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: url_helper
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: link_helper
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 22:14:11 --> CI_Session Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Session: Regenerate ID
DEBUG - 2015-02-13 22:14:11 --> CI_Session routines successfully run
DEBUG - 2015-02-13 22:14:11 --> Model Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Model Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Controller Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 22:14:11 --> Email Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: language_helper
DEBUG - 2015-02-13 22:14:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 22:14:11 --> Model Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Database Driver Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: date_helper
DEBUG - 2015-02-13 22:14:11 --> Helper loaded: form_helper
DEBUG - 2015-02-13 22:14:11 --> Form Validation Class Initialized
DEBUG - 2015-02-13 22:14:11 --> Model Class Initialized
DEBUG - 2015-02-13 22:14:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 22:14:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 22:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 22:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 22:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 22:14:12 --> Final output sent to browser
DEBUG - 2015-02-13 22:14:12 --> Total execution time: 1.1551
DEBUG - 2015-02-13 22:29:13 --> Config Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Hooks Class Initialized
DEBUG - 2015-02-13 22:29:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 22:29:13 --> Utf8 Class Initialized
DEBUG - 2015-02-13 22:29:13 --> URI Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Router Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Output Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Security Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Input Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 22:29:13 --> Language Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Loader Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: url_helper
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: link_helper
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 22:29:13 --> CI_Session Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Session: Regenerate ID
DEBUG - 2015-02-13 22:29:13 --> CI_Session routines successfully run
DEBUG - 2015-02-13 22:29:13 --> Model Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Model Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Controller Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 22:29:13 --> Email Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: language_helper
DEBUG - 2015-02-13 22:29:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 22:29:13 --> Model Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Database Driver Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: date_helper
DEBUG - 2015-02-13 22:29:13 --> Helper loaded: form_helper
DEBUG - 2015-02-13 22:29:13 --> Form Validation Class Initialized
DEBUG - 2015-02-13 22:29:13 --> Model Class Initialized
DEBUG - 2015-02-13 22:29:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 22:29:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 22:29:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 22:29:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 22:29:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 22:29:14 --> Final output sent to browser
DEBUG - 2015-02-13 22:29:14 --> Total execution time: 1.0461
DEBUG - 2015-02-13 22:44:14 --> Config Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Hooks Class Initialized
DEBUG - 2015-02-13 22:44:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 22:44:14 --> Utf8 Class Initialized
DEBUG - 2015-02-13 22:44:14 --> URI Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Router Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Output Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Security Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Input Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 22:44:14 --> Language Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Loader Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: url_helper
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: link_helper
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 22:44:14 --> CI_Session Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Session: Regenerate ID
DEBUG - 2015-02-13 22:44:14 --> CI_Session routines successfully run
DEBUG - 2015-02-13 22:44:14 --> Model Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Model Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Controller Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 22:44:14 --> Email Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: language_helper
DEBUG - 2015-02-13 22:44:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 22:44:14 --> Model Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Database Driver Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: date_helper
DEBUG - 2015-02-13 22:44:14 --> Helper loaded: form_helper
DEBUG - 2015-02-13 22:44:14 --> Form Validation Class Initialized
DEBUG - 2015-02-13 22:44:14 --> Model Class Initialized
DEBUG - 2015-02-13 22:44:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 22:44:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 22:44:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 22:44:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 22:44:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 22:44:15 --> Final output sent to browser
DEBUG - 2015-02-13 22:44:15 --> Total execution time: 1.0771
DEBUG - 2015-02-13 22:59:16 --> Config Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Hooks Class Initialized
DEBUG - 2015-02-13 22:59:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 22:59:16 --> Utf8 Class Initialized
DEBUG - 2015-02-13 22:59:16 --> URI Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Router Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Output Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Security Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Input Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 22:59:16 --> Language Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Loader Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: url_helper
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: link_helper
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 22:59:16 --> CI_Session Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Session: Regenerate ID
DEBUG - 2015-02-13 22:59:16 --> CI_Session routines successfully run
DEBUG - 2015-02-13 22:59:16 --> Model Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Model Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Controller Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 22:59:16 --> Email Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: language_helper
DEBUG - 2015-02-13 22:59:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 22:59:16 --> Model Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Database Driver Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: date_helper
DEBUG - 2015-02-13 22:59:16 --> Helper loaded: form_helper
DEBUG - 2015-02-13 22:59:16 --> Form Validation Class Initialized
DEBUG - 2015-02-13 22:59:16 --> Model Class Initialized
DEBUG - 2015-02-13 22:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 22:59:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 22:59:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 22:59:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 22:59:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 22:59:17 --> Final output sent to browser
DEBUG - 2015-02-13 22:59:17 --> Total execution time: 1.1151
DEBUG - 2015-02-13 23:14:17 --> Config Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Hooks Class Initialized
DEBUG - 2015-02-13 23:14:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 23:14:17 --> Utf8 Class Initialized
DEBUG - 2015-02-13 23:14:17 --> URI Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Router Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Output Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Security Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Input Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 23:14:17 --> Language Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Loader Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 23:14:17 --> Helper loaded: url_helper
DEBUG - 2015-02-13 23:14:17 --> Helper loaded: link_helper
DEBUG - 2015-02-13 23:14:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 23:14:17 --> CI_Session Class Initialized
DEBUG - 2015-02-13 23:14:17 --> Session: Regenerate ID
DEBUG - 2015-02-13 23:14:17 --> CI_Session routines successfully run
DEBUG - 2015-02-13 23:14:18 --> Model Class Initialized
DEBUG - 2015-02-13 23:14:18 --> Model Class Initialized
DEBUG - 2015-02-13 23:14:18 --> Controller Class Initialized
DEBUG - 2015-02-13 23:14:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 23:14:18 --> Email Class Initialized
DEBUG - 2015-02-13 23:14:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 23:14:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 23:14:18 --> Helper loaded: language_helper
DEBUG - 2015-02-13 23:14:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 23:14:18 --> Model Class Initialized
DEBUG - 2015-02-13 23:14:18 --> Database Driver Class Initialized
DEBUG - 2015-02-13 23:14:18 --> Helper loaded: date_helper
DEBUG - 2015-02-13 23:14:18 --> Helper loaded: form_helper
DEBUG - 2015-02-13 23:14:18 --> Form Validation Class Initialized
DEBUG - 2015-02-13 23:14:18 --> Model Class Initialized
DEBUG - 2015-02-13 23:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 23:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 23:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 23:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 23:14:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 23:14:18 --> Final output sent to browser
DEBUG - 2015-02-13 23:14:18 --> Total execution time: 1.1691
DEBUG - 2015-02-13 23:29:19 --> Config Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Hooks Class Initialized
DEBUG - 2015-02-13 23:29:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 23:29:19 --> Utf8 Class Initialized
DEBUG - 2015-02-13 23:29:19 --> URI Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Router Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Output Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Security Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Input Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 23:29:19 --> Language Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Loader Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: url_helper
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: link_helper
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 23:29:19 --> CI_Session Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Session: Regenerate ID
DEBUG - 2015-02-13 23:29:19 --> CI_Session routines successfully run
DEBUG - 2015-02-13 23:29:19 --> Model Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Model Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Controller Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 23:29:19 --> Email Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: language_helper
DEBUG - 2015-02-13 23:29:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 23:29:19 --> Model Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Database Driver Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: date_helper
DEBUG - 2015-02-13 23:29:19 --> Helper loaded: form_helper
DEBUG - 2015-02-13 23:29:19 --> Form Validation Class Initialized
DEBUG - 2015-02-13 23:29:19 --> Model Class Initialized
DEBUG - 2015-02-13 23:29:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 23:29:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 23:29:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 23:29:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 23:29:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 23:29:20 --> Final output sent to browser
DEBUG - 2015-02-13 23:29:20 --> Total execution time: 1.1851
DEBUG - 2015-02-13 23:44:21 --> Config Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Hooks Class Initialized
DEBUG - 2015-02-13 23:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 23:44:21 --> Utf8 Class Initialized
DEBUG - 2015-02-13 23:44:21 --> URI Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Router Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Output Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Security Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Input Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 23:44:21 --> Language Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Loader Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: url_helper
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: link_helper
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 23:44:21 --> CI_Session Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Session: Regenerate ID
DEBUG - 2015-02-13 23:44:21 --> CI_Session routines successfully run
DEBUG - 2015-02-13 23:44:21 --> Model Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Model Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Controller Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 23:44:21 --> Email Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: language_helper
DEBUG - 2015-02-13 23:44:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 23:44:21 --> Model Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Database Driver Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: date_helper
DEBUG - 2015-02-13 23:44:21 --> Helper loaded: form_helper
DEBUG - 2015-02-13 23:44:21 --> Form Validation Class Initialized
DEBUG - 2015-02-13 23:44:21 --> Model Class Initialized
DEBUG - 2015-02-13 23:44:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 23:44:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 23:44:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 23:44:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 23:44:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 23:44:22 --> Final output sent to browser
DEBUG - 2015-02-13 23:44:22 --> Total execution time: 1.1001
DEBUG - 2015-02-13 23:59:22 --> Config Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Hooks Class Initialized
DEBUG - 2015-02-13 23:59:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-13 23:59:22 --> Utf8 Class Initialized
DEBUG - 2015-02-13 23:59:22 --> URI Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Router Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Output Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Security Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Input Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-13 23:59:22 --> Language Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Loader Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: url_helper
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: link_helper
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-13 23:59:22 --> CI_Session Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Session: Regenerate ID
DEBUG - 2015-02-13 23:59:22 --> CI_Session routines successfully run
DEBUG - 2015-02-13 23:59:22 --> Model Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Model Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Controller Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-13 23:59:22 --> Email Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: language_helper
DEBUG - 2015-02-13 23:59:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-13 23:59:22 --> Model Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Database Driver Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: date_helper
DEBUG - 2015-02-13 23:59:22 --> Helper loaded: form_helper
DEBUG - 2015-02-13 23:59:22 --> Form Validation Class Initialized
DEBUG - 2015-02-13 23:59:22 --> Model Class Initialized
DEBUG - 2015-02-13 23:59:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-13 23:59:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-13 23:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/edit.php
DEBUG - 2015-02-13 23:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-13 23:59:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-13 23:59:23 --> Final output sent to browser
DEBUG - 2015-02-13 23:59:23 --> Total execution time: 1.2421
