<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-29 11:04:21 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:21 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:21 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:21 --> No URI present. Default controller set.
DEBUG - 2015-01-29 11:04:21 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:21 --> Language Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Loader Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:04:21 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:04:21 --> CI_Session Class Initialized
ERROR - 2015-01-29 11:04:21 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-01-29 11:04:21 --> Session: Creating new session (709868b8ddf2575d68a0d3cb4667f2e3)
DEBUG - 2015-01-29 11:04:21 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:04:21 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Controller Class Initialized
DEBUG - 2015-01-29 11:04:21 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-01-29 11:04:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-01-29 11:04:21 --> Final output sent to browser
DEBUG - 2015-01-29 11:04:21 --> Total execution time: 0.2970
DEBUG - 2015-01-29 11:04:25 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:25 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:25 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:25 --> No URI present. Default controller set.
DEBUG - 2015-01-29 11:04:25 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:25 --> Language Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Loader Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:04:25 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:04:25 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:04:25 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:04:25 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Controller Class Initialized
DEBUG - 2015-01-29 11:04:25 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-01-29 11:04:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-01-29 11:04:25 --> Final output sent to browser
DEBUG - 2015-01-29 11:04:25 --> Total execution time: 0.3040
DEBUG - 2015-01-29 11:04:39 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:39 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:39 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:39 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:39 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:39 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:39 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:39 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:39 --> Language Class Initialized
ERROR - 2015-01-29 11:04:39 --> 404 Page Not Found: admin/User/index
DEBUG - 2015-01-29 11:04:41 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:41 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:41 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:41 --> Language Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Loader Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:04:41 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:04:41 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:04:41 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:04:41 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Controller Class Initialized
DEBUG - 2015-01-29 11:04:41 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:04:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:04:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-01-29 11:04:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 11:04:41 --> Final output sent to browser
DEBUG - 2015-01-29 11:04:41 --> Total execution time: 0.4990
DEBUG - 2015-01-29 11:04:45 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:45 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:45 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:45 --> Language Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Loader Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:04:45 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:04:45 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:04:45 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:04:45 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Controller Class Initialized
DEBUG - 2015-01-29 11:04:45 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:04:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:04:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-01-29 11:04:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 11:04:45 --> Final output sent to browser
DEBUG - 2015-01-29 11:04:45 --> Total execution time: 0.2920
DEBUG - 2015-01-29 11:04:47 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:47 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:47 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:47 --> Language Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Loader Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:04:47 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:04:47 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:04:47 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:04:47 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Controller Class Initialized
DEBUG - 2015-01-29 11:04:47 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:04:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:04:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 11:04:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 11:04:47 --> Final output sent to browser
DEBUG - 2015-01-29 11:04:47 --> Total execution time: 0.1870
DEBUG - 2015-01-29 11:04:50 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:50 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:50 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:50 --> Language Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Loader Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:04:50 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:04:50 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:04:50 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:04:50 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Controller Class Initialized
DEBUG - 2015-01-29 11:04:50 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:04:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:04:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-01-29 11:04:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 11:04:50 --> Final output sent to browser
DEBUG - 2015-01-29 11:04:50 --> Total execution time: 0.3360
DEBUG - 2015-01-29 11:04:53 --> Config Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:04:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:04:53 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:04:53 --> URI Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Router Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Output Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Security Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Input Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:04:53 --> Language Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Loader Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:04:53 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:04:53 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:04:53 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:04:53 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Controller Class Initialized
DEBUG - 2015-01-29 11:04:53 --> Model Class Initialized
DEBUG - 2015-01-29 11:04:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:04:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:04:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-01-29 11:04:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 11:04:53 --> Final output sent to browser
DEBUG - 2015-01-29 11:04:53 --> Total execution time: 0.2760
DEBUG - 2015-01-29 11:05:01 --> Config Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:05:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:05:01 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:05:01 --> URI Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Router Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Output Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Security Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Input Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:05:01 --> Language Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Loader Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:05:01 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:05:01 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:05:01 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:05:01 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Controller Class Initialized
DEBUG - 2015-01-29 11:05:01 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:05:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:05:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-01-29 11:05:02 --> Config Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:05:02 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:05:02 --> URI Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Router Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Output Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Security Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Input Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:05:02 --> Language Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Loader Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:05:02 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:05:02 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:05:02 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:05:02 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Controller Class Initialized
DEBUG - 2015-01-29 11:05:02 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:05:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:05:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-01-29 11:05:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 11:05:02 --> Final output sent to browser
DEBUG - 2015-01-29 11:05:02 --> Total execution time: 0.2820
DEBUG - 2015-01-29 11:05:07 --> Config Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:05:07 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:05:07 --> URI Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Router Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Output Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Security Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Input Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:05:07 --> Language Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Loader Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:05:07 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:05:07 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:05:07 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:05:07 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Controller Class Initialized
DEBUG - 2015-01-29 11:05:07 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 11:05:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 11:05:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-01-29 11:05:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 11:05:07 --> Final output sent to browser
DEBUG - 2015-01-29 11:05:07 --> Total execution time: 0.3830
DEBUG - 2015-01-29 11:05:10 --> Config Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:05:10 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:05:10 --> URI Class Initialized
DEBUG - 2015-01-29 11:05:10 --> No URI present. Default controller set.
DEBUG - 2015-01-29 11:05:10 --> Router Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Output Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Security Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Input Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:05:10 --> Language Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Loader Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:05:10 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:05:10 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:05:10 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:05:10 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Controller Class Initialized
DEBUG - 2015-01-29 11:05:10 --> Model Class Initialized
DEBUG - 2015-01-29 11:05:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-01-29 11:05:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-01-29 11:05:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:05:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:05:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:05:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:05:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:05:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:05:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-01-29 11:05:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-01-29 11:05:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-01-29 11:05:11 --> Final output sent to browser
DEBUG - 2015-01-29 11:05:11 --> Total execution time: 0.3180
DEBUG - 2015-01-29 11:09:09 --> Config Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Hooks Class Initialized
DEBUG - 2015-01-29 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 11:09:09 --> Utf8 Class Initialized
DEBUG - 2015-01-29 11:09:09 --> URI Class Initialized
DEBUG - 2015-01-29 11:09:09 --> No URI present. Default controller set.
DEBUG - 2015-01-29 11:09:09 --> Router Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Output Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Security Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Input Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 11:09:09 --> Language Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Loader Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Helper loaded: url_helper
DEBUG - 2015-01-29 11:09:09 --> Helper loaded: link_helper
DEBUG - 2015-01-29 11:09:09 --> CI_Session Class Initialized
DEBUG - 2015-01-29 11:09:09 --> CI_Session routines successfully run
DEBUG - 2015-01-29 11:09:09 --> Model Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Model Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Controller Class Initialized
DEBUG - 2015-01-29 11:09:09 --> Model Class Initialized
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-01-29 11:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-01-29 11:09:09 --> Final output sent to browser
DEBUG - 2015-01-29 11:09:09 --> Total execution time: 0.3560
DEBUG - 2015-01-29 14:09:47 --> Config Class Initialized
DEBUG - 2015-01-29 14:09:47 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:09:47 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:09:47 --> URI Class Initialized
DEBUG - 2015-01-29 14:09:47 --> No URI present. Default controller set.
DEBUG - 2015-01-29 14:09:47 --> Router Class Initialized
DEBUG - 2015-01-29 14:09:47 --> Output Class Initialized
DEBUG - 2015-01-29 14:09:47 --> Security Class Initialized
DEBUG - 2015-01-29 14:09:47 --> Input Class Initialized
DEBUG - 2015-01-29 14:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:09:47 --> Language Class Initialized
DEBUG - 2015-01-29 14:09:47 --> Loader Class Initialized
DEBUG - 2015-01-29 14:09:47 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:09:47 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:09:48 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:09:48 --> A session cookie was not found.
DEBUG - 2015-01-29 14:09:48 --> Session: Creating new session (8bdde1110aee797dfff6ef09c32cf60a)
DEBUG - 2015-01-29 14:09:48 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:09:48 --> Model Class Initialized
DEBUG - 2015-01-29 14:09:48 --> Model Class Initialized
DEBUG - 2015-01-29 14:09:48 --> Controller Class Initialized
DEBUG - 2015-01-29 14:09:48 --> Model Class Initialized
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-01-29 14:09:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-01-29 14:09:50 --> Final output sent to browser
DEBUG - 2015-01-29 14:09:50 --> Total execution time: 2.7983
DEBUG - 2015-01-29 14:16:57 --> Config Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:16:57 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:16:57 --> URI Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Router Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Output Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Security Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Input Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:16:57 --> Language Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Loader Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:16:57 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:16:57 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Session: Regenerate ID
DEBUG - 2015-01-29 14:16:57 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:16:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Controller Class Initialized
DEBUG - 2015-01-29 14:16:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:16:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:16:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:16:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:16:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:16:57 --> Final output sent to browser
DEBUG - 2015-01-29 14:16:57 --> Total execution time: 0.2290
DEBUG - 2015-01-29 14:18:51 --> Config Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:18:51 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:18:51 --> URI Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Router Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Output Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Security Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Input Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:18:51 --> Language Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Loader Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:18:51 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:18:51 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:18:51 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:18:51 --> Model Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Model Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Controller Class Initialized
DEBUG - 2015-01-29 14:18:51 --> Model Class Initialized
DEBUG - 2015-01-29 14:18:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:18:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:18:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:18:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:18:51 --> Final output sent to browser
DEBUG - 2015-01-29 14:18:51 --> Total execution time: 0.1490
DEBUG - 2015-01-29 14:18:57 --> Config Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:18:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:18:57 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:18:57 --> URI Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Router Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Output Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Security Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Input Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:18:57 --> Language Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Loader Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:18:57 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:18:57 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:18:57 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:18:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Controller Class Initialized
DEBUG - 2015-01-29 14:18:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:18:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:18:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:18:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:18:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:18:57 --> Final output sent to browser
DEBUG - 2015-01-29 14:18:57 --> Total execution time: 0.1520
DEBUG - 2015-01-29 14:19:15 --> Config Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:19:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:19:15 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:19:15 --> URI Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Router Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Output Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Security Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Input Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:19:15 --> Language Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Loader Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:19:15 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:19:15 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:19:15 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:19:15 --> Model Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Model Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Controller Class Initialized
DEBUG - 2015-01-29 14:19:15 --> Model Class Initialized
DEBUG - 2015-01-29 14:19:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:19:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:19:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:19:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:19:15 --> Final output sent to browser
DEBUG - 2015-01-29 14:19:15 --> Total execution time: 0.1500
DEBUG - 2015-01-29 14:19:32 --> Config Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:19:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:19:32 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:19:32 --> URI Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Router Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Output Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Security Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Input Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:19:32 --> Language Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Loader Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:19:32 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:19:32 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:19:32 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:19:32 --> Model Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Model Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Controller Class Initialized
DEBUG - 2015-01-29 14:19:32 --> Model Class Initialized
DEBUG - 2015-01-29 14:19:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:19:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:19:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:19:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:19:32 --> Final output sent to browser
DEBUG - 2015-01-29 14:19:32 --> Total execution time: 0.1490
DEBUG - 2015-01-29 14:20:53 --> Config Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:20:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:20:53 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:20:53 --> URI Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Router Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Output Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Security Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Input Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:20:53 --> Language Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Loader Class Initialized
DEBUG - 2015-01-29 14:20:53 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:20:53 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:20:53 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:20:53 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:20:54 --> Model Class Initialized
DEBUG - 2015-01-29 14:20:54 --> Model Class Initialized
DEBUG - 2015-01-29 14:20:54 --> Controller Class Initialized
DEBUG - 2015-01-29 14:20:54 --> Model Class Initialized
DEBUG - 2015-01-29 14:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:20:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:20:54 --> Final output sent to browser
DEBUG - 2015-01-29 14:20:54 --> Total execution time: 0.1800
DEBUG - 2015-01-29 14:20:57 --> Config Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:20:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:20:57 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:20:57 --> URI Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Router Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Output Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Security Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Input Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:20:57 --> Language Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Loader Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:20:57 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:20:57 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:20:57 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:20:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Controller Class Initialized
DEBUG - 2015-01-29 14:20:57 --> Model Class Initialized
DEBUG - 2015-01-29 14:20:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:20:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:20:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:20:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:20:57 --> Final output sent to browser
DEBUG - 2015-01-29 14:20:57 --> Total execution time: 0.1550
DEBUG - 2015-01-29 14:21:05 --> Config Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:21:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:21:05 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:21:05 --> URI Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Router Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Output Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Security Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Input Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:21:05 --> Language Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Loader Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:21:05 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:21:05 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:21:05 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:21:05 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Controller Class Initialized
DEBUG - 2015-01-29 14:21:05 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:21:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:21:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:21:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:21:05 --> Final output sent to browser
DEBUG - 2015-01-29 14:21:05 --> Total execution time: 0.1570
DEBUG - 2015-01-29 14:21:40 --> Config Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:21:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:21:40 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:21:40 --> URI Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Router Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Output Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Security Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Input Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:21:40 --> Language Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Loader Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:21:40 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:21:40 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:21:40 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:21:40 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Controller Class Initialized
DEBUG - 2015-01-29 14:21:40 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:21:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:21:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:21:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:21:40 --> Final output sent to browser
DEBUG - 2015-01-29 14:21:40 --> Total execution time: 0.2370
DEBUG - 2015-01-29 14:21:58 --> Config Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:21:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:21:58 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:21:58 --> URI Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Router Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Output Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Security Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Input Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:21:58 --> Language Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Loader Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:21:58 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:21:58 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Session: Regenerate ID
DEBUG - 2015-01-29 14:21:58 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:21:58 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Controller Class Initialized
DEBUG - 2015-01-29 14:21:58 --> Model Class Initialized
DEBUG - 2015-01-29 14:21:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:21:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:21:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:21:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:21:58 --> Final output sent to browser
DEBUG - 2015-01-29 14:21:58 --> Total execution time: 0.1520
DEBUG - 2015-01-29 14:22:43 --> Config Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:22:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:22:43 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:22:43 --> URI Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Router Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Output Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Security Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Input Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:22:43 --> Language Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Loader Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:22:43 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:22:43 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:22:43 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:22:43 --> Model Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Model Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Controller Class Initialized
DEBUG - 2015-01-29 14:22:43 --> Model Class Initialized
DEBUG - 2015-01-29 14:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:22:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:22:43 --> Final output sent to browser
DEBUG - 2015-01-29 14:22:43 --> Total execution time: 0.1930
DEBUG - 2015-01-29 14:23:52 --> Config Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Hooks Class Initialized
DEBUG - 2015-01-29 14:23:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-29 14:23:52 --> Utf8 Class Initialized
DEBUG - 2015-01-29 14:23:52 --> URI Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Router Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Output Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Security Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Input Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-29 14:23:52 --> Language Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Loader Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Helper loaded: url_helper
DEBUG - 2015-01-29 14:23:52 --> Helper loaded: link_helper
DEBUG - 2015-01-29 14:23:52 --> CI_Session Class Initialized
DEBUG - 2015-01-29 14:23:52 --> CI_Session routines successfully run
DEBUG - 2015-01-29 14:23:52 --> Model Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Model Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Controller Class Initialized
DEBUG - 2015-01-29 14:23:52 --> Model Class Initialized
DEBUG - 2015-01-29 14:23:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-29 14:23:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-29 14:23:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/add.php
DEBUG - 2015-01-29 14:23:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-29 14:23:52 --> Final output sent to browser
DEBUG - 2015-01-29 14:23:52 --> Total execution time: 0.1720
