<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-07 00:01:16 --> Config Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Hooks Class Initialized
DEBUG - 2015-02-07 00:01:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 00:01:16 --> Utf8 Class Initialized
DEBUG - 2015-02-07 00:01:16 --> URI Class Initialized
DEBUG - 2015-02-07 00:01:16 --> No URI present. Default controller set.
DEBUG - 2015-02-07 00:01:16 --> Router Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Output Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Security Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Input Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 00:01:16 --> Language Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Loader Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 00:01:16 --> Helper loaded: url_helper
DEBUG - 2015-02-07 00:01:16 --> Helper loaded: link_helper
DEBUG - 2015-02-07 00:01:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 00:01:16 --> CI_Session Class Initialized
DEBUG - 2015-02-07 00:01:16 --> Session: Regenerate ID
DEBUG - 2015-02-07 00:01:16 --> CI_Session routines successfully run
DEBUG - 2015-02-07 00:01:17 --> Model Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Model Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Controller Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 00:01:17 --> Email Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 00:01:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 00:01:17 --> Helper loaded: language_helper
DEBUG - 2015-02-07 00:01:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 00:01:17 --> Model Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Database Driver Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Helper loaded: date_helper
DEBUG - 2015-02-07 00:01:17 --> Helper loaded: form_helper
DEBUG - 2015-02-07 00:01:17 --> Form Validation Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Model Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 00:01:17 --> Pagination Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Model Class Initialized
DEBUG - 2015-02-07 00:01:17 --> Model Class Initialized
DEBUG - 2015-02-07 00:01:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 00:01:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 00:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 00:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 00:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 00:01:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 00:01:18 --> Final output sent to browser
DEBUG - 2015-02-07 00:01:18 --> Total execution time: 1.1341
DEBUG - 2015-02-07 00:16:19 --> Config Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Hooks Class Initialized
DEBUG - 2015-02-07 00:16:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 00:16:19 --> Utf8 Class Initialized
DEBUG - 2015-02-07 00:16:19 --> URI Class Initialized
DEBUG - 2015-02-07 00:16:19 --> No URI present. Default controller set.
DEBUG - 2015-02-07 00:16:19 --> Router Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Output Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Security Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Input Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 00:16:19 --> Language Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Loader Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: url_helper
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: link_helper
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 00:16:19 --> CI_Session Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Session: Regenerate ID
DEBUG - 2015-02-07 00:16:19 --> CI_Session routines successfully run
DEBUG - 2015-02-07 00:16:19 --> Model Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Model Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Controller Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 00:16:19 --> Email Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: language_helper
DEBUG - 2015-02-07 00:16:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 00:16:19 --> Model Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Database Driver Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: date_helper
DEBUG - 2015-02-07 00:16:19 --> Helper loaded: form_helper
DEBUG - 2015-02-07 00:16:19 --> Form Validation Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Model Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 00:16:19 --> Pagination Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Model Class Initialized
DEBUG - 2015-02-07 00:16:19 --> Model Class Initialized
DEBUG - 2015-02-07 00:16:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 00:16:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 00:16:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 00:16:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 00:16:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 00:16:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 00:16:20 --> Final output sent to browser
DEBUG - 2015-02-07 00:16:20 --> Total execution time: 1.2241
DEBUG - 2015-02-07 00:31:21 --> Config Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Hooks Class Initialized
DEBUG - 2015-02-07 00:31:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 00:31:21 --> Utf8 Class Initialized
DEBUG - 2015-02-07 00:31:21 --> URI Class Initialized
DEBUG - 2015-02-07 00:31:21 --> No URI present. Default controller set.
DEBUG - 2015-02-07 00:31:21 --> Router Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Output Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Security Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Input Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 00:31:21 --> Language Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Loader Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: url_helper
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: link_helper
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 00:31:21 --> CI_Session Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Session: Regenerate ID
DEBUG - 2015-02-07 00:31:21 --> CI_Session routines successfully run
DEBUG - 2015-02-07 00:31:21 --> Model Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Model Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Controller Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 00:31:21 --> Email Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: language_helper
DEBUG - 2015-02-07 00:31:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 00:31:21 --> Model Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Database Driver Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: date_helper
DEBUG - 2015-02-07 00:31:21 --> Helper loaded: form_helper
DEBUG - 2015-02-07 00:31:21 --> Form Validation Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Model Class Initialized
DEBUG - 2015-02-07 00:31:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 00:31:21 --> Pagination Class Initialized
DEBUG - 2015-02-07 00:31:22 --> Model Class Initialized
DEBUG - 2015-02-07 00:31:22 --> Model Class Initialized
DEBUG - 2015-02-07 00:31:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 00:31:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 00:31:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 00:31:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 00:31:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 00:31:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 00:31:22 --> Final output sent to browser
DEBUG - 2015-02-07 00:31:22 --> Total execution time: 1.3651
DEBUG - 2015-02-07 00:46:24 --> Config Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Hooks Class Initialized
DEBUG - 2015-02-07 00:46:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 00:46:24 --> Utf8 Class Initialized
DEBUG - 2015-02-07 00:46:24 --> URI Class Initialized
DEBUG - 2015-02-07 00:46:24 --> No URI present. Default controller set.
DEBUG - 2015-02-07 00:46:24 --> Router Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Output Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Security Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Input Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 00:46:24 --> Language Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Loader Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: url_helper
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: link_helper
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 00:46:24 --> CI_Session Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Session: Regenerate ID
DEBUG - 2015-02-07 00:46:24 --> CI_Session routines successfully run
DEBUG - 2015-02-07 00:46:24 --> Model Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Model Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Controller Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 00:46:24 --> Email Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: language_helper
DEBUG - 2015-02-07 00:46:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 00:46:24 --> Model Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Database Driver Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: date_helper
DEBUG - 2015-02-07 00:46:24 --> Helper loaded: form_helper
DEBUG - 2015-02-07 00:46:24 --> Form Validation Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Model Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 00:46:24 --> Pagination Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Model Class Initialized
DEBUG - 2015-02-07 00:46:24 --> Model Class Initialized
DEBUG - 2015-02-07 00:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 00:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 00:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 00:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 00:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 00:46:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 00:46:25 --> Final output sent to browser
DEBUG - 2015-02-07 00:46:25 --> Total execution time: 1.1541
DEBUG - 2015-02-07 01:01:26 --> Config Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Hooks Class Initialized
DEBUG - 2015-02-07 01:01:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 01:01:26 --> Utf8 Class Initialized
DEBUG - 2015-02-07 01:01:26 --> URI Class Initialized
DEBUG - 2015-02-07 01:01:26 --> No URI present. Default controller set.
DEBUG - 2015-02-07 01:01:26 --> Router Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Output Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Security Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Input Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 01:01:26 --> Language Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Loader Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: url_helper
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: link_helper
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 01:01:26 --> CI_Session Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Session: Regenerate ID
DEBUG - 2015-02-07 01:01:26 --> CI_Session routines successfully run
DEBUG - 2015-02-07 01:01:26 --> Model Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Model Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Controller Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 01:01:26 --> Email Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: language_helper
DEBUG - 2015-02-07 01:01:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 01:01:26 --> Model Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Database Driver Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: date_helper
DEBUG - 2015-02-07 01:01:26 --> Helper loaded: form_helper
DEBUG - 2015-02-07 01:01:26 --> Form Validation Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Model Class Initialized
DEBUG - 2015-02-07 01:01:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 01:01:26 --> Pagination Class Initialized
DEBUG - 2015-02-07 01:01:27 --> Model Class Initialized
DEBUG - 2015-02-07 01:01:27 --> Model Class Initialized
DEBUG - 2015-02-07 01:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 01:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 01:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 01:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 01:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 01:01:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 01:01:27 --> Final output sent to browser
DEBUG - 2015-02-07 01:01:27 --> Total execution time: 1.1791
DEBUG - 2015-02-07 01:16:29 --> Config Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Hooks Class Initialized
DEBUG - 2015-02-07 01:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 01:16:29 --> Utf8 Class Initialized
DEBUG - 2015-02-07 01:16:29 --> URI Class Initialized
DEBUG - 2015-02-07 01:16:29 --> No URI present. Default controller set.
DEBUG - 2015-02-07 01:16:29 --> Router Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Output Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Security Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Input Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 01:16:29 --> Language Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Loader Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: url_helper
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: link_helper
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 01:16:29 --> CI_Session Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Session: Regenerate ID
DEBUG - 2015-02-07 01:16:29 --> CI_Session routines successfully run
DEBUG - 2015-02-07 01:16:29 --> Model Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Model Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Controller Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 01:16:29 --> Email Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: language_helper
DEBUG - 2015-02-07 01:16:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 01:16:29 --> Model Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Database Driver Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: date_helper
DEBUG - 2015-02-07 01:16:29 --> Helper loaded: form_helper
DEBUG - 2015-02-07 01:16:29 --> Form Validation Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Model Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 01:16:29 --> Pagination Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Model Class Initialized
DEBUG - 2015-02-07 01:16:29 --> Model Class Initialized
DEBUG - 2015-02-07 01:16:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 01:16:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 01:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 01:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 01:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 01:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 01:16:30 --> Final output sent to browser
DEBUG - 2015-02-07 01:16:30 --> Total execution time: 1.1371
DEBUG - 2015-02-07 01:23:00 --> Config Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Hooks Class Initialized
DEBUG - 2015-02-07 01:23:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 01:23:00 --> Utf8 Class Initialized
DEBUG - 2015-02-07 01:23:00 --> URI Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Router Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Output Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Security Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Input Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 01:23:00 --> Language Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Loader Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: url_helper
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: link_helper
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 01:23:00 --> CI_Session Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Session: Regenerate ID
DEBUG - 2015-02-07 01:23:00 --> CI_Session routines successfully run
DEBUG - 2015-02-07 01:23:00 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Controller Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 01:23:00 --> Email Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: language_helper
DEBUG - 2015-02-07 01:23:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 01:23:00 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Database Driver Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: date_helper
DEBUG - 2015-02-07 01:23:00 --> Helper loaded: form_helper
DEBUG - 2015-02-07 01:23:00 --> Form Validation Class Initialized
DEBUG - 2015-02-07 01:23:00 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 01:23:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 01:23:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-07 01:23:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 01:23:00 --> Final output sent to browser
DEBUG - 2015-02-07 01:23:00 --> Total execution time: 0.6731
DEBUG - 2015-02-07 01:23:07 --> Config Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Hooks Class Initialized
DEBUG - 2015-02-07 01:23:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 01:23:07 --> Utf8 Class Initialized
DEBUG - 2015-02-07 01:23:07 --> URI Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Router Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Output Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Security Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Input Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 01:23:07 --> Language Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Loader Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: url_helper
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: link_helper
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 01:23:07 --> CI_Session Class Initialized
DEBUG - 2015-02-07 01:23:07 --> CI_Session routines successfully run
DEBUG - 2015-02-07 01:23:07 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Controller Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 01:23:07 --> Email Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: language_helper
DEBUG - 2015-02-07 01:23:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 01:23:07 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Database Driver Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: date_helper
DEBUG - 2015-02-07 01:23:07 --> Helper loaded: form_helper
DEBUG - 2015-02-07 01:23:07 --> Form Validation Class Initialized
DEBUG - 2015-02-07 01:23:07 --> Model Class Initialized
DEBUG - 2015-02-07 01:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 01:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 01:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 01:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 01:23:07 --> Final output sent to browser
DEBUG - 2015-02-07 01:23:07 --> Total execution time: 0.5691
DEBUG - 2015-02-07 01:38:08 --> Config Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Hooks Class Initialized
DEBUG - 2015-02-07 01:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 01:38:08 --> Utf8 Class Initialized
DEBUG - 2015-02-07 01:38:08 --> URI Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Router Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Output Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Security Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Input Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 01:38:08 --> Language Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Loader Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: url_helper
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: link_helper
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 01:38:08 --> CI_Session Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Session: Regenerate ID
DEBUG - 2015-02-07 01:38:08 --> CI_Session routines successfully run
DEBUG - 2015-02-07 01:38:08 --> Model Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Model Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Controller Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 01:38:08 --> Email Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: language_helper
DEBUG - 2015-02-07 01:38:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 01:38:08 --> Model Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Database Driver Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: date_helper
DEBUG - 2015-02-07 01:38:08 --> Helper loaded: form_helper
DEBUG - 2015-02-07 01:38:08 --> Form Validation Class Initialized
DEBUG - 2015-02-07 01:38:08 --> Model Class Initialized
DEBUG - 2015-02-07 01:38:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 01:38:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 01:38:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 01:38:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 01:38:08 --> Final output sent to browser
DEBUG - 2015-02-07 01:38:08 --> Total execution time: 0.3790
DEBUG - 2015-02-07 01:53:08 --> Config Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Hooks Class Initialized
DEBUG - 2015-02-07 01:53:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 01:53:08 --> Utf8 Class Initialized
DEBUG - 2015-02-07 01:53:08 --> URI Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Router Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Output Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Security Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Input Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 01:53:08 --> Language Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Loader Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 01:53:08 --> Helper loaded: url_helper
DEBUG - 2015-02-07 01:53:08 --> Helper loaded: link_helper
DEBUG - 2015-02-07 01:53:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 01:53:08 --> CI_Session Class Initialized
DEBUG - 2015-02-07 01:53:08 --> Session: Regenerate ID
DEBUG - 2015-02-07 01:53:08 --> CI_Session routines successfully run
DEBUG - 2015-02-07 01:53:09 --> Model Class Initialized
DEBUG - 2015-02-07 01:53:09 --> Model Class Initialized
DEBUG - 2015-02-07 01:53:09 --> Controller Class Initialized
DEBUG - 2015-02-07 01:53:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 01:53:09 --> Email Class Initialized
DEBUG - 2015-02-07 01:53:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 01:53:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 01:53:09 --> Helper loaded: language_helper
DEBUG - 2015-02-07 01:53:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 01:53:09 --> Model Class Initialized
DEBUG - 2015-02-07 01:53:09 --> Database Driver Class Initialized
DEBUG - 2015-02-07 01:53:09 --> Helper loaded: date_helper
DEBUG - 2015-02-07 01:53:09 --> Helper loaded: form_helper
DEBUG - 2015-02-07 01:53:09 --> Form Validation Class Initialized
DEBUG - 2015-02-07 01:53:09 --> Model Class Initialized
DEBUG - 2015-02-07 01:53:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 01:53:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 01:53:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 01:53:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 01:53:09 --> Final output sent to browser
DEBUG - 2015-02-07 01:53:09 --> Total execution time: 0.4030
DEBUG - 2015-02-07 02:08:09 --> Config Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Hooks Class Initialized
DEBUG - 2015-02-07 02:08:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 02:08:09 --> Utf8 Class Initialized
DEBUG - 2015-02-07 02:08:09 --> URI Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Router Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Output Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Security Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Input Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 02:08:09 --> Language Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Loader Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 02:08:09 --> Helper loaded: url_helper
DEBUG - 2015-02-07 02:08:09 --> Helper loaded: link_helper
DEBUG - 2015-02-07 02:08:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 02:08:09 --> CI_Session Class Initialized
DEBUG - 2015-02-07 02:08:09 --> Session: Regenerate ID
DEBUG - 2015-02-07 02:08:09 --> CI_Session routines successfully run
DEBUG - 2015-02-07 02:08:10 --> Model Class Initialized
DEBUG - 2015-02-07 02:08:10 --> Model Class Initialized
DEBUG - 2015-02-07 02:08:10 --> Controller Class Initialized
DEBUG - 2015-02-07 02:08:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 02:08:10 --> Email Class Initialized
DEBUG - 2015-02-07 02:08:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 02:08:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 02:08:10 --> Helper loaded: language_helper
DEBUG - 2015-02-07 02:08:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 02:08:10 --> Model Class Initialized
DEBUG - 2015-02-07 02:08:10 --> Database Driver Class Initialized
DEBUG - 2015-02-07 02:08:10 --> Helper loaded: date_helper
DEBUG - 2015-02-07 02:08:10 --> Helper loaded: form_helper
DEBUG - 2015-02-07 02:08:10 --> Form Validation Class Initialized
DEBUG - 2015-02-07 02:08:10 --> Model Class Initialized
DEBUG - 2015-02-07 02:08:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 02:08:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 02:08:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 02:08:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 02:08:10 --> Final output sent to browser
DEBUG - 2015-02-07 02:08:10 --> Total execution time: 0.3930
DEBUG - 2015-02-07 02:23:10 --> Config Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Hooks Class Initialized
DEBUG - 2015-02-07 02:23:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 02:23:10 --> Utf8 Class Initialized
DEBUG - 2015-02-07 02:23:10 --> URI Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Router Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Output Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Security Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Input Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 02:23:10 --> Language Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Loader Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 02:23:10 --> Helper loaded: url_helper
DEBUG - 2015-02-07 02:23:10 --> Helper loaded: link_helper
DEBUG - 2015-02-07 02:23:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 02:23:10 --> CI_Session Class Initialized
DEBUG - 2015-02-07 02:23:10 --> Session: Regenerate ID
DEBUG - 2015-02-07 02:23:10 --> CI_Session routines successfully run
DEBUG - 2015-02-07 02:23:11 --> Model Class Initialized
DEBUG - 2015-02-07 02:23:11 --> Model Class Initialized
DEBUG - 2015-02-07 02:23:11 --> Controller Class Initialized
DEBUG - 2015-02-07 02:23:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 02:23:11 --> Email Class Initialized
DEBUG - 2015-02-07 02:23:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 02:23:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 02:23:11 --> Helper loaded: language_helper
DEBUG - 2015-02-07 02:23:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 02:23:11 --> Model Class Initialized
DEBUG - 2015-02-07 02:23:11 --> Database Driver Class Initialized
DEBUG - 2015-02-07 02:23:11 --> Helper loaded: date_helper
DEBUG - 2015-02-07 02:23:11 --> Helper loaded: form_helper
DEBUG - 2015-02-07 02:23:11 --> Form Validation Class Initialized
DEBUG - 2015-02-07 02:23:11 --> Model Class Initialized
DEBUG - 2015-02-07 02:23:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 02:23:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 02:23:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 02:23:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 02:23:11 --> Final output sent to browser
DEBUG - 2015-02-07 02:23:11 --> Total execution time: 0.4760
DEBUG - 2015-02-07 02:38:13 --> Config Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Hooks Class Initialized
DEBUG - 2015-02-07 02:38:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 02:38:13 --> Utf8 Class Initialized
DEBUG - 2015-02-07 02:38:13 --> URI Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Router Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Output Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Security Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Input Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 02:38:13 --> Language Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Loader Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: url_helper
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: link_helper
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 02:38:13 --> CI_Session Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Session: Regenerate ID
DEBUG - 2015-02-07 02:38:13 --> CI_Session routines successfully run
DEBUG - 2015-02-07 02:38:13 --> Model Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Model Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Controller Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 02:38:13 --> Email Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: language_helper
DEBUG - 2015-02-07 02:38:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 02:38:13 --> Model Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Database Driver Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: date_helper
DEBUG - 2015-02-07 02:38:13 --> Helper loaded: form_helper
DEBUG - 2015-02-07 02:38:13 --> Form Validation Class Initialized
DEBUG - 2015-02-07 02:38:13 --> Model Class Initialized
DEBUG - 2015-02-07 02:38:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 02:38:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 02:38:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 02:38:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 02:38:13 --> Final output sent to browser
DEBUG - 2015-02-07 02:38:13 --> Total execution time: 0.3890
DEBUG - 2015-02-07 02:53:14 --> Config Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Hooks Class Initialized
DEBUG - 2015-02-07 02:53:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 02:53:14 --> Utf8 Class Initialized
DEBUG - 2015-02-07 02:53:14 --> URI Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Router Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Output Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Security Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Input Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 02:53:14 --> Language Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Loader Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: url_helper
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: link_helper
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 02:53:14 --> CI_Session Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Session: Regenerate ID
DEBUG - 2015-02-07 02:53:14 --> CI_Session routines successfully run
DEBUG - 2015-02-07 02:53:14 --> Model Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Model Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Controller Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 02:53:14 --> Email Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: language_helper
DEBUG - 2015-02-07 02:53:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 02:53:14 --> Model Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Database Driver Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: date_helper
DEBUG - 2015-02-07 02:53:14 --> Helper loaded: form_helper
DEBUG - 2015-02-07 02:53:14 --> Form Validation Class Initialized
DEBUG - 2015-02-07 02:53:14 --> Model Class Initialized
DEBUG - 2015-02-07 02:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 02:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 02:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 02:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 02:53:14 --> Final output sent to browser
DEBUG - 2015-02-07 02:53:14 --> Total execution time: 0.3760
DEBUG - 2015-02-07 03:08:15 --> Config Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Hooks Class Initialized
DEBUG - 2015-02-07 03:08:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 03:08:15 --> Utf8 Class Initialized
DEBUG - 2015-02-07 03:08:15 --> URI Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Router Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Output Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Security Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Input Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 03:08:15 --> Language Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Loader Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: url_helper
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: link_helper
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 03:08:15 --> CI_Session Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Session: Regenerate ID
DEBUG - 2015-02-07 03:08:15 --> CI_Session routines successfully run
DEBUG - 2015-02-07 03:08:15 --> Model Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Model Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Controller Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 03:08:15 --> Email Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: language_helper
DEBUG - 2015-02-07 03:08:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 03:08:15 --> Model Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Database Driver Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: date_helper
DEBUG - 2015-02-07 03:08:15 --> Helper loaded: form_helper
DEBUG - 2015-02-07 03:08:15 --> Form Validation Class Initialized
DEBUG - 2015-02-07 03:08:15 --> Model Class Initialized
DEBUG - 2015-02-07 03:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 03:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 03:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 03:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 03:08:15 --> Final output sent to browser
DEBUG - 2015-02-07 03:08:15 --> Total execution time: 0.3800
DEBUG - 2015-02-07 03:23:16 --> Config Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Hooks Class Initialized
DEBUG - 2015-02-07 03:23:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 03:23:16 --> Utf8 Class Initialized
DEBUG - 2015-02-07 03:23:16 --> URI Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Router Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Output Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Security Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Input Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 03:23:16 --> Language Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Loader Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: url_helper
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: link_helper
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 03:23:16 --> CI_Session Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Session: Regenerate ID
DEBUG - 2015-02-07 03:23:16 --> CI_Session routines successfully run
DEBUG - 2015-02-07 03:23:16 --> Model Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Model Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Controller Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 03:23:16 --> Email Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: language_helper
DEBUG - 2015-02-07 03:23:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 03:23:16 --> Model Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Database Driver Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: date_helper
DEBUG - 2015-02-07 03:23:16 --> Helper loaded: form_helper
DEBUG - 2015-02-07 03:23:16 --> Form Validation Class Initialized
DEBUG - 2015-02-07 03:23:16 --> Model Class Initialized
DEBUG - 2015-02-07 03:23:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 03:23:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 03:23:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 03:23:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 03:23:16 --> Final output sent to browser
DEBUG - 2015-02-07 03:23:16 --> Total execution time: 0.3800
DEBUG - 2015-02-07 03:38:17 --> Config Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Hooks Class Initialized
DEBUG - 2015-02-07 03:38:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 03:38:17 --> Utf8 Class Initialized
DEBUG - 2015-02-07 03:38:17 --> URI Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Router Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Output Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Security Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Input Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 03:38:17 --> Language Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Loader Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: url_helper
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: link_helper
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 03:38:17 --> CI_Session Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Session: Regenerate ID
DEBUG - 2015-02-07 03:38:17 --> CI_Session routines successfully run
DEBUG - 2015-02-07 03:38:17 --> Model Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Model Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Controller Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 03:38:17 --> Email Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: language_helper
DEBUG - 2015-02-07 03:38:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 03:38:17 --> Model Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Database Driver Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: date_helper
DEBUG - 2015-02-07 03:38:17 --> Helper loaded: form_helper
DEBUG - 2015-02-07 03:38:17 --> Form Validation Class Initialized
DEBUG - 2015-02-07 03:38:17 --> Model Class Initialized
DEBUG - 2015-02-07 03:38:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 03:38:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 03:38:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 03:38:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 03:38:18 --> Final output sent to browser
DEBUG - 2015-02-07 03:38:18 --> Total execution time: 0.4190
DEBUG - 2015-02-07 03:53:19 --> Config Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Hooks Class Initialized
DEBUG - 2015-02-07 03:53:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 03:53:19 --> Utf8 Class Initialized
DEBUG - 2015-02-07 03:53:19 --> URI Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Router Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Output Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Security Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Input Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 03:53:19 --> Language Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Loader Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: url_helper
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: link_helper
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 03:53:19 --> CI_Session Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Session: Regenerate ID
DEBUG - 2015-02-07 03:53:19 --> CI_Session routines successfully run
DEBUG - 2015-02-07 03:53:19 --> Model Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Model Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Controller Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 03:53:19 --> Email Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: language_helper
DEBUG - 2015-02-07 03:53:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 03:53:19 --> Model Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Database Driver Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: date_helper
DEBUG - 2015-02-07 03:53:19 --> Helper loaded: form_helper
DEBUG - 2015-02-07 03:53:19 --> Form Validation Class Initialized
DEBUG - 2015-02-07 03:53:19 --> Model Class Initialized
DEBUG - 2015-02-07 03:53:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 03:53:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 03:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 03:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 03:53:20 --> Final output sent to browser
DEBUG - 2015-02-07 03:53:20 --> Total execution time: 0.3810
DEBUG - 2015-02-07 04:08:21 --> Config Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Hooks Class Initialized
DEBUG - 2015-02-07 04:08:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 04:08:21 --> Utf8 Class Initialized
DEBUG - 2015-02-07 04:08:21 --> URI Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Router Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Output Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Security Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Input Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 04:08:21 --> Language Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Loader Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: url_helper
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: link_helper
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 04:08:21 --> CI_Session Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Session: Regenerate ID
DEBUG - 2015-02-07 04:08:21 --> CI_Session routines successfully run
DEBUG - 2015-02-07 04:08:21 --> Model Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Model Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Controller Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 04:08:21 --> Email Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: language_helper
DEBUG - 2015-02-07 04:08:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 04:08:21 --> Model Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Database Driver Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: date_helper
DEBUG - 2015-02-07 04:08:21 --> Helper loaded: form_helper
DEBUG - 2015-02-07 04:08:21 --> Form Validation Class Initialized
DEBUG - 2015-02-07 04:08:21 --> Model Class Initialized
DEBUG - 2015-02-07 04:08:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 04:08:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 04:08:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 04:08:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 04:08:21 --> Final output sent to browser
DEBUG - 2015-02-07 04:08:21 --> Total execution time: 0.3990
DEBUG - 2015-02-07 04:23:22 --> Config Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Hooks Class Initialized
DEBUG - 2015-02-07 04:23:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 04:23:22 --> Utf8 Class Initialized
DEBUG - 2015-02-07 04:23:22 --> URI Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Router Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Output Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Security Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Input Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 04:23:22 --> Language Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Loader Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: url_helper
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: link_helper
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 04:23:22 --> CI_Session Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Session: Regenerate ID
DEBUG - 2015-02-07 04:23:22 --> CI_Session routines successfully run
DEBUG - 2015-02-07 04:23:22 --> Model Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Model Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Controller Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 04:23:22 --> Email Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: language_helper
DEBUG - 2015-02-07 04:23:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 04:23:22 --> Model Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Database Driver Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: date_helper
DEBUG - 2015-02-07 04:23:22 --> Helper loaded: form_helper
DEBUG - 2015-02-07 04:23:22 --> Form Validation Class Initialized
DEBUG - 2015-02-07 04:23:22 --> Model Class Initialized
DEBUG - 2015-02-07 04:23:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 04:23:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 04:23:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 04:23:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 04:23:22 --> Final output sent to browser
DEBUG - 2015-02-07 04:23:22 --> Total execution time: 0.3690
DEBUG - 2015-02-07 04:38:25 --> Config Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Hooks Class Initialized
DEBUG - 2015-02-07 04:38:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 04:38:25 --> Utf8 Class Initialized
DEBUG - 2015-02-07 04:38:25 --> URI Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Router Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Output Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Security Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Input Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 04:38:25 --> Language Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Loader Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: url_helper
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: link_helper
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 04:38:25 --> CI_Session Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Session: Regenerate ID
DEBUG - 2015-02-07 04:38:25 --> CI_Session routines successfully run
DEBUG - 2015-02-07 04:38:25 --> Model Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Model Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Controller Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 04:38:25 --> Email Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: language_helper
DEBUG - 2015-02-07 04:38:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 04:38:25 --> Model Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Database Driver Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: date_helper
DEBUG - 2015-02-07 04:38:25 --> Helper loaded: form_helper
DEBUG - 2015-02-07 04:38:25 --> Form Validation Class Initialized
DEBUG - 2015-02-07 04:38:25 --> Model Class Initialized
DEBUG - 2015-02-07 04:38:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 04:38:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 04:38:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 04:38:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 04:38:26 --> Final output sent to browser
DEBUG - 2015-02-07 04:38:26 --> Total execution time: 0.3940
DEBUG - 2015-02-07 04:53:27 --> Config Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Hooks Class Initialized
DEBUG - 2015-02-07 04:53:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 04:53:27 --> Utf8 Class Initialized
DEBUG - 2015-02-07 04:53:27 --> URI Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Router Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Output Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Security Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Input Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 04:53:27 --> Language Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Loader Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: url_helper
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: link_helper
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 04:53:27 --> CI_Session Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Session: Regenerate ID
DEBUG - 2015-02-07 04:53:27 --> CI_Session routines successfully run
DEBUG - 2015-02-07 04:53:27 --> Model Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Model Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Controller Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 04:53:27 --> Email Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: language_helper
DEBUG - 2015-02-07 04:53:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 04:53:27 --> Model Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Database Driver Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: date_helper
DEBUG - 2015-02-07 04:53:27 --> Helper loaded: form_helper
DEBUG - 2015-02-07 04:53:27 --> Form Validation Class Initialized
DEBUG - 2015-02-07 04:53:27 --> Model Class Initialized
DEBUG - 2015-02-07 04:53:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 04:53:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 04:53:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 04:53:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 04:53:27 --> Final output sent to browser
DEBUG - 2015-02-07 04:53:27 --> Total execution time: 0.3800
DEBUG - 2015-02-07 05:08:28 --> Config Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Hooks Class Initialized
DEBUG - 2015-02-07 05:08:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 05:08:28 --> Utf8 Class Initialized
DEBUG - 2015-02-07 05:08:28 --> URI Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Router Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Output Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Security Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Input Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 05:08:28 --> Language Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Loader Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: url_helper
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: link_helper
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 05:08:28 --> CI_Session Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Session: Regenerate ID
DEBUG - 2015-02-07 05:08:28 --> CI_Session routines successfully run
DEBUG - 2015-02-07 05:08:28 --> Model Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Model Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Controller Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 05:08:28 --> Email Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: language_helper
DEBUG - 2015-02-07 05:08:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 05:08:28 --> Model Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Database Driver Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: date_helper
DEBUG - 2015-02-07 05:08:28 --> Helper loaded: form_helper
DEBUG - 2015-02-07 05:08:28 --> Form Validation Class Initialized
DEBUG - 2015-02-07 05:08:28 --> Model Class Initialized
DEBUG - 2015-02-07 05:08:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 05:08:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 05:08:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 05:08:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 05:08:28 --> Final output sent to browser
DEBUG - 2015-02-07 05:08:28 --> Total execution time: 0.4220
DEBUG - 2015-02-07 05:23:30 --> Config Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Hooks Class Initialized
DEBUG - 2015-02-07 05:23:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 05:23:30 --> Utf8 Class Initialized
DEBUG - 2015-02-07 05:23:30 --> URI Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Router Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Output Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Security Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Input Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 05:23:30 --> Language Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Loader Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: url_helper
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: link_helper
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 05:23:30 --> CI_Session Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Session: Regenerate ID
DEBUG - 2015-02-07 05:23:30 --> CI_Session routines successfully run
DEBUG - 2015-02-07 05:23:30 --> Model Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Model Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Controller Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 05:23:30 --> Email Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: language_helper
DEBUG - 2015-02-07 05:23:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 05:23:30 --> Model Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Database Driver Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: date_helper
DEBUG - 2015-02-07 05:23:30 --> Helper loaded: form_helper
DEBUG - 2015-02-07 05:23:30 --> Form Validation Class Initialized
DEBUG - 2015-02-07 05:23:30 --> Model Class Initialized
DEBUG - 2015-02-07 05:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 05:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 05:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 05:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 05:23:30 --> Final output sent to browser
DEBUG - 2015-02-07 05:23:30 --> Total execution time: 0.3660
DEBUG - 2015-02-07 05:38:31 --> Config Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Hooks Class Initialized
DEBUG - 2015-02-07 05:38:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 05:38:31 --> Utf8 Class Initialized
DEBUG - 2015-02-07 05:38:31 --> URI Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Router Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Output Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Security Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Input Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 05:38:31 --> Language Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Loader Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: url_helper
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: link_helper
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 05:38:31 --> CI_Session Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Session: Regenerate ID
DEBUG - 2015-02-07 05:38:31 --> CI_Session routines successfully run
DEBUG - 2015-02-07 05:38:31 --> Model Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Model Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Controller Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 05:38:31 --> Email Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: language_helper
DEBUG - 2015-02-07 05:38:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 05:38:31 --> Model Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Database Driver Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: date_helper
DEBUG - 2015-02-07 05:38:31 --> Helper loaded: form_helper
DEBUG - 2015-02-07 05:38:31 --> Form Validation Class Initialized
DEBUG - 2015-02-07 05:38:31 --> Model Class Initialized
DEBUG - 2015-02-07 05:38:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 05:38:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 05:38:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 05:38:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 05:38:31 --> Final output sent to browser
DEBUG - 2015-02-07 05:38:31 --> Total execution time: 0.3820
DEBUG - 2015-02-07 05:53:32 --> Config Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Hooks Class Initialized
DEBUG - 2015-02-07 05:53:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 05:53:32 --> Utf8 Class Initialized
DEBUG - 2015-02-07 05:53:32 --> URI Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Router Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Output Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Security Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Input Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 05:53:32 --> Language Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Loader Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: url_helper
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: link_helper
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 05:53:32 --> CI_Session Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Session: Regenerate ID
DEBUG - 2015-02-07 05:53:32 --> CI_Session routines successfully run
DEBUG - 2015-02-07 05:53:32 --> Model Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Model Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Controller Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 05:53:32 --> Email Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: language_helper
DEBUG - 2015-02-07 05:53:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 05:53:32 --> Model Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Database Driver Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: date_helper
DEBUG - 2015-02-07 05:53:32 --> Helper loaded: form_helper
DEBUG - 2015-02-07 05:53:32 --> Form Validation Class Initialized
DEBUG - 2015-02-07 05:53:32 --> Model Class Initialized
DEBUG - 2015-02-07 05:53:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 05:53:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 05:53:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 05:53:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 05:53:32 --> Final output sent to browser
DEBUG - 2015-02-07 05:53:32 --> Total execution time: 0.3700
DEBUG - 2015-02-07 06:08:32 --> Config Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:08:32 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:08:32 --> URI Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Router Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Output Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Security Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Input Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:08:32 --> Language Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Loader Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:08:32 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:08:32 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:08:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:08:32 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:08:32 --> Session: Regenerate ID
DEBUG - 2015-02-07 06:08:32 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:08:33 --> Controller Class Initialized
DEBUG - 2015-02-07 06:08:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:08:33 --> Email Class Initialized
DEBUG - 2015-02-07 06:08:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:08:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:08:33 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:08:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:08:33 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:08:33 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:08:33 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:08:33 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:08:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:08:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 06:08:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 06:08:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 06:08:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 06:08:33 --> Final output sent to browser
DEBUG - 2015-02-07 06:08:33 --> Total execution time: 0.3880
DEBUG - 2015-02-07 06:23:33 --> Config Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:23:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:23:33 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:23:33 --> URI Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Router Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Output Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Security Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Input Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:23:33 --> Language Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Loader Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:23:33 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Session: Regenerate ID
DEBUG - 2015-02-07 06:23:33 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:23:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Controller Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:23:33 --> Email Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:23:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:23:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:23:33 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:23:33 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:23:33 --> Model Class Initialized
DEBUG - 2015-02-07 06:23:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 06:23:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 06:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 06:23:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 06:23:34 --> Final output sent to browser
DEBUG - 2015-02-07 06:23:34 --> Total execution time: 0.3840
DEBUG - 2015-02-07 06:38:34 --> Config Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:38:34 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:38:34 --> URI Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Router Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Output Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Security Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Input Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:38:34 --> Language Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Loader Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:38:34 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Session: Regenerate ID
DEBUG - 2015-02-07 06:38:34 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:38:34 --> Model Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Model Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Controller Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:38:34 --> Email Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:38:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:38:34 --> Model Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:38:34 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:38:34 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:38:34 --> Model Class Initialized
DEBUG - 2015-02-07 06:38:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 06:38:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 06:38:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 06:38:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 06:38:35 --> Final output sent to browser
DEBUG - 2015-02-07 06:38:35 --> Total execution time: 0.3860
DEBUG - 2015-02-07 06:53:35 --> Config Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:53:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:53:35 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:53:35 --> URI Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Router Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Output Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Security Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Input Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:53:35 --> Language Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Loader Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:53:35 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Session: Regenerate ID
DEBUG - 2015-02-07 06:53:35 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:53:35 --> Model Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Model Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Controller Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:53:35 --> Email Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:53:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:53:35 --> Model Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:53:35 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:53:35 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:53:35 --> Model Class Initialized
DEBUG - 2015-02-07 06:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 06:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 06:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 06:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 06:53:35 --> Final output sent to browser
DEBUG - 2015-02-07 06:53:35 --> Total execution time: 0.3810
DEBUG - 2015-02-07 07:08:36 --> Config Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:08:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:08:36 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:08:36 --> URI Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Router Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Output Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Security Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Input Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:08:36 --> Language Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Loader Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:08:36 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Session: Regenerate ID
DEBUG - 2015-02-07 07:08:36 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:08:36 --> Model Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Model Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Controller Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:08:36 --> Email Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:08:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:08:36 --> Model Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:08:36 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:08:36 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:08:36 --> Model Class Initialized
DEBUG - 2015-02-07 07:08:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 07:08:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 07:08:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 07:08:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 07:08:36 --> Final output sent to browser
DEBUG - 2015-02-07 07:08:36 --> Total execution time: 0.3820
DEBUG - 2015-02-07 07:23:37 --> Config Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:23:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:23:37 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:23:37 --> URI Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Router Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Output Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Security Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Input Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:23:37 --> Language Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Loader Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:23:37 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Session: Regenerate ID
DEBUG - 2015-02-07 07:23:37 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:23:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Controller Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:23:37 --> Email Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:23:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:23:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:23:37 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:23:37 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:23:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:23:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 07:23:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 07:23:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 07:23:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 07:23:38 --> Final output sent to browser
DEBUG - 2015-02-07 07:23:38 --> Total execution time: 0.3570
DEBUG - 2015-02-07 07:38:38 --> Config Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:38:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:38:38 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:38:38 --> URI Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Router Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Output Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Security Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Input Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:38:38 --> Language Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Loader Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:38:38 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Session: Regenerate ID
DEBUG - 2015-02-07 07:38:38 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:38:38 --> Model Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Model Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Controller Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:38:38 --> Email Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:38:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:38:38 --> Model Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:38:38 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:38:38 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:38:38 --> Model Class Initialized
DEBUG - 2015-02-07 07:38:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 07:38:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 07:38:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 07:38:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 07:38:38 --> Final output sent to browser
DEBUG - 2015-02-07 07:38:38 --> Total execution time: 0.3850
DEBUG - 2015-02-07 07:53:39 --> Config Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:53:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:53:39 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:53:39 --> URI Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Router Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Output Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Security Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Input Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:53:39 --> Language Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Loader Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:53:39 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Session: Regenerate ID
DEBUG - 2015-02-07 07:53:39 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:53:39 --> Model Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Model Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Controller Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:53:39 --> Email Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:53:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:53:39 --> Model Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:53:39 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:53:39 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:53:39 --> Model Class Initialized
DEBUG - 2015-02-07 07:53:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 07:53:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 07:53:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 07:53:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 07:53:39 --> Final output sent to browser
DEBUG - 2015-02-07 07:53:39 --> Total execution time: 0.4540
DEBUG - 2015-02-07 08:08:40 --> Config Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:08:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:08:40 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:08:40 --> URI Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Router Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Output Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Security Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Input Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:08:40 --> Language Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Loader Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:08:40 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:08:40 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:08:40 --> Model Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Model Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Controller Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:08:40 --> Email Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:08:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:08:40 --> Model Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:08:40 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:08:40 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:08:40 --> Model Class Initialized
DEBUG - 2015-02-07 08:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 08:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 08:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 08:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 08:08:40 --> Final output sent to browser
DEBUG - 2015-02-07 08:08:40 --> Total execution time: 0.3660
DEBUG - 2015-02-07 08:23:42 --> Config Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:23:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:23:42 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:23:42 --> URI Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Router Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Output Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Security Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Input Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:23:42 --> Language Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Loader Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:23:42 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:23:42 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:23:42 --> Model Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Model Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Controller Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:23:42 --> Email Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:23:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:23:42 --> Model Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:23:42 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:23:42 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:23:42 --> Model Class Initialized
DEBUG - 2015-02-07 08:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 08:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 08:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 08:23:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 08:23:42 --> Final output sent to browser
DEBUG - 2015-02-07 08:23:42 --> Total execution time: 0.3940
DEBUG - 2015-02-07 08:38:43 --> Config Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:38:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:38:43 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:38:43 --> URI Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Router Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Output Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Security Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Input Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:38:43 --> Language Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Loader Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:38:43 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:38:43 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:38:43 --> Model Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Model Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Controller Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:38:43 --> Email Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:38:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:38:43 --> Model Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:38:43 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:38:43 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:38:43 --> Model Class Initialized
DEBUG - 2015-02-07 08:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 08:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 08:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 08:38:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 08:38:43 --> Final output sent to browser
DEBUG - 2015-02-07 08:38:43 --> Total execution time: 0.5090
DEBUG - 2015-02-07 08:53:44 --> Config Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:53:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:53:44 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:53:44 --> URI Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Router Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Output Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Security Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Input Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:53:44 --> Language Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Loader Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:53:44 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:53:44 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:53:44 --> Model Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Model Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Controller Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:53:44 --> Email Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:53:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:53:44 --> Model Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:53:44 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:53:44 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:53:44 --> Model Class Initialized
DEBUG - 2015-02-07 08:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 08:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 08:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 08:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 08:53:44 --> Final output sent to browser
DEBUG - 2015-02-07 08:53:44 --> Total execution time: 0.3820
DEBUG - 2015-02-07 09:08:45 --> Config Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Hooks Class Initialized
DEBUG - 2015-02-07 09:08:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 09:08:45 --> Utf8 Class Initialized
DEBUG - 2015-02-07 09:08:45 --> URI Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Router Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Output Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Security Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Input Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 09:08:45 --> Language Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Loader Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: url_helper
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: link_helper
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 09:08:45 --> CI_Session Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Session: Regenerate ID
DEBUG - 2015-02-07 09:08:45 --> CI_Session routines successfully run
DEBUG - 2015-02-07 09:08:45 --> Model Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Model Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Controller Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 09:08:45 --> Email Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: language_helper
DEBUG - 2015-02-07 09:08:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 09:08:45 --> Model Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Database Driver Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: date_helper
DEBUG - 2015-02-07 09:08:45 --> Helper loaded: form_helper
DEBUG - 2015-02-07 09:08:45 --> Form Validation Class Initialized
DEBUG - 2015-02-07 09:08:45 --> Model Class Initialized
DEBUG - 2015-02-07 09:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 09:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 09:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 09:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 09:08:45 --> Final output sent to browser
DEBUG - 2015-02-07 09:08:45 --> Total execution time: 0.4880
DEBUG - 2015-02-07 09:23:46 --> Config Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Hooks Class Initialized
DEBUG - 2015-02-07 09:23:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 09:23:46 --> Utf8 Class Initialized
DEBUG - 2015-02-07 09:23:46 --> URI Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Router Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Output Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Security Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Input Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 09:23:46 --> Language Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Loader Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: url_helper
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: link_helper
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 09:23:46 --> CI_Session Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Session: Regenerate ID
DEBUG - 2015-02-07 09:23:46 --> CI_Session routines successfully run
DEBUG - 2015-02-07 09:23:46 --> Model Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Model Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Controller Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 09:23:46 --> Email Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: language_helper
DEBUG - 2015-02-07 09:23:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 09:23:46 --> Model Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Database Driver Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: date_helper
DEBUG - 2015-02-07 09:23:46 --> Helper loaded: form_helper
DEBUG - 2015-02-07 09:23:46 --> Form Validation Class Initialized
DEBUG - 2015-02-07 09:23:46 --> Model Class Initialized
DEBUG - 2015-02-07 09:23:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 09:23:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 09:23:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 09:23:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 09:23:46 --> Final output sent to browser
DEBUG - 2015-02-07 09:23:46 --> Total execution time: 0.3980
DEBUG - 2015-02-07 09:38:47 --> Config Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Hooks Class Initialized
DEBUG - 2015-02-07 09:38:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 09:38:47 --> Utf8 Class Initialized
DEBUG - 2015-02-07 09:38:47 --> URI Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Router Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Output Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Security Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Input Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 09:38:47 --> Language Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Loader Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: url_helper
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: link_helper
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 09:38:47 --> CI_Session Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Session: Regenerate ID
DEBUG - 2015-02-07 09:38:47 --> CI_Session routines successfully run
DEBUG - 2015-02-07 09:38:47 --> Model Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Model Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Controller Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 09:38:47 --> Email Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: language_helper
DEBUG - 2015-02-07 09:38:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 09:38:47 --> Model Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Database Driver Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: date_helper
DEBUG - 2015-02-07 09:38:47 --> Helper loaded: form_helper
DEBUG - 2015-02-07 09:38:47 --> Form Validation Class Initialized
DEBUG - 2015-02-07 09:38:47 --> Model Class Initialized
DEBUG - 2015-02-07 09:38:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 09:38:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 09:38:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 09:38:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 09:38:47 --> Final output sent to browser
DEBUG - 2015-02-07 09:38:47 --> Total execution time: 0.3970
DEBUG - 2015-02-07 09:53:47 --> Config Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Hooks Class Initialized
DEBUG - 2015-02-07 09:53:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 09:53:47 --> Utf8 Class Initialized
DEBUG - 2015-02-07 09:53:47 --> URI Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Router Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Output Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Security Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Input Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 09:53:47 --> Language Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Loader Class Initialized
DEBUG - 2015-02-07 09:53:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 09:53:48 --> Helper loaded: url_helper
DEBUG - 2015-02-07 09:53:48 --> Helper loaded: link_helper
DEBUG - 2015-02-07 09:53:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 09:53:48 --> CI_Session Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Session: Regenerate ID
DEBUG - 2015-02-07 09:53:48 --> CI_Session routines successfully run
DEBUG - 2015-02-07 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Controller Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 09:53:48 --> Email Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 09:53:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 09:53:48 --> Helper loaded: language_helper
DEBUG - 2015-02-07 09:53:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Database Driver Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Helper loaded: date_helper
DEBUG - 2015-02-07 09:53:48 --> Helper loaded: form_helper
DEBUG - 2015-02-07 09:53:48 --> Form Validation Class Initialized
DEBUG - 2015-02-07 09:53:48 --> Model Class Initialized
DEBUG - 2015-02-07 09:53:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 09:53:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 09:53:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 09:53:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 09:53:48 --> Final output sent to browser
DEBUG - 2015-02-07 09:53:48 --> Total execution time: 0.3650
DEBUG - 2015-02-07 10:08:48 --> Config Class Initialized
DEBUG - 2015-02-07 10:08:48 --> Hooks Class Initialized
DEBUG - 2015-02-07 10:08:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 10:08:48 --> Utf8 Class Initialized
DEBUG - 2015-02-07 10:08:48 --> URI Class Initialized
DEBUG - 2015-02-07 10:08:48 --> Router Class Initialized
DEBUG - 2015-02-07 10:08:48 --> Output Class Initialized
DEBUG - 2015-02-07 10:08:48 --> Security Class Initialized
DEBUG - 2015-02-07 10:08:48 --> Input Class Initialized
DEBUG - 2015-02-07 10:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 10:08:48 --> Language Class Initialized
DEBUG - 2015-02-07 10:08:48 --> Loader Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: url_helper
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: link_helper
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 10:08:49 --> CI_Session Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Session: Regenerate ID
DEBUG - 2015-02-07 10:08:49 --> CI_Session routines successfully run
DEBUG - 2015-02-07 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Controller Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 10:08:49 --> Email Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: language_helper
DEBUG - 2015-02-07 10:08:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Database Driver Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: date_helper
DEBUG - 2015-02-07 10:08:49 --> Helper loaded: form_helper
DEBUG - 2015-02-07 10:08:49 --> Form Validation Class Initialized
DEBUG - 2015-02-07 10:08:49 --> Model Class Initialized
DEBUG - 2015-02-07 10:08:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 10:08:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 10:08:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 10:08:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 10:08:49 --> Final output sent to browser
DEBUG - 2015-02-07 10:08:49 --> Total execution time: 0.4700
DEBUG - 2015-02-07 10:23:49 --> Config Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Hooks Class Initialized
DEBUG - 2015-02-07 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 10:23:49 --> Utf8 Class Initialized
DEBUG - 2015-02-07 10:23:49 --> URI Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Router Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Output Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Security Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Input Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 10:23:49 --> Language Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Loader Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 10:23:49 --> Helper loaded: url_helper
DEBUG - 2015-02-07 10:23:49 --> Helper loaded: link_helper
DEBUG - 2015-02-07 10:23:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 10:23:49 --> CI_Session Class Initialized
DEBUG - 2015-02-07 10:23:49 --> Session: Regenerate ID
DEBUG - 2015-02-07 10:23:49 --> CI_Session routines successfully run
DEBUG - 2015-02-07 10:23:50 --> Model Class Initialized
DEBUG - 2015-02-07 10:23:50 --> Model Class Initialized
DEBUG - 2015-02-07 10:23:50 --> Controller Class Initialized
DEBUG - 2015-02-07 10:23:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 10:23:50 --> Email Class Initialized
DEBUG - 2015-02-07 10:23:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 10:23:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 10:23:50 --> Helper loaded: language_helper
DEBUG - 2015-02-07 10:23:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 10:23:50 --> Model Class Initialized
DEBUG - 2015-02-07 10:23:50 --> Database Driver Class Initialized
DEBUG - 2015-02-07 10:23:50 --> Helper loaded: date_helper
DEBUG - 2015-02-07 10:23:50 --> Helper loaded: form_helper
DEBUG - 2015-02-07 10:23:50 --> Form Validation Class Initialized
DEBUG - 2015-02-07 10:23:50 --> Model Class Initialized
DEBUG - 2015-02-07 10:23:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 10:23:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 10:23:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 10:23:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 10:23:50 --> Final output sent to browser
DEBUG - 2015-02-07 10:23:50 --> Total execution time: 0.4570
DEBUG - 2015-02-07 10:38:59 --> Config Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Hooks Class Initialized
DEBUG - 2015-02-07 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 10:38:59 --> Utf8 Class Initialized
DEBUG - 2015-02-07 10:38:59 --> URI Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Router Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Output Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Security Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Input Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 10:38:59 --> Language Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Loader Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 10:38:59 --> Helper loaded: url_helper
DEBUG - 2015-02-07 10:38:59 --> Helper loaded: link_helper
DEBUG - 2015-02-07 10:38:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 10:38:59 --> CI_Session Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Session: Regenerate ID
DEBUG - 2015-02-07 10:38:59 --> CI_Session routines successfully run
DEBUG - 2015-02-07 10:38:59 --> Model Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Model Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Controller Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 10:38:59 --> Email Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 10:38:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 10:38:59 --> Helper loaded: language_helper
DEBUG - 2015-02-07 10:38:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 10:38:59 --> Model Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Database Driver Class Initialized
DEBUG - 2015-02-07 10:38:59 --> Helper loaded: date_helper
DEBUG - 2015-02-07 10:39:00 --> Helper loaded: form_helper
DEBUG - 2015-02-07 10:39:00 --> Form Validation Class Initialized
DEBUG - 2015-02-07 10:39:00 --> Model Class Initialized
DEBUG - 2015-02-07 10:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 10:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 10:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 10:39:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 10:39:00 --> Final output sent to browser
DEBUG - 2015-02-07 10:39:00 --> Total execution time: 0.3920
DEBUG - 2015-02-07 10:54:00 --> Config Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Hooks Class Initialized
DEBUG - 2015-02-07 10:54:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 10:54:00 --> Utf8 Class Initialized
DEBUG - 2015-02-07 10:54:00 --> URI Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Router Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Output Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Security Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Input Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 10:54:00 --> Language Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Loader Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: url_helper
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: link_helper
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 10:54:00 --> CI_Session Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Session: Regenerate ID
DEBUG - 2015-02-07 10:54:00 --> CI_Session routines successfully run
DEBUG - 2015-02-07 10:54:00 --> Model Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Model Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Controller Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 10:54:00 --> Email Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: language_helper
DEBUG - 2015-02-07 10:54:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 10:54:00 --> Model Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Database Driver Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: date_helper
DEBUG - 2015-02-07 10:54:00 --> Helper loaded: form_helper
DEBUG - 2015-02-07 10:54:00 --> Form Validation Class Initialized
DEBUG - 2015-02-07 10:54:00 --> Model Class Initialized
DEBUG - 2015-02-07 10:54:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 10:54:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 10:54:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 10:54:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 10:54:01 --> Final output sent to browser
DEBUG - 2015-02-07 10:54:01 --> Total execution time: 0.3970
DEBUG - 2015-02-07 11:09:01 --> Config Class Initialized
DEBUG - 2015-02-07 11:09:01 --> Hooks Class Initialized
DEBUG - 2015-02-07 11:09:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 11:09:02 --> Utf8 Class Initialized
DEBUG - 2015-02-07 11:09:02 --> URI Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Router Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Output Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Security Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Input Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 11:09:02 --> Language Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Loader Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: url_helper
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: link_helper
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 11:09:02 --> CI_Session Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Session: Regenerate ID
DEBUG - 2015-02-07 11:09:02 --> CI_Session routines successfully run
DEBUG - 2015-02-07 11:09:02 --> Model Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Model Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Controller Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 11:09:02 --> Email Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: language_helper
DEBUG - 2015-02-07 11:09:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 11:09:02 --> Model Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Database Driver Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: date_helper
DEBUG - 2015-02-07 11:09:02 --> Helper loaded: form_helper
DEBUG - 2015-02-07 11:09:02 --> Form Validation Class Initialized
DEBUG - 2015-02-07 11:09:02 --> Model Class Initialized
DEBUG - 2015-02-07 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 11:09:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 11:09:02 --> Final output sent to browser
DEBUG - 2015-02-07 11:09:02 --> Total execution time: 0.3920
DEBUG - 2015-02-07 11:24:03 --> Config Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Hooks Class Initialized
DEBUG - 2015-02-07 11:24:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 11:24:03 --> Utf8 Class Initialized
DEBUG - 2015-02-07 11:24:03 --> URI Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Router Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Output Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Security Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Input Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 11:24:03 --> Language Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Loader Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 11:24:03 --> Helper loaded: url_helper
DEBUG - 2015-02-07 11:24:03 --> Helper loaded: link_helper
DEBUG - 2015-02-07 11:24:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 11:24:03 --> CI_Session Class Initialized
DEBUG - 2015-02-07 11:24:03 --> Session: Regenerate ID
DEBUG - 2015-02-07 11:24:03 --> CI_Session routines successfully run
DEBUG - 2015-02-07 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-07 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-07 11:24:04 --> Controller Class Initialized
DEBUG - 2015-02-07 11:24:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 11:24:04 --> Email Class Initialized
DEBUG - 2015-02-07 11:24:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 11:24:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 11:24:04 --> Helper loaded: language_helper
DEBUG - 2015-02-07 11:24:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-07 11:24:04 --> Database Driver Class Initialized
DEBUG - 2015-02-07 11:24:04 --> Helper loaded: date_helper
DEBUG - 2015-02-07 11:24:04 --> Helper loaded: form_helper
DEBUG - 2015-02-07 11:24:04 --> Form Validation Class Initialized
DEBUG - 2015-02-07 11:24:04 --> Model Class Initialized
DEBUG - 2015-02-07 11:24:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 11:24:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 11:24:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 11:24:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 11:24:04 --> Final output sent to browser
DEBUG - 2015-02-07 11:24:04 --> Total execution time: 0.3830
DEBUG - 2015-02-07 11:39:05 --> Config Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Hooks Class Initialized
DEBUG - 2015-02-07 11:39:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 11:39:05 --> Utf8 Class Initialized
DEBUG - 2015-02-07 11:39:05 --> URI Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Router Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Output Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Security Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Input Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 11:39:05 --> Language Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Loader Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: url_helper
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: link_helper
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 11:39:05 --> CI_Session Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Session: Regenerate ID
DEBUG - 2015-02-07 11:39:05 --> CI_Session routines successfully run
DEBUG - 2015-02-07 11:39:05 --> Model Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Model Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Controller Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 11:39:05 --> Email Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: language_helper
DEBUG - 2015-02-07 11:39:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 11:39:05 --> Model Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Database Driver Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: date_helper
DEBUG - 2015-02-07 11:39:05 --> Helper loaded: form_helper
DEBUG - 2015-02-07 11:39:05 --> Form Validation Class Initialized
DEBUG - 2015-02-07 11:39:05 --> Model Class Initialized
DEBUG - 2015-02-07 11:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 11:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 11:39:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 11:39:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 11:39:06 --> Final output sent to browser
DEBUG - 2015-02-07 11:39:06 --> Total execution time: 0.4720
DEBUG - 2015-02-07 11:54:06 --> Config Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Hooks Class Initialized
DEBUG - 2015-02-07 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 11:54:06 --> Utf8 Class Initialized
DEBUG - 2015-02-07 11:54:06 --> URI Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Router Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Output Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Security Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Input Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 11:54:06 --> Language Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Loader Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: url_helper
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: link_helper
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 11:54:06 --> CI_Session Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Session: Regenerate ID
DEBUG - 2015-02-07 11:54:06 --> CI_Session routines successfully run
DEBUG - 2015-02-07 11:54:06 --> Model Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Model Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Controller Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 11:54:06 --> Email Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: language_helper
DEBUG - 2015-02-07 11:54:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 11:54:06 --> Model Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Database Driver Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: date_helper
DEBUG - 2015-02-07 11:54:06 --> Helper loaded: form_helper
DEBUG - 2015-02-07 11:54:06 --> Form Validation Class Initialized
DEBUG - 2015-02-07 11:54:06 --> Model Class Initialized
DEBUG - 2015-02-07 11:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 11:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 11:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 11:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 11:54:07 --> Final output sent to browser
DEBUG - 2015-02-07 11:54:07 --> Total execution time: 0.4150
DEBUG - 2015-02-07 12:09:07 --> Config Class Initialized
DEBUG - 2015-02-07 12:09:07 --> Hooks Class Initialized
DEBUG - 2015-02-07 12:09:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 12:09:07 --> Utf8 Class Initialized
DEBUG - 2015-02-07 12:09:08 --> URI Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Router Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Output Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Security Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Input Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 12:09:08 --> Language Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Loader Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: url_helper
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: link_helper
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 12:09:08 --> CI_Session Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Session: Regenerate ID
DEBUG - 2015-02-07 12:09:08 --> CI_Session routines successfully run
DEBUG - 2015-02-07 12:09:08 --> Model Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Model Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Controller Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 12:09:08 --> Email Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: language_helper
DEBUG - 2015-02-07 12:09:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 12:09:08 --> Model Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Database Driver Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: date_helper
DEBUG - 2015-02-07 12:09:08 --> Helper loaded: form_helper
DEBUG - 2015-02-07 12:09:08 --> Form Validation Class Initialized
DEBUG - 2015-02-07 12:09:08 --> Model Class Initialized
DEBUG - 2015-02-07 12:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 12:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 12:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/edit.php
DEBUG - 2015-02-07 12:09:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 12:09:08 --> Final output sent to browser
DEBUG - 2015-02-07 12:09:08 --> Total execution time: 0.4330
DEBUG - 2015-02-07 06:43:26 --> Config Class Initialized
DEBUG - 2015-02-07 06:43:26 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:43:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:43:26 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:43:26 --> URI Class Initialized
DEBUG - 2015-02-07 06:43:26 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:43:26 --> Router Class Initialized
DEBUG - 2015-02-07 06:43:26 --> Output Class Initialized
DEBUG - 2015-02-07 06:43:26 --> Security Class Initialized
DEBUG - 2015-02-07 06:43:27 --> Input Class Initialized
DEBUG - 2015-02-07 06:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:43:27 --> Language Class Initialized
ERROR - 2015-02-07 06:43:27 --> Severity: Warning --> require(C:\xampp\htdocs\myblog\vendor/tracy/tracy/src/shortcuts.php): failed to open stream: No such file or directory C:\xampp\htdocs\myblog\vendor\composer\autoload_real.php 54
ERROR - 2015-02-07 06:43:27 --> Severity: Compile Error --> require(): Failed opening required 'C:\xampp\htdocs\myblog\vendor/tracy/tracy/src/shortcuts.php' (include_path='.;C:\xampp\php\PEAR') C:\xampp\htdocs\myblog\vendor\composer\autoload_real.php 54
DEBUG - 2015-02-07 06:46:56 --> Config Class Initialized
DEBUG - 2015-02-07 06:46:56 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:46:56 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:46:56 --> URI Class Initialized
DEBUG - 2015-02-07 06:46:56 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:46:56 --> Router Class Initialized
DEBUG - 2015-02-07 06:46:56 --> Output Class Initialized
DEBUG - 2015-02-07 06:46:56 --> Security Class Initialized
DEBUG - 2015-02-07 06:46:56 --> Input Class Initialized
DEBUG - 2015-02-07 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:46:56 --> Language Class Initialized
DEBUG - 2015-02-07 06:46:56 --> Loader Class Initialized
DEBUG - 2015-02-07 06:46:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:46:56 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:46:56 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:46:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:46:56 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:46:56 --> A session cookie was not found.
DEBUG - 2015-02-07 06:46:56 --> Session: Creating new session (55310a78b5bfda938205d300548f4736)
DEBUG - 2015-02-07 06:46:56 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:46:57 --> Model Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Model Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Controller Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:46:57 --> Email Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:46:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:46:57 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:46:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:46:57 --> Model Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:46:57 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:46:57 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Model Class Initialized
DEBUG - 2015-02-07 06:46:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 06:46:57 --> Pagination Class Initialized
DEBUG - 2015-02-07 06:46:58 --> Model Class Initialized
DEBUG - 2015-02-07 06:46:58 --> Model Class Initialized
DEBUG - 2015-02-07 06:46:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:46:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:46:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 06:46:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:46:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:46:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:46:59 --> Final output sent to browser
DEBUG - 2015-02-07 06:46:59 --> Total execution time: 2.6071
DEBUG - 2015-02-07 06:47:39 --> Config Class Initialized
DEBUG - 2015-02-07 06:47:39 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:47:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:47:39 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:47:39 --> URI Class Initialized
DEBUG - 2015-02-07 06:47:39 --> Router Class Initialized
DEBUG - 2015-02-07 06:47:39 --> Output Class Initialized
DEBUG - 2015-02-07 06:47:39 --> Security Class Initialized
DEBUG - 2015-02-07 06:47:39 --> Input Class Initialized
DEBUG - 2015-02-07 06:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:47:39 --> Language Class Initialized
DEBUG - 2015-02-07 06:47:39 --> Loader Class Initialized
DEBUG - 2015-02-07 06:47:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:47:40 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:47:40 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:47:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:47:40 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:47:40 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:47:42 --> Model Class Initialized
DEBUG - 2015-02-07 06:47:42 --> Model Class Initialized
DEBUG - 2015-02-07 06:47:42 --> Controller Class Initialized
DEBUG - 2015-02-07 06:47:42 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:47:42 --> Email Class Initialized
DEBUG - 2015-02-07 06:47:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:47:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:47:42 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:47:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:47:42 --> Model Class Initialized
DEBUG - 2015-02-07 06:47:42 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:47:43 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:47:43 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:47:43 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:47:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 06:47:43 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 06:47:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 06:47:43 --> Model Class Initialized
DEBUG - 2015-02-07 06:47:46 --> Model Class Initialized
DEBUG - 2015-02-07 06:47:47 --> Model Class Initialized
DEBUG - 2015-02-07 06:47:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:47:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:47:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-07 06:47:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:47:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:47:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:47:47 --> Final output sent to browser
DEBUG - 2015-02-07 06:47:47 --> Total execution time: 8.1325
DEBUG - 2015-02-07 06:48:26 --> Config Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:48:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:48:26 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:48:26 --> URI Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Router Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Output Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Security Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Input Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:48:26 --> Language Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Loader Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:48:26 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:48:26 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:48:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:48:26 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:48:26 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:48:26 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Controller Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:48:26 --> Email Class Initialized
DEBUG - 2015-02-07 06:48:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:48:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:48:26 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:48:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:48:27 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:48:27 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:48:27 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 06:48:27 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 06:48:27 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 06:48:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-07 06:48:27 --> Config Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:48:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:48:27 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:48:27 --> URI Class Initialized
DEBUG - 2015-02-07 06:48:27 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:48:27 --> Router Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Output Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Security Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Input Class Initialized
DEBUG - 2015-02-07 06:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:48:27 --> Language Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Loader Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:48:28 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:48:28 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:48:28 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Controller Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:48:28 --> Email Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:48:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:48:28 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:48:28 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:48:28 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 06:48:28 --> Pagination Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:28 --> Model Class Initialized
DEBUG - 2015-02-07 06:48:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:48:28 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:48:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 06:48:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:48:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:48:29 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:48:29 --> Final output sent to browser
DEBUG - 2015-02-07 06:48:29 --> Total execution time: 1.2461
DEBUG - 2015-02-07 06:49:01 --> Config Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:49:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:49:01 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:49:01 --> URI Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Router Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Output Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Security Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Input Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:49:01 --> Language Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Loader Class Initialized
DEBUG - 2015-02-07 06:49:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:49:01 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:49:01 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:49:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:49:01 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:49:01 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:49:01 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Controller Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:49:02 --> Email Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:49:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:49:02 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 06:49:02 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 06:49:02 --> Session: Creating new session (4a1c70c154a28238a676e211d826fb49)
DEBUG - 2015-02-07 06:49:02 --> Config Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:49:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:49:02 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:49:02 --> URI Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Router Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Output Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Security Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Input Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:49:02 --> Language Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Loader Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:49:02 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:49:02 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Controller Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:49:02 --> Email Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:49:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:49:02 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:49:02 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 06:49:02 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:49:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:49:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-07 06:49:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:49:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:49:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:49:02 --> Final output sent to browser
DEBUG - 2015-02-07 06:49:02 --> Total execution time: 0.6550
DEBUG - 2015-02-07 06:49:09 --> Config Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:49:09 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:49:09 --> URI Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Router Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Output Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Security Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Input Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:49:09 --> Language Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Loader Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:49:09 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:49:09 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:49:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Controller Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:49:09 --> Email Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:49:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:49:09 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:49:09 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Config Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:49:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:49:14 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:49:14 --> URI Class Initialized
DEBUG - 2015-02-07 06:49:14 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:49:14 --> Router Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Output Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Security Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Input Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:49:14 --> Language Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Loader Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:49:14 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:49:14 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:49:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:49:14 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:49:14 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:49:14 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Controller Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:49:14 --> Email Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:49:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:49:14 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:49:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:14 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:14 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:49:15 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:49:15 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:49:15 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:49:15 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 06:49:15 --> Pagination Class Initialized
DEBUG - 2015-02-07 06:49:15 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:15 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:49:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:49:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 06:49:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:49:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:49:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:49:15 --> Final output sent to browser
DEBUG - 2015-02-07 06:49:15 --> Total execution time: 0.9211
DEBUG - 2015-02-07 06:49:55 --> Config Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:49:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:49:55 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:49:55 --> URI Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Router Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Output Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Security Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Input Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:49:55 --> Language Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Loader Class Initialized
DEBUG - 2015-02-07 06:49:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:49:55 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:49:55 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:49:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:49:55 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:49:55 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:49:56 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:56 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:56 --> Controller Class Initialized
DEBUG - 2015-02-07 06:49:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:49:56 --> Email Class Initialized
DEBUG - 2015-02-07 06:49:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:49:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:49:56 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:49:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:56 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:56 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:49:56 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:49:56 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:49:56 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:49:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 06:49:56 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 06:49:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 06:49:56 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:57 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:57 --> Model Class Initialized
DEBUG - 2015-02-07 06:49:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:49:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:49:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-07 06:49:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:49:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:49:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:49:57 --> Final output sent to browser
DEBUG - 2015-02-07 06:49:57 --> Total execution time: 2.7012
DEBUG - 2015-02-07 06:50:08 --> Config Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:50:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:50:08 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:50:08 --> URI Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Router Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Output Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Security Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Input Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:50:08 --> Language Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Loader Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:50:08 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:50:08 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:50:08 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Controller Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:50:08 --> Email Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:50:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:50:08 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:50:08 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:50:08 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:50:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 06:50:08 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 06:50:08 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 06:50:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-07 06:50:09 --> Config Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:50:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:50:09 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:50:09 --> URI Class Initialized
DEBUG - 2015-02-07 06:50:09 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:50:09 --> Router Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Output Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Security Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Input Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:50:09 --> Language Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Loader Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:50:09 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:50:09 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:50:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Controller Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:50:09 --> Email Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:50:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:50:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:50:09 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:50:09 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 06:50:09 --> Pagination Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:09 --> Model Class Initialized
DEBUG - 2015-02-07 06:50:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:50:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:50:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 06:50:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:50:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:50:10 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:50:10 --> Final output sent to browser
DEBUG - 2015-02-07 06:50:10 --> Total execution time: 1.0601
DEBUG - 2015-02-07 06:58:40 --> Config Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:58:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:58:40 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:58:40 --> URI Class Initialized
DEBUG - 2015-02-07 06:58:40 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:58:40 --> Router Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Output Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Security Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Input Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:58:40 --> Language Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Loader Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:58:40 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:58:40 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:58:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:58:40 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:58:40 --> Session: Regenerate ID
DEBUG - 2015-02-07 06:58:40 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:58:41 --> Model Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Model Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Controller Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:58:41 --> Email Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:58:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:58:41 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:58:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:58:41 --> Model Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:58:41 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:58:41 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Model Class Initialized
DEBUG - 2015-02-07 06:58:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 06:58:41 --> Pagination Class Initialized
DEBUG - 2015-02-07 06:58:42 --> Model Class Initialized
DEBUG - 2015-02-07 06:58:42 --> Model Class Initialized
DEBUG - 2015-02-07 06:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 06:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-07 06:58:42 --> Severity: Error --> Call to undefined method Entity\Articles::getName() C:\xampp\htdocs\myblog\application\helpers\admin_helper.php 115
DEBUG - 2015-02-07 06:59:01 --> Config Class Initialized
DEBUG - 2015-02-07 06:59:01 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:59:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:59:01 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:59:01 --> URI Class Initialized
DEBUG - 2015-02-07 06:59:01 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:59:01 --> Router Class Initialized
DEBUG - 2015-02-07 06:59:01 --> Output Class Initialized
DEBUG - 2015-02-07 06:59:01 --> Security Class Initialized
DEBUG - 2015-02-07 06:59:01 --> Input Class Initialized
DEBUG - 2015-02-07 06:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:59:01 --> Language Class Initialized
DEBUG - 2015-02-07 06:59:01 --> Loader Class Initialized
DEBUG - 2015-02-07 06:59:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:59:01 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:59:01 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:59:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:59:01 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:59:02 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:59:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Controller Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:59:02 --> Email Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:59:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:59:02 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:59:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:59:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:59:02 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:59:02 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 06:59:02 --> Pagination Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:02 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:59:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:59:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 06:59:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:59:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:59:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:59:02 --> Final output sent to browser
DEBUG - 2015-02-07 06:59:02 --> Total execution time: 0.9191
DEBUG - 2015-02-07 06:59:36 --> Config Class Initialized
DEBUG - 2015-02-07 06:59:36 --> Hooks Class Initialized
DEBUG - 2015-02-07 06:59:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 06:59:36 --> Utf8 Class Initialized
DEBUG - 2015-02-07 06:59:36 --> URI Class Initialized
DEBUG - 2015-02-07 06:59:36 --> No URI present. Default controller set.
DEBUG - 2015-02-07 06:59:36 --> Router Class Initialized
DEBUG - 2015-02-07 06:59:36 --> Output Class Initialized
DEBUG - 2015-02-07 06:59:36 --> Security Class Initialized
DEBUG - 2015-02-07 06:59:36 --> Input Class Initialized
DEBUG - 2015-02-07 06:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 06:59:36 --> Language Class Initialized
DEBUG - 2015-02-07 06:59:36 --> Loader Class Initialized
DEBUG - 2015-02-07 06:59:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 06:59:36 --> Helper loaded: url_helper
DEBUG - 2015-02-07 06:59:36 --> Helper loaded: link_helper
DEBUG - 2015-02-07 06:59:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 06:59:36 --> CI_Session Class Initialized
DEBUG - 2015-02-07 06:59:36 --> CI_Session routines successfully run
DEBUG - 2015-02-07 06:59:37 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Controller Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 06:59:37 --> Email Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 06:59:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 06:59:37 --> Helper loaded: language_helper
DEBUG - 2015-02-07 06:59:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 06:59:37 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Database Driver Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Helper loaded: date_helper
DEBUG - 2015-02-07 06:59:37 --> Helper loaded: form_helper
DEBUG - 2015-02-07 06:59:37 --> Form Validation Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 06:59:37 --> Pagination Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:37 --> Model Class Initialized
DEBUG - 2015-02-07 06:59:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 06:59:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 06:59:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 06:59:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 06:59:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 06:59:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 06:59:37 --> Final output sent to browser
DEBUG - 2015-02-07 06:59:37 --> Total execution time: 1.0121
DEBUG - 2015-02-07 07:02:15 --> Config Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:02:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:02:15 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:02:15 --> URI Class Initialized
DEBUG - 2015-02-07 07:02:15 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:02:15 --> Router Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Output Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Security Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Input Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:02:15 --> Language Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Loader Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:02:15 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:02:15 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:02:15 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Controller Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:02:15 --> Email Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:02:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:02:15 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:02:15 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:02:15 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:02:15 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:15 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:02:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:02:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:02:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-07 07:02:16 --> Severity: Error --> Call to undefined method Doctrine\ORM\QueryBuilder::setMaxResult() C:\xampp\htdocs\myblog\application\models\Article_model.php 244
DEBUG - 2015-02-07 07:02:23 --> Config Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:02:23 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:02:23 --> URI Class Initialized
DEBUG - 2015-02-07 07:02:23 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:02:23 --> Router Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Output Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Security Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Input Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:02:23 --> Language Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Loader Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:02:23 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:02:23 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:02:23 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Controller Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:02:23 --> Email Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:02:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:02:23 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:02:23 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:02:23 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:02:23 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:23 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:02:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:02:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:02:23 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
ERROR - 2015-02-07 07:02:23 --> Severity: Notice --> Undefined property: Doctrine\ORM\QueryBuilder::$getQuery C:\xampp\htdocs\myblog\application\models\Article_model.php 245
ERROR - 2015-02-07 07:02:23 --> Severity: Error --> Call to a member function getResult() on null C:\xampp\htdocs\myblog\application\models\Article_model.php 245
DEBUG - 2015-02-07 07:02:46 --> Config Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:02:46 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:02:46 --> URI Class Initialized
DEBUG - 2015-02-07 07:02:46 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:02:46 --> Router Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Output Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Security Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Input Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:02:46 --> Language Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Loader Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:02:46 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:02:46 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:02:46 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Controller Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:02:46 --> Email Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:02:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:02:46 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:02:46 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:02:46 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:02:46 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:02:46 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:47 --> Model Class Initialized
DEBUG - 2015-02-07 07:02:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:02:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:02:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:02:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 07:02:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 07:02:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 07:02:47 --> Final output sent to browser
DEBUG - 2015-02-07 07:02:47 --> Total execution time: 0.8470
DEBUG - 2015-02-07 07:04:16 --> Config Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:04:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:04:16 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:04:16 --> URI Class Initialized
DEBUG - 2015-02-07 07:04:16 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:04:16 --> Router Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Output Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Security Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Input Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:04:16 --> Language Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Loader Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:04:16 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Session: Regenerate ID
DEBUG - 2015-02-07 07:04:16 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:04:16 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Controller Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:04:16 --> Email Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:04:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:04:16 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:04:16 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:04:16 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:04:16 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:04:17 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:17 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:04:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:04:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:04:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 07:04:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 07:04:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 07:04:17 --> Final output sent to browser
DEBUG - 2015-02-07 07:04:17 --> Total execution time: 0.9891
DEBUG - 2015-02-07 07:04:37 --> Config Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:04:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:04:37 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:04:37 --> URI Class Initialized
DEBUG - 2015-02-07 07:04:37 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:04:37 --> Router Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Output Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Security Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Input Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:04:37 --> Language Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Loader Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:04:37 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:04:37 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:04:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Controller Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:04:37 --> Email Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:04:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:04:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:04:37 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:04:37 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:04:37 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:04:38 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:38 --> Model Class Initialized
DEBUG - 2015-02-07 07:04:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:04:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:04:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:04:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 07:04:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 07:04:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 07:04:38 --> Final output sent to browser
DEBUG - 2015-02-07 07:04:38 --> Total execution time: 1.0011
DEBUG - 2015-02-07 07:09:33 --> Config Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:09:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:09:33 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:09:33 --> URI Class Initialized
DEBUG - 2015-02-07 07:09:33 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:09:33 --> Router Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Output Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Security Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Input Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:09:33 --> Language Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Loader Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:09:33 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Session: Regenerate ID
DEBUG - 2015-02-07 07:09:33 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:09:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Controller Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:09:33 --> Email Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:09:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:09:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:09:33 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:09:33 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:09:33 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:09:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:09:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:09:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:09:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:09:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 07:09:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 07:09:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 07:09:34 --> Final output sent to browser
DEBUG - 2015-02-07 07:09:34 --> Total execution time: 1.3151
DEBUG - 2015-02-07 07:11:19 --> Config Class Initialized
DEBUG - 2015-02-07 07:11:19 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:11:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:11:19 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:11:19 --> URI Class Initialized
DEBUG - 2015-02-07 07:11:19 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:11:19 --> Router Class Initialized
DEBUG - 2015-02-07 07:11:19 --> Output Class Initialized
DEBUG - 2015-02-07 07:11:19 --> Security Class Initialized
DEBUG - 2015-02-07 07:11:19 --> Input Class Initialized
DEBUG - 2015-02-07 07:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:11:19 --> Language Class Initialized
DEBUG - 2015-02-07 07:11:19 --> Loader Class Initialized
DEBUG - 2015-02-07 07:11:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:11:19 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:11:19 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:11:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:11:19 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:11:19 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:11:20 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Controller Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:11:20 --> Email Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:11:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:11:20 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:11:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:11:20 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:11:20 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:11:20 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:11:20 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:20 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:11:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:11:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:11:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 07:11:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 07:11:20 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 07:11:20 --> Final output sent to browser
DEBUG - 2015-02-07 07:11:20 --> Total execution time: 0.9771
DEBUG - 2015-02-07 07:11:33 --> Config Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:11:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:11:33 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:11:33 --> URI Class Initialized
DEBUG - 2015-02-07 07:11:33 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:11:33 --> Router Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Output Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Security Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Input Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:11:33 --> Language Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Loader Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:11:33 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:11:33 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:11:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:11:33 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:11:33 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:11:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Controller Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:11:33 --> Email Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:11:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:11:33 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:11:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:11:33 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:11:33 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:11:34 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:11:34 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:11:34 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:11:34 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:11:34 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:34 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:11:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:11:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:11:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 07:11:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 07:11:34 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 07:11:34 --> Final output sent to browser
DEBUG - 2015-02-07 07:11:34 --> Total execution time: 0.8610
DEBUG - 2015-02-07 07:11:54 --> Config Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Hooks Class Initialized
DEBUG - 2015-02-07 07:11:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 07:11:54 --> Utf8 Class Initialized
DEBUG - 2015-02-07 07:11:54 --> URI Class Initialized
DEBUG - 2015-02-07 07:11:54 --> No URI present. Default controller set.
DEBUG - 2015-02-07 07:11:54 --> Router Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Output Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Security Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Input Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 07:11:54 --> Language Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Loader Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: url_helper
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: link_helper
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 07:11:54 --> CI_Session Class Initialized
DEBUG - 2015-02-07 07:11:54 --> CI_Session routines successfully run
DEBUG - 2015-02-07 07:11:54 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Controller Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 07:11:54 --> Email Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: language_helper
DEBUG - 2015-02-07 07:11:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 07:11:54 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Database Driver Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: date_helper
DEBUG - 2015-02-07 07:11:54 --> Helper loaded: form_helper
DEBUG - 2015-02-07 07:11:54 --> Form Validation Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 07:11:54 --> Pagination Class Initialized
DEBUG - 2015-02-07 07:11:55 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:55 --> Model Class Initialized
DEBUG - 2015-02-07 07:11:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 07:11:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 07:11:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 07:11:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 07:11:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 07:11:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 07:11:55 --> Final output sent to browser
DEBUG - 2015-02-07 07:11:55 --> Total execution time: 0.8650
DEBUG - 2015-02-07 08:05:27 --> Config Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:05:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:05:27 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:05:27 --> URI Class Initialized
DEBUG - 2015-02-07 08:05:27 --> No URI present. Default controller set.
DEBUG - 2015-02-07 08:05:27 --> Router Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Output Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Security Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Input Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:05:27 --> Language Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Loader Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:05:27 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:05:27 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:05:27 --> Model Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Model Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Controller Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:05:27 --> Email Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:05:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:05:27 --> Model Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:05:27 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:05:27 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Model Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 08:05:27 --> Pagination Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Model Class Initialized
DEBUG - 2015-02-07 08:05:27 --> Model Class Initialized
DEBUG - 2015-02-07 08:05:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:05:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:05:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 08:05:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:05:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:05:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:05:27 --> Final output sent to browser
DEBUG - 2015-02-07 08:05:27 --> Total execution time: 0.6040
DEBUG - 2015-02-07 08:06:34 --> Config Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:06:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:06:34 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:06:34 --> URI Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Router Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Output Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Security Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Input Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:06:34 --> Language Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Loader Class Initialized
DEBUG - 2015-02-07 08:06:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:06:34 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:06:34 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:06:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:06:34 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:06:34 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:06:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:35 --> Controller Class Initialized
DEBUG - 2015-02-07 08:06:35 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:06:35 --> Email Class Initialized
DEBUG - 2015-02-07 08:06:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:06:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:06:35 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:06:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:06:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:35 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:06:35 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:06:35 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:06:35 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:06:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 08:06:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 08:06:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-07 08:06:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 08:06:35 --> Final output sent to browser
DEBUG - 2015-02-07 08:06:35 --> Total execution time: 0.6610
DEBUG - 2015-02-07 08:06:54 --> Config Class Initialized
DEBUG - 2015-02-07 08:06:54 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:06:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:06:54 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:06:54 --> URI Class Initialized
DEBUG - 2015-02-07 08:06:54 --> Router Class Initialized
DEBUG - 2015-02-07 08:06:54 --> Output Class Initialized
DEBUG - 2015-02-07 08:06:54 --> Security Class Initialized
DEBUG - 2015-02-07 08:06:54 --> Input Class Initialized
DEBUG - 2015-02-07 08:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:06:54 --> Language Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Loader Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:06:55 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:06:55 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:06:55 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Controller Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:06:55 --> Email Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:06:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:06:55 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:06:55 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:06:55 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:06:55 --> Model Class Initialized
DEBUG - 2015-02-07 08:06:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 08:06:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 08:06:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-07 08:06:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 08:06:58 --> Final output sent to browser
DEBUG - 2015-02-07 08:06:58 --> Total execution time: 3.7282
DEBUG - 2015-02-07 08:22:00 --> Config Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:22:01 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:22:01 --> URI Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Router Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Output Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Security Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Input Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:22:01 --> Language Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Loader Class Initialized
DEBUG - 2015-02-07 08:22:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:22:01 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:22:01 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:22:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:22:02 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:22:02 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:22:02 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:22:03 --> Model Class Initialized
DEBUG - 2015-02-07 08:22:03 --> Model Class Initialized
DEBUG - 2015-02-07 08:22:03 --> Controller Class Initialized
DEBUG - 2015-02-07 08:22:03 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:22:03 --> Email Class Initialized
DEBUG - 2015-02-07 08:22:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:22:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:22:03 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:22:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:22:03 --> Model Class Initialized
DEBUG - 2015-02-07 08:22:04 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:22:04 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:22:04 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:22:04 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:22:05 --> Model Class Initialized
DEBUG - 2015-02-07 08:22:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-07 08:22:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-07 08:22:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-07 08:22:09 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-07 08:22:09 --> Final output sent to browser
DEBUG - 2015-02-07 08:22:09 --> Total execution time: 8.9705
DEBUG - 2015-02-07 08:36:13 --> Config Class Initialized
DEBUG - 2015-02-07 08:36:13 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:36:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:36:14 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:36:14 --> URI Class Initialized
DEBUG - 2015-02-07 08:36:14 --> No URI present. Default controller set.
DEBUG - 2015-02-07 08:36:14 --> Router Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Output Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Security Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Input Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:36:14 --> Language Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Loader Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:36:14 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:36:14 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:36:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:36:14 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:36:14 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:36:14 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Controller Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:36:14 --> Email Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:36:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:36:14 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:36:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:36:14 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:36:14 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:36:15 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:36:15 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:36:15 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 08:36:15 --> Pagination Class Initialized
DEBUG - 2015-02-07 08:36:17 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:17 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 08:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:36:18 --> Final output sent to browser
DEBUG - 2015-02-07 08:36:18 --> Total execution time: 5.0793
DEBUG - 2015-02-07 08:36:30 --> Config Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:36:30 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:36:30 --> URI Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Router Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Output Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Security Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Input Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:36:30 --> Language Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Loader Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:36:30 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:36:30 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:36:30 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Controller Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:36:30 --> Email Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:36:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:36:30 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:36:30 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:36:30 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:36:30 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:36:30 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 08:36:30 --> Session: Creating new session (9c8536671bde02a125a9987a334e4af2)
DEBUG - 2015-02-07 08:36:30 --> Config Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:36:30 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:36:30 --> URI Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Router Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Output Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Security Class Initialized
DEBUG - 2015-02-07 08:36:30 --> Input Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:36:31 --> Language Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Loader Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:36:31 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:36:31 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:36:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Controller Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:36:31 --> Email Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:36:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:36:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:36:31 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:36:31 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:36:31 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:36:31 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 08:36:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:36:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:36:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-07 08:36:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:36:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:36:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:36:31 --> Final output sent to browser
DEBUG - 2015-02-07 08:36:31 --> Total execution time: 0.8080
DEBUG - 2015-02-07 08:36:36 --> Config Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:36:36 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:36:36 --> URI Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Router Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Output Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Security Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Input Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:36:36 --> Language Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Loader Class Initialized
DEBUG - 2015-02-07 08:36:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:36:36 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:36:36 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:36:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:36:36 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:36:36 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:36:37 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:37 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:37 --> Controller Class Initialized
DEBUG - 2015-02-07 08:36:37 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:36:37 --> Email Class Initialized
DEBUG - 2015-02-07 08:36:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:36:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:36:37 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:36:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:36:37 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:37 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:36:37 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:36:37 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:36:37 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:36:37 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:36:37 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:36:37 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-07 08:36:37 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-07 08:36:38 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:38 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:38 --> Model Class Initialized
DEBUG - 2015-02-07 08:36:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:36:38 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:36:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-07 08:36:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:36:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:36:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:36:39 --> Final output sent to browser
DEBUG - 2015-02-07 08:36:39 --> Total execution time: 2.4111
DEBUG - 2015-02-07 08:51:41 --> Config Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:51:41 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:51:41 --> URI Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Router Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Output Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Security Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Input Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:51:41 --> Language Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Loader Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:51:41 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:51:41 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:51:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:51:41 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:51:41 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:51:41 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:51:42 --> Model Class Initialized
DEBUG - 2015-02-07 08:51:42 --> Model Class Initialized
DEBUG - 2015-02-07 08:51:42 --> Controller Class Initialized
DEBUG - 2015-02-07 08:51:42 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:51:42 --> Email Class Initialized
DEBUG - 2015-02-07 08:51:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:51:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:51:42 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:51:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:51:42 --> Model Class Initialized
DEBUG - 2015-02-07 08:51:42 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:51:42 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:51:42 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:51:42 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:51:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:51:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:51:42 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-07 08:51:42 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-07 08:51:43 --> Model Class Initialized
DEBUG - 2015-02-07 08:51:45 --> Model Class Initialized
DEBUG - 2015-02-07 08:51:45 --> Model Class Initialized
DEBUG - 2015-02-07 08:51:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:51:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:51:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-07 08:51:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:51:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:51:45 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:51:45 --> Final output sent to browser
DEBUG - 2015-02-07 08:51:45 --> Total execution time: 4.4763
DEBUG - 2015-02-07 08:56:34 --> Config Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:56:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:56:34 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:56:34 --> URI Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Router Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Output Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Security Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Input Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:56:34 --> Language Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Loader Class Initialized
DEBUG - 2015-02-07 08:56:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:56:34 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:56:34 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:56:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:56:34 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:56:34 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Controller Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:56:35 --> Email Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:56:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:56:35 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:56:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:56:35 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:56:35 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:56:35 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:56:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:35 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:56:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:56:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-07 08:56:35 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:56:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:56:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:56:36 --> Final output sent to browser
DEBUG - 2015-02-07 08:56:36 --> Total execution time: 1.2641
DEBUG - 2015-02-07 08:56:54 --> Config Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:56:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:56:54 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:56:54 --> URI Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Router Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Output Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Security Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Input Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:56:54 --> Language Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Loader Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:56:54 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Session: Regenerate ID
DEBUG - 2015-02-07 08:56:54 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:56:54 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Controller Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:56:54 --> Email Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:56:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:56:54 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:56:54 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:56:54 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:56:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:56:54 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:56:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 08:56:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-07 08:56:55 --> Config Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:56:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:56:55 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:56:55 --> URI Class Initialized
DEBUG - 2015-02-07 08:56:55 --> No URI present. Default controller set.
DEBUG - 2015-02-07 08:56:55 --> Router Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Output Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Security Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Input Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:56:55 --> Language Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Loader Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:56:55 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:56:55 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:56:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:56:55 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:56:55 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:56:55 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:55 --> Controller Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:56:56 --> Email Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:56:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:56:56 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:56:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:56:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:56:56 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:56:56 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 08:56:56 --> Pagination Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 08:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:56:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:56:56 --> Final output sent to browser
DEBUG - 2015-02-07 08:56:56 --> Total execution time: 1.0601
DEBUG - 2015-02-07 08:57:01 --> Config Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:57:01 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:57:01 --> URI Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Router Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Output Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Security Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Input Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:57:01 --> Language Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Loader Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:57:01 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:57:01 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:57:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Controller Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:57:01 --> Email Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:57:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:57:01 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:57:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:57:01 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:01 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-07 08:57:01 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-07 08:57:01 --> Helper loaded: string_helper
DEBUG - 2015-02-07 08:57:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:02 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:02 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:57:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:57:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-07 08:57:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:57:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:57:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:57:02 --> Final output sent to browser
DEBUG - 2015-02-07 08:57:02 --> Total execution time: 1.0381
DEBUG - 2015-02-07 08:57:13 --> Config Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:57:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:57:13 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:57:13 --> URI Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Router Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Output Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Security Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Input Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:57:13 --> Language Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Loader Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:57:13 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:57:13 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:57:13 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Controller Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:57:13 --> Email Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:57:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:13 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:57:13 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:57:13 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:57:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:57:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:13 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-07 08:57:13 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-07 08:57:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-07 08:57:14 --> Config Class Initialized
DEBUG - 2015-02-07 08:57:14 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:57:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:57:14 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:57:14 --> URI Class Initialized
DEBUG - 2015-02-07 08:57:14 --> No URI present. Default controller set.
DEBUG - 2015-02-07 08:57:14 --> Router Class Initialized
DEBUG - 2015-02-07 08:57:14 --> Output Class Initialized
DEBUG - 2015-02-07 08:57:14 --> Security Class Initialized
DEBUG - 2015-02-07 08:57:14 --> Input Class Initialized
DEBUG - 2015-02-07 08:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:57:14 --> Language Class Initialized
DEBUG - 2015-02-07 08:57:14 --> Loader Class Initialized
DEBUG - 2015-02-07 08:57:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:57:14 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:57:14 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:57:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:57:14 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:57:14 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:57:15 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Controller Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:57:15 --> Email Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:57:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:57:15 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:57:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:15 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:57:15 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:57:15 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 08:57:15 --> Pagination Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:15 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:57:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:57:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 08:57:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:57:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:57:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:57:15 --> Final output sent to browser
DEBUG - 2015-02-07 08:57:15 --> Total execution time: 0.8070
DEBUG - 2015-02-07 08:57:30 --> Config Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:57:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:57:30 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:57:30 --> URI Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Router Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Output Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Security Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Input Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:57:30 --> Language Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Loader Class Initialized
DEBUG - 2015-02-07 08:57:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:57:30 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:57:30 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:57:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:57:30 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:57:30 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:57:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Controller Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:57:31 --> Email Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:57:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:57:31 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:57:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:57:31 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:57:31 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:57:31 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:31 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-07 08:57:31 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-07 08:57:31 --> Helper loaded: string_helper
DEBUG - 2015-02-07 08:57:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:31 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:57:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:57:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-07 08:57:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:57:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:57:31 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:57:31 --> Final output sent to browser
DEBUG - 2015-02-07 08:57:31 --> Total execution time: 0.9961
DEBUG - 2015-02-07 08:57:39 --> Config Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:57:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:57:39 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:57:39 --> URI Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Router Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Output Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Security Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Input Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:57:39 --> Language Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Loader Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:57:39 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:57:39 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:57:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:57:39 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:57:39 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:57:39 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:39 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Controller Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:57:40 --> Email Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:57:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:40 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:57:40 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:57:40 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:40 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-07 08:57:40 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-07 08:57:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-07 08:57:40 --> Config Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:57:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:57:40 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:57:40 --> URI Class Initialized
DEBUG - 2015-02-07 08:57:40 --> No URI present. Default controller set.
DEBUG - 2015-02-07 08:57:40 --> Router Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Output Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Security Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Input Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:57:40 --> Language Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Loader Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:57:40 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:57:40 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:57:40 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Controller Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:57:40 --> Email Class Initialized
DEBUG - 2015-02-07 08:57:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:57:40 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:57:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:41 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:41 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:57:41 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:57:41 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:57:41 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:57:41 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-07 08:57:41 --> Pagination Class Initialized
DEBUG - 2015-02-07 08:57:41 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:41 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:57:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:57:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\welcome_message.php
DEBUG - 2015-02-07 08:57:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:57:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:57:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:57:41 --> Final output sent to browser
DEBUG - 2015-02-07 08:57:41 --> Total execution time: 0.8300
DEBUG - 2015-02-07 08:57:56 --> Config Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:57:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:57:56 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:57:56 --> URI Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Router Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Output Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Security Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Input Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:57:56 --> Language Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Loader Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:57:56 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:57:56 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:57:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Controller Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:57:56 --> Email Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:57:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:57:56 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:57:56 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:57:56 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-07 08:57:56 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-07 08:57:56 --> Helper loaded: string_helper
DEBUG - 2015-02-07 08:57:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:56 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:57 --> Model Class Initialized
DEBUG - 2015-02-07 08:57:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:57:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:57:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-07 08:57:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:57:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:57:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:57:57 --> Final output sent to browser
DEBUG - 2015-02-07 08:57:57 --> Total execution time: 0.9791
DEBUG - 2015-02-07 08:58:00 --> Config Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:58:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:58:00 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:58:00 --> URI Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Router Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Output Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Security Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Input Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:58:00 --> Language Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Loader Class Initialized
DEBUG - 2015-02-07 08:58:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:58:00 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:58:00 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:58:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:58:00 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:58:00 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Controller Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:58:01 --> Email Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:58:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:58:01 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:58:01 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:58:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 08:58:01 --> Session: Creating new session (e6fa5ae14dfc15dccb4861ad73c4733b)
DEBUG - 2015-02-07 08:58:01 --> Config Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:58:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:58:01 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:58:01 --> URI Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Router Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Output Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Security Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Input Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:58:01 --> Language Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Loader Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:58:01 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:58:01 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Controller Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:58:01 --> Email Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:58:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:58:01 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:58:01 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:58:01 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:58:01 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:01 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:02 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:58:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:58:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/login.php
DEBUG - 2015-02-07 08:58:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:58:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:58:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:58:02 --> Final output sent to browser
DEBUG - 2015-02-07 08:58:02 --> Total execution time: 0.6540
DEBUG - 2015-02-07 08:58:04 --> Config Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Hooks Class Initialized
DEBUG - 2015-02-07 08:58:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 08:58:04 --> Utf8 Class Initialized
DEBUG - 2015-02-07 08:58:04 --> URI Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Router Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Output Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Security Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Input Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 08:58:04 --> Language Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Loader Class Initialized
DEBUG - 2015-02-07 08:58:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 08:58:04 --> Helper loaded: url_helper
DEBUG - 2015-02-07 08:58:04 --> Helper loaded: link_helper
DEBUG - 2015-02-07 08:58:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 08:58:04 --> CI_Session Class Initialized
DEBUG - 2015-02-07 08:58:04 --> CI_Session routines successfully run
DEBUG - 2015-02-07 08:58:05 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Controller Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 08:58:05 --> Email Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 08:58:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 08:58:05 --> Helper loaded: language_helper
DEBUG - 2015-02-07 08:58:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 08:58:05 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Database Driver Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Helper loaded: date_helper
DEBUG - 2015-02-07 08:58:05 --> Helper loaded: form_helper
DEBUG - 2015-02-07 08:58:05 --> Form Validation Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 08:58:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 08:58:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 08:58:05 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:05 --> Model Class Initialized
DEBUG - 2015-02-07 08:58:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 08:58:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 08:58:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-07 08:58:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 08:58:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 08:58:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 08:58:05 --> Final output sent to browser
DEBUG - 2015-02-07 08:58:05 --> Total execution time: 0.8510
DEBUG - 2015-02-07 16:32:21 --> Config Class Initialized
DEBUG - 2015-02-07 16:32:21 --> Hooks Class Initialized
DEBUG - 2015-02-07 16:32:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 16:32:21 --> Utf8 Class Initialized
DEBUG - 2015-02-07 16:32:22 --> URI Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Router Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Output Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Security Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Input Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 16:32:22 --> Language Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Loader Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 16:32:22 --> Helper loaded: url_helper
DEBUG - 2015-02-07 16:32:22 --> Helper loaded: link_helper
DEBUG - 2015-02-07 16:32:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 16:32:22 --> CI_Session Class Initialized
DEBUG - 2015-02-07 16:32:22 --> A session cookie was not found.
DEBUG - 2015-02-07 16:32:22 --> Session: Creating new session (8164496dc7774bad8e1019f320e49471)
DEBUG - 2015-02-07 16:32:22 --> CI_Session routines successfully run
DEBUG - 2015-02-07 16:32:22 --> Model Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Model Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Controller Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 16:32:22 --> Email Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 16:32:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 16:32:22 --> Helper loaded: language_helper
DEBUG - 2015-02-07 16:32:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 16:32:22 --> Model Class Initialized
DEBUG - 2015-02-07 16:32:22 --> Database Driver Class Initialized
DEBUG - 2015-02-07 16:32:24 --> Helper loaded: date_helper
DEBUG - 2015-02-07 16:32:24 --> Helper loaded: form_helper
DEBUG - 2015-02-07 16:32:24 --> Form Validation Class Initialized
DEBUG - 2015-02-07 16:32:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 16:32:24 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 16:32:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 16:32:24 --> Model Class Initialized
DEBUG - 2015-02-07 16:32:25 --> Model Class Initialized
DEBUG - 2015-02-07 16:32:25 --> Model Class Initialized
DEBUG - 2015-02-07 16:32:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 16:32:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 16:32:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-07 16:32:25 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 16:32:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 16:32:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 16:32:26 --> Final output sent to browser
DEBUG - 2015-02-07 16:32:26 --> Total execution time: 4.0702
DEBUG - 2015-02-07 16:47:33 --> Config Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Hooks Class Initialized
DEBUG - 2015-02-07 16:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 16:47:33 --> Utf8 Class Initialized
DEBUG - 2015-02-07 16:47:33 --> URI Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Router Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Output Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Security Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Input Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 16:47:33 --> Language Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Loader Class Initialized
DEBUG - 2015-02-07 16:47:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 16:47:34 --> Helper loaded: url_helper
DEBUG - 2015-02-07 16:47:34 --> Helper loaded: link_helper
DEBUG - 2015-02-07 16:47:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 16:47:34 --> CI_Session Class Initialized
DEBUG - 2015-02-07 16:47:34 --> Session: Regenerate ID
DEBUG - 2015-02-07 16:47:34 --> CI_Session routines successfully run
DEBUG - 2015-02-07 16:47:34 --> Model Class Initialized
DEBUG - 2015-02-07 16:47:34 --> Model Class Initialized
DEBUG - 2015-02-07 16:47:34 --> Controller Class Initialized
DEBUG - 2015-02-07 16:47:34 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 16:47:34 --> Email Class Initialized
DEBUG - 2015-02-07 16:47:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 16:47:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 16:47:34 --> Helper loaded: language_helper
DEBUG - 2015-02-07 16:47:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 16:47:34 --> Model Class Initialized
DEBUG - 2015-02-07 16:47:34 --> Database Driver Class Initialized
DEBUG - 2015-02-07 16:47:34 --> Helper loaded: date_helper
DEBUG - 2015-02-07 16:47:35 --> Helper loaded: form_helper
DEBUG - 2015-02-07 16:47:35 --> Form Validation Class Initialized
DEBUG - 2015-02-07 16:47:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 16:47:35 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 16:47:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 16:47:35 --> Model Class Initialized
DEBUG - 2015-02-07 16:47:36 --> Model Class Initialized
DEBUG - 2015-02-07 16:47:37 --> Model Class Initialized
DEBUG - 2015-02-07 16:47:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 16:47:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 16:47:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-07 16:47:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 16:47:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 16:47:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 16:47:37 --> Final output sent to browser
DEBUG - 2015-02-07 16:47:37 --> Total execution time: 4.3552
DEBUG - 2015-02-07 17:02:43 --> Config Class Initialized
DEBUG - 2015-02-07 17:02:43 --> Hooks Class Initialized
DEBUG - 2015-02-07 17:02:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 17:02:43 --> Utf8 Class Initialized
DEBUG - 2015-02-07 17:02:43 --> URI Class Initialized
DEBUG - 2015-02-07 17:02:43 --> Router Class Initialized
DEBUG - 2015-02-07 17:02:43 --> Output Class Initialized
DEBUG - 2015-02-07 17:02:43 --> Security Class Initialized
DEBUG - 2015-02-07 17:02:43 --> Input Class Initialized
DEBUG - 2015-02-07 17:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 17:02:43 --> Language Class Initialized
DEBUG - 2015-02-07 17:02:44 --> Loader Class Initialized
DEBUG - 2015-02-07 17:02:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 17:02:44 --> Helper loaded: url_helper
DEBUG - 2015-02-07 17:02:44 --> Helper loaded: link_helper
DEBUG - 2015-02-07 17:02:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 17:02:44 --> CI_Session Class Initialized
DEBUG - 2015-02-07 17:02:44 --> Session: Regenerate ID
DEBUG - 2015-02-07 17:02:44 --> CI_Session routines successfully run
DEBUG - 2015-02-07 17:02:44 --> Model Class Initialized
DEBUG - 2015-02-07 17:02:44 --> Model Class Initialized
DEBUG - 2015-02-07 17:02:44 --> Controller Class Initialized
DEBUG - 2015-02-07 17:02:44 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 17:02:44 --> Email Class Initialized
DEBUG - 2015-02-07 17:02:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 17:02:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 17:02:45 --> Helper loaded: language_helper
DEBUG - 2015-02-07 17:02:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 17:02:45 --> Model Class Initialized
DEBUG - 2015-02-07 17:02:45 --> Database Driver Class Initialized
DEBUG - 2015-02-07 17:02:46 --> Helper loaded: date_helper
DEBUG - 2015-02-07 17:02:46 --> Helper loaded: form_helper
DEBUG - 2015-02-07 17:02:46 --> Form Validation Class Initialized
DEBUG - 2015-02-07 17:02:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 17:02:46 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 17:02:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 17:02:46 --> Model Class Initialized
DEBUG - 2015-02-07 17:02:48 --> Model Class Initialized
DEBUG - 2015-02-07 17:02:48 --> Model Class Initialized
DEBUG - 2015-02-07 17:02:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 17:02:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 17:02:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-07 17:02:48 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 17:02:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 17:02:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 17:02:49 --> Final output sent to browser
DEBUG - 2015-02-07 17:02:49 --> Total execution time: 5.5363
DEBUG - 2015-02-07 17:17:53 --> Config Class Initialized
DEBUG - 2015-02-07 17:17:53 --> Hooks Class Initialized
DEBUG - 2015-02-07 17:17:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-07 17:17:53 --> Utf8 Class Initialized
DEBUG - 2015-02-07 17:17:53 --> URI Class Initialized
DEBUG - 2015-02-07 17:17:53 --> Router Class Initialized
DEBUG - 2015-02-07 17:17:53 --> Output Class Initialized
DEBUG - 2015-02-07 17:17:53 --> Security Class Initialized
DEBUG - 2015-02-07 17:17:53 --> Input Class Initialized
DEBUG - 2015-02-07 17:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-07 17:17:53 --> Language Class Initialized
DEBUG - 2015-02-07 17:17:53 --> Loader Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: url_helper
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: link_helper
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-07 17:17:54 --> CI_Session Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Session: Regenerate ID
DEBUG - 2015-02-07 17:17:54 --> CI_Session routines successfully run
DEBUG - 2015-02-07 17:17:54 --> Model Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Model Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Controller Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Config file loaded: C:\xampp\htdocs\myblog\application\config/ion_auth.php
DEBUG - 2015-02-07 17:17:54 --> Email Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: language_helper
DEBUG - 2015-02-07 17:17:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-07 17:17:54 --> Model Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Database Driver Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: date_helper
DEBUG - 2015-02-07 17:17:54 --> Helper loaded: form_helper
DEBUG - 2015-02-07 17:17:54 --> Form Validation Class Initialized
DEBUG - 2015-02-07 17:17:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-07 17:17:54 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-07 17:17:54 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-07 17:17:54 --> Model Class Initialized
DEBUG - 2015-02-07 17:17:56 --> Model Class Initialized
DEBUG - 2015-02-07 17:17:56 --> Model Class Initialized
DEBUG - 2015-02-07 17:17:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/nav.php
DEBUG - 2015-02-07 17:17:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/header.php
DEBUG - 2015-02-07 17:17:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\auth/forgot_password.php
DEBUG - 2015-02-07 17:17:56 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-07 17:17:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-07 17:17:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\layout/footer.php
DEBUG - 2015-02-07 17:17:57 --> Final output sent to browser
DEBUG - 2015-02-07 17:17:57 --> Total execution time: 3.6752
