<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-10 13:26:49 --> Config Class Initialized
DEBUG - 2015-02-10 13:26:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:26:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:26:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:26:49 --> URI Class Initialized
DEBUG - 2015-02-10 13:26:49 --> No URI present. Default controller set.
DEBUG - 2015-02-10 13:26:49 --> Router Class Initialized
DEBUG - 2015-02-10 13:26:49 --> Output Class Initialized
DEBUG - 2015-02-10 13:26:49 --> Security Class Initialized
DEBUG - 2015-02-10 13:26:49 --> Input Class Initialized
DEBUG - 2015-02-10 13:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:26:49 --> Language Class Initialized
DEBUG - 2015-02-10 13:26:49 --> Loader Class Initialized
DEBUG - 2015-02-10 13:26:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:26:50 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:26:50 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:26:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:26:50 --> CI_Session Class Initialized
ERROR - 2015-02-10 13:26:50 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-10 13:26:50 --> Session: Creating new session (aba5d2678eae7793f6c29c4fd8e20513)
DEBUG - 2015-02-10 13:26:50 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:26:51 --> Model Class Initialized
DEBUG - 2015-02-10 13:26:51 --> Model Class Initialized
DEBUG - 2015-02-10 13:26:51 --> Controller Class Initialized
DEBUG - 2015-02-10 13:26:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:26:51 --> Email Class Initialized
DEBUG - 2015-02-10 13:26:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:26:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:26:51 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:26:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:26:51 --> Model Class Initialized
DEBUG - 2015-02-10 13:26:51 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:26:52 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:26:52 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:26:52 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:26:52 --> Model Class Initialized
DEBUG - 2015-02-10 13:26:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 13:26:52 --> Pagination Class Initialized
DEBUG - 2015-02-10 13:26:53 --> Model Class Initialized
DEBUG - 2015-02-10 13:26:54 --> Model Class Initialized
DEBUG - 2015-02-10 13:26:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:26:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 13:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:26:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:26:55 --> Final output sent to browser
DEBUG - 2015-02-10 13:26:55 --> Total execution time: 6.1886
DEBUG - 2015-02-10 13:27:03 --> Config Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:27:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:27:03 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:27:03 --> URI Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Router Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Output Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Security Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Input Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:27:03 --> Language Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Loader Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:27:03 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:27:03 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:27:03 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Controller Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:27:03 --> Email Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:27:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:03 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:27:03 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:27:03 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:27:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-10 13:27:03 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:03 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-10 13:27:03 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:04 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:04 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-10 13:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:27:04 --> Final output sent to browser
DEBUG - 2015-02-10 13:27:04 --> Total execution time: 1.3001
DEBUG - 2015-02-10 13:27:12 --> Config Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:27:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:27:12 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:27:12 --> URI Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Router Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Output Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Security Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Input Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:27:12 --> Language Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Loader Class Initialized
DEBUG - 2015-02-10 13:27:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:27:12 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:27:12 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:27:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:27:12 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:27:12 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Controller Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:27:13 --> Email Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:27:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:27:13 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-10 13:27:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-10 13:27:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-10 13:27:13 --> Config Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:27:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:27:13 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:27:13 --> URI Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Router Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Output Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Security Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Input Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:27:13 --> Language Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Loader Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:27:13 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:27:13 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Controller Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:27:13 --> Email Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:27:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:27:13 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:27:13 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-10 13:27:13 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:13 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:13 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:14 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:27:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:27:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-10 13:27:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:27:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:27:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:27:14 --> Final output sent to browser
DEBUG - 2015-02-10 13:27:14 --> Total execution time: 0.8081
DEBUG - 2015-02-10 13:27:21 --> Config Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:27:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:27:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:27:21 --> URI Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Router Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Output Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Security Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Input Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:27:21 --> Language Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Loader Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:27:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:27:21 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:27:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Controller Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:27:21 --> Email Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:27:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:27:21 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:27:21 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:27:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-10 13:27:21 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:21 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-10 13:27:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-10 13:27:22 --> Config Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:27:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:27:22 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:27:22 --> URI Class Initialized
DEBUG - 2015-02-10 13:27:22 --> No URI present. Default controller set.
DEBUG - 2015-02-10 13:27:22 --> Router Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Output Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Security Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Input Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:27:22 --> Language Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Loader Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:27:22 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:27:22 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:27:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Controller Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:27:22 --> Email Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:27:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:27:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:27:22 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:27:22 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 13:27:22 --> Pagination Class Initialized
DEBUG - 2015-02-10 13:27:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:23 --> Model Class Initialized
DEBUG - 2015-02-10 13:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 13:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:27:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:27:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:27:24 --> Final output sent to browser
DEBUG - 2015-02-10 13:27:24 --> Total execution time: 1.8812
DEBUG - 2015-02-10 13:28:15 --> Config Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:28:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:28:15 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:28:15 --> URI Class Initialized
DEBUG - 2015-02-10 13:28:15 --> No URI present. Default controller set.
DEBUG - 2015-02-10 13:28:15 --> Router Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Output Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Security Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Input Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:28:15 --> Language Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Loader Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:28:15 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:28:15 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:28:15 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Controller Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:28:15 --> Email Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:28:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:28:15 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:28:15 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:28:15 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 13:28:15 --> Pagination Class Initialized
DEBUG - 2015-02-10 13:28:16 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:16 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:28:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:28:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 13:28:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:28:17 --> Final output sent to browser
DEBUG - 2015-02-10 13:28:17 --> Total execution time: 1.4201
DEBUG - 2015-02-10 13:28:42 --> Config Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:28:42 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:28:42 --> URI Class Initialized
DEBUG - 2015-02-10 13:28:42 --> No URI present. Default controller set.
DEBUG - 2015-02-10 13:28:42 --> Router Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Output Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Security Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Input Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:28:42 --> Language Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Loader Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:28:42 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:28:42 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:28:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:28:42 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:28:42 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:28:42 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Controller Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:28:42 --> Email Class Initialized
DEBUG - 2015-02-10 13:28:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:28:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:28:42 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:28:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:28:42 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:43 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:28:43 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:28:43 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:28:43 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:28:43 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 13:28:43 --> Pagination Class Initialized
DEBUG - 2015-02-10 13:28:43 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:43 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:28:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:28:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 13:28:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:28:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:28:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:28:44 --> Final output sent to browser
DEBUG - 2015-02-10 13:28:44 --> Total execution time: 1.7082
DEBUG - 2015-02-10 13:28:58 --> Config Class Initialized
DEBUG - 2015-02-10 13:28:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:28:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:28:59 --> URI Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Router Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Output Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Security Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Input Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:28:59 --> Language Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Loader Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:28:59 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:28:59 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:28:59 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Controller Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:28:59 --> Email Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:28:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:28:59 --> Model Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:28:59 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:28:59 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:28:59 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:00 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:00 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:29:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:29:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:29:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:29:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:29:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:29:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:29:01 --> Final output sent to browser
DEBUG - 2015-02-10 13:29:01 --> Total execution time: 2.0612
DEBUG - 2015-02-10 13:29:21 --> Config Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:29:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:29:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:29:21 --> URI Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Router Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Output Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Security Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Input Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:29:21 --> Language Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Loader Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:29:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:29:21 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:29:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Controller Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:29:21 --> Email Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:29:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:29:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:29:21 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:29:21 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:29:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:29:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:29:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:29:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:29:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:29:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:29:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:29:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:29:22 --> Final output sent to browser
DEBUG - 2015-02-10 13:29:22 --> Total execution time: 1.3561
DEBUG - 2015-02-10 13:44:24 --> Config Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:44:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:44:24 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:44:24 --> URI Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Router Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Output Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Security Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Input Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:44:24 --> Language Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Loader Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:44:24 --> CI_Session Class Initialized
ERROR - 2015-02-10 13:44:24 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-10 13:44:24 --> Session: Creating new session (19eadf414dafa5efd650358922059115)
DEBUG - 2015-02-10 13:44:24 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:44:24 --> Model Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Model Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Controller Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:44:24 --> Email Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:44:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:44:24 --> Model Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:44:24 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:44:24 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:44:24 --> Model Class Initialized
DEBUG - 2015-02-10 13:44:25 --> Model Class Initialized
DEBUG - 2015-02-10 13:44:25 --> Model Class Initialized
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:44:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 13:44:25 --> Final output sent to browser
DEBUG - 2015-02-10 13:44:25 --> Total execution time: 1.2101
DEBUG - 2015-02-10 13:51:09 --> Config Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:51:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:51:09 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:51:09 --> URI Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Router Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Output Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Security Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Input Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:51:09 --> Language Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Loader Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:51:09 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Session: Regenerate ID
DEBUG - 2015-02-10 13:51:09 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:51:09 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Controller Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:51:09 --> Email Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:51:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:51:09 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:51:09 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:51:09 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:51:09 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:10 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:10 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:51:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 13:51:10 --> Final output sent to browser
DEBUG - 2015-02-10 13:51:10 --> Total execution time: 1.2391
DEBUG - 2015-02-10 13:51:22 --> Config Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:51:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:51:22 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:51:22 --> URI Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Router Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Output Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Security Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Input Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:51:22 --> Language Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Loader Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:51:22 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:51:22 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:51:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Controller Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:51:22 --> Email Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:51:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:51:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:51:22 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:51:22 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:51:23 --> Final output sent to browser
DEBUG - 2015-02-10 13:51:23 --> Total execution time: 1.0141
DEBUG - 2015-02-10 13:53:21 --> Config Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:53:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:53:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:53:21 --> URI Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Router Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Output Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Security Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Input Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:53:21 --> Language Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Loader Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:53:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:53:21 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:53:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Controller Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:53:21 --> Email Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:53:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:53:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:53:21 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:53:21 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:53:21 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:22 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:53:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 13:53:22 --> Final output sent to browser
DEBUG - 2015-02-10 13:53:22 --> Total execution time: 1.2841
DEBUG - 2015-02-10 13:53:34 --> Config Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:53:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:53:34 --> URI Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Router Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Output Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Security Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Input Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:53:34 --> Language Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Loader Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:53:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:53:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:53:34 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Controller Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:53:34 --> Email Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:53:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:53:34 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:53:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:53:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:34 --> Model Class Initialized
DEBUG - 2015-02-10 13:53:35 --> Final output sent to browser
DEBUG - 2015-02-10 13:53:35 --> Total execution time: 1.0891
DEBUG - 2015-02-10 13:57:04 --> Config Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:57:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:57:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:57:04 --> URI Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Router Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Output Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Security Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Input Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:57:04 --> Language Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Loader Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:57:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Session: Regenerate ID
DEBUG - 2015-02-10 13:57:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Controller Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:57:04 --> Email Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:57:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:57:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:57:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:05 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:06 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 13:57:06 --> Final output sent to browser
DEBUG - 2015-02-10 13:57:06 --> Total execution time: 1.5602
DEBUG - 2015-02-10 13:57:17 --> Config Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:57:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:57:17 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:57:17 --> URI Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Router Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Output Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Security Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Input Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:57:17 --> Language Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Loader Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:57:17 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:57:17 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:57:17 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Controller Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:57:17 --> Email Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:57:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:57:17 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:57:17 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:57:17 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:17 --> Model Class Initialized
DEBUG - 2015-02-10 13:57:18 --> Final output sent to browser
DEBUG - 2015-02-10 13:57:18 --> Total execution time: 0.9001
DEBUG - 2015-02-10 13:58:38 --> Config Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:58:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:58:38 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:58:38 --> URI Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Router Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Output Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Security Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Input Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:58:38 --> Language Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Loader Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:58:38 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:58:38 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:58:38 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Controller Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:58:38 --> Email Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:58:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:58:38 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:58:38 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:58:38 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:58:38 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:39 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:39 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:58:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 13:58:39 --> Final output sent to browser
DEBUG - 2015-02-10 13:58:39 --> Total execution time: 1.4261
DEBUG - 2015-02-10 13:58:45 --> Config Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:58:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:58:45 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:58:45 --> URI Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Router Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Output Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Security Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Input Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:58:45 --> Language Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Loader Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:58:45 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:58:45 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:58:45 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Controller Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:58:45 --> Email Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:58:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:58:45 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:58:45 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:58:45 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:58:45 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:46 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:46 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 13:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 13:58:46 --> Final output sent to browser
DEBUG - 2015-02-10 13:58:46 --> Total execution time: 1.3001
DEBUG - 2015-02-10 13:58:48 --> Config Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:58:48 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:58:48 --> URI Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Router Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Output Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Security Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Input Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:58:48 --> Language Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Loader Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:58:48 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:58:48 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:58:48 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Controller Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:58:48 --> Email Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:58:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:58:48 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:58:48 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:58:48 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:48 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:49 --> Final output sent to browser
DEBUG - 2015-02-10 13:58:49 --> Total execution time: 0.9701
DEBUG - 2015-02-10 13:58:58 --> Config Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 13:58:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 13:58:58 --> URI Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Router Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Output Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Security Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Input Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 13:58:58 --> Language Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Loader Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 13:58:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 13:58:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 13:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Controller Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 13:58:58 --> Email Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: language_helper
DEBUG - 2015-02-10 13:58:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 13:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Database Driver Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: date_helper
DEBUG - 2015-02-10 13:58:58 --> Helper loaded: form_helper
DEBUG - 2015-02-10 13:58:58 --> Form Validation Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 13:58:59 --> Final output sent to browser
DEBUG - 2015-02-10 13:58:59 --> Total execution time: 0.9891
DEBUG - 2015-02-10 14:13:48 --> Config Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:13:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:13:48 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:13:48 --> URI Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Router Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Output Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Security Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Input Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:13:48 --> Language Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Loader Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:13:48 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Session: Regenerate ID
DEBUG - 2015-02-10 14:13:48 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:13:48 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Controller Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:13:48 --> Email Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:13:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:13:48 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:13:48 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:13:48 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:13:48 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:49 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:49 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 14:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 14:13:49 --> Final output sent to browser
DEBUG - 2015-02-10 14:13:49 --> Total execution time: 1.1701
DEBUG - 2015-02-10 14:13:51 --> Config Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:13:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:13:51 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:13:51 --> URI Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Router Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Output Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Security Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Input Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:13:51 --> Language Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Loader Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:13:51 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:13:51 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:13:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Controller Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:13:51 --> Email Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:13:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:13:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:13:51 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:13:51 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:13:52 --> Final output sent to browser
DEBUG - 2015-02-10 14:13:52 --> Total execution time: 0.8371
DEBUG - 2015-02-10 14:14:01 --> Config Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:14:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:14:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:14:01 --> URI Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Router Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Output Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Security Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Input Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:14:01 --> Language Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Loader Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:14:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:14:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:14:01 --> Model Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Model Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Controller Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:14:01 --> Email Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:14:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:14:01 --> Model Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:14:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:14:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Model Class Initialized
DEBUG - 2015-02-10 14:14:01 --> Model Class Initialized
DEBUG - 2015-02-10 14:14:02 --> Final output sent to browser
DEBUG - 2015-02-10 14:14:02 --> Total execution time: 0.8051
DEBUG - 2015-02-10 14:28:51 --> Config Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:28:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:28:51 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:28:51 --> URI Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Router Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Output Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Security Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Input Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:28:51 --> Language Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Loader Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:28:51 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Session: Regenerate ID
DEBUG - 2015-02-10 14:28:51 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:28:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Controller Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:28:51 --> Email Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:28:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:28:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:28:51 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:28:51 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:28:51 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:52 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:52 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 14:28:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 14:28:52 --> Final output sent to browser
DEBUG - 2015-02-10 14:28:52 --> Total execution time: 1.3981
DEBUG - 2015-02-10 14:28:54 --> Config Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:28:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:28:54 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:28:54 --> URI Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Router Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Output Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Security Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Input Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:28:54 --> Language Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Loader Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:28:54 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:28:54 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:28:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:28:54 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:28:54 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:28:54 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Controller Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:28:54 --> Email Class Initialized
DEBUG - 2015-02-10 14:28:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:28:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:28:54 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:28:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:28:54 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:55 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:28:55 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:28:55 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:28:55 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:28:55 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:55 --> Model Class Initialized
DEBUG - 2015-02-10 14:28:55 --> Final output sent to browser
DEBUG - 2015-02-10 14:28:55 --> Total execution time: 0.8981
DEBUG - 2015-02-10 14:29:04 --> Config Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:29:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:29:04 --> URI Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Router Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Output Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Security Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Input Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:29:04 --> Language Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Loader Class Initialized
DEBUG - 2015-02-10 14:29:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:29:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:29:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:29:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:29:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:29:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Controller Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:29:05 --> Email Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:29:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:29:05 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:29:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:29:05 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:29:05 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 14:29:05 --> Final output sent to browser
DEBUG - 2015-02-10 14:29:05 --> Total execution time: 0.9421
DEBUG - 2015-02-10 14:43:55 --> Config Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:43:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:43:55 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:43:55 --> URI Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Router Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Output Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Security Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Input Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:43:55 --> Language Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Loader Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:43:55 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Session: Regenerate ID
DEBUG - 2015-02-10 14:43:55 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:43:55 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Controller Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:43:55 --> Email Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:43:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:43:55 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:43:55 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:43:55 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:43:55 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:56 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:56 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 14:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 14:43:56 --> Final output sent to browser
DEBUG - 2015-02-10 14:43:56 --> Total execution time: 1.1621
DEBUG - 2015-02-10 14:43:58 --> Config Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:43:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:43:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:43:58 --> URI Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Router Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Output Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Security Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Input Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:43:58 --> Language Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Loader Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:43:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:43:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:43:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Controller Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:43:58 --> Email Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:43:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:43:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:43:58 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:43:58 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:43:59 --> Final output sent to browser
DEBUG - 2015-02-10 14:43:59 --> Total execution time: 0.8621
DEBUG - 2015-02-10 14:44:08 --> Config Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:44:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:44:08 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:44:08 --> URI Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Router Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Output Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Security Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Input Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:44:08 --> Language Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Loader Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:44:08 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:44:08 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Controller Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:44:08 --> Email Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:44:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:44:08 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:44:08 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 14:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 14:44:09 --> Final output sent to browser
DEBUG - 2015-02-10 14:44:09 --> Total execution time: 0.8171
DEBUG - 2015-02-10 14:58:58 --> Config Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:58:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:58:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:58:58 --> URI Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Router Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Output Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Security Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Input Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:58:58 --> Language Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Loader Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:58:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Session: Regenerate ID
DEBUG - 2015-02-10 14:58:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Controller Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:58:58 --> Email Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:58:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:58:58 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:58:58 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:58:58 --> Model Class Initialized
DEBUG - 2015-02-10 14:58:59 --> Model Class Initialized
DEBUG - 2015-02-10 14:58:59 --> Model Class Initialized
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 14:58:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 14:58:59 --> Final output sent to browser
DEBUG - 2015-02-10 14:58:59 --> Total execution time: 1.1041
DEBUG - 2015-02-10 14:59:02 --> Config Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:59:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:59:02 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:59:02 --> URI Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Router Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Output Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Security Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Input Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:59:02 --> Language Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Loader Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:59:02 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:59:02 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:59:02 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Controller Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:59:02 --> Email Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:59:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:59:02 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:59:02 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:59:02 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:02 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:03 --> Final output sent to browser
DEBUG - 2015-02-10 14:59:03 --> Total execution time: 0.8591
DEBUG - 2015-02-10 14:59:12 --> Config Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Hooks Class Initialized
DEBUG - 2015-02-10 14:59:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 14:59:12 --> Utf8 Class Initialized
DEBUG - 2015-02-10 14:59:12 --> URI Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Router Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Output Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Security Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Input Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 14:59:12 --> Language Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Loader Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: url_helper
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: link_helper
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 14:59:12 --> CI_Session Class Initialized
DEBUG - 2015-02-10 14:59:12 --> CI_Session routines successfully run
DEBUG - 2015-02-10 14:59:12 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Controller Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 14:59:12 --> Email Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: language_helper
DEBUG - 2015-02-10 14:59:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 14:59:12 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Database Driver Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: date_helper
DEBUG - 2015-02-10 14:59:12 --> Helper loaded: form_helper
DEBUG - 2015-02-10 14:59:12 --> Form Validation Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Model Class Initialized
DEBUG - 2015-02-10 14:59:12 --> Final output sent to browser
DEBUG - 2015-02-10 14:59:12 --> Total execution time: 0.7681
DEBUG - 2015-02-10 15:14:02 --> Config Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:14:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:14:02 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:14:02 --> URI Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Router Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Output Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Security Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Input Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:14:02 --> Language Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Loader Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:14:02 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Session: Regenerate ID
DEBUG - 2015-02-10 15:14:02 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:14:02 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Controller Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:14:02 --> Email Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:14:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:14:02 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:14:02 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:14:02 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:14:02 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:03 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:03 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 15:14:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 15:14:03 --> Final output sent to browser
DEBUG - 2015-02-10 15:14:03 --> Total execution time: 1.1281
DEBUG - 2015-02-10 15:14:05 --> Config Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:14:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:14:05 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:14:05 --> URI Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Router Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Output Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Security Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Input Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:14:05 --> Language Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Loader Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:14:05 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:14:05 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:14:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Controller Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:14:05 --> Email Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:14:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:14:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:14:05 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:14:05 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:06 --> Final output sent to browser
DEBUG - 2015-02-10 15:14:06 --> Total execution time: 0.8821
DEBUG - 2015-02-10 15:14:15 --> Config Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:14:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:14:15 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:14:15 --> URI Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Router Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Output Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Security Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Input Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:14:15 --> Language Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Loader Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:14:15 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:14:15 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:14:15 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Controller Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:14:15 --> Email Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:14:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:14:15 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:14:15 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:14:15 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:15 --> Model Class Initialized
DEBUG - 2015-02-10 15:14:16 --> Final output sent to browser
DEBUG - 2015-02-10 15:14:16 --> Total execution time: 0.7891
DEBUG - 2015-02-10 15:29:05 --> Config Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:29:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:29:05 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:29:05 --> URI Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Router Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Output Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Security Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Input Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:29:05 --> Language Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Loader Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:29:05 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Session: Regenerate ID
DEBUG - 2015-02-10 15:29:05 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Controller Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:29:05 --> Email Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:29:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:29:05 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:29:05 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:29:05 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:06 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:06 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 15:29:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 15:29:06 --> Final output sent to browser
DEBUG - 2015-02-10 15:29:06 --> Total execution time: 1.1371
DEBUG - 2015-02-10 15:29:08 --> Config Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:29:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:29:08 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:29:08 --> URI Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Router Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Output Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Security Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Input Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:29:08 --> Language Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Loader Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:29:08 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:29:08 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:29:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Controller Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:29:08 --> Email Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:29:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:29:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:29:08 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:29:08 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:09 --> Final output sent to browser
DEBUG - 2015-02-10 15:29:09 --> Total execution time: 0.8831
DEBUG - 2015-02-10 15:29:18 --> Config Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:29:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:29:18 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:29:18 --> URI Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Router Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Output Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Security Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Input Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:29:18 --> Language Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Loader Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:29:18 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:29:18 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:29:18 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Controller Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:29:18 --> Email Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:29:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:29:18 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:29:18 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:29:18 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:18 --> Model Class Initialized
DEBUG - 2015-02-10 15:29:19 --> Final output sent to browser
DEBUG - 2015-02-10 15:29:19 --> Total execution time: 0.8001
DEBUG - 2015-02-10 15:44:08 --> Config Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:44:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:44:08 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:44:08 --> URI Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Router Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Output Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Security Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Input Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:44:08 --> Language Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Loader Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:44:08 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Session: Regenerate ID
DEBUG - 2015-02-10 15:44:08 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Controller Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:44:08 --> Email Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:44:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:44:08 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:44:08 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:44:08 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:09 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:09 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 15:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 15:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 15:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 15:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 15:44:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 15:44:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 15:44:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 15:44:10 --> Final output sent to browser
DEBUG - 2015-02-10 15:44:10 --> Total execution time: 1.2101
DEBUG - 2015-02-10 15:44:11 --> Config Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:44:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:44:11 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:44:11 --> URI Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Router Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Output Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Security Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Input Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:44:11 --> Language Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Loader Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:44:11 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:44:11 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:44:11 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Controller Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:44:11 --> Email Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:44:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:44:11 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:44:11 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:44:11 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:11 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:12 --> Final output sent to browser
DEBUG - 2015-02-10 15:44:12 --> Total execution time: 0.9651
DEBUG - 2015-02-10 15:44:21 --> Config Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 15:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 15:44:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 15:44:21 --> URI Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Router Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Output Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Security Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Input Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 15:44:21 --> Language Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Loader Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 15:44:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 15:44:21 --> CI_Session routines successfully run
DEBUG - 2015-02-10 15:44:21 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Controller Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 15:44:21 --> Email Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: language_helper
DEBUG - 2015-02-10 15:44:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 15:44:21 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Database Driver Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: date_helper
DEBUG - 2015-02-10 15:44:21 --> Helper loaded: form_helper
DEBUG - 2015-02-10 15:44:21 --> Form Validation Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:21 --> Model Class Initialized
DEBUG - 2015-02-10 15:44:22 --> Final output sent to browser
DEBUG - 2015-02-10 15:44:22 --> Total execution time: 0.8131
DEBUG - 2015-02-10 17:31:40 --> Config Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:31:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:31:40 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:31:40 --> URI Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Router Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Output Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Security Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Input Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:31:40 --> Language Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Loader Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:31:40 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:31:40 --> A session cookie was not found.
DEBUG - 2015-02-10 17:31:40 --> Session: Creating new session (16819600455d092d444f028eddb0b028)
DEBUG - 2015-02-10 17:31:40 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:31:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Controller Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:31:40 --> Email Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:31:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:31:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:31:40 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:31:40 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:31:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:41 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:41 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:31:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:31:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:31:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:31:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:31:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:31:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:31:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:31:42 --> Final output sent to browser
DEBUG - 2015-02-10 17:31:42 --> Total execution time: 1.4351
DEBUG - 2015-02-10 17:31:43 --> Config Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:31:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:31:43 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:31:43 --> URI Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Router Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Output Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Security Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Input Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:31:43 --> Language Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Loader Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:31:43 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:31:43 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:31:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Controller Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:31:43 --> Email Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:31:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:31:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:31:43 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:31:43 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:44 --> Final output sent to browser
DEBUG - 2015-02-10 17:31:44 --> Total execution time: 0.9581
DEBUG - 2015-02-10 17:31:53 --> Config Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:31:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:31:53 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:31:53 --> URI Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Router Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Output Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Security Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Input Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:31:53 --> Language Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Loader Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:31:53 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:31:53 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:31:53 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Controller Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:31:53 --> Email Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:31:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:31:53 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:31:53 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:31:53 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:53 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Final output sent to browser
DEBUG - 2015-02-10 17:31:54 --> Total execution time: 0.8441
DEBUG - 2015-02-10 17:31:54 --> Config Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:31:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:31:54 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:31:54 --> URI Class Initialized
DEBUG - 2015-02-10 17:31:54 --> No URI present. Default controller set.
DEBUG - 2015-02-10 17:31:54 --> Router Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Output Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Security Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Input Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:31:54 --> Language Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Loader Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:31:54 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:31:54 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:31:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Controller Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:31:54 --> Email Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:31:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:31:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:31:54 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:31:54 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 17:31:54 --> Pagination Class Initialized
DEBUG - 2015-02-10 17:31:55 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:55 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 17:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:31:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:31:55 --> Final output sent to browser
DEBUG - 2015-02-10 17:31:55 --> Total execution time: 1.4341
DEBUG - 2015-02-10 17:31:57 --> Config Class Initialized
DEBUG - 2015-02-10 17:31:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:31:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:31:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:31:58 --> URI Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Router Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Output Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Security Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Input Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:31:58 --> Language Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Loader Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:31:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:31:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:31:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Controller Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:31:58 --> Email Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:31:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:31:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:31:58 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:31:58 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:31:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:31:59 --> Final output sent to browser
DEBUG - 2015-02-10 17:31:59 --> Total execution time: 1.1981
DEBUG - 2015-02-10 17:31:59 --> Config Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:31:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:31:59 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:31:59 --> URI Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Router Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Output Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Security Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Input Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:31:59 --> Language Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Loader Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:31:59 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:31:59 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:31:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Controller Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:31:59 --> Email Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:31:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:31:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:31:59 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:31:59 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:31:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:32:00 --> Final output sent to browser
DEBUG - 2015-02-10 17:32:00 --> Total execution time: 0.8791
DEBUG - 2015-02-10 17:32:09 --> Config Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:32:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:32:09 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:32:09 --> URI Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Router Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Output Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Security Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Input Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:32:09 --> Language Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Loader Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:32:09 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:32:09 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:32:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Controller Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:32:09 --> Email Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:32:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:32:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:32:09 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:32:09 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:32:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:32:10 --> Final output sent to browser
DEBUG - 2015-02-10 17:32:10 --> Total execution time: 0.9121
DEBUG - 2015-02-10 17:34:23 --> Config Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:34:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:34:23 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:34:23 --> URI Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Router Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Output Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Security Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Input Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:34:23 --> Language Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Loader Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:34:23 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:34:23 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:34:23 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Controller Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:34:23 --> Email Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:34:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:34:23 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:34:23 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:34:23 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:34:23 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:34:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:34:24 --> Final output sent to browser
DEBUG - 2015-02-10 17:34:24 --> Total execution time: 1.2791
DEBUG - 2015-02-10 17:34:25 --> Config Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:34:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:34:25 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:34:25 --> URI Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Router Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Output Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Security Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Input Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:34:25 --> Language Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Loader Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:34:25 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:34:25 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:34:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Controller Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:34:25 --> Email Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:34:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:34:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:34:25 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:34:25 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:26 --> Final output sent to browser
DEBUG - 2015-02-10 17:34:26 --> Total execution time: 0.9221
DEBUG - 2015-02-10 17:34:35 --> Config Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:34:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:34:35 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:34:35 --> URI Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Router Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Output Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Security Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Input Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:34:35 --> Language Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Loader Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:34:35 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:34:35 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:34:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Controller Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:34:35 --> Email Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:34:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:34:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:34:35 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:34:35 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:34:35 --> Final output sent to browser
DEBUG - 2015-02-10 17:34:35 --> Total execution time: 0.8561
DEBUG - 2015-02-10 17:36:28 --> Config Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:36:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:36:28 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:36:28 --> URI Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Router Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Output Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Security Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Input Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:36:28 --> Language Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Loader Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:36:28 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:36:28 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:36:28 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Controller Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:36:28 --> Email Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:36:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:36:28 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:36:28 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:36:28 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:36:28 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:29 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:29 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:36:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:36:29 --> Final output sent to browser
DEBUG - 2015-02-10 17:36:29 --> Total execution time: 1.1411
DEBUG - 2015-02-10 17:36:30 --> Config Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:36:30 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:36:30 --> URI Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Router Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Output Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Security Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Input Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:36:30 --> Language Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Loader Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:36:30 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:36:30 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:36:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Controller Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:36:30 --> Email Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:36:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:36:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:36:30 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:36:30 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:31 --> Final output sent to browser
DEBUG - 2015-02-10 17:36:31 --> Total execution time: 0.9711
DEBUG - 2015-02-10 17:36:40 --> Config Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:36:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:36:40 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:36:40 --> URI Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Router Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Output Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Security Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Input Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:36:40 --> Language Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Loader Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:36:40 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:36:40 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:36:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Controller Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:36:40 --> Email Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:36:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:36:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:36:40 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:36:40 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:40 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:41 --> Final output sent to browser
DEBUG - 2015-02-10 17:36:41 --> Total execution time: 0.8581
DEBUG - 2015-02-10 17:36:45 --> Config Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:36:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:36:45 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:36:45 --> URI Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Router Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Output Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Security Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Input Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:36:45 --> Language Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Loader Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:36:45 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Session: Regenerate ID
DEBUG - 2015-02-10 17:36:45 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:36:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Controller Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:36:45 --> Email Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:36:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:36:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:36:45 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:36:45 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:36:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:36:46 --> Final output sent to browser
DEBUG - 2015-02-10 17:36:46 --> Total execution time: 1.1471
DEBUG - 2015-02-10 17:36:47 --> Config Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:36:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:36:47 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:36:47 --> URI Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Router Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Output Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Security Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Input Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:36:47 --> Language Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Loader Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:36:47 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:36:47 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Controller Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:36:47 --> Email Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:36:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:36:47 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:36:47 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:47 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:48 --> Final output sent to browser
DEBUG - 2015-02-10 17:36:48 --> Total execution time: 0.9271
DEBUG - 2015-02-10 17:36:57 --> Config Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:36:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:36:57 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:36:57 --> URI Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Router Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Output Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Security Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Input Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:36:57 --> Language Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Loader Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:36:57 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:36:57 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:36:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Controller Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:36:57 --> Email Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:36:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:36:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:36:57 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:36:57 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:36:58 --> Final output sent to browser
DEBUG - 2015-02-10 17:36:58 --> Total execution time: 0.8351
DEBUG - 2015-02-10 17:37:14 --> Config Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:37:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:37:14 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:37:14 --> URI Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Router Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Output Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Security Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Input Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:37:14 --> Language Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Loader Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:37:14 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:37:14 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:37:14 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Controller Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:37:14 --> Email Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:37:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:37:14 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:37:14 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:37:14 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:14 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:37:15 --> Final output sent to browser
DEBUG - 2015-02-10 17:37:15 --> Total execution time: 1.1221
DEBUG - 2015-02-10 17:37:15 --> Config Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:37:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:37:15 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:37:15 --> URI Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Router Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Output Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Security Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Input Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:37:15 --> Language Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Loader Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:37:15 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:37:15 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:37:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Controller Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:37:15 --> Email Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:37:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:37:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:37:15 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:37:15 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:16 --> Final output sent to browser
DEBUG - 2015-02-10 17:37:16 --> Total execution time: 1.1101
DEBUG - 2015-02-10 17:37:25 --> Config Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:37:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:37:25 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:37:25 --> URI Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Router Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Output Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Security Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Input Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:37:25 --> Language Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Loader Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:37:25 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:37:25 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:37:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Controller Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:37:25 --> Email Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:37:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:37:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:37:25 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:37:25 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:37:26 --> Final output sent to browser
DEBUG - 2015-02-10 17:37:26 --> Total execution time: 0.8881
DEBUG - 2015-02-10 17:38:47 --> Config Class Initialized
DEBUG - 2015-02-10 17:38:47 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:38:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:38:47 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:38:47 --> URI Class Initialized
DEBUG - 2015-02-10 17:38:47 --> Router Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Output Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Security Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Input Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:38:48 --> Language Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Loader Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:38:48 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:38:48 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:38:48 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Controller Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:38:48 --> Email Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:38:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:38:48 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:38:48 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:38:48 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:48 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:49 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:38:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:38:49 --> Final output sent to browser
DEBUG - 2015-02-10 17:38:49 --> Total execution time: 1.1031
DEBUG - 2015-02-10 17:38:50 --> Config Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:38:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:38:50 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:38:50 --> URI Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Router Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Output Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Security Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Input Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:38:50 --> Language Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Loader Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:38:50 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:38:50 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Controller Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:38:50 --> Email Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:38:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:38:50 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:38:50 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Model Class Initialized
DEBUG - 2015-02-10 17:38:50 --> Final output sent to browser
DEBUG - 2015-02-10 17:38:50 --> Total execution time: 0.9571
DEBUG - 2015-02-10 17:38:59 --> Config Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:38:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:38:59 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:38:59 --> URI Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Router Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Output Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Security Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Input Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:38:59 --> Language Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Loader Class Initialized
DEBUG - 2015-02-10 17:38:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:38:59 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:38:59 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:38:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:38:59 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:38:59 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Controller Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:39:00 --> Email Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:39:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:39:00 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:39:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:39:00 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:39:00 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:00 --> Final output sent to browser
DEBUG - 2015-02-10 17:39:00 --> Total execution time: 0.8661
DEBUG - 2015-02-10 17:39:25 --> Config Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:39:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:39:25 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:39:25 --> URI Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Router Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Output Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Security Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Input Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:39:25 --> Language Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Loader Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:39:25 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:39:25 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:39:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Controller Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:39:25 --> Email Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:39:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:39:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:39:25 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:39:25 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:39:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:39:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:39:26 --> Final output sent to browser
DEBUG - 2015-02-10 17:39:26 --> Total execution time: 1.1761
DEBUG - 2015-02-10 17:39:26 --> Config Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:39:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:39:26 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:39:26 --> URI Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Router Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Output Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Security Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Input Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:39:26 --> Language Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Loader Class Initialized
DEBUG - 2015-02-10 17:39:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:39:26 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:39:26 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:39:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:39:26 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:39:26 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:39:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Controller Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:39:27 --> Email Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:39:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:39:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:39:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:39:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:39:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:39:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:27 --> Final output sent to browser
DEBUG - 2015-02-10 17:39:27 --> Total execution time: 1.0221
DEBUG - 2015-02-10 17:39:36 --> Config Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:39:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:39:36 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:39:36 --> URI Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Router Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Output Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Security Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Input Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:39:36 --> Language Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Loader Class Initialized
DEBUG - 2015-02-10 17:39:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:39:36 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:39:36 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:39:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:39:36 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:39:36 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:39:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Controller Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:39:37 --> Email Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:39:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:39:37 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:39:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:39:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:39:37 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:39:37 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:37 --> Final output sent to browser
DEBUG - 2015-02-10 17:39:37 --> Total execution time: 0.8701
DEBUG - 2015-02-10 17:39:57 --> Config Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:39:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:39:57 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:39:57 --> URI Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Router Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Output Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Security Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Input Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:39:57 --> Language Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Loader Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:39:57 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:39:57 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:39:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Controller Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:39:57 --> Email Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:39:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:39:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:39:57 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:39:57 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:39:57 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:39:58 --> Final output sent to browser
DEBUG - 2015-02-10 17:39:58 --> Total execution time: 1.1721
DEBUG - 2015-02-10 17:39:59 --> Config Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:39:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:39:59 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:39:59 --> URI Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Router Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Output Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Security Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Input Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:39:59 --> Language Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Loader Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:39:59 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:39:59 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:39:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Controller Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:39:59 --> Email Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:39:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:39:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:39:59 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:39:59 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:39:59 --> Final output sent to browser
DEBUG - 2015-02-10 17:39:59 --> Total execution time: 0.9111
DEBUG - 2015-02-10 17:40:08 --> Config Class Initialized
DEBUG - 2015-02-10 17:40:08 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:40:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:40:08 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:40:08 --> URI Class Initialized
DEBUG - 2015-02-10 17:40:08 --> Router Class Initialized
DEBUG - 2015-02-10 17:40:08 --> Output Class Initialized
DEBUG - 2015-02-10 17:40:08 --> Security Class Initialized
DEBUG - 2015-02-10 17:40:08 --> Input Class Initialized
DEBUG - 2015-02-10 17:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:40:08 --> Language Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Loader Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:40:09 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:40:09 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:40:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Controller Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:40:09 --> Email Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:40:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:40:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:40:09 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:40:09 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:09 --> Final output sent to browser
DEBUG - 2015-02-10 17:40:09 --> Total execution time: 0.8571
DEBUG - 2015-02-10 17:40:10 --> Config Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:40:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:40:10 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:40:10 --> URI Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Router Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Output Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Security Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Input Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:40:10 --> Language Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Loader Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:40:10 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:40:10 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:40:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Controller Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:40:10 --> Email Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:40:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:40:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:40:10 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:40:10 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:40:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:11 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:11 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:40:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:40:11 --> Final output sent to browser
DEBUG - 2015-02-10 17:40:11 --> Total execution time: 1.1901
DEBUG - 2015-02-10 17:40:12 --> Config Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:40:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:40:12 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:40:12 --> URI Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Router Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Output Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Security Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Input Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:40:12 --> Language Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Loader Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:40:12 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:40:12 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:40:12 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Controller Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:40:12 --> Email Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:40:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:40:12 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:40:12 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:40:12 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:12 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:13 --> Final output sent to browser
DEBUG - 2015-02-10 17:40:13 --> Total execution time: 0.9591
DEBUG - 2015-02-10 17:40:22 --> Config Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:40:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:40:22 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:40:22 --> URI Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Router Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Output Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Security Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Input Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:40:22 --> Language Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Loader Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:40:22 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:40:22 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:40:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Controller Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:40:22 --> Email Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:40:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:40:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:40:22 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:40:22 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:40:23 --> Final output sent to browser
DEBUG - 2015-02-10 17:40:23 --> Total execution time: 0.8031
DEBUG - 2015-02-10 17:41:34 --> Config Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:41:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:41:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:41:34 --> URI Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Router Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Output Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Security Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Input Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:41:34 --> Language Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Loader Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:41:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:41:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:41:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Controller Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:41:34 --> Email Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:41:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:41:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:41:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:41:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:41:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:41:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:41:35 --> Final output sent to browser
DEBUG - 2015-02-10 17:41:35 --> Total execution time: 1.1371
DEBUG - 2015-02-10 17:41:36 --> Config Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:41:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:41:36 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:41:36 --> URI Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Router Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Output Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Security Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Input Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:41:36 --> Language Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Loader Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:41:36 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:41:36 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:41:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Controller Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:41:36 --> Email Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:41:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:41:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:41:36 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:41:36 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:37 --> Final output sent to browser
DEBUG - 2015-02-10 17:41:37 --> Total execution time: 0.9431
DEBUG - 2015-02-10 17:41:46 --> Config Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:41:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:41:46 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:41:46 --> URI Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Router Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Output Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Security Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Input Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:41:46 --> Language Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Loader Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:41:46 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:41:46 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:41:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Controller Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:41:46 --> Email Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:41:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:41:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:41:46 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:41:46 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:47 --> Final output sent to browser
DEBUG - 2015-02-10 17:41:47 --> Total execution time: 0.8191
DEBUG - 2015-02-10 17:41:54 --> Config Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:41:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:41:54 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:41:54 --> URI Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Router Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Output Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Security Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Input Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:41:54 --> Language Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Loader Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:41:54 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:41:54 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:41:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Controller Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:41:54 --> Email Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:41:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:41:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:41:54 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:41:54 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:41:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:55 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:55 --> Model Class Initialized
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:41:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:41:55 --> Final output sent to browser
DEBUG - 2015-02-10 17:41:55 --> Total execution time: 1.1911
DEBUG - 2015-02-10 17:42:01 --> Config Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:42:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:42:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:42:01 --> URI Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Router Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Output Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Security Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Input Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:42:01 --> Language Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Loader Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:42:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:42:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:42:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Controller Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:42:01 --> Email Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:42:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:42:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:42:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:42:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:02 --> Final output sent to browser
DEBUG - 2015-02-10 17:42:02 --> Total execution time: 0.9521
DEBUG - 2015-02-10 17:42:11 --> Config Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:42:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:42:11 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:42:11 --> URI Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Router Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Output Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Security Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Input Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:42:11 --> Language Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Loader Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:42:11 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:42:11 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:42:11 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Controller Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:42:11 --> Email Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:42:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:42:11 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:42:11 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:42:11 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:11 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:12 --> Final output sent to browser
DEBUG - 2015-02-10 17:42:12 --> Total execution time: 0.8051
DEBUG - 2015-02-10 17:42:32 --> Config Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:42:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:42:32 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:42:32 --> URI Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Router Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Output Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Security Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Input Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:42:32 --> Language Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Loader Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:42:32 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:42:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:42:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Controller Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:42:32 --> Email Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:42:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:42:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:42:32 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:42:32 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:42:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:33 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:33 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:42:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:42:33 --> Final output sent to browser
DEBUG - 2015-02-10 17:42:33 --> Total execution time: 1.1671
DEBUG - 2015-02-10 17:42:35 --> Config Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:42:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:42:35 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:42:35 --> URI Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Router Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Output Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Security Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Input Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:42:35 --> Language Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Loader Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:42:35 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:42:35 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:42:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Controller Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:42:35 --> Email Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:42:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:42:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:42:35 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:42:35 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:36 --> Final output sent to browser
DEBUG - 2015-02-10 17:42:36 --> Total execution time: 0.9601
DEBUG - 2015-02-10 17:42:43 --> Config Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:42:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:42:43 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:42:43 --> URI Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Router Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Output Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Security Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Input Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:42:43 --> Language Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Loader Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:42:43 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:42:43 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:42:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Controller Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:42:43 --> Email Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:42:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:42:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:42:43 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:42:43 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:42:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:44 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:44 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:42:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:42:44 --> Final output sent to browser
DEBUG - 2015-02-10 17:42:44 --> Total execution time: 1.2721
DEBUG - 2015-02-10 17:42:46 --> Config Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:42:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:42:46 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:42:46 --> URI Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Router Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Output Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Security Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Input Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:42:46 --> Language Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Loader Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:42:46 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:42:46 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Controller Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:42:46 --> Email Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:42:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:42:46 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:42:46 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:46 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:47 --> Final output sent to browser
DEBUG - 2015-02-10 17:42:47 --> Total execution time: 1.2821
DEBUG - 2015-02-10 17:42:56 --> Config Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:42:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:42:56 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:42:56 --> URI Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Router Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Output Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Security Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Input Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:42:56 --> Language Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Loader Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:42:56 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:42:56 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:42:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Controller Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:42:56 --> Email Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:42:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:42:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:42:56 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:42:56 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:42:57 --> Final output sent to browser
DEBUG - 2015-02-10 17:42:57 --> Total execution time: 0.9341
DEBUG - 2015-02-10 17:43:23 --> Config Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:43:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:43:23 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:43:23 --> URI Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Router Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Output Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Security Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Input Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:43:23 --> Language Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Loader Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:43:23 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:43:23 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:43:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:43:23 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:43:23 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:43:23 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Controller Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:43:23 --> Email Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:43:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:43:23 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:43:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:43:23 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:43:23 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:43:24 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:43:24 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:43:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:43:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:43:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:43:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:43:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:43:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:43:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:43:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:43:25 --> Final output sent to browser
DEBUG - 2015-02-10 17:43:25 --> Total execution time: 1.1671
DEBUG - 2015-02-10 17:43:26 --> Config Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:43:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:43:26 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:43:26 --> URI Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Router Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Output Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Security Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Input Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:43:26 --> Language Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Loader Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:43:26 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:43:26 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:43:26 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Controller Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:43:26 --> Email Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:43:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:43:26 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:43:26 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:43:26 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:26 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:27 --> Final output sent to browser
DEBUG - 2015-02-10 17:43:27 --> Total execution time: 1.1961
DEBUG - 2015-02-10 17:43:36 --> Config Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:43:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:43:36 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:43:36 --> URI Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Router Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Output Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Security Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Input Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:43:36 --> Language Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Loader Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:43:36 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:43:36 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:43:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Controller Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:43:36 --> Email Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:43:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:43:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:43:36 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:43:36 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:43:36 --> Final output sent to browser
DEBUG - 2015-02-10 17:43:36 --> Total execution time: 0.8051
DEBUG - 2015-02-10 17:44:15 --> Config Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:44:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:44:15 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:44:15 --> URI Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Router Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Output Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Security Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Input Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:44:15 --> Language Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Loader Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:44:15 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:44:15 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:44:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Controller Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:44:15 --> Email Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:44:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:44:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:44:15 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:44:15 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:15 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:16 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:44:16 --> Final output sent to browser
DEBUG - 2015-02-10 17:44:16 --> Total execution time: 1.1161
DEBUG - 2015-02-10 17:44:17 --> Config Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:44:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:44:17 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:44:17 --> URI Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Router Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Output Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Security Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Input Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:44:17 --> Language Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Loader Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:44:17 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:44:17 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:44:17 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Controller Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:44:17 --> Email Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:44:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:44:17 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:44:17 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:44:17 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:17 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:18 --> Final output sent to browser
DEBUG - 2015-02-10 17:44:18 --> Total execution time: 0.8961
DEBUG - 2015-02-10 17:44:27 --> Config Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:44:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:44:27 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:44:27 --> URI Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Router Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Output Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Security Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Input Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:44:27 --> Language Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Loader Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:44:27 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:44:27 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:44:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Controller Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:44:27 --> Email Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:44:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:44:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:44:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:44:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:44:28 --> Final output sent to browser
DEBUG - 2015-02-10 17:44:28 --> Total execution time: 0.9691
DEBUG - 2015-02-10 17:45:42 --> Config Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:45:42 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:45:42 --> URI Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Router Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Output Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Security Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Input Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:45:42 --> Language Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Loader Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:45:42 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:45:42 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:45:42 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Controller Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:45:42 --> Email Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:45:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:45:42 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:45:42 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:45:42 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:45:42 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:43 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:45:43 --> Final output sent to browser
DEBUG - 2015-02-10 17:45:43 --> Total execution time: 1.2061
DEBUG - 2015-02-10 17:45:44 --> Config Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:45:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:45:44 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:45:44 --> URI Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Router Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Output Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Security Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Input Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:45:44 --> Language Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Loader Class Initialized
DEBUG - 2015-02-10 17:45:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:45:44 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:45:44 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:45:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:45:44 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:45:44 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:45:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Controller Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:45:45 --> Email Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:45:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:45:45 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:45:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:45:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:45:45 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:45:45 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:45 --> Final output sent to browser
DEBUG - 2015-02-10 17:45:45 --> Total execution time: 0.9951
DEBUG - 2015-02-10 17:45:54 --> Config Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:45:54 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:45:54 --> URI Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Router Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Output Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Security Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Input Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:45:54 --> Language Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Loader Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:45:54 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:45:54 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:45:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Controller Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:45:54 --> Email Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:45:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:45:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:45:54 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:45:54 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:45:55 --> Final output sent to browser
DEBUG - 2015-02-10 17:45:55 --> Total execution time: 0.8291
DEBUG - 2015-02-10 17:48:24 --> Config Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:48:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:48:24 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:48:24 --> URI Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Router Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Output Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Security Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Input Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:48:24 --> Language Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Loader Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:48:24 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Session: Regenerate ID
DEBUG - 2015-02-10 17:48:24 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:48:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Controller Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:48:24 --> Email Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:48:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:48:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:48:24 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:48:24 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:48:24 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:25 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:48:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:48:25 --> Final output sent to browser
DEBUG - 2015-02-10 17:48:25 --> Total execution time: 1.2351
DEBUG - 2015-02-10 17:48:27 --> Config Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:48:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:48:27 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:48:27 --> URI Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Router Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Output Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Security Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Input Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:48:27 --> Language Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Loader Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:48:27 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:48:27 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:48:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Controller Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:48:27 --> Email Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:48:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:48:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:48:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:48:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:27 --> Model Class Initialized
DEBUG - 2015-02-10 17:48:28 --> Final output sent to browser
DEBUG - 2015-02-10 17:48:28 --> Total execution time: 1.0321
DEBUG - 2015-02-10 17:49:37 --> Config Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:49:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:49:37 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:49:37 --> URI Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Router Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Output Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Security Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Input Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:49:37 --> Language Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Loader Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:49:37 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:49:37 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:49:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Controller Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:49:37 --> Email Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:49:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:49:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:49:37 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:49:37 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:49:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:38 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:38 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:49:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:49:38 --> Final output sent to browser
DEBUG - 2015-02-10 17:49:38 --> Total execution time: 1.1431
DEBUG - 2015-02-10 17:49:39 --> Config Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:49:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:49:39 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:49:39 --> URI Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Router Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Output Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Security Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Input Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:49:39 --> Language Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Loader Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:49:39 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:49:39 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Controller Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:49:39 --> Email Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:49:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:49:39 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:49:39 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-10 17:49:40 --> Final output sent to browser
DEBUG - 2015-02-10 17:49:40 --> Total execution time: 0.9541
DEBUG - 2015-02-10 17:50:58 --> Config Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:50:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:50:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:50:58 --> URI Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Router Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Output Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Security Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Input Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:50:58 --> Language Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Loader Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:50:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:50:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:50:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Controller Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:50:58 --> Email Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:50:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:50:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:50:58 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:50:58 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:50:58 --> Model Class Initialized
DEBUG - 2015-02-10 17:50:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:50:59 --> Model Class Initialized
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:50:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:50:59 --> Final output sent to browser
DEBUG - 2015-02-10 17:50:59 --> Total execution time: 1.1381
DEBUG - 2015-02-10 17:51:00 --> Config Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:51:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:51:00 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:51:00 --> URI Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Router Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Output Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Security Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Input Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:51:00 --> Language Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Loader Class Initialized
DEBUG - 2015-02-10 17:51:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:51:00 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:51:00 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:51:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:51:00 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:51:00 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:51:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Controller Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:51:01 --> Email Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:51:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:51:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:51:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:51:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:51:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:51:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Model Class Initialized
DEBUG - 2015-02-10 17:51:01 --> Final output sent to browser
DEBUG - 2015-02-10 17:51:01 --> Total execution time: 0.9181
DEBUG - 2015-02-10 17:52:08 --> Config Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:52:08 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:52:08 --> URI Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Router Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Output Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Security Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Input Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:52:08 --> Language Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Loader Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:52:08 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:52:08 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:52:08 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Controller Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:52:08 --> Email Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:52:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:52:08 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:52:08 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:52:08 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:52:08 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:09 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:52:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:52:09 --> Final output sent to browser
DEBUG - 2015-02-10 17:52:09 --> Total execution time: 1.2131
DEBUG - 2015-02-10 17:52:10 --> Config Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:52:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:52:10 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:52:10 --> URI Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Router Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Output Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Security Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Input Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:52:10 --> Language Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Loader Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:52:10 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:52:10 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:52:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Controller Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:52:10 --> Email Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:52:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:52:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:52:10 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:52:10 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:10 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:11 --> Final output sent to browser
DEBUG - 2015-02-10 17:52:11 --> Total execution time: 0.9851
DEBUG - 2015-02-10 17:52:29 --> Config Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:52:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:52:29 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:52:29 --> URI Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Router Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Output Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Security Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Input Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:52:29 --> Language Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Loader Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:52:29 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:52:29 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:52:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:52:29 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:52:29 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:52:29 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Controller Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:52:29 --> Email Class Initialized
DEBUG - 2015-02-10 17:52:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:52:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:52:29 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:52:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:52:29 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:30 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:52:30 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:52:30 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:52:30 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:52:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:30 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:52:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:52:30 --> Final output sent to browser
DEBUG - 2015-02-10 17:52:30 --> Total execution time: 1.1491
DEBUG - 2015-02-10 17:52:32 --> Config Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:52:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:52:32 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:52:32 --> URI Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Router Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Output Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Security Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Input Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:52:32 --> Language Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Loader Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:52:32 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:52:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:52:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Controller Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:52:32 --> Email Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:52:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:52:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:52:32 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:52:32 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:33 --> Final output sent to browser
DEBUG - 2015-02-10 17:52:33 --> Total execution time: 0.9461
DEBUG - 2015-02-10 17:52:54 --> Config Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:52:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:52:54 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:52:54 --> URI Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Router Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Output Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Security Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Input Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:52:54 --> Language Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Loader Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:52:54 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:52:54 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:52:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Controller Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:52:54 --> Email Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:52:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:52:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:52:54 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:52:54 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:52:54 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:55 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:55 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:52:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:52:55 --> Final output sent to browser
DEBUG - 2015-02-10 17:52:55 --> Total execution time: 1.1071
DEBUG - 2015-02-10 17:52:56 --> Config Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:52:56 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:52:56 --> URI Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Router Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Output Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Security Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Input Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:52:56 --> Language Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Loader Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:52:56 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:52:56 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:52:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Controller Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:52:56 --> Email Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:52:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:52:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:52:56 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:52:56 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:56 --> Model Class Initialized
DEBUG - 2015-02-10 17:52:57 --> Final output sent to browser
DEBUG - 2015-02-10 17:52:57 --> Total execution time: 0.9361
DEBUG - 2015-02-10 17:53:20 --> Config Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:53:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:53:20 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:53:20 --> URI Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Router Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Output Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Security Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Input Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:53:20 --> Language Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Loader Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:53:20 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:53:20 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:53:20 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Controller Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:53:20 --> Email Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:53:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:53:20 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:53:20 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:53:20 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:53:20 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:53:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:53:21 --> Final output sent to browser
DEBUG - 2015-02-10 17:53:21 --> Total execution time: 1.1861
DEBUG - 2015-02-10 17:53:21 --> Config Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:53:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:53:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:53:21 --> URI Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Router Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Output Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Security Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Input Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:53:21 --> Language Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Loader Class Initialized
DEBUG - 2015-02-10 17:53:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:53:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:53:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:53:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:53:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:53:22 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:53:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Controller Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:53:22 --> Email Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:53:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:53:22 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:53:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:53:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:53:22 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:53:22 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:22 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:23 --> Final output sent to browser
DEBUG - 2015-02-10 17:53:23 --> Total execution time: 1.1471
DEBUG - 2015-02-10 17:53:35 --> Config Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:53:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:53:35 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:53:35 --> URI Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Router Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Output Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Security Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Input Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:53:35 --> Language Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Loader Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:53:35 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Session: Regenerate ID
DEBUG - 2015-02-10 17:53:35 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:53:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Controller Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:53:35 --> Email Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:53:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:53:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:53:35 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:53:35 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:53:35 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:53:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:53:36 --> Final output sent to browser
DEBUG - 2015-02-10 17:53:36 --> Total execution time: 1.1501
DEBUG - 2015-02-10 17:53:36 --> Config Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:53:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:53:36 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:53:36 --> URI Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Router Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Output Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Security Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Input Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:53:36 --> Language Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Loader Class Initialized
DEBUG - 2015-02-10 17:53:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:53:36 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:53:36 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:53:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:53:36 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:53:36 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:53:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Controller Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:53:37 --> Email Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:53:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:53:37 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:53:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:53:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:53:37 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:53:37 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Model Class Initialized
DEBUG - 2015-02-10 17:53:37 --> Final output sent to browser
DEBUG - 2015-02-10 17:53:37 --> Total execution time: 0.8811
DEBUG - 2015-02-10 17:54:05 --> Config Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:54:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:54:05 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:54:05 --> URI Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Router Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Output Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Security Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Input Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:54:05 --> Language Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Loader Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:54:05 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:54:05 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:54:05 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Controller Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:54:05 --> Email Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:54:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:54:05 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:54:05 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:54:05 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:54:05 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:54:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:54:06 --> Final output sent to browser
DEBUG - 2015-02-10 17:54:06 --> Total execution time: 1.1861
DEBUG - 2015-02-10 17:54:06 --> Config Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:54:06 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:54:06 --> URI Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Router Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Output Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Security Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Input Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:54:06 --> Language Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Loader Class Initialized
DEBUG - 2015-02-10 17:54:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:54:06 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:54:06 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:54:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:54:06 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:54:06 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:54:07 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Controller Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:54:07 --> Email Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:54:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:54:07 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:54:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:54:07 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:54:07 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:54:07 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Model Class Initialized
DEBUG - 2015-02-10 17:54:07 --> Final output sent to browser
DEBUG - 2015-02-10 17:54:07 --> Total execution time: 0.8861
DEBUG - 2015-02-10 17:57:04 --> Config Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:57:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:57:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:57:04 --> URI Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Router Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Output Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Security Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Input Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:57:04 --> Language Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Loader Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:57:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:57:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Controller Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:57:04 --> Email Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:57:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:57:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:57:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:57:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:05 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:05 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:57:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:57:05 --> Final output sent to browser
DEBUG - 2015-02-10 17:57:05 --> Total execution time: 1.1791
DEBUG - 2015-02-10 17:57:06 --> Config Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:57:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:57:06 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:57:06 --> URI Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Router Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Output Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Security Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Input Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:57:06 --> Language Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Loader Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:57:06 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:57:06 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:57:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Controller Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:57:06 --> Email Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:57:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:57:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:57:06 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:57:06 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:07 --> Final output sent to browser
DEBUG - 2015-02-10 17:57:07 --> Total execution time: 1.1421
DEBUG - 2015-02-10 17:57:36 --> Config Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:57:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:57:36 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:57:36 --> URI Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Router Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Output Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Security Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Input Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:57:36 --> Language Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Loader Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:57:36 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:57:36 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:57:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Controller Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:57:36 --> Email Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:57:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:57:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:57:36 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:57:36 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:36 --> Model Class Initialized
DEBUG - 2015-02-10 17:57:37 --> Final output sent to browser
DEBUG - 2015-02-10 17:57:37 --> Total execution time: 0.8491
DEBUG - 2015-02-10 17:58:06 --> Config Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:58:06 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:58:06 --> URI Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Router Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Output Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Security Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Input Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:58:06 --> Language Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Loader Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:58:06 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:58:06 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:58:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Controller Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:58:06 --> Email Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:58:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:58:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:58:06 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:58:06 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:06 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:07 --> Final output sent to browser
DEBUG - 2015-02-10 17:58:07 --> Total execution time: 0.8471
DEBUG - 2015-02-10 17:58:31 --> Config Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:58:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:58:31 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:58:31 --> URI Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Router Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Output Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Security Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Input Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:58:31 --> Language Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Loader Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:58:31 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:58:31 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:58:31 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Controller Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:58:31 --> Email Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:58:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:58:31 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:58:31 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:58:31 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:58:31 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:32 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 17:58:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 17:58:32 --> Final output sent to browser
DEBUG - 2015-02-10 17:58:32 --> Total execution time: 1.1401
DEBUG - 2015-02-10 17:58:33 --> Config Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:58:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:58:33 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:58:33 --> URI Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Router Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Output Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Security Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Input Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:58:33 --> Language Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Loader Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:58:33 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:58:33 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:58:33 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Controller Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:58:33 --> Email Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:58:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:58:33 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:58:33 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:58:33 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:33 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:34 --> Final output sent to browser
DEBUG - 2015-02-10 17:58:34 --> Total execution time: 1.0791
DEBUG - 2015-02-10 17:58:49 --> Config Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:58:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:58:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:58:49 --> URI Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Router Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Output Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Security Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Input Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:58:49 --> Language Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Loader Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:58:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:58:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:58:49 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Controller Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:58:49 --> Email Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:58:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:58:49 --> Model Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:58:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:58:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:58:49 --> Model Class Initialized
ERROR - 2015-02-10 17:58:49 --> Severity: Notice --> Undefined index: aritcle D:\phutx\project\ups\myblog\application\models\Comment_model.php 18
ERROR - 2015-02-10 17:58:49 --> Severity: error --> Exception: The identifier id is missing for a query of Entity\Comments D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 160
DEBUG - 2015-02-10 17:59:04 --> Config Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:59:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:59:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:59:04 --> URI Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Router Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Output Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Security Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Input Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:59:04 --> Language Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Loader Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:59:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:59:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:59:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Controller Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:59:04 --> Email Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:59:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:59:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:59:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:59:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:04 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:05 --> Final output sent to browser
DEBUG - 2015-02-10 17:59:05 --> Total execution time: 0.8141
DEBUG - 2015-02-10 17:59:34 --> Config Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 17:59:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 17:59:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 17:59:34 --> URI Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Router Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Output Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Security Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Input Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 17:59:34 --> Language Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Loader Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 17:59:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 17:59:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 17:59:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Controller Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 17:59:34 --> Email Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 17:59:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 17:59:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 17:59:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 17:59:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:34 --> Model Class Initialized
DEBUG - 2015-02-10 17:59:35 --> Final output sent to browser
DEBUG - 2015-02-10 17:59:35 --> Total execution time: 1.0051
DEBUG - 2015-02-10 18:00:04 --> Config Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:00:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:00:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:00:04 --> URI Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Router Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Output Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Security Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Input Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:00:04 --> Language Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Loader Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:00:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:00:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:00:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Controller Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:00:04 --> Email Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:00:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:00:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:00:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:00:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:05 --> Final output sent to browser
DEBUG - 2015-02-10 18:00:05 --> Total execution time: 0.8161
DEBUG - 2015-02-10 18:00:34 --> Config Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:00:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:00:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:00:34 --> URI Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Router Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Output Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Security Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Input Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:00:34 --> Language Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Loader Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:00:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:00:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:00:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Controller Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:00:34 --> Email Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:00:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:00:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:00:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:00:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:00:35 --> Final output sent to browser
DEBUG - 2015-02-10 18:00:35 --> Total execution time: 0.8521
DEBUG - 2015-02-10 18:01:04 --> Config Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:01:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:01:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:01:04 --> URI Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Router Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Output Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Security Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Input Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:01:04 --> Language Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Loader Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:01:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:01:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:01:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Controller Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:01:04 --> Email Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:01:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:01:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:01:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:01:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:05 --> Final output sent to browser
DEBUG - 2015-02-10 18:01:05 --> Total execution time: 0.8331
DEBUG - 2015-02-10 18:01:34 --> Config Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:01:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:01:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:01:34 --> URI Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Router Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Output Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Security Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Input Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:01:34 --> Language Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Loader Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:01:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:01:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:01:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Controller Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:01:34 --> Email Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:01:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:01:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:01:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:01:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:01:35 --> Final output sent to browser
DEBUG - 2015-02-10 18:01:35 --> Total execution time: 0.8621
DEBUG - 2015-02-10 18:02:01 --> Config Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:02:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:02:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:02:01 --> URI Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Router Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Output Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Security Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Input Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:02:01 --> Language Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Loader Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:02:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:02:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:02:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Controller Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:02:01 --> Email Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:02:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:02:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:02:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:02:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:02:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:02:02 --> Final output sent to browser
DEBUG - 2015-02-10 18:02:02 --> Total execution time: 1.1671
DEBUG - 2015-02-10 18:02:04 --> Config Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:02:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:02:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:02:04 --> URI Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Router Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Output Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Security Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Input Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:02:04 --> Language Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Loader Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:02:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:02:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:02:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Controller Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:02:04 --> Email Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:02:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:02:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:02:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:02:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:05 --> Final output sent to browser
DEBUG - 2015-02-10 18:02:05 --> Total execution time: 0.8891
DEBUG - 2015-02-10 18:02:16 --> Config Class Initialized
DEBUG - 2015-02-10 18:02:16 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:02:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:02:16 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:02:16 --> URI Class Initialized
DEBUG - 2015-02-10 18:02:16 --> Router Class Initialized
DEBUG - 2015-02-10 18:02:16 --> Output Class Initialized
DEBUG - 2015-02-10 18:02:16 --> Security Class Initialized
DEBUG - 2015-02-10 18:02:16 --> Input Class Initialized
DEBUG - 2015-02-10 18:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:02:16 --> Language Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Loader Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:02:17 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:02:17 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:02:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Controller Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:02:17 --> Email Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:02:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:02:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:02:17 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:02:17 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:02:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:02:18 --> Final output sent to browser
DEBUG - 2015-02-10 18:02:18 --> Total execution time: 1.0901
DEBUG - 2015-02-10 18:02:18 --> Config Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:02:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:02:18 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:02:18 --> URI Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Router Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Output Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Security Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Input Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:02:18 --> Language Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Loader Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:02:18 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:02:18 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Controller Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:02:18 --> Email Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:02:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:02:18 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:02:18 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:19 --> Final output sent to browser
DEBUG - 2015-02-10 18:02:19 --> Total execution time: 1.0011
DEBUG - 2015-02-10 18:02:48 --> Config Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:02:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:02:48 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:02:48 --> URI Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Router Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Output Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Security Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Input Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:02:48 --> Language Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Loader Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:02:48 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:02:48 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:02:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Controller Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:02:48 --> Email Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:02:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:02:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:02:48 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:02:48 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:02:49 --> Final output sent to browser
DEBUG - 2015-02-10 18:02:49 --> Total execution time: 1.0361
DEBUG - 2015-02-10 18:03:18 --> Config Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:03:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:03:18 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:03:18 --> URI Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Router Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Output Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Security Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Input Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:03:18 --> Language Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Loader Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:03:18 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:03:18 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:03:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Controller Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:03:18 --> Email Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:03:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:03:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:03:18 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:03:18 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:19 --> Final output sent to browser
DEBUG - 2015-02-10 18:03:19 --> Total execution time: 0.8431
DEBUG - 2015-02-10 18:03:48 --> Config Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:03:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:03:48 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:03:48 --> URI Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Router Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Output Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Security Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Input Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:03:48 --> Language Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Loader Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:03:48 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:03:48 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:03:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Controller Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:03:48 --> Email Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:03:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:03:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:03:48 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:03:48 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:03:49 --> Final output sent to browser
DEBUG - 2015-02-10 18:03:49 --> Total execution time: 0.8101
DEBUG - 2015-02-10 18:04:05 --> Config Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:04:05 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:04:05 --> URI Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Router Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Output Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Security Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Input Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:04:05 --> Language Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Loader Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:04:05 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Session: Regenerate ID
DEBUG - 2015-02-10 18:04:05 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:04:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Controller Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:04:05 --> Email Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:04:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:04:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:04:05 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:04:05 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:04:05 --> Model Class Initialized
ERROR - 2015-02-10 18:04:05 --> Severity: Notice --> Undefined property: article::$em D:\phutx\project\ups\myblog\application\controllers\article.php 10
ERROR - 2015-02-10 18:04:05 --> Severity: Error --> Call to a member function getRepository() on a non-object D:\phutx\project\ups\myblog\application\controllers\article.php 10
DEBUG - 2015-02-10 18:05:28 --> Config Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:05:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:05:28 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:05:28 --> URI Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Router Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Output Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Security Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Input Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:05:28 --> Language Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Loader Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:05:28 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:05:28 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:05:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Controller Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:05:28 --> Email Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:05:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:05:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:05:28 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:05:28 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:05:28 --> Model Class Initialized
ERROR - 2015-02-10 18:05:29 --> Severity: error --> Exception: The identifier id is missing for a query of Entity\Users D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 160
DEBUG - 2015-02-10 18:06:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:19 --> Language Class Initialized
ERROR - 2015-02-10 18:06:19 --> Severity: Compile Error --> Cannot use isset() on the result of a function call (you can use "null !== func()" instead) D:\phutx\project\ups\myblog\application\controllers\article.php 10
DEBUG - 2015-02-10 18:06:30 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:30 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:30 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:30 --> Language Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Loader Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:06:30 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:06:30 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:06:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:06:30 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:06:30 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:06:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Controller Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:06:30 --> Email Class Initialized
DEBUG - 2015-02-10 18:06:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:06:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:06:30 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:06:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:31 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:06:31 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:06:31 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:06:31 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:06:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:06:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:06:32 --> Final output sent to browser
DEBUG - 2015-02-10 18:06:32 --> Total execution time: 1.3231
DEBUG - 2015-02-10 18:06:32 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:32 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:32 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:32 --> Language Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Loader Class Initialized
DEBUG - 2015-02-10 18:06:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:06:32 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:06:32 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:06:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:06:32 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:06:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Controller Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:06:33 --> Email Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:06:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:06:33 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:06:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:06:33 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:06:33 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:33 --> Final output sent to browser
DEBUG - 2015-02-10 18:06:33 --> Total execution time: 1.0431
DEBUG - 2015-02-10 18:06:35 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:35 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:35 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:35 --> Language Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Loader Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:06:35 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:06:35 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:06:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:06:35 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:06:35 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:06:35 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Controller Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:06:35 --> Email Class Initialized
DEBUG - 2015-02-10 18:06:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:06:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:06:35 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:06:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:36 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:06:36 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:06:36 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:06:36 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:06:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-10 18:06:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-10 18:06:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:06:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:06:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-10 18:06:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:06:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:06:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:06:36 --> Final output sent to browser
DEBUG - 2015-02-10 18:06:36 --> Total execution time: 0.9531
DEBUG - 2015-02-10 18:06:42 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:42 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:42 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:42 --> Language Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Loader Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:06:42 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:06:42 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:06:42 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Controller Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:06:42 --> Email Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:06:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:42 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:06:42 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:06:42 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:06:42 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-10 18:06:42 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:42 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-10 18:06:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-10 18:06:43 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:43 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:43 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:43 --> No URI present. Default controller set.
DEBUG - 2015-02-10 18:06:43 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:43 --> Language Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Loader Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:06:43 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:06:43 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:06:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Controller Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:06:43 --> Email Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:06:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:06:43 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:06:43 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 18:06:43 --> Pagination Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:06:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:06:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 18:06:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:06:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:06:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:06:45 --> Final output sent to browser
DEBUG - 2015-02-10 18:06:45 --> Total execution time: 1.9612
DEBUG - 2015-02-10 18:06:47 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:47 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:47 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:47 --> Language Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Loader Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:06:47 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:06:47 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:06:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Controller Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:06:47 --> Email Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:06:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:06:47 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:06:47 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:06:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:06:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:06:49 --> Final output sent to browser
DEBUG - 2015-02-10 18:06:49 --> Total execution time: 2.0632
DEBUG - 2015-02-10 18:06:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:06:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:06:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:06:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:06:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:06:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:06:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:06:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:06:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:06:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:06:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:06:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:06:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:06:50 --> Final output sent to browser
DEBUG - 2015-02-10 18:06:50 --> Total execution time: 1.0851
DEBUG - 2015-02-10 18:07:02 --> Config Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:07:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:07:02 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:07:02 --> URI Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Router Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Output Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Security Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Input Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:07:02 --> Language Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Loader Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:07:02 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:07:02 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Controller Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:07:02 --> Email Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:07:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:07:02 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:07:02 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:07:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:07:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:07:04 --> Final output sent to browser
DEBUG - 2015-02-10 18:07:04 --> Total execution time: 1.6042
DEBUG - 2015-02-10 18:07:04 --> Config Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:07:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:07:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:07:04 --> URI Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Router Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Output Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Security Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Input Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:07:04 --> Language Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Loader Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:07:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:07:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:07:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Controller Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:07:04 --> Email Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:07:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:07:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:07:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:07:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:04 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:05 --> Final output sent to browser
DEBUG - 2015-02-10 18:07:05 --> Total execution time: 0.8891
DEBUG - 2015-02-10 18:07:34 --> Config Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:07:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:07:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:07:34 --> URI Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Router Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Output Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Security Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Input Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:07:34 --> Language Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Loader Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:07:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:07:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Controller Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:07:34 --> Email Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:07:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:07:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:07:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:35 --> Final output sent to browser
DEBUG - 2015-02-10 18:07:35 --> Total execution time: 0.8831
DEBUG - 2015-02-10 18:07:43 --> Config Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:07:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:07:43 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:07:43 --> URI Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Router Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Output Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Security Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Input Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:07:43 --> Language Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Loader Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:07:43 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:07:43 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:07:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Controller Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:07:43 --> Email Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:07:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:07:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:07:43 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:07:43 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:07:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:07:45 --> Final output sent to browser
DEBUG - 2015-02-10 18:07:45 --> Total execution time: 1.3621
DEBUG - 2015-02-10 18:07:45 --> Config Class Initialized
DEBUG - 2015-02-10 18:07:45 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:07:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:07:45 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:07:45 --> URI Class Initialized
DEBUG - 2015-02-10 18:07:45 --> Router Class Initialized
DEBUG - 2015-02-10 18:07:45 --> Output Class Initialized
DEBUG - 2015-02-10 18:07:45 --> Security Class Initialized
DEBUG - 2015-02-10 18:07:45 --> Input Class Initialized
DEBUG - 2015-02-10 18:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:07:45 --> Language Class Initialized
DEBUG - 2015-02-10 18:07:45 --> Loader Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:07:46 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:07:46 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:07:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Controller Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:07:46 --> Email Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:07:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:07:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:07:46 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:07:46 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:07:47 --> Final output sent to browser
DEBUG - 2015-02-10 18:07:47 --> Total execution time: 1.1381
DEBUG - 2015-02-10 18:08:01 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:01 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:01 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:01 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:01 --> Model Class Initialized
ERROR - 2015-02-10 18:08:02 --> Severity: Notice --> Undefined index: comment D:\phutx\project\ups\myblog\application\models\Comment_model.php 20
ERROR - 2015-02-10 18:08:02 --> Severity: error --> Exception: The identifier id is missing for a query of Entity\Comments D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 160
DEBUG - 2015-02-10 18:08:02 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:02 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:02 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:02 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:02 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:02 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:02 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:02 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:02 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:03 --> Final output sent to browser
DEBUG - 2015-02-10 18:08:03 --> Total execution time: 0.8291
DEBUG - 2015-02-10 18:08:16 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:16 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:16 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:16 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:16 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:16 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:16 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:16 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:16 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:17 --> Final output sent to browser
DEBUG - 2015-02-10 18:08:17 --> Total execution time: 0.9451
DEBUG - 2015-02-10 18:08:18 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:18 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:18 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:18 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:18 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:18 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:18 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:18 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:18 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:18 --> Model Class Initialized
ERROR - 2015-02-10 18:08:19 --> Severity: Notice --> Undefined index: comment D:\phutx\project\ups\myblog\application\models\Comment_model.php 20
ERROR - 2015-02-10 18:08:19 --> Severity: error --> Exception: The identifier id is missing for a query of Entity\Comments D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 160
DEBUG - 2015-02-10 18:08:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:19 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:19 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:20 --> Final output sent to browser
DEBUG - 2015-02-10 18:08:20 --> Total execution time: 1.0471
DEBUG - 2015-02-10 18:08:33 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:33 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:33 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:33 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:33 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:33 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:33 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:33 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:33 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:33 --> Final output sent to browser
DEBUG - 2015-02-10 18:08:33 --> Total execution time: 0.8121
DEBUG - 2015-02-10 18:08:47 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:47 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:47 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:47 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:47 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:47 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:47 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:47 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:47 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:48 --> Final output sent to browser
DEBUG - 2015-02-10 18:08:48 --> Total execution time: 0.8781
DEBUG - 2015-02-10 18:08:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:08:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:08:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:08:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:08:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:08:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:08:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:08:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:08:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:08:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:08:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:08:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:08:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:08:50 --> Final output sent to browser
DEBUG - 2015-02-10 18:08:50 --> Total execution time: 0.8141
DEBUG - 2015-02-10 18:09:03 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:03 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:03 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:03 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:03 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:03 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:03 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:03 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:03 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:03 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:03 --> Total execution time: 0.8541
DEBUG - 2015-02-10 18:09:17 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:17 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:17 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:17 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:17 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:17 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:17 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:17 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:17 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:17 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:18 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:18 --> Total execution time: 0.8111
DEBUG - 2015-02-10 18:09:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:19 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:19 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:20 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:20 --> Total execution time: 0.8901
DEBUG - 2015-02-10 18:09:25 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:25 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:25 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:25 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:25 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:25 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:25 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:25 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:25 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:25 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:25 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:25 --> Model Class Initialized
ERROR - 2015-02-10 18:09:25 --> Severity: Notice --> Undefined variable: user D:\phutx\project\ups\myblog\application\models\Comment_model.php 23
DEBUG - 2015-02-10 18:09:25 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:25 --> Total execution time: 0.9001
DEBUG - 2015-02-10 18:09:26 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:26 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:26 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:26 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:26 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:26 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:26 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:26 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:26 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:26 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:26 --> Total execution time: 0.9301
DEBUG - 2015-02-10 18:09:34 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:34 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:34 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:34 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:34 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:34 --> Total execution time: 0.8451
DEBUG - 2015-02-10 18:09:48 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:48 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:48 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:48 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:48 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:48 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:48 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:48 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:48 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:48 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:49 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:49 --> Total execution time: 0.8761
DEBUG - 2015-02-10 18:09:50 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:50 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:50 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:50 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:50 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:50 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:50 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:50 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:50 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:51 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:51 --> Total execution time: 0.8231
DEBUG - 2015-02-10 18:09:56 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:56 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:56 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:56 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:56 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:56 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:56 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:56 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:56 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:57 --> Total execution time: 0.9491
DEBUG - 2015-02-10 18:09:57 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:57 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:57 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:57 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:57 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:57 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:57 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:57 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:58 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:58 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:58 --> Total execution time: 0.9611
DEBUG - 2015-02-10 18:09:58 --> Config Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:09:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:09:58 --> URI Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Router Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Output Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Security Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Input Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:09:58 --> Language Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Loader Class Initialized
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:09:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:09:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:09:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:09:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Controller Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:09:59 --> Email Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:09:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:09:59 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:09:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:09:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:09:59 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:09:59 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:09:59 --> Final output sent to browser
DEBUG - 2015-02-10 18:09:59 --> Total execution time: 1.0351
DEBUG - 2015-02-10 18:10:05 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:05 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:05 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:05 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:05 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:05 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:05 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:05 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:05 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:05 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:05 --> Total execution time: 0.9091
DEBUG - 2015-02-10 18:10:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:19 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:19 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:20 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:20 --> Total execution time: 0.8051
DEBUG - 2015-02-10 18:10:21 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:21 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:21 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:21 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:21 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:21 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:21 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:22 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:22 --> Total execution time: 1.0701
DEBUG - 2015-02-10 18:10:27 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:27 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:27 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:27 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:27 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:27 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:27 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:27 --> Model Class Initialized
ERROR - 2015-02-10 18:10:27 --> Severity: 4096 --> Argument 1 passed to getAvatar() must be an instance of Entity\Users, null given, called in D:\phutx\project\ups\myblog\application\controllers\comment.php on line 15 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 11
ERROR - 2015-02-10 18:10:27 --> Severity: Error --> Call to a member function getGender() on a non-object D:\phutx\project\ups\myblog\application\helpers\link_helper.php 13
DEBUG - 2015-02-10 18:10:28 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:28 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:28 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:28 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:28 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:28 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:28 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:28 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:29 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:29 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:29 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:29 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:29 --> Model Class Initialized
ERROR - 2015-02-10 18:10:29 --> Severity: 4096 --> Argument 1 passed to getAvatar() must be an instance of Entity\Users, null given, called in D:\phutx\project\ups\myblog\application\controllers\comment.php on line 15 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 11
ERROR - 2015-02-10 18:10:29 --> Severity: Error --> Call to a member function getGender() on a non-object D:\phutx\project\ups\myblog\application\helpers\link_helper.php 13
DEBUG - 2015-02-10 18:10:35 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:35 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:35 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:35 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:35 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:35 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:35 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:35 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:35 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:35 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:35 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:35 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:35 --> Total execution time: 0.8141
DEBUG - 2015-02-10 18:10:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:50 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:50 --> Total execution time: 0.9271
DEBUG - 2015-02-10 18:10:51 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:51 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:51 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:51 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:51 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:51 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:51 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:51 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:51 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:51 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:51 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:51 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:52 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:52 --> Total execution time: 0.8241
DEBUG - 2015-02-10 18:10:57 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:57 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:57 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:57 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:57 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:57 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:57 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:57 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:57 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:57 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:57 --> Total execution time: 0.8801
DEBUG - 2015-02-10 18:10:58 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:58 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:58 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:59 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:59 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Config Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:10:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:10:59 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:10:59 --> URI Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Router Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Output Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Security Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Input Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:10:59 --> Language Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Loader Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:10:59 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Final output sent to browser
DEBUG - 2015-02-10 18:10:59 --> Total execution time: 0.8851
DEBUG - 2015-02-10 18:10:59 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Controller Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:10:59 --> Email Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:10:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:10:59 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:10:59 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:10:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:00 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:00 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:11:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:11:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:11:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:11:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:11:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:11:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:11:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:11:01 --> Final output sent to browser
DEBUG - 2015-02-10 18:11:01 --> Total execution time: 1.4341
DEBUG - 2015-02-10 18:11:01 --> Config Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:11:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:11:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:11:01 --> URI Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Router Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Output Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Security Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Input Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:11:01 --> Language Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Loader Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:11:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:11:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:11:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Controller Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:11:01 --> Email Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:11:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:11:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:11:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:11:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:02 --> Final output sent to browser
DEBUG - 2015-02-10 18:11:02 --> Total execution time: 1.1121
DEBUG - 2015-02-10 18:11:31 --> Config Class Initialized
DEBUG - 2015-02-10 18:11:31 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:11:31 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:11:31 --> URI Class Initialized
DEBUG - 2015-02-10 18:11:31 --> Router Class Initialized
DEBUG - 2015-02-10 18:11:31 --> Output Class Initialized
DEBUG - 2015-02-10 18:11:31 --> Security Class Initialized
DEBUG - 2015-02-10 18:11:31 --> Input Class Initialized
DEBUG - 2015-02-10 18:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:11:31 --> Language Class Initialized
ERROR - 2015-02-10 18:11:31 --> Severity: Parsing Error --> syntax error, unexpected '/' D:\phutx\project\ups\myblog\application\controllers\comment.php 30
DEBUG - 2015-02-10 18:11:46 --> Config Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:11:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:11:46 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:11:46 --> URI Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Router Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Output Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Security Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Input Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:11:46 --> Language Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Loader Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:11:46 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:11:46 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:11:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Controller Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:11:46 --> Email Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:11:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:11:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:11:46 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:11:46 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:11:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:11:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:11:47 --> Final output sent to browser
DEBUG - 2015-02-10 18:11:47 --> Total execution time: 1.3101
DEBUG - 2015-02-10 18:11:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:11:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:11:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:11:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:11:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:11:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:11:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:11:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:11:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:11:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:11:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:11:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:11:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:11:50 --> Final output sent to browser
DEBUG - 2015-02-10 18:11:50 --> Total execution time: 0.9511
DEBUG - 2015-02-10 18:12:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:12:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:12:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:12:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:12:19 --> Language Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Loader Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:12:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:12:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:12:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Controller Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:12:19 --> Email Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:12:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:12:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:12:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:12:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:19 --> Final output sent to browser
DEBUG - 2015-02-10 18:12:19 --> Total execution time: 0.8031
DEBUG - 2015-02-10 18:12:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:12:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:12:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:12:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:12:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:12:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:12:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:12:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:12:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:12:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:12:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:12:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:12:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:12:49 --> Final output sent to browser
DEBUG - 2015-02-10 18:12:49 --> Total execution time: 0.8841
DEBUG - 2015-02-10 18:13:07 --> Config Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:13:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:13:07 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:13:07 --> URI Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Router Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Output Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Security Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Input Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:13:07 --> Language Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Loader Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:13:07 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:13:07 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Controller Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:13:07 --> Email Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:13:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:13:07 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:13:07 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:13:08 --> Final output sent to browser
DEBUG - 2015-02-10 18:13:08 --> Total execution time: 1.2921
DEBUG - 2015-02-10 18:13:08 --> Config Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:13:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:13:08 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:13:08 --> URI Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Router Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Output Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Security Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Input Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:13:08 --> Language Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Loader Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:13:08 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:13:08 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Controller Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:13:08 --> Email Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:13:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:13:08 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:13:08 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:09 --> Final output sent to browser
DEBUG - 2015-02-10 18:13:09 --> Total execution time: 0.9431
DEBUG - 2015-02-10 18:13:38 --> Config Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:13:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:13:38 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:13:38 --> URI Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Router Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Output Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Security Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Input Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:13:38 --> Language Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Loader Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:13:38 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:13:38 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:13:38 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Controller Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:13:38 --> Email Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:13:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:13:38 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:13:38 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:13:38 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:38 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:39 --> Final output sent to browser
DEBUG - 2015-02-10 18:13:39 --> Total execution time: 0.8421
DEBUG - 2015-02-10 18:13:57 --> Config Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:13:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:13:57 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:13:57 --> URI Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Router Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Output Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Security Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Input Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:13:57 --> Language Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Loader Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:13:57 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:13:57 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:13:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Controller Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:13:57 --> Email Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:13:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:13:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:13:57 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:13:57 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:13:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Final output sent to browser
DEBUG - 2015-02-10 18:13:58 --> Total execution time: 0.8811
DEBUG - 2015-02-10 18:13:58 --> Config Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:13:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:13:58 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:13:58 --> URI Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Router Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Output Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Security Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Input Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:13:58 --> Language Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Loader Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:13:58 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:13:58 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:13:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Controller Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:13:58 --> Email Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:13:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:13:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:13:58 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:13:58 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:13:59 --> Final output sent to browser
DEBUG - 2015-02-10 18:13:59 --> Total execution time: 0.8171
DEBUG - 2015-02-10 18:14:09 --> Config Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:14:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:14:09 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:14:09 --> URI Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Router Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Output Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Security Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Input Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:14:09 --> Language Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Loader Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:14:09 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:14:09 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:14:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Controller Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:14:09 --> Email Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:14:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:14:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:14:09 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:14:09 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:10 --> Final output sent to browser
DEBUG - 2015-02-10 18:14:10 --> Total execution time: 0.9451
DEBUG - 2015-02-10 18:14:27 --> Config Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:14:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:14:27 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:14:27 --> URI Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Router Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Output Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Security Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Input Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:14:27 --> Language Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Loader Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:14:27 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Session: Regenerate ID
DEBUG - 2015-02-10 18:14:27 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:14:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Controller Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:14:27 --> Email Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:14:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:14:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:14:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:14:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:14:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Config Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:14:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:14:28 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:14:28 --> URI Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Router Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Output Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Security Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Input Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:14:28 --> Language Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Loader Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:14:28 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:14:28 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:14:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Controller Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:14:28 --> Email Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:14:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:14:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:14:28 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:14:28 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:14:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:14:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:14:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:14:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:14:29 --> Final output sent to browser
DEBUG - 2015-02-10 18:14:29 --> Total execution time: 1.9322
DEBUG - 2015-02-10 18:14:29 --> Final output sent to browser
DEBUG - 2015-02-10 18:14:29 --> Total execution time: 1.3531
DEBUG - 2015-02-10 18:14:32 --> Config Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:14:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:14:32 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:14:32 --> URI Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Router Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Output Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Security Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Input Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:14:32 --> Language Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Loader Class Initialized
DEBUG - 2015-02-10 18:14:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:14:32 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:14:32 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:14:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:14:32 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:14:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:14:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Controller Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:14:33 --> Email Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:14:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:14:33 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:14:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:14:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:14:33 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:14:33 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:33 --> Final output sent to browser
DEBUG - 2015-02-10 18:14:33 --> Total execution time: 1.0301
DEBUG - 2015-02-10 18:14:39 --> Config Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:14:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:14:39 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:14:39 --> URI Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Router Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Output Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Security Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Input Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:14:39 --> Language Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Loader Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:14:39 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:14:39 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:14:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Controller Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:14:39 --> Email Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:14:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:14:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:14:39 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:14:39 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:14:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Final output sent to browser
DEBUG - 2015-02-10 18:14:40 --> Total execution time: 0.8471
DEBUG - 2015-02-10 18:14:40 --> Config Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:14:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:14:40 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:14:40 --> URI Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Router Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Output Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Security Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Input Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:14:40 --> Language Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Loader Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:14:40 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:14:40 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:14:40 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Controller Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:14:40 --> Email Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:14:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:14:40 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:14:40 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:14:40 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:40 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:41 --> Final output sent to browser
DEBUG - 2015-02-10 18:14:41 --> Total execution time: 0.8451
DEBUG - 2015-02-10 18:14:56 --> Config Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:14:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:14:56 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:14:56 --> URI Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Router Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Output Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Security Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Input Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:14:56 --> Language Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Loader Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:14:56 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:14:56 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:14:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Controller Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:14:56 --> Email Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:14:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:14:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:14:56 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:14:56 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:14:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:14:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:14:57 --> Final output sent to browser
DEBUG - 2015-02-10 18:14:57 --> Total execution time: 1.3561
DEBUG - 2015-02-10 18:15:01 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:01 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:01 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:01 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:02 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:02 --> Total execution time: 0.8931
DEBUG - 2015-02-10 18:15:10 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:10 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:10 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:10 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:10 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:10 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:10 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:10 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:10 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:11 --> Total execution time: 1.0051
DEBUG - 2015-02-10 18:15:11 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:11 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:11 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:11 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:11 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:11 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:11 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:11 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:11 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:11 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:11 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:11 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:12 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:12 --> Total execution time: 0.9341
DEBUG - 2015-02-10 18:15:32 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:32 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:32 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:32 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:32 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:32 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:32 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:32 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:33 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:33 --> Total execution time: 0.8901
DEBUG - 2015-02-10 18:15:36 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:36 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:36 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:36 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:36 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:36 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:36 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:36 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:36 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:36 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:37 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:37 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:15:37 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:37 --> Total execution time: 1.3401
DEBUG - 2015-02-10 18:15:38 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:38 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:38 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:38 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:38 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:38 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:38 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:38 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:39 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:39 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:39 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:39 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:39 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:39 --> Total execution time: 1.0361
DEBUG - 2015-02-10 18:15:42 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:42 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:42 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:42 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:42 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:42 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:42 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:42 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:42 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:42 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:42 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:42 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:43 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:15:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:15:43 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:43 --> Total execution time: 1.3691
DEBUG - 2015-02-10 18:15:45 --> Config Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:15:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:15:45 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:15:45 --> URI Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Router Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Output Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Security Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Input Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:15:45 --> Language Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Loader Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:15:45 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:15:45 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:15:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Controller Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:15:45 --> Email Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:15:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:15:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:15:45 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:15:45 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:15:46 --> Final output sent to browser
DEBUG - 2015-02-10 18:15:46 --> Total execution time: 0.9731
DEBUG - 2015-02-10 18:16:00 --> Config Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:16:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:16:00 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:16:00 --> URI Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Router Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Output Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Security Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Input Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:16:00 --> Language Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Loader Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:16:00 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:16:00 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:16:00 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Controller Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:16:00 --> Email Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:16:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:16:00 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:16:00 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:16:00 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Final output sent to browser
DEBUG - 2015-02-10 18:16:01 --> Total execution time: 0.9391
DEBUG - 2015-02-10 18:16:01 --> Config Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:16:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:16:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:16:01 --> URI Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Router Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Output Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Security Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Input Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:16:01 --> Language Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Loader Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:16:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:16:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:16:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Controller Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:16:01 --> Email Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:16:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:16:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:16:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:16:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:02 --> Final output sent to browser
DEBUG - 2015-02-10 18:16:02 --> Total execution time: 0.9931
DEBUG - 2015-02-10 18:16:16 --> Config Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:16:16 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:16:16 --> URI Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Router Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Output Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Security Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Input Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:16:16 --> Language Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Loader Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:16:16 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:16:16 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:16:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Controller Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:16:16 --> Email Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:16:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:16:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:16:16 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:16:16 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:16 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:17 --> Final output sent to browser
DEBUG - 2015-02-10 18:16:17 --> Total execution time: 1.0871
DEBUG - 2015-02-10 18:16:29 --> Config Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:16:29 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:16:29 --> URI Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Router Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Output Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Security Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Input Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:16:29 --> Language Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Loader Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:16:29 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:16:29 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:16:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Controller Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:16:29 --> Email Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:16:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:16:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:16:29 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:16:29 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:16:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:16:30 --> Final output sent to browser
DEBUG - 2015-02-10 18:16:30 --> Total execution time: 1.5872
DEBUG - 2015-02-10 18:16:31 --> Config Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:16:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:16:31 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:16:31 --> URI Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Router Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Output Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Security Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Input Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:16:31 --> Language Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Loader Class Initialized
DEBUG - 2015-02-10 18:16:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:16:31 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:16:31 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:16:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:16:31 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:16:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:16:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Controller Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:16:32 --> Email Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:16:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:16:32 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:16:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:16:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:16:32 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:16:32 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:16:33 --> Final output sent to browser
DEBUG - 2015-02-10 18:16:33 --> Total execution time: 1.0791
DEBUG - 2015-02-10 18:17:01 --> Config Class Initialized
DEBUG - 2015-02-10 18:17:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:17:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:17:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:17:01 --> URI Class Initialized
DEBUG - 2015-02-10 18:17:01 --> Router Class Initialized
DEBUG - 2015-02-10 18:17:01 --> Output Class Initialized
DEBUG - 2015-02-10 18:17:01 --> Security Class Initialized
DEBUG - 2015-02-10 18:17:01 --> Input Class Initialized
DEBUG - 2015-02-10 18:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:17:02 --> Language Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Loader Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:17:02 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:17:02 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:17:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Controller Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:17:02 --> Email Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:17:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:17:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:17:02 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:17:02 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:02 --> Final output sent to browser
DEBUG - 2015-02-10 18:17:02 --> Total execution time: 0.8761
DEBUG - 2015-02-10 18:17:18 --> Config Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:17:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:17:18 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:17:18 --> URI Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Router Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Output Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Security Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Input Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:17:18 --> Language Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Loader Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:17:18 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:17:18 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:17:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Controller Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:17:18 --> Email Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:17:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:17:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:17:18 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:17:18 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:17:18 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Final output sent to browser
DEBUG - 2015-02-10 18:17:19 --> Total execution time: 0.9061
DEBUG - 2015-02-10 18:17:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:17:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:17:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:17:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:17:19 --> Language Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Loader Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:17:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:17:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:17:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Controller Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:17:19 --> Email Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:17:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:17:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:17:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:17:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:20 --> Final output sent to browser
DEBUG - 2015-02-10 18:17:20 --> Total execution time: 0.8941
DEBUG - 2015-02-10 18:17:32 --> Config Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:17:32 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:17:32 --> URI Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Router Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Output Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Security Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Input Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:17:32 --> Language Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Loader Class Initialized
DEBUG - 2015-02-10 18:17:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:17:32 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:17:32 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:17:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:17:32 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:17:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:17:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Controller Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:17:33 --> Email Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:17:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:17:33 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:17:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:17:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:17:33 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:17:33 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:33 --> Final output sent to browser
DEBUG - 2015-02-10 18:17:33 --> Total execution time: 0.9331
DEBUG - 2015-02-10 18:17:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:17:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:17:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:17:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:17:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:17:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:17:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:17:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:17:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:17:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:17:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:17:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:17:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:17:50 --> Final output sent to browser
DEBUG - 2015-02-10 18:17:50 --> Total execution time: 0.9031
DEBUG - 2015-02-10 18:18:02 --> Config Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:18:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:18:02 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:18:02 --> URI Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Router Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Output Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Security Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Input Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:18:02 --> Language Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Loader Class Initialized
DEBUG - 2015-02-10 18:18:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:18:02 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:18:02 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:18:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:18:02 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:18:02 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:18:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Controller Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:18:03 --> Email Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:18:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:18:03 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:18:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:18:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:18:03 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:18:03 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:03 --> Final output sent to browser
DEBUG - 2015-02-10 18:18:03 --> Total execution time: 0.9141
DEBUG - 2015-02-10 18:18:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:18:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:18:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:18:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:18:19 --> Language Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Loader Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:18:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:18:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:18:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Controller Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:18:19 --> Email Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:18:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:18:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:18:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:18:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:20 --> Final output sent to browser
DEBUG - 2015-02-10 18:18:20 --> Total execution time: 0.8381
DEBUG - 2015-02-10 18:18:32 --> Config Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:18:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:18:32 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:18:32 --> URI Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Router Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Output Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Security Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Input Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:18:32 --> Language Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Loader Class Initialized
DEBUG - 2015-02-10 18:18:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:18:32 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:18:32 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:18:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:18:32 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:18:32 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:18:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Controller Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:18:33 --> Email Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:18:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:18:33 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:18:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:18:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:18:33 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:18:33 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:33 --> Final output sent to browser
DEBUG - 2015-02-10 18:18:33 --> Total execution time: 0.8781
DEBUG - 2015-02-10 18:18:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:18:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:18:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:18:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:18:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:18:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:18:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:18:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:18:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:18:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:18:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:18:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:18:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:50 --> Final output sent to browser
DEBUG - 2015-02-10 18:18:50 --> Total execution time: 0.8621
DEBUG - 2015-02-10 18:18:57 --> Config Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:18:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:18:57 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:18:57 --> URI Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Router Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Output Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Security Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Input Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:18:57 --> Language Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Loader Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:18:57 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:18:57 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:18:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Controller Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:18:57 --> Email Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:18:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:18:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:18:57 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:18:57 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:18:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:58 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:18:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:18:58 --> Final output sent to browser
DEBUG - 2015-02-10 18:18:58 --> Total execution time: 1.3581
DEBUG - 2015-02-10 18:18:59 --> Config Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:18:59 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:18:59 --> URI Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Router Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Output Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Security Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Input Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:18:59 --> Language Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Loader Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:18:59 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:18:59 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:18:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Controller Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:18:59 --> Email Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:18:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:18:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:18:59 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:18:59 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:18:59 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:00 --> Final output sent to browser
DEBUG - 2015-02-10 18:19:00 --> Total execution time: 1.0131
DEBUG - 2015-02-10 18:19:21 --> Config Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:19:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:19:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:19:21 --> URI Class Initialized
DEBUG - 2015-02-10 18:19:21 --> No URI present. Default controller set.
DEBUG - 2015-02-10 18:19:21 --> Router Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Output Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Security Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Input Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:19:21 --> Language Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Loader Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:19:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:19:21 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:19:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Controller Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:19:21 --> Email Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:19:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:19:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:19:21 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:19:21 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 18:19:21 --> Pagination Class Initialized
DEBUG - 2015-02-10 18:19:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:22 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:19:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:19:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 18:19:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:19:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:19:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:19:22 --> Final output sent to browser
DEBUG - 2015-02-10 18:19:22 --> Total execution time: 1.3631
DEBUG - 2015-02-10 18:19:27 --> Config Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:19:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:19:27 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:19:27 --> URI Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Router Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Output Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Security Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Input Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:19:27 --> Language Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Loader Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:19:27 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:19:27 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:19:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Controller Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:19:27 --> Email Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:19:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:19:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:19:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:19:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:19:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-10 18:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-10 18:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-10 18:19:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-10 18:19:27 --> Final output sent to browser
DEBUG - 2015-02-10 18:19:27 --> Total execution time: 0.5401
DEBUG - 2015-02-10 18:19:30 --> Config Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:19:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:19:30 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:19:30 --> URI Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Router Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Output Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Security Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Input Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:19:30 --> Language Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Loader Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:19:30 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Session: Regenerate ID
DEBUG - 2015-02-10 18:19:30 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:19:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Controller Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:19:30 --> Email Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:19:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:19:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:19:30 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:19:30 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:19:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-10 18:19:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-10 18:19:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-10 18:19:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-10 18:19:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-10 18:19:31 --> Final output sent to browser
DEBUG - 2015-02-10 18:19:31 --> Total execution time: 0.6221
DEBUG - 2015-02-10 18:19:56 --> Config Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:19:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:19:56 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:19:56 --> URI Class Initialized
DEBUG - 2015-02-10 18:19:56 --> No URI present. Default controller set.
DEBUG - 2015-02-10 18:19:56 --> Router Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Output Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Security Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Input Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:19:56 --> Language Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Loader Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:19:56 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:19:56 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:19:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Controller Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:19:56 --> Email Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:19:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:19:56 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:19:56 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:19:56 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:19:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-10 18:19:57 --> Pagination Class Initialized
DEBUG - 2015-02-10 18:19:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:57 --> Model Class Initialized
DEBUG - 2015-02-10 18:19:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:19:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:19:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-10 18:19:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:19:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:19:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:19:58 --> Final output sent to browser
DEBUG - 2015-02-10 18:19:58 --> Total execution time: 1.3091
DEBUG - 2015-02-10 18:20:01 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:01 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:01 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:01 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:01 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:01 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:01 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:01 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:01 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:01 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:09 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:09 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:09 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:09 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:09 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:09 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:09 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:09 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\tag/view.php
DEBUG - 2015-02-10 18:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:20:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:20:10 --> Final output sent to browser
DEBUG - 2015-02-10 18:20:10 --> Total execution time: 1.2971
DEBUG - 2015-02-10 18:20:20 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:20 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:20 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:20 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:20 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:20 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:20 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:20 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:20 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:21 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:20:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:20:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:20:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:20:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:20:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:20:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:20:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:20:22 --> Final output sent to browser
DEBUG - 2015-02-10 18:20:22 --> Total execution time: 1.4341
DEBUG - 2015-02-10 18:20:22 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:22 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:22 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:22 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:22 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:22 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:22 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:22 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:22 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:22 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:22 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:22 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:23 --> Final output sent to browser
DEBUG - 2015-02-10 18:20:23 --> Total execution time: 1.0571
DEBUG - 2015-02-10 18:20:30 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:30 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:30 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:30 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:30 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:30 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:30 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:30 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:30 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:30 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Final output sent to browser
DEBUG - 2015-02-10 18:20:31 --> Total execution time: 0.8401
DEBUG - 2015-02-10 18:20:31 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:31 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:31 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:31 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:31 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:31 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:31 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:31 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:31 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:32 --> Final output sent to browser
DEBUG - 2015-02-10 18:20:32 --> Total execution time: 0.8701
DEBUG - 2015-02-10 18:20:49 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:49 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:49 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:49 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:49 --> Final output sent to browser
DEBUG - 2015-02-10 18:20:49 --> Total execution time: 0.8681
DEBUG - 2015-02-10 18:20:50 --> Config Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:20:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:20:50 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:20:50 --> URI Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Router Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Output Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Security Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Input Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:20:50 --> Language Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Loader Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:20:50 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:20:50 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:20:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Controller Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:20:50 --> Email Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:20:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:20:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:20:50 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:20:50 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Model Class Initialized
DEBUG - 2015-02-10 18:20:50 --> Final output sent to browser
DEBUG - 2015-02-10 18:20:50 --> Total execution time: 0.9081
DEBUG - 2015-02-10 18:21:07 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:07 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:07 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:07 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:07 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:07 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:07 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:07 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:07 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:08 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:21:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:21:08 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:08 --> Total execution time: 1.6672
DEBUG - 2015-02-10 18:21:09 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:09 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:09 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:09 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:09 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:09 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:09 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:09 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:09 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:09 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:10 --> Total execution time: 0.9171
DEBUG - 2015-02-10 18:21:10 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:10 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:10 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:10 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:10 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:10 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:10 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:10 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:10 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:10 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:10 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:10 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:11 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:11 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:11 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:11 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:21:12 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:12 --> Total execution time: 1.3801
DEBUG - 2015-02-10 18:21:12 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:12 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:12 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:12 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:12 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:12 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:12 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:12 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:12 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:13 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:13 --> Total execution time: 0.9861
DEBUG - 2015-02-10 18:21:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:19 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:19 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:19 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:21:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:21:20 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:20 --> Total execution time: 1.3571
DEBUG - 2015-02-10 18:21:20 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:20 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:20 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:20 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:20 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:20 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:20 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:20 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:20 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:21 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:21 --> Total execution time: 0.9751
DEBUG - 2015-02-10 18:21:24 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:24 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:24 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:24 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:24 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:24 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:24 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:24 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:24 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:24 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:24 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:24 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:25 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:25 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:21:25 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:25 --> Total execution time: 1.4361
DEBUG - 2015-02-10 18:21:25 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:25 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:25 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:25 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:25 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:26 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:26 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:26 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:26 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:26 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:26 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:26 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:26 --> Total execution time: 0.8951
DEBUG - 2015-02-10 18:21:31 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:31 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:31 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:31 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:31 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:31 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:31 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:31 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:31 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:21:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:21:32 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:32 --> Total execution time: 1.3771
DEBUG - 2015-02-10 18:21:33 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:33 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:33 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:33 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:33 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:33 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:33 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:33 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:33 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:34 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:34 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:35 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:35 --> Total execution time: 1.3871
DEBUG - 2015-02-10 18:21:45 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:45 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:45 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:45 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:45 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:45 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:45 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:45 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:45 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:45 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:21:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/commentjs.php
DEBUG - 2015-02-10 18:21:46 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:46 --> Total execution time: 1.3431
DEBUG - 2015-02-10 18:21:46 --> Config Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:21:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:21:46 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:21:46 --> URI Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Router Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Output Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Security Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Input Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:21:46 --> Language Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Loader Class Initialized
DEBUG - 2015-02-10 18:21:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:21:46 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:21:46 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:21:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:21:46 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:21:46 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:21:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Controller Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:21:47 --> Email Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:21:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:21:47 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:21:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:21:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:21:47 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:21:47 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Model Class Initialized
DEBUG - 2015-02-10 18:21:47 --> Final output sent to browser
DEBUG - 2015-02-10 18:21:47 --> Total execution time: 0.9531
DEBUG - 2015-02-10 18:22:07 --> Config Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:22:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:22:07 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:22:07 --> URI Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Router Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Output Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Security Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Input Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:22:07 --> Language Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Loader Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:22:07 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:22:07 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Controller Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:22:07 --> Email Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:22:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:22:07 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:22:07 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:22:07 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Config Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:22:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:22:12 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:22:12 --> URI Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Router Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Output Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Security Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Input Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:22:12 --> Language Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Loader Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:22:12 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:22:12 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:22:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Controller Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:22:12 --> Email Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:22:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:22:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:22:12 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:22:12 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:22:12 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:13 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:13 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:22:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:22:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 18:22:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:22:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:22:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:22:13 --> Final output sent to browser
DEBUG - 2015-02-10 18:22:13 --> Total execution time: 1.3141
DEBUG - 2015-02-10 18:22:19 --> Config Class Initialized
DEBUG - 2015-02-10 18:22:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:22:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:22:19 --> URI Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Router Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Output Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Security Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Input Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:22:20 --> Language Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Loader Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:22:20 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:22:20 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:22:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Controller Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:22:20 --> Email Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:22:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:22:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:22:20 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:22:20 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:20 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:22:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:22:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 18:22:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:22:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:22:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:22:21 --> Final output sent to browser
DEBUG - 2015-02-10 18:22:21 --> Total execution time: 1.3111
DEBUG - 2015-02-10 18:22:27 --> Config Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:22:27 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:22:27 --> URI Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Router Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Output Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Security Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Input Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:22:27 --> Language Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Loader Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:22:27 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:22:27 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:22:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Controller Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:22:27 --> Email Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:22:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:22:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:22:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:22:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:22:27 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:28 --> Model Class Initialized
DEBUG - 2015-02-10 18:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 18:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:22:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:22:28 --> Final output sent to browser
DEBUG - 2015-02-10 18:22:28 --> Total execution time: 1.2671
DEBUG - 2015-02-10 18:37:29 --> Config Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:37:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:37:29 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:37:29 --> URI Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Router Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Output Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Security Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Input Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:37:29 --> Language Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Loader Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:37:29 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Session: Regenerate ID
DEBUG - 2015-02-10 18:37:29 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:37:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Controller Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:37:29 --> Email Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:37:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:37:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:37:29 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:37:29 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:37:29 --> Model Class Initialized
DEBUG - 2015-02-10 18:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 18:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:37:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:37:30 --> Final output sent to browser
DEBUG - 2015-02-10 18:37:30 --> Total execution time: 1.1721
DEBUG - 2015-02-10 18:52:31 --> Config Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Hooks Class Initialized
DEBUG - 2015-02-10 18:52:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 18:52:31 --> Utf8 Class Initialized
DEBUG - 2015-02-10 18:52:31 --> URI Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Router Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Output Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Security Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Input Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 18:52:31 --> Language Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Loader Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: url_helper
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: link_helper
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 18:52:31 --> CI_Session Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Session: Regenerate ID
DEBUG - 2015-02-10 18:52:31 --> CI_Session routines successfully run
DEBUG - 2015-02-10 18:52:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Controller Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 18:52:31 --> Email Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: language_helper
DEBUG - 2015-02-10 18:52:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 18:52:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Database Driver Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: date_helper
DEBUG - 2015-02-10 18:52:31 --> Helper loaded: form_helper
DEBUG - 2015-02-10 18:52:31 --> Form Validation Class Initialized
DEBUG - 2015-02-10 18:52:31 --> Model Class Initialized
DEBUG - 2015-02-10 18:52:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:52:32 --> Model Class Initialized
DEBUG - 2015-02-10 18:52:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 18:52:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 18:52:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 18:52:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 18:52:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 18:52:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 18:52:32 --> Final output sent to browser
DEBUG - 2015-02-10 18:52:32 --> Total execution time: 1.2361
DEBUG - 2015-02-10 19:07:34 --> Config Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Hooks Class Initialized
DEBUG - 2015-02-10 19:07:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 19:07:34 --> Utf8 Class Initialized
DEBUG - 2015-02-10 19:07:34 --> URI Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Router Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Output Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Security Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Input Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 19:07:34 --> Language Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Loader Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: url_helper
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: link_helper
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 19:07:34 --> CI_Session Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Session: Regenerate ID
DEBUG - 2015-02-10 19:07:34 --> CI_Session routines successfully run
DEBUG - 2015-02-10 19:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Controller Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 19:07:34 --> Email Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: language_helper
DEBUG - 2015-02-10 19:07:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 19:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Database Driver Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: date_helper
DEBUG - 2015-02-10 19:07:34 --> Helper loaded: form_helper
DEBUG - 2015-02-10 19:07:34 --> Form Validation Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 19:07:34 --> Model Class Initialized
DEBUG - 2015-02-10 19:07:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 19:07:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 19:07:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 19:07:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 19:07:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 19:07:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 19:07:35 --> Final output sent to browser
DEBUG - 2015-02-10 19:07:35 --> Total execution time: 1.1781
DEBUG - 2015-02-10 19:22:36 --> Config Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Hooks Class Initialized
DEBUG - 2015-02-10 19:22:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 19:22:36 --> Utf8 Class Initialized
DEBUG - 2015-02-10 19:22:36 --> URI Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Router Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Output Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Security Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Input Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 19:22:36 --> Language Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Loader Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 19:22:36 --> Helper loaded: url_helper
DEBUG - 2015-02-10 19:22:36 --> Helper loaded: link_helper
DEBUG - 2015-02-10 19:22:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 19:22:36 --> CI_Session Class Initialized
DEBUG - 2015-02-10 19:22:36 --> Session: Regenerate ID
DEBUG - 2015-02-10 19:22:36 --> CI_Session routines successfully run
DEBUG - 2015-02-10 19:22:37 --> Model Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Model Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Controller Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 19:22:37 --> Email Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 19:22:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 19:22:37 --> Helper loaded: language_helper
DEBUG - 2015-02-10 19:22:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 19:22:37 --> Model Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Database Driver Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Helper loaded: date_helper
DEBUG - 2015-02-10 19:22:37 --> Helper loaded: form_helper
DEBUG - 2015-02-10 19:22:37 --> Form Validation Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Model Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Model Class Initialized
DEBUG - 2015-02-10 19:22:37 --> Model Class Initialized
DEBUG - 2015-02-10 19:22:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 19:22:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 19:22:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 19:22:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 19:22:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 19:22:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 19:22:38 --> Final output sent to browser
DEBUG - 2015-02-10 19:22:38 --> Total execution time: 1.1751
DEBUG - 2015-02-10 19:37:39 --> Config Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Hooks Class Initialized
DEBUG - 2015-02-10 19:37:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 19:37:39 --> Utf8 Class Initialized
DEBUG - 2015-02-10 19:37:39 --> URI Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Router Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Output Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Security Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Input Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 19:37:39 --> Language Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Loader Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: url_helper
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: link_helper
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 19:37:39 --> CI_Session Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Session: Regenerate ID
DEBUG - 2015-02-10 19:37:39 --> CI_Session routines successfully run
DEBUG - 2015-02-10 19:37:39 --> Model Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Model Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Controller Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 19:37:39 --> Email Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: language_helper
DEBUG - 2015-02-10 19:37:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 19:37:39 --> Model Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Database Driver Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: date_helper
DEBUG - 2015-02-10 19:37:39 --> Helper loaded: form_helper
DEBUG - 2015-02-10 19:37:39 --> Form Validation Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Model Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Model Class Initialized
DEBUG - 2015-02-10 19:37:39 --> Model Class Initialized
DEBUG - 2015-02-10 19:37:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 19:37:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 19:37:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 19:37:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 19:37:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 19:37:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 19:37:40 --> Final output sent to browser
DEBUG - 2015-02-10 19:37:40 --> Total execution time: 1.1821
DEBUG - 2015-02-10 19:52:41 --> Config Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Hooks Class Initialized
DEBUG - 2015-02-10 19:52:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 19:52:41 --> Utf8 Class Initialized
DEBUG - 2015-02-10 19:52:41 --> URI Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Router Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Output Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Security Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Input Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 19:52:41 --> Language Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Loader Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: url_helper
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: link_helper
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 19:52:41 --> CI_Session Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Session: Regenerate ID
DEBUG - 2015-02-10 19:52:41 --> CI_Session routines successfully run
DEBUG - 2015-02-10 19:52:41 --> Model Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Model Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Controller Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 19:52:41 --> Email Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: language_helper
DEBUG - 2015-02-10 19:52:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 19:52:41 --> Model Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Database Driver Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: date_helper
DEBUG - 2015-02-10 19:52:41 --> Helper loaded: form_helper
DEBUG - 2015-02-10 19:52:41 --> Form Validation Class Initialized
DEBUG - 2015-02-10 19:52:41 --> Model Class Initialized
DEBUG - 2015-02-10 19:52:42 --> Model Class Initialized
DEBUG - 2015-02-10 19:52:42 --> Model Class Initialized
DEBUG - 2015-02-10 19:52:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 19:52:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 19:52:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 19:52:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 19:52:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 19:52:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 19:52:42 --> Final output sent to browser
DEBUG - 2015-02-10 19:52:42 --> Total execution time: 1.1651
DEBUG - 2015-02-10 20:07:43 --> Config Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Hooks Class Initialized
DEBUG - 2015-02-10 20:07:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 20:07:43 --> Utf8 Class Initialized
DEBUG - 2015-02-10 20:07:43 --> URI Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Router Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Output Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Security Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Input Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 20:07:43 --> Language Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Loader Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 20:07:43 --> Helper loaded: url_helper
DEBUG - 2015-02-10 20:07:43 --> Helper loaded: link_helper
DEBUG - 2015-02-10 20:07:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 20:07:43 --> CI_Session Class Initialized
DEBUG - 2015-02-10 20:07:43 --> Session: Regenerate ID
DEBUG - 2015-02-10 20:07:43 --> CI_Session routines successfully run
DEBUG - 2015-02-10 20:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Controller Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 20:07:44 --> Email Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 20:07:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 20:07:44 --> Helper loaded: language_helper
DEBUG - 2015-02-10 20:07:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 20:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Database Driver Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Helper loaded: date_helper
DEBUG - 2015-02-10 20:07:44 --> Helper loaded: form_helper
DEBUG - 2015-02-10 20:07:44 --> Form Validation Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 20:07:44 --> Model Class Initialized
DEBUG - 2015-02-10 20:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 20:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 20:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 20:07:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 20:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 20:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 20:07:45 --> Final output sent to browser
DEBUG - 2015-02-10 20:07:45 --> Total execution time: 1.1451
DEBUG - 2015-02-10 20:22:46 --> Config Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Hooks Class Initialized
DEBUG - 2015-02-10 20:22:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 20:22:46 --> Utf8 Class Initialized
DEBUG - 2015-02-10 20:22:46 --> URI Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Router Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Output Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Security Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Input Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 20:22:46 --> Language Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Loader Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: url_helper
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: link_helper
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 20:22:46 --> CI_Session Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Session: Regenerate ID
DEBUG - 2015-02-10 20:22:46 --> CI_Session routines successfully run
DEBUG - 2015-02-10 20:22:46 --> Model Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Model Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Controller Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 20:22:46 --> Email Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: language_helper
DEBUG - 2015-02-10 20:22:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 20:22:46 --> Model Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Database Driver Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: date_helper
DEBUG - 2015-02-10 20:22:46 --> Helper loaded: form_helper
DEBUG - 2015-02-10 20:22:46 --> Form Validation Class Initialized
DEBUG - 2015-02-10 20:22:46 --> Model Class Initialized
DEBUG - 2015-02-10 20:22:47 --> Model Class Initialized
DEBUG - 2015-02-10 20:22:47 --> Model Class Initialized
DEBUG - 2015-02-10 20:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 20:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 20:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 20:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 20:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 20:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 20:22:47 --> Final output sent to browser
DEBUG - 2015-02-10 20:22:47 --> Total execution time: 1.1601
DEBUG - 2015-02-10 20:37:48 --> Config Class Initialized
DEBUG - 2015-02-10 20:37:48 --> Hooks Class Initialized
DEBUG - 2015-02-10 20:37:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 20:37:49 --> Utf8 Class Initialized
DEBUG - 2015-02-10 20:37:49 --> URI Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Router Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Output Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Security Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Input Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 20:37:49 --> Language Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Loader Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: url_helper
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: link_helper
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 20:37:49 --> CI_Session Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Session: Regenerate ID
DEBUG - 2015-02-10 20:37:49 --> CI_Session routines successfully run
DEBUG - 2015-02-10 20:37:49 --> Model Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Model Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Controller Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 20:37:49 --> Email Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: language_helper
DEBUG - 2015-02-10 20:37:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 20:37:49 --> Model Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Database Driver Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: date_helper
DEBUG - 2015-02-10 20:37:49 --> Helper loaded: form_helper
DEBUG - 2015-02-10 20:37:49 --> Form Validation Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Model Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Model Class Initialized
DEBUG - 2015-02-10 20:37:49 --> Model Class Initialized
DEBUG - 2015-02-10 20:37:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 20:37:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 20:37:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 20:37:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 20:37:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 20:37:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 20:37:50 --> Final output sent to browser
DEBUG - 2015-02-10 20:37:50 --> Total execution time: 1.1441
DEBUG - 2015-02-10 20:52:51 --> Config Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Hooks Class Initialized
DEBUG - 2015-02-10 20:52:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 20:52:51 --> Utf8 Class Initialized
DEBUG - 2015-02-10 20:52:51 --> URI Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Router Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Output Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Security Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Input Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 20:52:51 --> Language Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Loader Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: url_helper
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: link_helper
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 20:52:51 --> CI_Session Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Session: Regenerate ID
DEBUG - 2015-02-10 20:52:51 --> CI_Session routines successfully run
DEBUG - 2015-02-10 20:52:51 --> Model Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Model Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Controller Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 20:52:51 --> Email Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: language_helper
DEBUG - 2015-02-10 20:52:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 20:52:51 --> Model Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Database Driver Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: date_helper
DEBUG - 2015-02-10 20:52:51 --> Helper loaded: form_helper
DEBUG - 2015-02-10 20:52:51 --> Form Validation Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Model Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Model Class Initialized
DEBUG - 2015-02-10 20:52:51 --> Model Class Initialized
DEBUG - 2015-02-10 20:52:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 20:52:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 20:52:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 20:52:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 20:52:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 20:52:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 20:52:52 --> Final output sent to browser
DEBUG - 2015-02-10 20:52:52 --> Total execution time: 1.1731
DEBUG - 2015-02-10 21:07:54 --> Config Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Hooks Class Initialized
DEBUG - 2015-02-10 21:07:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 21:07:54 --> Utf8 Class Initialized
DEBUG - 2015-02-10 21:07:54 --> URI Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Router Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Output Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Security Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Input Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 21:07:54 --> Language Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Loader Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 21:07:54 --> Helper loaded: url_helper
DEBUG - 2015-02-10 21:07:54 --> Helper loaded: link_helper
DEBUG - 2015-02-10 21:07:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 21:07:54 --> CI_Session Class Initialized
DEBUG - 2015-02-10 21:07:54 --> Session: Regenerate ID
DEBUG - 2015-02-10 21:07:54 --> CI_Session routines successfully run
DEBUG - 2015-02-10 21:07:55 --> Model Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Model Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Controller Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 21:07:55 --> Email Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 21:07:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 21:07:55 --> Helper loaded: language_helper
DEBUG - 2015-02-10 21:07:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 21:07:55 --> Model Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Database Driver Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Helper loaded: date_helper
DEBUG - 2015-02-10 21:07:55 --> Helper loaded: form_helper
DEBUG - 2015-02-10 21:07:55 --> Form Validation Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Model Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Model Class Initialized
DEBUG - 2015-02-10 21:07:55 --> Model Class Initialized
DEBUG - 2015-02-10 21:07:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 21:07:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 21:07:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 21:07:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 21:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 21:07:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 21:07:56 --> Final output sent to browser
DEBUG - 2015-02-10 21:07:56 --> Total execution time: 1.1381
DEBUG - 2015-02-10 21:22:57 --> Config Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Hooks Class Initialized
DEBUG - 2015-02-10 21:22:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 21:22:57 --> Utf8 Class Initialized
DEBUG - 2015-02-10 21:22:57 --> URI Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Router Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Output Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Security Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Input Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 21:22:57 --> Language Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Loader Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: url_helper
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: link_helper
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 21:22:57 --> CI_Session Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Session: Regenerate ID
DEBUG - 2015-02-10 21:22:57 --> CI_Session routines successfully run
DEBUG - 2015-02-10 21:22:57 --> Model Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Model Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Controller Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 21:22:57 --> Email Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: language_helper
DEBUG - 2015-02-10 21:22:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 21:22:57 --> Model Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Database Driver Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: date_helper
DEBUG - 2015-02-10 21:22:57 --> Helper loaded: form_helper
DEBUG - 2015-02-10 21:22:57 --> Form Validation Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Model Class Initialized
DEBUG - 2015-02-10 21:22:57 --> Model Class Initialized
DEBUG - 2015-02-10 21:22:58 --> Model Class Initialized
DEBUG - 2015-02-10 21:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 21:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 21:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 21:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 21:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 21:22:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 21:22:58 --> Final output sent to browser
DEBUG - 2015-02-10 21:22:58 --> Total execution time: 1.1781
DEBUG - 2015-02-10 21:37:59 --> Config Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Hooks Class Initialized
DEBUG - 2015-02-10 21:37:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 21:37:59 --> Utf8 Class Initialized
DEBUG - 2015-02-10 21:37:59 --> URI Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Router Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Output Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Security Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Input Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 21:37:59 --> Language Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Loader Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 21:37:59 --> Helper loaded: url_helper
DEBUG - 2015-02-10 21:37:59 --> Helper loaded: link_helper
DEBUG - 2015-02-10 21:37:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 21:37:59 --> CI_Session Class Initialized
DEBUG - 2015-02-10 21:37:59 --> Session: Regenerate ID
DEBUG - 2015-02-10 21:37:59 --> CI_Session routines successfully run
DEBUG - 2015-02-10 21:38:00 --> Model Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Model Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Controller Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 21:38:00 --> Email Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 21:38:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 21:38:00 --> Helper loaded: language_helper
DEBUG - 2015-02-10 21:38:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 21:38:00 --> Model Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Database Driver Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Helper loaded: date_helper
DEBUG - 2015-02-10 21:38:00 --> Helper loaded: form_helper
DEBUG - 2015-02-10 21:38:00 --> Form Validation Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Model Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Model Class Initialized
DEBUG - 2015-02-10 21:38:00 --> Model Class Initialized
DEBUG - 2015-02-10 21:38:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 21:38:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 21:38:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 21:38:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 21:38:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 21:38:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 21:38:01 --> Final output sent to browser
DEBUG - 2015-02-10 21:38:01 --> Total execution time: 1.2161
DEBUG - 2015-02-10 21:53:02 --> Config Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Hooks Class Initialized
DEBUG - 2015-02-10 21:53:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 21:53:02 --> Utf8 Class Initialized
DEBUG - 2015-02-10 21:53:02 --> URI Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Router Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Output Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Security Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Input Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 21:53:02 --> Language Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Loader Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: url_helper
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: link_helper
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 21:53:02 --> CI_Session Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Session: Regenerate ID
DEBUG - 2015-02-10 21:53:02 --> CI_Session routines successfully run
DEBUG - 2015-02-10 21:53:02 --> Model Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Model Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Controller Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 21:53:02 --> Email Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: language_helper
DEBUG - 2015-02-10 21:53:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 21:53:02 --> Model Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Database Driver Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: date_helper
DEBUG - 2015-02-10 21:53:02 --> Helper loaded: form_helper
DEBUG - 2015-02-10 21:53:02 --> Form Validation Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Model Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Model Class Initialized
DEBUG - 2015-02-10 21:53:02 --> Model Class Initialized
DEBUG - 2015-02-10 21:53:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 21:53:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 21:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 21:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 21:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 21:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 21:53:03 --> Final output sent to browser
DEBUG - 2015-02-10 21:53:03 --> Total execution time: 1.2311
DEBUG - 2015-02-10 22:08:04 --> Config Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Hooks Class Initialized
DEBUG - 2015-02-10 22:08:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 22:08:04 --> Utf8 Class Initialized
DEBUG - 2015-02-10 22:08:04 --> URI Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Router Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Output Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Security Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Input Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 22:08:04 --> Language Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Loader Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: url_helper
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: link_helper
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 22:08:04 --> CI_Session Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Session: Regenerate ID
DEBUG - 2015-02-10 22:08:04 --> CI_Session routines successfully run
DEBUG - 2015-02-10 22:08:04 --> Model Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Model Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Controller Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 22:08:04 --> Email Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: language_helper
DEBUG - 2015-02-10 22:08:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 22:08:04 --> Model Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Database Driver Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: date_helper
DEBUG - 2015-02-10 22:08:04 --> Helper loaded: form_helper
DEBUG - 2015-02-10 22:08:04 --> Form Validation Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Model Class Initialized
DEBUG - 2015-02-10 22:08:04 --> Model Class Initialized
DEBUG - 2015-02-10 22:08:05 --> Model Class Initialized
DEBUG - 2015-02-10 22:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 22:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 22:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 22:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 22:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 22:08:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 22:08:05 --> Final output sent to browser
DEBUG - 2015-02-10 22:08:05 --> Total execution time: 1.1791
DEBUG - 2015-02-10 22:23:06 --> Config Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Hooks Class Initialized
DEBUG - 2015-02-10 22:23:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 22:23:06 --> Utf8 Class Initialized
DEBUG - 2015-02-10 22:23:06 --> URI Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Router Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Output Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Security Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Input Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 22:23:06 --> Language Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Loader Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: url_helper
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: link_helper
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 22:23:06 --> CI_Session Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Session: Regenerate ID
DEBUG - 2015-02-10 22:23:06 --> CI_Session routines successfully run
DEBUG - 2015-02-10 22:23:06 --> Model Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Model Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Controller Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 22:23:06 --> Email Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: language_helper
DEBUG - 2015-02-10 22:23:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 22:23:06 --> Model Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Database Driver Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: date_helper
DEBUG - 2015-02-10 22:23:06 --> Helper loaded: form_helper
DEBUG - 2015-02-10 22:23:06 --> Form Validation Class Initialized
DEBUG - 2015-02-10 22:23:06 --> Model Class Initialized
DEBUG - 2015-02-10 22:23:07 --> Model Class Initialized
DEBUG - 2015-02-10 22:23:07 --> Model Class Initialized
DEBUG - 2015-02-10 22:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 22:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 22:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 22:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 22:23:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 22:23:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 22:23:08 --> Final output sent to browser
DEBUG - 2015-02-10 22:23:08 --> Total execution time: 1.2381
DEBUG - 2015-02-10 22:38:16 --> Config Class Initialized
DEBUG - 2015-02-10 22:38:16 --> Hooks Class Initialized
DEBUG - 2015-02-10 22:38:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 22:38:16 --> Utf8 Class Initialized
DEBUG - 2015-02-10 22:38:17 --> URI Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Router Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Output Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Security Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Input Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 22:38:17 --> Language Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Loader Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: url_helper
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: link_helper
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 22:38:17 --> CI_Session Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Session: Regenerate ID
DEBUG - 2015-02-10 22:38:17 --> CI_Session routines successfully run
DEBUG - 2015-02-10 22:38:17 --> Model Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Model Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Controller Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 22:38:17 --> Email Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: language_helper
DEBUG - 2015-02-10 22:38:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 22:38:17 --> Model Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Database Driver Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: date_helper
DEBUG - 2015-02-10 22:38:17 --> Helper loaded: form_helper
DEBUG - 2015-02-10 22:38:17 --> Form Validation Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Model Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Model Class Initialized
DEBUG - 2015-02-10 22:38:17 --> Model Class Initialized
DEBUG - 2015-02-10 22:38:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 22:38:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 22:38:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 22:38:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 22:38:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 22:38:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 22:38:18 --> Final output sent to browser
DEBUG - 2015-02-10 22:38:18 --> Total execution time: 1.1471
DEBUG - 2015-02-10 22:53:19 --> Config Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Hooks Class Initialized
DEBUG - 2015-02-10 22:53:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 22:53:19 --> Utf8 Class Initialized
DEBUG - 2015-02-10 22:53:19 --> URI Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Router Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Output Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Security Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Input Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 22:53:19 --> Language Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Loader Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: url_helper
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: link_helper
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 22:53:19 --> CI_Session Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Session: Regenerate ID
DEBUG - 2015-02-10 22:53:19 --> CI_Session routines successfully run
DEBUG - 2015-02-10 22:53:19 --> Model Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Model Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Controller Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 22:53:19 --> Email Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: language_helper
DEBUG - 2015-02-10 22:53:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 22:53:19 --> Model Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Database Driver Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: date_helper
DEBUG - 2015-02-10 22:53:19 --> Helper loaded: form_helper
DEBUG - 2015-02-10 22:53:19 --> Form Validation Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Model Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Model Class Initialized
DEBUG - 2015-02-10 22:53:19 --> Model Class Initialized
DEBUG - 2015-02-10 22:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 22:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 22:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 22:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 22:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 22:53:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 22:53:20 --> Final output sent to browser
DEBUG - 2015-02-10 22:53:20 --> Total execution time: 1.2101
DEBUG - 2015-02-10 23:08:21 --> Config Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Hooks Class Initialized
DEBUG - 2015-02-10 23:08:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 23:08:21 --> Utf8 Class Initialized
DEBUG - 2015-02-10 23:08:21 --> URI Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Router Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Output Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Security Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Input Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 23:08:21 --> Language Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Loader Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: url_helper
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: link_helper
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 23:08:21 --> CI_Session Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Session: Regenerate ID
DEBUG - 2015-02-10 23:08:21 --> CI_Session routines successfully run
DEBUG - 2015-02-10 23:08:21 --> Model Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Model Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Controller Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 23:08:21 --> Email Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: language_helper
DEBUG - 2015-02-10 23:08:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 23:08:21 --> Model Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Database Driver Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: date_helper
DEBUG - 2015-02-10 23:08:21 --> Helper loaded: form_helper
DEBUG - 2015-02-10 23:08:21 --> Form Validation Class Initialized
DEBUG - 2015-02-10 23:08:21 --> Model Class Initialized
DEBUG - 2015-02-10 23:08:22 --> Model Class Initialized
DEBUG - 2015-02-10 23:08:22 --> Model Class Initialized
DEBUG - 2015-02-10 23:08:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 23:08:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 23:08:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 23:08:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 23:08:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 23:08:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 23:08:22 --> Final output sent to browser
DEBUG - 2015-02-10 23:08:22 --> Total execution time: 1.1471
DEBUG - 2015-02-10 23:23:23 --> Config Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Hooks Class Initialized
DEBUG - 2015-02-10 23:23:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 23:23:23 --> Utf8 Class Initialized
DEBUG - 2015-02-10 23:23:23 --> URI Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Router Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Output Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Security Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Input Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 23:23:23 --> Language Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Loader Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: url_helper
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: link_helper
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 23:23:23 --> CI_Session Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Session: Regenerate ID
DEBUG - 2015-02-10 23:23:23 --> CI_Session routines successfully run
DEBUG - 2015-02-10 23:23:23 --> Model Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Model Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Controller Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 23:23:23 --> Email Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: language_helper
DEBUG - 2015-02-10 23:23:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 23:23:23 --> Model Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Database Driver Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: date_helper
DEBUG - 2015-02-10 23:23:23 --> Helper loaded: form_helper
DEBUG - 2015-02-10 23:23:23 --> Form Validation Class Initialized
DEBUG - 2015-02-10 23:23:23 --> Model Class Initialized
DEBUG - 2015-02-10 23:23:24 --> Model Class Initialized
DEBUG - 2015-02-10 23:23:24 --> Model Class Initialized
DEBUG - 2015-02-10 23:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 23:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 23:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 23:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 23:23:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 23:23:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 23:23:25 --> Final output sent to browser
DEBUG - 2015-02-10 23:23:25 --> Total execution time: 1.1981
DEBUG - 2015-02-10 23:38:27 --> Config Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Hooks Class Initialized
DEBUG - 2015-02-10 23:38:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 23:38:27 --> Utf8 Class Initialized
DEBUG - 2015-02-10 23:38:27 --> URI Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Router Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Output Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Security Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Input Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 23:38:27 --> Language Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Loader Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: url_helper
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: link_helper
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 23:38:27 --> CI_Session Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Session: Regenerate ID
DEBUG - 2015-02-10 23:38:27 --> CI_Session routines successfully run
DEBUG - 2015-02-10 23:38:27 --> Model Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Model Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Controller Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 23:38:27 --> Email Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: language_helper
DEBUG - 2015-02-10 23:38:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 23:38:27 --> Model Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Database Driver Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: date_helper
DEBUG - 2015-02-10 23:38:27 --> Helper loaded: form_helper
DEBUG - 2015-02-10 23:38:27 --> Form Validation Class Initialized
DEBUG - 2015-02-10 23:38:27 --> Model Class Initialized
DEBUG - 2015-02-10 23:38:28 --> Model Class Initialized
DEBUG - 2015-02-10 23:38:28 --> Model Class Initialized
DEBUG - 2015-02-10 23:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 23:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 23:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 23:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 23:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 23:38:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 23:38:28 --> Final output sent to browser
DEBUG - 2015-02-10 23:38:28 --> Total execution time: 1.1471
DEBUG - 2015-02-10 23:53:33 --> Config Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Hooks Class Initialized
DEBUG - 2015-02-10 23:53:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-10 23:53:33 --> Utf8 Class Initialized
DEBUG - 2015-02-10 23:53:33 --> URI Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Router Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Output Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Security Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Input Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-10 23:53:33 --> Language Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Loader Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: url_helper
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: link_helper
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-10 23:53:33 --> CI_Session Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Session: Regenerate ID
DEBUG - 2015-02-10 23:53:33 --> CI_Session routines successfully run
DEBUG - 2015-02-10 23:53:33 --> Model Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Model Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Controller Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-10 23:53:33 --> Email Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: language_helper
DEBUG - 2015-02-10 23:53:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-10 23:53:33 --> Model Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Database Driver Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: date_helper
DEBUG - 2015-02-10 23:53:33 --> Helper loaded: form_helper
DEBUG - 2015-02-10 23:53:33 --> Form Validation Class Initialized
DEBUG - 2015-02-10 23:53:33 --> Model Class Initialized
DEBUG - 2015-02-10 23:53:34 --> Model Class Initialized
DEBUG - 2015-02-10 23:53:34 --> Model Class Initialized
DEBUG - 2015-02-10 23:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-10 23:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-10 23:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-10 23:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-10 23:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-10 23:53:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-10 23:53:35 --> Final output sent to browser
DEBUG - 2015-02-10 23:53:35 --> Total execution time: 1.2101
