<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-06 12:29:41 --> Config Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:29:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:29:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:29:41 --> URI Class Initialized
DEBUG - 2015-02-06 12:29:41 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:29:41 --> Router Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Output Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Security Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Input Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:29:41 --> Language Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Loader Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:29:41 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:29:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:29:41 --> CI_Session Class Initialized
ERROR - 2015-02-06 12:29:41 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-06 12:29:41 --> Session: Creating new session (a1967612563f374cc3772a669388483c)
DEBUG - 2015-02-06 12:29:41 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:29:41 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Controller Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:29:41 --> Email Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:29:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:29:41 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:29:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:29:41 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:29:41 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:29:41 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:29:41 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:29:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:29:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:29:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:29:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:29:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:29:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:29:42 --> Final output sent to browser
DEBUG - 2015-02-06 12:29:42 --> Total execution time: 1.3051
DEBUG - 2015-02-06 12:29:49 --> Config Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:29:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:29:49 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:29:49 --> URI Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Router Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Output Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Security Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Input Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:29:49 --> Language Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Loader Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:29:49 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:29:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:29:49 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:29:49 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:29:49 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Controller Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:29:49 --> Email Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:29:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:29:49 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:29:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:29:49 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:29:49 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:29:49 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:29:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 12:29:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 12:29:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 12:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 12:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:29:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:29:49 --> Final output sent to browser
DEBUG - 2015-02-06 12:29:49 --> Total execution time: 0.2000
DEBUG - 2015-02-06 12:29:55 --> Config Class Initialized
DEBUG - 2015-02-06 12:29:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:29:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:29:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:29:55 --> URI Class Initialized
DEBUG - 2015-02-06 12:29:55 --> Router Class Initialized
DEBUG - 2015-02-06 12:29:55 --> Output Class Initialized
DEBUG - 2015-02-06 12:29:55 --> Security Class Initialized
DEBUG - 2015-02-06 12:29:55 --> Input Class Initialized
DEBUG - 2015-02-06 12:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:29:55 --> Language Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Loader Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:29:56 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:29:56 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:29:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Controller Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:29:56 --> Email Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:29:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:29:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:29:56 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 12:29:56 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 12:29:56 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 12:29:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 12:29:56 --> Config Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:29:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:29:56 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:29:56 --> URI Class Initialized
DEBUG - 2015-02-06 12:29:56 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:29:56 --> Router Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Output Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Security Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Input Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:29:56 --> Language Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Loader Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:29:56 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:29:56 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:29:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Controller Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:29:56 --> Email Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:29:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:29:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:29:56 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:29:56 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:29:56 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:29:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:29:57 --> Final output sent to browser
DEBUG - 2015-02-06 12:29:57 --> Total execution time: 0.8141
DEBUG - 2015-02-06 12:29:59 --> Config Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:29:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:29:59 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:29:59 --> URI Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Router Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Output Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Security Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Input Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:29:59 --> Language Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Loader Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:29:59 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:29:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:29:59 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:29:59 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:29:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Controller Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:29:59 --> Email Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:29:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:29:59 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:29:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:29:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:29:59 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:29:59 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:29:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:29:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:29:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:30:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-06 12:30:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:30:00 --> Final output sent to browser
DEBUG - 2015-02-06 12:30:00 --> Total execution time: 0.9551
DEBUG - 2015-02-06 12:30:07 --> Config Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:30:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:30:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:30:07 --> URI Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Router Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Output Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Security Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Input Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:30:07 --> Language Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Loader Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:30:07 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:30:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:30:07 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:30:07 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Controller Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:30:07 --> Email Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:30:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:30:07 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:30:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:30:07 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:30:07 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:30:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/index.php
DEBUG - 2015-02-06 12:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:30:08 --> Final output sent to browser
DEBUG - 2015-02-06 12:30:08 --> Total execution time: 1.6992
DEBUG - 2015-02-06 12:30:22 --> Config Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:30:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:30:22 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:30:22 --> URI Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Router Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Output Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Security Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Input Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:30:22 --> Language Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Loader Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:30:22 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:30:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:30:22 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:30:22 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Controller Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:30:22 --> Email Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:30:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:30:22 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:30:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:30:22 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:30:22 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:30:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:30:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/file/index.php
DEBUG - 2015-02-06 12:30:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:30:23 --> Final output sent to browser
DEBUG - 2015-02-06 12:30:23 --> Total execution time: 1.1671
DEBUG - 2015-02-06 12:30:29 --> Config Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:30:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:30:29 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:30:29 --> URI Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Router Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Output Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Security Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Input Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:30:29 --> Language Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Loader Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:30:29 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:30:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:30:29 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:30:29 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:30:29 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Controller Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:30:29 --> Email Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:30:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:30:29 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:30:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:30:29 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:30:29 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:30:29 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:30:29 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:30:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:30:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 12:30:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:30:30 --> Final output sent to browser
DEBUG - 2015-02-06 12:30:30 --> Total execution time: 0.3830
DEBUG - 2015-02-06 12:30:54 --> Config Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:30:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:30:54 --> URI Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Router Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Output Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Security Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Input Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:30:54 --> Language Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Loader Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:30:54 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:30:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:30:54 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:30:54 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:30:54 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Controller Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:30:54 --> Email Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:30:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:30:54 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:30:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:30:54 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:30:54 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:30:54 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:30:54 --> Model Class Initialized
DEBUG - 2015-02-06 12:30:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:30:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:30:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 12:30:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:30:54 --> Final output sent to browser
DEBUG - 2015-02-06 12:30:54 --> Total execution time: 0.4000
DEBUG - 2015-02-06 12:31:00 --> Config Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:31:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:31:00 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:31:00 --> URI Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Router Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Output Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Security Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Input Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:31:00 --> Language Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Loader Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:31:00 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:31:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:31:00 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:31:00 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:31:00 --> Model Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Model Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Controller Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:31:00 --> Email Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:31:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:31:00 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:31:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:31:00 --> Model Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:31:00 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:31:00 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:31:00 --> Model Class Initialized
DEBUG - 2015-02-06 12:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:31:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
ERROR - 2015-02-06 12:31:00 --> Severity: Error --> Call to undefined method User_model::getBySlugName() D:\phutx\project\ups\myblog\application\controllers\admin\Users.php 43
DEBUG - 2015-02-06 12:32:03 --> Config Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:32:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:32:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:32:03 --> URI Class Initialized
DEBUG - 2015-02-06 12:32:03 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:32:03 --> Router Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Output Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Security Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Input Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:32:03 --> Language Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Loader Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:32:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:32:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:32:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:32:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:32:03 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Controller Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:32:03 --> Email Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:32:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:32:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:32:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:32:03 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:32:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:32:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:32:03 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:32:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:32:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:32:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:32:04 --> Final output sent to browser
DEBUG - 2015-02-06 12:32:04 --> Total execution time: 0.7901
DEBUG - 2015-02-06 12:32:05 --> Config Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:32:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:32:05 --> URI Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Router Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Output Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Security Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Input Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:32:05 --> Language Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Loader Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:32:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:32:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:32:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Controller Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:32:05 --> Email Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:32:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:32:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:32:05 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 12:32:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 12:32:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 12:32:05 --> Session: Creating new session (ee8f8e8eee9e1f98ad995434041d33ef)
DEBUG - 2015-02-06 12:32:05 --> Config Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:32:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:32:05 --> URI Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Router Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Output Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Security Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Input Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:32:05 --> Language Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Loader Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:32:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:32:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:32:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Controller Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:32:05 --> Email Class Initialized
DEBUG - 2015-02-06 12:32:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:32:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:32:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:32:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:06 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:32:06 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:32:06 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:32:06 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:32:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 12:32:06 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 12:32:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 12:32:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:32:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:32:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 12:32:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:32:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:32:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:32:06 --> Final output sent to browser
DEBUG - 2015-02-06 12:32:06 --> Total execution time: 0.2000
DEBUG - 2015-02-06 12:32:10 --> Config Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:32:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:32:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:32:10 --> URI Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Router Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Output Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Security Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Input Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:32:10 --> Language Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Loader Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:32:10 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:32:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:32:10 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:32:10 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:32:10 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Controller Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:32:10 --> Email Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:32:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:32:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:32:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:32:10 --> Model Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:32:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:32:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:32:10 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 12:32:10 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 12:32:10 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 12:32:10 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 12:32:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:32:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:32:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 12:32:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:32:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:32:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:32:10 --> Final output sent to browser
DEBUG - 2015-02-06 12:32:10 --> Total execution time: 0.2020
DEBUG - 2015-02-06 12:36:43 --> Config Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:36:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:36:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:36:43 --> URI Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Router Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Output Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Security Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Input Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:36:43 --> Language Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Loader Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:36:43 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:36:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:36:43 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:36:43 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:36:43 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Controller Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:36:43 --> Email Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:36:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:36:43 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:36:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:36:43 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:36:43 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:36:43 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:36:43 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 12:36:43 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 12:36:43 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 12:36:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:36:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:36:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 12:36:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:36:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:36:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:36:43 --> Final output sent to browser
DEBUG - 2015-02-06 12:36:43 --> Total execution time: 0.1940
DEBUG - 2015-02-06 12:36:54 --> Config Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:36:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:36:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:36:54 --> URI Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Router Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Output Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Security Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Input Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:36:54 --> Language Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Loader Class Initialized
DEBUG - 2015-02-06 12:36:54 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:36:54 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:36:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:36:54 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:36:55 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:36:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Controller Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:36:55 --> Email Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:36:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:36:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:36:55 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 12:36:55 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 12:36:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 12:36:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 12:36:55 --> Config Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:36:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:36:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:36:55 --> URI Class Initialized
DEBUG - 2015-02-06 12:36:55 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:36:55 --> Router Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Output Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Security Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Input Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:36:55 --> Language Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Loader Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:36:55 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:36:55 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:36:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Controller Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:36:55 --> Email Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:36:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:36:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:36:55 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:36:55 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:36:55 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:36:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:36:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:36:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:36:56 --> Final output sent to browser
DEBUG - 2015-02-06 12:36:56 --> Total execution time: 0.7941
DEBUG - 2015-02-06 12:36:57 --> Config Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:36:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:36:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:36:57 --> URI Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Router Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Output Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Security Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Input Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:36:57 --> Language Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Loader Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:36:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:36:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:36:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:36:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:36:57 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Controller Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:36:57 --> Email Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:36:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:36:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:36:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:36:57 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:36:57 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:36:57 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:36:57 --> Model Class Initialized
DEBUG - 2015-02-06 12:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-06 12:36:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:36:57 --> Final output sent to browser
DEBUG - 2015-02-06 12:36:57 --> Total execution time: 0.4050
DEBUG - 2015-02-06 12:37:00 --> Config Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:37:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:37:00 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:37:00 --> URI Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Router Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Output Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Security Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Input Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:37:00 --> Language Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Loader Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:37:00 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:37:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:37:00 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:37:00 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:37:00 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Controller Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:37:00 --> Email Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:37:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:37:00 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:37:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:37:00 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:37:00 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:37:01 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:37:01 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:37:01 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:37:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:37:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 12:37:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:37:01 --> Final output sent to browser
DEBUG - 2015-02-06 12:37:01 --> Total execution time: 0.4080
DEBUG - 2015-02-06 12:37:33 --> Config Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:37:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:37:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:37:33 --> URI Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Router Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Output Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Security Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Input Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:37:33 --> Language Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Loader Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:37:33 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:37:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:37:33 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Session: Regenerate ID
DEBUG - 2015-02-06 12:37:33 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:37:33 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Controller Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:37:33 --> Email Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:37:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:37:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:37:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:37:33 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:37:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:37:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:37:33 --> Model Class Initialized
DEBUG - 2015-02-06 12:37:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:37:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:37:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 12:37:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:37:34 --> Final output sent to browser
DEBUG - 2015-02-06 12:37:34 --> Total execution time: 0.4190
DEBUG - 2015-02-06 12:40:59 --> Config Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:40:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:40:59 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:40:59 --> URI Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Router Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Output Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Security Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Input Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:40:59 --> Language Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Loader Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:40:59 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:40:59 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:40:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Controller Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:40:59 --> Email Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:40:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:40:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:40:59 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:40:59 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:40:59 --> Model Class Initialized
DEBUG - 2015-02-06 12:40:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:40:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:41:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 12:41:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:41:01 --> Final output sent to browser
DEBUG - 2015-02-06 12:41:01 --> Total execution time: 1.7872
DEBUG - 2015-02-06 12:41:39 --> Config Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:41:39 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:41:39 --> URI Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Router Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Output Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Security Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Input Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:41:39 --> Language Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Loader Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:41:39 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:41:39 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:41:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Controller Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:41:39 --> Email Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:41:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:41:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:41:39 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:41:39 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:41:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:41:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:41:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 12:41:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:41:41 --> Final output sent to browser
DEBUG - 2015-02-06 12:41:41 --> Total execution time: 1.9032
DEBUG - 2015-02-06 12:41:56 --> Config Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:41:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:41:56 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:41:56 --> URI Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Router Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Output Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Security Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Input Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:41:56 --> Language Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Loader Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:41:56 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:41:56 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:41:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Controller Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:41:56 --> Email Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:41:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:41:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:41:56 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:41:56 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:41:56 --> Model Class Initialized
DEBUG - 2015-02-06 12:41:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 12:41:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 12:41:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 12:41:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 12:41:58 --> Final output sent to browser
DEBUG - 2015-02-06 12:41:58 --> Total execution time: 1.7912
DEBUG - 2015-02-06 12:47:43 --> Config Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:47:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:47:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:47:43 --> URI Class Initialized
DEBUG - 2015-02-06 12:47:43 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:47:43 --> Router Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Output Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Security Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Input Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:47:43 --> Language Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Loader Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:47:43 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Session: Regenerate ID
DEBUG - 2015-02-06 12:47:43 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:47:43 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Controller Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:47:43 --> Email Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:47:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:47:43 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:47:43 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:47:43 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:47:43 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:47:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:47:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:47:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:47:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:47:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:47:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:47:43 --> Final output sent to browser
DEBUG - 2015-02-06 12:47:43 --> Total execution time: 0.8221
DEBUG - 2015-02-06 12:47:45 --> Config Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:47:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:47:45 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:47:45 --> URI Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Router Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Output Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Security Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Input Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:47:45 --> Language Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Loader Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:47:45 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:47:45 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:47:45 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Controller Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:47:45 --> Email Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:47:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:47:45 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:47:45 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:47:45 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:47:45 --> Model Class Initialized
DEBUG - 2015-02-06 12:47:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:47:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:47:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:47:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:47:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:47:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:47:46 --> Final output sent to browser
DEBUG - 2015-02-06 12:47:46 --> Total execution time: 1.1301
DEBUG - 2015-02-06 12:48:10 --> Config Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:48:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:48:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:48:10 --> URI Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Router Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Output Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Security Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Input Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:48:10 --> Language Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Loader Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:48:10 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:48:10 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:48:10 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Controller Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:48:10 --> Email Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:48:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:48:10 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:48:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:48:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:48:10 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:48:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:48:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:48:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:48:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:48:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
ERROR - 2015-02-06 12:48:11 --> Severity: error --> Exception: An exception occurred while executing 'INSERT INTO article_categories (article_id, user_id) VALUES (?, ?)' with params [37, 1]:

SQLSTATE[42S22]: Column not found: 1054 Unknown column 'user_id' in 'field list' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-06 12:48:48 --> Config Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:48:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:48:48 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:48:48 --> URI Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Router Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Output Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Security Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Input Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:48:48 --> Language Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Loader Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:48:48 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:48:48 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:48:48 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Controller Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:48:48 --> Email Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:48:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:48:48 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:48:48 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:48:48 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:48:48 --> Model Class Initialized
DEBUG - 2015-02-06 12:48:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:48:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:48:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:48:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:48:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:48:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
ERROR - 2015-02-06 12:48:49 --> Severity: error --> Exception: An exception occurred while executing 'INSERT INTO user_articles (article_id, user_id) VALUES (?, ?)' with params [37, 1]:

SQLSTATE[42S22]: Column not found: 1054 Unknown column 'article_id' in 'field list' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-06 12:49:12 --> Config Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:49:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:49:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:49:12 --> URI Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Router Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Output Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Security Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Input Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:49:12 --> Language Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Loader Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:49:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:49:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:49:12 --> Model Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Model Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Controller Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:49:12 --> Email Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:49:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:49:12 --> Model Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:49:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:49:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:49:12 --> Model Class Initialized
DEBUG - 2015-02-06 12:49:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:49:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:49:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:49:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:49:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:49:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:49:13 --> Final output sent to browser
DEBUG - 2015-02-06 12:49:13 --> Total execution time: 1.0281
DEBUG - 2015-02-06 12:50:22 --> Config Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:50:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:50:22 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:50:22 --> URI Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Router Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Output Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Security Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Input Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:50:22 --> Language Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Loader Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:50:22 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:50:22 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:50:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:50:22 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:50:22 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:50:22 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Controller Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:50:22 --> Email Class Initialized
DEBUG - 2015-02-06 12:50:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:50:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:50:22 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:50:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:50:22 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:23 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:50:23 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:50:23 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:50:23 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:50:23 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:50:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
ERROR - 2015-02-06 12:50:23 --> Severity: error --> Exception: An exception occurred while executing 'INSERT INTO user_articles (article_id, user_id) VALUES (?, ?)' with params [37, 1]:

SQLSTATE[23000]: Integrity constraint violation: 1062 Duplicate entry '0' for key 'PRIMARY' D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-06 12:50:55 --> Config Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:50:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:50:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:50:55 --> URI Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Router Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Output Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Security Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Input Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:50:55 --> Language Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Loader Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:50:55 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:50:55 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:50:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Controller Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:50:55 --> Email Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:50:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:50:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:50:55 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:50:55 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:50:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:50:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:50:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:50:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:50:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:50:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:50:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:50:56 --> Final output sent to browser
DEBUG - 2015-02-06 12:50:56 --> Total execution time: 1.0501
DEBUG - 2015-02-06 12:53:55 --> Config Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:53:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:53:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:53:55 --> URI Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Router Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Output Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Security Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Input Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:53:55 --> Language Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Loader Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:53:55 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Session: Regenerate ID
DEBUG - 2015-02-06 12:53:55 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:53:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Controller Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:53:55 --> Email Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:53:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:53:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:53:55 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:53:55 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:53:55 --> Model Class Initialized
DEBUG - 2015-02-06 12:53:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:53:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:53:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:53:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:53:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:53:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:53:56 --> Final output sent to browser
DEBUG - 2015-02-06 12:53:56 --> Total execution time: 1.0191
DEBUG - 2015-02-06 12:54:50 --> Config Class Initialized
DEBUG - 2015-02-06 12:54:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:54:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:54:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:54:50 --> URI Class Initialized
DEBUG - 2015-02-06 12:54:50 --> Router Class Initialized
DEBUG - 2015-02-06 12:54:50 --> Output Class Initialized
DEBUG - 2015-02-06 12:54:50 --> Security Class Initialized
DEBUG - 2015-02-06 12:54:50 --> Input Class Initialized
DEBUG - 2015-02-06 12:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:54:50 --> Language Class Initialized
DEBUG - 2015-02-06 12:54:50 --> Loader Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:54:51 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:54:51 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:54:51 --> Model Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Model Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Controller Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:54:51 --> Email Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:54:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:54:51 --> Model Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:54:51 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:54:51 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:54:51 --> Model Class Initialized
DEBUG - 2015-02-06 12:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:54:52 --> Final output sent to browser
DEBUG - 2015-02-06 12:54:52 --> Total execution time: 1.5242
DEBUG - 2015-02-06 12:55:28 --> Config Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:55:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:55:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:55:28 --> URI Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Router Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Output Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Security Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Input Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:55:28 --> Language Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Loader Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:55:28 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:55:28 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:55:28 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Controller Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:55:28 --> Email Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:55:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:55:28 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:55:28 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:55:28 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:55:28 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:55:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:55:29 --> Final output sent to browser
DEBUG - 2015-02-06 12:55:29 --> Total execution time: 1.1161
DEBUG - 2015-02-06 12:55:46 --> Config Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:55:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:55:46 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:55:46 --> URI Class Initialized
DEBUG - 2015-02-06 12:55:46 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:55:46 --> Router Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Output Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Security Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Input Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:55:46 --> Language Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Loader Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:55:46 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:55:46 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:55:46 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Controller Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:55:46 --> Email Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:55:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:55:46 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:55:46 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:55:46 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Model Class Initialized
DEBUG - 2015-02-06 12:55:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:55:46 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:55:47 --> Final output sent to browser
DEBUG - 2015-02-06 12:55:47 --> Total execution time: 0.8271
DEBUG - 2015-02-06 12:56:34 --> Config Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:56:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:56:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:56:34 --> URI Class Initialized
DEBUG - 2015-02-06 12:56:34 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:56:34 --> Router Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Output Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Security Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Input Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:56:34 --> Language Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Loader Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:56:34 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:56:34 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:56:34 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Controller Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:56:34 --> Email Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:56:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:56:34 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:56:34 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:56:34 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:56:34 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:56:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:56:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:56:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:56:35 --> Final output sent to browser
DEBUG - 2015-02-06 12:56:35 --> Total execution time: 0.8811
DEBUG - 2015-02-06 12:56:42 --> Config Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:56:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:56:42 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:56:42 --> URI Class Initialized
DEBUG - 2015-02-06 12:56:42 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:56:42 --> Router Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Output Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Security Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Input Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:56:42 --> Language Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Loader Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:56:42 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:56:42 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:56:42 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Controller Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:56:42 --> Email Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:56:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:56:42 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:56:42 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:56:42 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:56:42 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:56:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:56:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:56:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:56:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:56:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:56:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:56:43 --> Final output sent to browser
DEBUG - 2015-02-06 12:56:43 --> Total execution time: 0.8491
DEBUG - 2015-02-06 12:56:58 --> Config Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:56:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:56:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:56:58 --> URI Class Initialized
DEBUG - 2015-02-06 12:56:58 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:56:58 --> Router Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Output Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Security Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Input Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:56:58 --> Language Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Loader Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:56:58 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:56:58 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:56:58 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Controller Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:56:58 --> Email Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:56:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:56:58 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:56:58 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:56:58 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Model Class Initialized
DEBUG - 2015-02-06 12:56:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:56:58 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:56:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:56:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:56:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:56:59 --> Final output sent to browser
DEBUG - 2015-02-06 12:56:59 --> Total execution time: 0.8591
DEBUG - 2015-02-06 12:57:39 --> Config Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:57:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:57:39 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:57:39 --> URI Class Initialized
DEBUG - 2015-02-06 12:57:39 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:57:39 --> Router Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Output Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Security Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Input Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:57:39 --> Language Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Loader Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:57:39 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:57:39 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:57:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Controller Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:57:39 --> Email Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:57:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:57:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:57:39 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:57:39 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:57:39 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:57:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:57:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:57:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:57:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:57:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:57:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:57:39 --> Final output sent to browser
DEBUG - 2015-02-06 12:57:39 --> Total execution time: 0.8471
DEBUG - 2015-02-06 12:57:52 --> Config Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:57:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:57:52 --> URI Class Initialized
DEBUG - 2015-02-06 12:57:52 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:57:52 --> Router Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Output Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Security Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Input Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:57:52 --> Language Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Loader Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:57:52 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:57:52 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:57:52 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Controller Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:57:52 --> Email Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:57:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:57:52 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:57:52 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:57:52 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Model Class Initialized
DEBUG - 2015-02-06 12:57:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:57:52 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:57:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:57:53 --> Final output sent to browser
DEBUG - 2015-02-06 12:57:53 --> Total execution time: 0.8931
DEBUG - 2015-02-06 12:58:05 --> Config Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:58:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:58:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:58:05 --> URI Class Initialized
DEBUG - 2015-02-06 12:58:05 --> No URI present. Default controller set.
DEBUG - 2015-02-06 12:58:05 --> Router Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Output Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Security Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Input Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:58:05 --> Language Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Loader Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:58:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:58:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:58:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Controller Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:58:05 --> Email Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:58:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:58:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:58:05 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:58:05 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 12:58:05 --> Pagination Class Initialized
DEBUG - 2015-02-06 12:58:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:58:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:58:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 12:58:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:58:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:58:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:58:05 --> Final output sent to browser
DEBUG - 2015-02-06 12:58:05 --> Total execution time: 0.7971
DEBUG - 2015-02-06 12:58:24 --> Config Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Hooks Class Initialized
DEBUG - 2015-02-06 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 12:58:24 --> Utf8 Class Initialized
DEBUG - 2015-02-06 12:58:24 --> URI Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Router Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Output Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Security Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Input Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 12:58:24 --> Language Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Loader Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: url_helper
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: link_helper
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 12:58:24 --> CI_Session Class Initialized
DEBUG - 2015-02-06 12:58:24 --> CI_Session routines successfully run
DEBUG - 2015-02-06 12:58:24 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Controller Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 12:58:24 --> Email Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: language_helper
DEBUG - 2015-02-06 12:58:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 12:58:24 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Database Driver Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: date_helper
DEBUG - 2015-02-06 12:58:24 --> Helper loaded: form_helper
DEBUG - 2015-02-06 12:58:24 --> Form Validation Class Initialized
DEBUG - 2015-02-06 12:58:24 --> Model Class Initialized
DEBUG - 2015-02-06 12:58:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 12:58:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 12:58:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 12:58:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 12:58:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 12:58:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 12:58:25 --> Final output sent to browser
DEBUG - 2015-02-06 12:58:25 --> Total execution time: 1.4101
DEBUG - 2015-02-06 13:08:37 --> Config Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:08:37 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:08:37 --> URI Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Router Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Output Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Security Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Input Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:08:37 --> Language Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Loader Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:08:37 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:08:37 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:08:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:08:37 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Session: Regenerate ID
DEBUG - 2015-02-06 13:08:37 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:08:37 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Controller Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:08:37 --> Email Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:08:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:08:37 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:08:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:08:37 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:08:37 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:08:38 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:08:38 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:08:38 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 13:08:38 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 13:08:38 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 13:08:38 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 13:08:38 --> Helper loaded: string_helper
DEBUG - 2015-02-06 13:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 13:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:08:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:08:38 --> Final output sent to browser
DEBUG - 2015-02-06 13:08:38 --> Total execution time: 0.3380
DEBUG - 2015-02-06 13:08:40 --> Config Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:08:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:08:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:08:40 --> URI Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Router Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Output Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Security Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Input Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:08:40 --> Language Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Loader Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:08:40 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:08:40 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:08:40 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Controller Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:08:40 --> Email Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:08:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:08:40 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:08:40 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:08:40 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:08:40 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 13:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 13:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-06 13:08:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 13:08:40 --> Final output sent to browser
DEBUG - 2015-02-06 13:08:40 --> Total execution time: 0.4170
DEBUG - 2015-02-06 13:08:49 --> Config Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:08:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:08:49 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:08:49 --> URI Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Router Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Output Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Security Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Input Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:08:49 --> Language Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Loader Class Initialized
DEBUG - 2015-02-06 13:08:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:08:49 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:08:49 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:08:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:08:49 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:08:49 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:08:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:50 --> Controller Class Initialized
DEBUG - 2015-02-06 13:08:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:08:50 --> Email Class Initialized
DEBUG - 2015-02-06 13:08:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:08:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:08:50 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:08:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:08:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:50 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:08:50 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:08:50 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:08:50 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:08:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 13:08:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 13:08:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-06 13:08:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 13:08:51 --> Final output sent to browser
DEBUG - 2015-02-06 13:08:51 --> Total execution time: 1.7492
DEBUG - 2015-02-06 13:11:19 --> Config Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:11:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:11:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:11:19 --> URI Class Initialized
DEBUG - 2015-02-06 13:11:19 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:11:19 --> Router Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Output Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Security Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Input Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:11:19 --> Language Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Loader Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:11:19 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:11:19 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:11:19 --> Model Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Model Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Controller Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:11:19 --> Email Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:11:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:11:19 --> Model Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:11:19 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:11:19 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Model Class Initialized
DEBUG - 2015-02-06 13:11:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:11:19 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:11:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:11:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:11:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:11:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:11:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:11:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:11:20 --> Final output sent to browser
DEBUG - 2015-02-06 13:11:20 --> Total execution time: 0.8551
DEBUG - 2015-02-06 13:11:22 --> Config Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:11:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:11:22 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:11:22 --> URI Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Router Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Output Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Security Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Input Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:11:22 --> Language Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Loader Class Initialized
DEBUG - 2015-02-06 13:11:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:11:22 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:11:22 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:11:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:11:22 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:11:22 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:11:23 --> Model Class Initialized
DEBUG - 2015-02-06 13:11:23 --> Model Class Initialized
DEBUG - 2015-02-06 13:11:23 --> Controller Class Initialized
DEBUG - 2015-02-06 13:11:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:11:23 --> Email Class Initialized
DEBUG - 2015-02-06 13:11:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:11:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:11:23 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:11:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:11:23 --> Model Class Initialized
DEBUG - 2015-02-06 13:11:23 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:11:23 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:11:23 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:11:23 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:11:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 13:11:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 13:11:23 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 13:11:23 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 13:11:23 --> Helper loaded: string_helper
DEBUG - 2015-02-06 13:11:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:11:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:11:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 13:11:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:11:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:11:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:11:23 --> Final output sent to browser
DEBUG - 2015-02-06 13:11:23 --> Total execution time: 0.2400
DEBUG - 2015-02-06 13:12:03 --> Config Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:12:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:12:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:12:03 --> URI Class Initialized
DEBUG - 2015-02-06 13:12:03 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:12:03 --> Router Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Output Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Security Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Input Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:12:03 --> Language Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Loader Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:12:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:12:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:12:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Controller Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:12:03 --> Email Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:12:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:12:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:12:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:12:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:12:03 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:12:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:12:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-06 13:12:04 --> Severity: Notice --> Array to string conversion D:\phutx\project\ups\myblog\application\views\welcome_message.php 20
ERROR - 2015-02-06 13:12:04 --> Severity: Notice --> Array to string conversion D:\phutx\project\ups\myblog\application\views\welcome_message.php 20
ERROR - 2015-02-06 13:12:04 --> Severity: Notice --> Array to string conversion D:\phutx\project\ups\myblog\application\views\welcome_message.php 20
DEBUG - 2015-02-06 13:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:12:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:12:04 --> Final output sent to browser
DEBUG - 2015-02-06 13:12:04 --> Total execution time: 0.9141
DEBUG - 2015-02-06 13:12:47 --> Config Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:12:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:12:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:12:47 --> URI Class Initialized
DEBUG - 2015-02-06 13:12:47 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:12:47 --> Router Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Output Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Security Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Input Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:12:47 --> Language Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Loader Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:12:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:12:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:12:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Controller Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:12:47 --> Email Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:12:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:12:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:12:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:12:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:12:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:12:47 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-06 13:12:48 --> Severity: Error --> Call to undefined method Entity\ArticleTags::getName() D:\phutx\project\ups\myblog\application\views\welcome_message.php 23
DEBUG - 2015-02-06 13:13:33 --> Config Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:13:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:13:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:13:33 --> URI Class Initialized
DEBUG - 2015-02-06 13:13:33 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:13:33 --> Router Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Output Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Security Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Input Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:13:33 --> Language Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Loader Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:13:33 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:13:33 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:13:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Controller Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:13:33 --> Email Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:13:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:13:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:13:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:13:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:13:33 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:13:59 --> Config Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:13:59 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:13:59 --> URI Class Initialized
DEBUG - 2015-02-06 13:13:59 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:13:59 --> Router Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Output Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Security Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Input Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:13:59 --> Language Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Loader Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:13:59 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Session: Regenerate ID
DEBUG - 2015-02-06 13:13:59 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Controller Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:13:59 --> Email Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:13:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:13:59 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:13:59 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Model Class Initialized
DEBUG - 2015-02-06 13:13:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:13:59 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:14:00 --> Final output sent to browser
DEBUG - 2015-02-06 13:14:00 --> Total execution time: 1.3641
DEBUG - 2015-02-06 13:14:26 --> Config Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:14:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:14:26 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:14:26 --> URI Class Initialized
DEBUG - 2015-02-06 13:14:26 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:14:26 --> Router Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Output Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Security Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Input Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:14:26 --> Language Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Loader Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:14:26 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:14:26 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:14:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Controller Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:14:26 --> Email Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:14:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:14:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:14:26 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:14:26 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:14:26 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:14:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:14:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:14:33 --> Config Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:14:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:14:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:14:33 --> URI Class Initialized
DEBUG - 2015-02-06 13:14:33 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:14:33 --> Router Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Output Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Security Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Input Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:14:33 --> Language Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Loader Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:14:33 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:14:33 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:14:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Controller Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:14:33 --> Email Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:14:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:14:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:14:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:14:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:14:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:14:33 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:14:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:14:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:14:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:14:34 --> Final output sent to browser
DEBUG - 2015-02-06 13:14:34 --> Total execution time: 1.2481
DEBUG - 2015-02-06 13:15:06 --> Config Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:15:06 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:15:06 --> URI Class Initialized
DEBUG - 2015-02-06 13:15:06 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:15:06 --> Router Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Output Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Security Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Input Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:15:06 --> Language Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Loader Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:15:06 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:15:06 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:15:06 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Controller Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:15:06 --> Email Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:15:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:15:06 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:15:06 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:15:06 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:15:06 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:15:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:15:07 --> Final output sent to browser
DEBUG - 2015-02-06 13:15:07 --> Total execution time: 1.1701
DEBUG - 2015-02-06 13:15:26 --> Config Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:15:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:15:26 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:15:26 --> URI Class Initialized
DEBUG - 2015-02-06 13:15:26 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:15:26 --> Router Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Output Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Security Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Input Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:15:26 --> Language Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Loader Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:15:26 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:15:26 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:15:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Controller Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:15:26 --> Email Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:15:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:15:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:15:26 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:15:26 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:15:26 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:15:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:15:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:15:27 --> Final output sent to browser
DEBUG - 2015-02-06 13:15:27 --> Total execution time: 1.0551
DEBUG - 2015-02-06 13:15:36 --> Config Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:15:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:15:36 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:15:36 --> URI Class Initialized
DEBUG - 2015-02-06 13:15:36 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:15:36 --> Router Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Output Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Security Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Input Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:15:36 --> Language Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Loader Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:15:36 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:15:36 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:15:36 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Controller Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:15:36 --> Email Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:15:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:15:36 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:15:36 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:15:36 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:15:36 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:15:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:15:47 --> Config Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:15:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:15:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:15:47 --> URI Class Initialized
DEBUG - 2015-02-06 13:15:47 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:15:47 --> Router Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Output Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Security Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Input Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:15:47 --> Language Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Loader Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:15:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:15:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:15:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Controller Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:15:47 --> Email Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:15:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:15:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:15:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:15:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Model Class Initialized
DEBUG - 2015-02-06 13:15:47 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:15:47 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:15:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:15:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:15:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:15:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:15:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:15:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:15:48 --> Final output sent to browser
DEBUG - 2015-02-06 13:15:48 --> Total execution time: 0.9811
DEBUG - 2015-02-06 13:16:06 --> Config Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:16:06 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:16:06 --> URI Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Router Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Output Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Security Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Input Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:16:06 --> Language Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Loader Class Initialized
DEBUG - 2015-02-06 13:16:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:16:06 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:16:06 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:16:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:16:06 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:16:06 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:16:07 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:07 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:07 --> Controller Class Initialized
DEBUG - 2015-02-06 13:16:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:16:07 --> Email Class Initialized
DEBUG - 2015-02-06 13:16:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:16:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:16:07 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:16:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:16:07 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:07 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:16:07 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:16:07 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:16:07 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:16:07 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:16:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:16:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 13:16:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:16:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:16:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:16:08 --> Final output sent to browser
DEBUG - 2015-02-06 13:16:08 --> Total execution time: 1.1741
DEBUG - 2015-02-06 13:16:29 --> Config Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:16:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:16:29 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:16:29 --> URI Class Initialized
DEBUG - 2015-02-06 13:16:29 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:16:29 --> Router Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Output Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Security Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Input Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:16:29 --> Language Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Loader Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:16:29 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:16:29 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:16:29 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Controller Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:16:29 --> Email Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:16:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:16:29 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:16:29 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:16:29 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Model Class Initialized
DEBUG - 2015-02-06 13:16:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:16:29 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:16:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:16:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:16:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:16:30 --> Final output sent to browser
DEBUG - 2015-02-06 13:16:30 --> Total execution time: 0.9501
DEBUG - 2015-02-06 13:19:10 --> Config Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:19:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:19:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:19:10 --> URI Class Initialized
DEBUG - 2015-02-06 13:19:10 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:19:10 --> Router Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Output Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Security Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Input Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:19:10 --> Language Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Loader Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:19:10 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Session: Regenerate ID
DEBUG - 2015-02-06 13:19:10 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:19:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Controller Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:19:10 --> Email Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:19:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:19:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:19:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:19:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:19:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:19:10 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:19:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:19:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:19:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:19:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:19:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:19:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:19:11 --> Final output sent to browser
DEBUG - 2015-02-06 13:19:11 --> Total execution time: 0.9111
DEBUG - 2015-02-06 13:20:24 --> Config Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:20:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:20:24 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:20:24 --> URI Class Initialized
DEBUG - 2015-02-06 13:20:24 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:20:24 --> Router Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Output Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Security Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Input Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:20:24 --> Language Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Loader Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:20:24 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:20:24 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:20:24 --> Model Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Model Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Controller Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:20:24 --> Email Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:20:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:20:24 --> Model Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:20:24 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:20:24 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Model Class Initialized
DEBUG - 2015-02-06 13:20:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:20:24 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:20:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:20:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:20:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:20:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:20:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:20:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:20:25 --> Final output sent to browser
DEBUG - 2015-02-06 13:20:25 --> Total execution time: 1.0271
DEBUG - 2015-02-06 13:21:11 --> Config Class Initialized
DEBUG - 2015-02-06 13:21:11 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:21:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:21:11 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:21:11 --> URI Class Initialized
DEBUG - 2015-02-06 13:21:11 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:21:11 --> Router Class Initialized
DEBUG - 2015-02-06 13:21:11 --> Output Class Initialized
DEBUG - 2015-02-06 13:21:11 --> Security Class Initialized
DEBUG - 2015-02-06 13:21:11 --> Input Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:21:12 --> Language Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Loader Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:21:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:21:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:21:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Controller Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:21:12 --> Email Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:21:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:21:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:21:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:21:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:21:12 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:21:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:21:12 --> Final output sent to browser
DEBUG - 2015-02-06 13:21:12 --> Total execution time: 0.9561
DEBUG - 2015-02-06 13:21:25 --> Config Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:21:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:21:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:21:25 --> URI Class Initialized
DEBUG - 2015-02-06 13:21:25 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:21:25 --> Router Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Output Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Security Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Input Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:21:25 --> Language Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Loader Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:21:25 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:21:25 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:21:25 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Controller Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:21:25 --> Email Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:21:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:21:25 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:21:25 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:21:25 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Model Class Initialized
DEBUG - 2015-02-06 13:21:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:21:25 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:21:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:21:25 --> Final output sent to browser
DEBUG - 2015-02-06 13:21:25 --> Total execution time: 0.8971
DEBUG - 2015-02-06 13:22:11 --> Config Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:22:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:22:11 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:22:11 --> URI Class Initialized
DEBUG - 2015-02-06 13:22:11 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:22:11 --> Router Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Output Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Security Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Input Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:22:11 --> Language Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Loader Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:22:11 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:22:11 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:22:11 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Controller Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:22:11 --> Email Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:22:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:22:11 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:22:11 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:22:11 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:22:11 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:22:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:22:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:22:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:22:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:22:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:22:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:22:11 --> Final output sent to browser
DEBUG - 2015-02-06 13:22:11 --> Total execution time: 0.9331
DEBUG - 2015-02-06 13:22:14 --> Config Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:22:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:22:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:22:14 --> URI Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Router Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Output Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Security Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Input Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:22:14 --> Language Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Loader Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:22:14 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:22:14 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:22:14 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Controller Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:22:14 --> Email Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:22:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:22:14 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:22:14 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:22:14 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:22:14 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:22:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:22:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 13:22:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:22:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:22:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:22:15 --> Final output sent to browser
DEBUG - 2015-02-06 13:22:15 --> Total execution time: 0.8901
DEBUG - 2015-02-06 13:22:33 --> Config Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:22:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:22:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:22:33 --> URI Class Initialized
DEBUG - 2015-02-06 13:22:33 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:22:33 --> Router Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Output Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Security Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Input Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:22:33 --> Language Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Loader Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:22:33 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:22:33 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:22:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Controller Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:22:33 --> Email Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:22:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:22:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:22:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:22:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:22:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:22:33 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:22:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:22:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:22:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:22:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:22:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:22:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:22:34 --> Final output sent to browser
DEBUG - 2015-02-06 13:22:34 --> Total execution time: 0.9601
DEBUG - 2015-02-06 13:23:03 --> Config Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:23:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:23:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:23:03 --> URI Class Initialized
DEBUG - 2015-02-06 13:23:03 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:23:03 --> Router Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Output Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Security Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Input Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:23:03 --> Language Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Loader Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:23:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:23:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:23:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Controller Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:23:03 --> Email Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:23:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:23:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:23:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:23:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:23:03 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:23:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:23:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:23:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:23:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:23:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:23:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:23:04 --> Final output sent to browser
DEBUG - 2015-02-06 13:23:04 --> Total execution time: 0.8981
DEBUG - 2015-02-06 13:23:11 --> Config Class Initialized
DEBUG - 2015-02-06 13:23:11 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:23:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:23:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:23:12 --> URI Class Initialized
DEBUG - 2015-02-06 13:23:12 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:23:12 --> Router Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Output Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Security Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Input Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:23:12 --> Language Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Loader Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:23:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:23:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:23:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Controller Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:23:12 --> Email Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:23:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:23:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:23:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:23:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:23:12 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:23:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:23:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:23:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:23:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:23:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:23:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:23:12 --> Final output sent to browser
DEBUG - 2015-02-06 13:23:12 --> Total execution time: 0.8971
DEBUG - 2015-02-06 13:23:20 --> Config Class Initialized
DEBUG - 2015-02-06 13:23:20 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:23:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:23:20 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:23:20 --> URI Class Initialized
DEBUG - 2015-02-06 13:23:20 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:23:20 --> Router Class Initialized
DEBUG - 2015-02-06 13:23:20 --> Output Class Initialized
DEBUG - 2015-02-06 13:23:20 --> Security Class Initialized
DEBUG - 2015-02-06 13:23:20 --> Input Class Initialized
DEBUG - 2015-02-06 13:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:23:20 --> Language Class Initialized
DEBUG - 2015-02-06 13:23:20 --> Loader Class Initialized
DEBUG - 2015-02-06 13:23:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:23:20 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:23:20 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:23:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:23:20 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:23:20 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:23:21 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Controller Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:23:21 --> Email Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:23:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:23:21 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:23:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:23:21 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:23:21 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:23:21 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:23:21 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:23:21 --> Final output sent to browser
DEBUG - 2015-02-06 13:23:21 --> Total execution time: 0.9621
DEBUG - 2015-02-06 13:23:48 --> Config Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:23:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:23:48 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:23:48 --> URI Class Initialized
DEBUG - 2015-02-06 13:23:48 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:23:48 --> Router Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Output Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Security Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Input Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:23:48 --> Language Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Loader Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:23:48 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:23:48 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:23:48 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Controller Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:23:48 --> Email Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:23:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:23:48 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:23:48 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:23:48 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Model Class Initialized
DEBUG - 2015-02-06 13:23:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:23:48 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:23:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:23:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:23:49 --> Final output sent to browser
DEBUG - 2015-02-06 13:23:49 --> Total execution time: 0.9331
DEBUG - 2015-02-06 13:24:08 --> Config Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:24:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:24:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:24:08 --> URI Class Initialized
DEBUG - 2015-02-06 13:24:08 --> No URI present. Default controller set.
DEBUG - 2015-02-06 13:24:08 --> Router Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Output Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Security Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Input Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:24:08 --> Language Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Loader Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:24:08 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:24:08 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:24:08 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Controller Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:24:08 --> Email Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:24:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:24:08 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:24:08 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:24:08 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:24:08 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:24:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:24:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:24:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:24:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:24:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:24:09 --> Final output sent to browser
DEBUG - 2015-02-06 13:24:09 --> Total execution time: 0.9441
DEBUG - 2015-02-06 13:24:56 --> Config Class Initialized
DEBUG - 2015-02-06 13:24:56 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:24:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:24:56 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:24:56 --> URI Class Initialized
DEBUG - 2015-02-06 13:24:56 --> Router Class Initialized
DEBUG - 2015-02-06 13:24:56 --> Output Class Initialized
DEBUG - 2015-02-06 13:24:56 --> Security Class Initialized
DEBUG - 2015-02-06 13:24:56 --> Input Class Initialized
DEBUG - 2015-02-06 13:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:24:56 --> Language Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Loader Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:24:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Session: Regenerate ID
DEBUG - 2015-02-06 13:24:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:24:57 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Controller Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:24:57 --> Email Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:24:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:24:57 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:24:57 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:24:57 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Model Class Initialized
DEBUG - 2015-02-06 13:24:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:24:57 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:24:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:24:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:24:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:24:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:24:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:24:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:24:57 --> Final output sent to browser
DEBUG - 2015-02-06 13:24:57 --> Total execution time: 0.9611
DEBUG - 2015-02-06 13:29:39 --> Config Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:29:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:29:39 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:29:39 --> URI Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Router Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Output Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Security Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Input Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:29:39 --> Language Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Loader Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:29:39 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:29:39 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:29:39 --> Model Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Model Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Controller Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:29:39 --> Email Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:29:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:29:39 --> Model Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:29:39 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:29:39 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Model Class Initialized
DEBUG - 2015-02-06 13:29:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:29:39 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:29:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:29:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:29:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:29:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:29:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:29:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:29:40 --> Final output sent to browser
DEBUG - 2015-02-06 13:29:40 --> Total execution time: 0.9521
DEBUG - 2015-02-06 13:31:10 --> Config Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:31:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:31:10 --> URI Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Router Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Output Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Security Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Input Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:31:10 --> Language Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Loader Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:31:10 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Session: Regenerate ID
DEBUG - 2015-02-06 13:31:10 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:31:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Controller Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:31:10 --> Email Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:31:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:31:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:31:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:31:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Model Class Initialized
DEBUG - 2015-02-06 13:31:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:31:10 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:31:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:31:11 --> Final output sent to browser
DEBUG - 2015-02-06 13:31:11 --> Total execution time: 0.9871
DEBUG - 2015-02-06 13:32:49 --> Config Class Initialized
DEBUG - 2015-02-06 13:32:49 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:32:49 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:32:49 --> URI Class Initialized
DEBUG - 2015-02-06 13:32:49 --> Router Class Initialized
DEBUG - 2015-02-06 13:32:49 --> Output Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Security Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Input Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:32:50 --> Language Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Loader Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:32:50 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:32:50 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:32:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Controller Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:32:50 --> Email Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:32:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:32:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:32:50 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:32:50 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Model Class Initialized
DEBUG - 2015-02-06 13:32:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:32:50 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:32:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:32:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:32:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:32:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:32:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:32:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:32:50 --> Final output sent to browser
DEBUG - 2015-02-06 13:32:50 --> Total execution time: 0.9741
DEBUG - 2015-02-06 13:37:12 --> Config Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:37:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:37:12 --> URI Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Router Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Output Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Security Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Input Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:37:12 --> Language Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Loader Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:37:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Session: Regenerate ID
DEBUG - 2015-02-06 13:37:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:37:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Controller Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:37:12 --> Email Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:37:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:37:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:37:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:37:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Model Class Initialized
DEBUG - 2015-02-06 13:37:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:37:12 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:37:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:37:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:37:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:37:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:37:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:37:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:37:13 --> Final output sent to browser
DEBUG - 2015-02-06 13:37:13 --> Total execution time: 1.0011
DEBUG - 2015-02-06 13:39:34 --> Config Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:39:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:39:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:39:34 --> URI Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Router Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Output Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Security Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Input Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:39:34 --> Language Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Loader Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:39:34 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:39:34 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:39:34 --> Model Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Model Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Controller Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:39:34 --> Email Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:39:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:39:34 --> Model Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:39:34 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:39:34 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Model Class Initialized
DEBUG - 2015-02-06 13:39:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:39:34 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:39:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:39:35 --> Final output sent to browser
DEBUG - 2015-02-06 13:39:35 --> Total execution time: 1.1001
DEBUG - 2015-02-06 13:40:13 --> Config Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:40:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:40:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:40:13 --> URI Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Router Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Output Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Security Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Input Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:40:13 --> Language Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Loader Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:40:13 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:40:13 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:40:13 --> Model Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Model Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Controller Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:40:13 --> Email Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:40:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:40:13 --> Model Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:40:13 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:40:13 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Model Class Initialized
DEBUG - 2015-02-06 13:40:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:40:13 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:40:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:40:14 --> Final output sent to browser
DEBUG - 2015-02-06 13:40:14 --> Total execution time: 1.1961
DEBUG - 2015-02-06 13:41:02 --> Config Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:41:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:41:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:41:02 --> URI Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Router Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Output Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Security Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Input Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:41:02 --> Language Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Loader Class Initialized
DEBUG - 2015-02-06 13:41:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:41:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:41:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:41:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:41:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:41:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:41:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Controller Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:41:03 --> Email Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:41:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:41:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:41:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:41:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:41:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:41:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:41:03 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:41:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:41:03 --> Final output sent to browser
DEBUG - 2015-02-06 13:41:03 --> Total execution time: 1.0281
DEBUG - 2015-02-06 13:41:30 --> Config Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:41:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:41:30 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:41:30 --> URI Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Router Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Output Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Security Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Input Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:41:30 --> Language Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Loader Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:41:30 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:41:30 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:41:30 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Controller Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:41:30 --> Email Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:41:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:41:30 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:41:30 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:41:30 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Model Class Initialized
DEBUG - 2015-02-06 13:41:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:41:30 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:41:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:41:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:41:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:41:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:41:31 --> Final output sent to browser
DEBUG - 2015-02-06 13:41:31 --> Total execution time: 0.9261
DEBUG - 2015-02-06 13:56:32 --> Config Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 13:56:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 13:56:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 13:56:32 --> URI Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Router Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Output Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Security Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Input Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 13:56:32 --> Language Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Loader Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 13:56:32 --> Helper loaded: url_helper
DEBUG - 2015-02-06 13:56:32 --> Helper loaded: link_helper
DEBUG - 2015-02-06 13:56:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 13:56:32 --> CI_Session Class Initialized
DEBUG - 2015-02-06 13:56:32 --> Session: Regenerate ID
DEBUG - 2015-02-06 13:56:32 --> CI_Session routines successfully run
DEBUG - 2015-02-06 13:56:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Controller Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 13:56:33 --> Email Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 13:56:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 13:56:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 13:56:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 13:56:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 13:56:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 13:56:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Model Class Initialized
DEBUG - 2015-02-06 13:56:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 13:56:33 --> Pagination Class Initialized
DEBUG - 2015-02-06 13:56:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 13:56:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 13:56:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 13:56:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 13:56:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 13:56:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 13:56:33 --> Final output sent to browser
DEBUG - 2015-02-06 13:56:33 --> Total execution time: 1.0101
DEBUG - 2015-02-06 14:00:00 --> Config Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:00:00 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:00:00 --> URI Class Initialized
DEBUG - 2015-02-06 14:00:00 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:00:00 --> Router Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Output Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Security Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Input Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:00:00 --> Language Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Loader Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:00:00 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:00:00 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:00:00 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Controller Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:00:00 --> Email Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:00:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:00:00 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:00:00 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:00:00 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:00:00 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:00:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:00:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:00:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:00:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:00:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:00:01 --> Final output sent to browser
DEBUG - 2015-02-06 14:00:01 --> Total execution time: 0.9241
DEBUG - 2015-02-06 14:00:42 --> Config Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:00:42 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:00:42 --> URI Class Initialized
DEBUG - 2015-02-06 14:00:42 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:00:42 --> Router Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Output Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Security Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Input Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:00:42 --> Language Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Loader Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:00:42 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:00:42 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:00:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Controller Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:00:42 --> Email Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:00:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:00:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:00:42 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:00:42 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:00:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:00:42 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:00:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:00:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:00:43 --> Final output sent to browser
DEBUG - 2015-02-06 14:00:43 --> Total execution time: 0.9241
DEBUG - 2015-02-06 14:02:28 --> Config Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:02:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:02:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:02:28 --> URI Class Initialized
DEBUG - 2015-02-06 14:02:28 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:02:28 --> Router Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Output Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Security Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Input Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:02:28 --> Language Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Loader Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:02:28 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Session: Regenerate ID
DEBUG - 2015-02-06 14:02:28 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Controller Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:02:28 --> Email Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:02:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:02:28 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:02:28 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:02:28 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:02:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:02:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:02:29 --> Final output sent to browser
DEBUG - 2015-02-06 14:02:29 --> Total execution time: 1.1061
DEBUG - 2015-02-06 14:02:43 --> Config Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:02:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:02:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:02:43 --> URI Class Initialized
DEBUG - 2015-02-06 14:02:43 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:02:43 --> Router Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Output Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Security Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Input Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:02:43 --> Language Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Loader Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:02:43 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:02:43 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:02:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Controller Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:02:43 --> Email Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:02:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:02:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:02:43 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:02:43 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:02:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:02:43 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:02:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:02:44 --> Final output sent to browser
DEBUG - 2015-02-06 14:02:44 --> Total execution time: 0.8891
DEBUG - 2015-02-06 14:03:38 --> Config Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:03:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:03:38 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:03:38 --> URI Class Initialized
DEBUG - 2015-02-06 14:03:38 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:03:38 --> Router Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Output Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Security Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Input Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:03:38 --> Language Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Loader Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:03:38 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:03:38 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:03:38 --> Model Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Model Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Controller Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:03:38 --> Email Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:03:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:03:38 --> Model Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:03:38 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:03:38 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Model Class Initialized
DEBUG - 2015-02-06 14:03:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:03:38 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:03:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:03:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:03:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:03:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:03:39 --> Final output sent to browser
DEBUG - 2015-02-06 14:03:39 --> Total execution time: 1.2991
DEBUG - 2015-02-06 14:16:21 --> Config Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:16:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:16:21 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:16:21 --> URI Class Initialized
DEBUG - 2015-02-06 14:16:21 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:16:21 --> Router Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Output Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Security Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Input Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:16:21 --> Language Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Loader Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:16:21 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Session: Regenerate ID
DEBUG - 2015-02-06 14:16:21 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:16:21 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Controller Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:16:21 --> Email Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:16:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:16:21 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:16:21 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:16:21 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:16:21 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:16:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:16:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:16:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:16:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:16:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:16:22 --> Final output sent to browser
DEBUG - 2015-02-06 14:16:22 --> Total execution time: 1.0731
DEBUG - 2015-02-06 14:16:41 --> Config Class Initialized
DEBUG - 2015-02-06 14:16:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:16:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:16:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:16:41 --> URI Class Initialized
DEBUG - 2015-02-06 14:16:42 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:16:42 --> Router Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Output Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Security Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Input Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:16:42 --> Language Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Loader Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:16:42 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:16:42 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:16:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Controller Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:16:42 --> Email Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:16:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:16:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:16:42 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:16:42 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:16:42 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:16:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:16:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:16:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:16:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:16:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:16:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:16:42 --> Final output sent to browser
DEBUG - 2015-02-06 14:16:42 --> Total execution time: 0.9701
DEBUG - 2015-02-06 14:16:57 --> Config Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:16:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:16:57 --> URI Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Router Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Output Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Security Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Input Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:16:57 --> Language Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Loader Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:16:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:16:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:16:57 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Controller Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:16:57 --> Email Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:16:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:16:57 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:16:57 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:16:57 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:57 --> Model Class Initialized
DEBUG - 2015-02-06 14:16:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:16:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 14:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:16:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:16:58 --> Final output sent to browser
DEBUG - 2015-02-06 14:16:58 --> Total execution time: 0.9481
DEBUG - 2015-02-06 14:17:32 --> Config Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:17:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:17:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:17:32 --> URI Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Router Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Output Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Security Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Input Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:17:32 --> Language Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Loader Class Initialized
DEBUG - 2015-02-06 14:17:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:17:32 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:17:32 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:17:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:17:32 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:17:32 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:17:33 --> Model Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Model Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Controller Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:17:33 --> Email Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:17:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:17:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:17:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:17:33 --> Model Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:17:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:17:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Model Class Initialized
DEBUG - 2015-02-06 14:17:33 --> Model Class Initialized
DEBUG - 2015-02-06 14:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 14:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:17:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:17:33 --> Final output sent to browser
DEBUG - 2015-02-06 14:17:33 --> Total execution time: 0.9001
DEBUG - 2015-02-06 14:18:07 --> Config Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:18:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:18:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:18:07 --> URI Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Router Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Output Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Security Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Input Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:18:07 --> Language Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Loader Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:18:07 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:18:07 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Controller Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:18:07 --> Email Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:18:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:18:07 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:18:07 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:08 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 14:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:18:08 --> Final output sent to browser
DEBUG - 2015-02-06 14:18:08 --> Total execution time: 0.9771
DEBUG - 2015-02-06 14:18:12 --> Config Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:18:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:18:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:18:12 --> URI Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Router Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Output Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Security Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Input Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:18:12 --> Language Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Loader Class Initialized
DEBUG - 2015-02-06 14:18:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:18:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:18:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:18:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:18:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:18:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:18:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Controller Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:18:13 --> Email Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:18:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:18:13 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:18:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:18:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:18:13 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:18:13 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:18:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:18:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:18:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 14:18:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:18:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:18:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:18:13 --> Final output sent to browser
DEBUG - 2015-02-06 14:18:13 --> Total execution time: 0.8801
DEBUG - 2015-02-06 14:19:27 --> Config Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:19:27 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:19:27 --> URI Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Router Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Output Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Security Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Input Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:19:27 --> Language Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Loader Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:19:27 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:19:27 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:19:27 --> Model Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Model Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Controller Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:19:27 --> Email Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:19:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:19:27 --> Model Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:19:27 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:19:27 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:19:27 --> Model Class Initialized
DEBUG - 2015-02-06 14:19:28 --> Model Class Initialized
DEBUG - 2015-02-06 14:19:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:19:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:19:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 14:19:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:19:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:19:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:19:28 --> Final output sent to browser
DEBUG - 2015-02-06 14:19:28 --> Total execution time: 0.9241
DEBUG - 2015-02-06 14:23:06 --> Config Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:23:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:23:06 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:23:06 --> URI Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Router Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Output Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Security Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Input Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:23:06 --> Language Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Loader Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:23:06 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Session: Regenerate ID
DEBUG - 2015-02-06 14:23:06 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:23:06 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Controller Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:23:06 --> Email Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:23:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:23:06 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:23:06 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:23:06 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:23:06 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 14:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:23:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:23:07 --> Final output sent to browser
DEBUG - 2015-02-06 14:23:07 --> Total execution time: 0.8731
DEBUG - 2015-02-06 14:23:13 --> Config Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:23:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:23:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:23:13 --> URI Class Initialized
DEBUG - 2015-02-06 14:23:13 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:23:13 --> Router Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Output Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Security Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Input Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:23:13 --> Language Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Loader Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:23:13 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:23:13 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:23:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Controller Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:23:13 --> Email Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:23:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:23:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:23:13 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:23:13 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:23:13 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:23:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:23:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:23:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:23:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:23:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:23:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:23:14 --> Final output sent to browser
DEBUG - 2015-02-06 14:23:14 --> Total execution time: 0.9591
DEBUG - 2015-02-06 14:23:17 --> Config Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:23:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:23:17 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:23:17 --> URI Class Initialized
DEBUG - 2015-02-06 14:23:17 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:23:17 --> Router Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Output Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Security Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Input Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:23:17 --> Language Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Loader Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:23:17 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:23:17 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:23:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:23:17 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:23:17 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:23:17 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Controller Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:23:17 --> Email Class Initialized
DEBUG - 2015-02-06 14:23:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:23:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:23:17 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:23:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:23:17 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:18 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:23:18 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:23:18 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:23:18 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:23:18 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:23:18 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:23:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:23:18 --> Final output sent to browser
DEBUG - 2015-02-06 14:23:18 --> Total execution time: 0.9651
DEBUG - 2015-02-06 14:23:23 --> Config Class Initialized
DEBUG - 2015-02-06 14:23:23 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:23:24 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:23:24 --> URI Class Initialized
DEBUG - 2015-02-06 14:23:24 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:23:24 --> Router Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Output Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Security Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Input Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:23:24 --> Language Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Loader Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:23:24 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:23:24 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:23:24 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Controller Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:23:24 --> Email Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:23:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:23:24 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:23:24 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:23:24 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:23:24 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:23:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:23:24 --> Final output sent to browser
DEBUG - 2015-02-06 14:23:24 --> Total execution time: 0.9971
DEBUG - 2015-02-06 14:23:43 --> Config Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:23:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:23:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:23:43 --> URI Class Initialized
DEBUG - 2015-02-06 14:23:43 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:23:43 --> Router Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Output Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Security Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Input Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:23:43 --> Language Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Loader Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:23:43 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:23:43 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:23:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Controller Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:23:43 --> Email Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:23:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:23:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:23:43 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:23:43 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Model Class Initialized
DEBUG - 2015-02-06 14:23:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:23:43 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:23:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:23:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:23:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:23:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:23:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:23:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:23:44 --> Final output sent to browser
DEBUG - 2015-02-06 14:23:44 --> Total execution time: 1.2421
DEBUG - 2015-02-06 14:37:11 --> Config Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:37:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:37:11 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:37:11 --> URI Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Router Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Output Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Security Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Input Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:37:11 --> Language Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Loader Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:37:11 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Session: Regenerate ID
DEBUG - 2015-02-06 14:37:11 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:37:11 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Controller Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:37:11 --> Email Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:37:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:37:11 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:37:11 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:37:11 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:37:11 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 14:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 14:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/category/index.php
DEBUG - 2015-02-06 14:37:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 14:37:11 --> Final output sent to browser
DEBUG - 2015-02-06 14:37:11 --> Total execution time: 0.5391
DEBUG - 2015-02-06 14:37:15 --> Config Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:37:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:37:15 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:37:15 --> URI Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Router Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Output Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Security Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Input Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:37:15 --> Language Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Loader Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:37:15 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:37:15 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:37:15 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Controller Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:37:15 --> Email Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:37:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:37:15 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:37:15 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:37:15 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:37:15 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-06 14:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-06 14:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-06 14:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-06 14:37:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-06 14:37:15 --> Final output sent to browser
DEBUG - 2015-02-06 14:37:15 --> Total execution time: 0.6901
DEBUG - 2015-02-06 14:37:25 --> Config Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:37:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:37:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:37:25 --> URI Class Initialized
DEBUG - 2015-02-06 14:37:25 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:37:25 --> Router Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Output Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Security Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Input Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:37:25 --> Language Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Loader Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:37:25 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:37:25 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:37:25 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Controller Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:37:25 --> Email Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:37:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:37:25 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:37:25 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:37:25 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Model Class Initialized
DEBUG - 2015-02-06 14:37:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:37:25 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:37:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:37:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:37:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:37:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:37:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:37:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:37:26 --> Final output sent to browser
DEBUG - 2015-02-06 14:37:26 --> Total execution time: 0.9061
DEBUG - 2015-02-06 14:38:29 --> Config Class Initialized
DEBUG - 2015-02-06 14:38:29 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:38:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:38:29 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:38:29 --> URI Class Initialized
DEBUG - 2015-02-06 14:38:29 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:38:29 --> Router Class Initialized
DEBUG - 2015-02-06 14:38:29 --> Output Class Initialized
DEBUG - 2015-02-06 14:38:29 --> Security Class Initialized
DEBUG - 2015-02-06 14:38:29 --> Input Class Initialized
DEBUG - 2015-02-06 14:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:38:29 --> Language Class Initialized
DEBUG - 2015-02-06 14:38:29 --> Loader Class Initialized
DEBUG - 2015-02-06 14:38:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:38:29 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:38:29 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:38:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:38:29 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:38:29 --> A session cookie was not found.
DEBUG - 2015-02-06 14:38:29 --> Session: Creating new session (e007a38bf1a5d58913bacc05b81ee184)
DEBUG - 2015-02-06 14:38:29 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:38:30 --> Model Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Model Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Controller Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:38:30 --> Email Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:38:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:38:30 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:38:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:38:30 --> Model Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:38:30 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:38:30 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Model Class Initialized
DEBUG - 2015-02-06 14:38:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:38:30 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:38:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:38:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:38:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:38:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:38:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:38:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:38:30 --> Final output sent to browser
DEBUG - 2015-02-06 14:38:30 --> Total execution time: 0.8931
DEBUG - 2015-02-06 14:39:54 --> Config Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:39:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:39:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:39:54 --> URI Class Initialized
DEBUG - 2015-02-06 14:39:54 --> No URI present. Default controller set.
DEBUG - 2015-02-06 14:39:54 --> Router Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Output Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Security Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Input Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:39:54 --> Language Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Loader Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:39:54 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:39:54 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:39:54 --> Model Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Model Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Controller Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:39:54 --> Email Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:39:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:39:54 --> Model Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:39:54 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:39:54 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Model Class Initialized
DEBUG - 2015-02-06 14:39:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:39:54 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:39:55 --> Final output sent to browser
DEBUG - 2015-02-06 14:39:55 --> Total execution time: 1.0451
DEBUG - 2015-02-06 14:40:03 --> Config Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:40:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:40:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:40:03 --> URI Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Router Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Output Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Security Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Input Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:40:03 --> Language Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Loader Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:40:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:40:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:40:03 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Controller Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:40:03 --> Email Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:40:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:40:03 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:40:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:40:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:40:03 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:40:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:40:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:40:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:40:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:40:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:40:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:40:04 --> Final output sent to browser
DEBUG - 2015-02-06 14:40:04 --> Total execution time: 0.9301
DEBUG - 2015-02-06 14:40:07 --> Config Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:40:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:40:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:40:07 --> URI Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Router Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Output Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Security Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Input Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:40:07 --> Language Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Loader Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:40:07 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:40:07 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:40:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Controller Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:40:07 --> Email Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:40:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:40:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:40:07 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:40:07 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 14:40:07 --> Pagination Class Initialized
DEBUG - 2015-02-06 14:40:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:40:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 14:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:40:08 --> Final output sent to browser
DEBUG - 2015-02-06 14:40:08 --> Total execution time: 1.0371
DEBUG - 2015-02-06 14:40:17 --> Config Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:40:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:40:17 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:40:17 --> URI Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Router Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Output Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Security Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Input Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:40:17 --> Language Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Loader Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:40:17 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:40:17 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:40:17 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Controller Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:40:17 --> Email Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:40:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:40:17 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:40:17 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:40:17 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:40:17 --> Model Class Initialized
DEBUG - 2015-02-06 14:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 14:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:40:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
ERROR - 2015-02-06 14:40:18 --> Severity: error --> Exception: The identifier id is missing for a query of Entity\Users D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 160
DEBUG - 2015-02-06 14:41:47 --> Config Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:41:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:41:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:41:47 --> URI Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Router Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Output Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Security Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Input Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:41:47 --> Language Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Loader Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:41:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:41:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:41:47 --> Model Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Model Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Controller Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:41:47 --> Email Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:41:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:41:47 --> Model Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:41:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:41:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:41:47 --> Model Class Initialized
DEBUG - 2015-02-06 14:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 14:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:41:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:41:48 --> Final output sent to browser
DEBUG - 2015-02-06 14:41:48 --> Total execution time: 1.5752
DEBUG - 2015-02-06 14:56:49 --> Config Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Hooks Class Initialized
DEBUG - 2015-02-06 14:56:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 14:56:49 --> Utf8 Class Initialized
DEBUG - 2015-02-06 14:56:49 --> URI Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Router Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Output Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Security Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Input Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 14:56:49 --> Language Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Loader Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: url_helper
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: link_helper
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 14:56:49 --> CI_Session Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Session: Regenerate ID
DEBUG - 2015-02-06 14:56:49 --> CI_Session routines successfully run
DEBUG - 2015-02-06 14:56:49 --> Model Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Model Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Controller Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 14:56:49 --> Email Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: language_helper
DEBUG - 2015-02-06 14:56:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 14:56:49 --> Model Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Database Driver Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: date_helper
DEBUG - 2015-02-06 14:56:49 --> Helper loaded: form_helper
DEBUG - 2015-02-06 14:56:49 --> Form Validation Class Initialized
DEBUG - 2015-02-06 14:56:49 --> Model Class Initialized
DEBUG - 2015-02-06 14:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 14:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 14:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 14:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 14:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 14:56:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 14:56:50 --> Final output sent to browser
DEBUG - 2015-02-06 14:56:50 --> Total execution time: 1.2221
DEBUG - 2015-02-06 15:00:35 --> Config Class Initialized
DEBUG - 2015-02-06 15:00:35 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:00:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:00:35 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:00:35 --> URI Class Initialized
DEBUG - 2015-02-06 15:00:35 --> Router Class Initialized
DEBUG - 2015-02-06 15:00:35 --> Output Class Initialized
DEBUG - 2015-02-06 15:00:35 --> Security Class Initialized
DEBUG - 2015-02-06 15:00:35 --> Input Class Initialized
DEBUG - 2015-02-06 15:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:00:35 --> Language Class Initialized
DEBUG - 2015-02-06 15:00:35 --> Loader Class Initialized
ERROR - 2015-02-06 15:00:35 --> Severity: Compile Error --> Cannot redeclare getRandomArticle() (previously declared in D:\phutx\project\ups\myblog\application\helpers\admin_helper.php:68) D:\phutx\project\ups\myblog\application\helpers\admin_helper.php 93
DEBUG - 2015-02-06 15:00:48 --> Config Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:00:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:00:48 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:00:48 --> URI Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Router Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Output Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Security Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Input Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:00:48 --> Language Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Loader Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:00:48 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:00:48 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:00:48 --> Model Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Model Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Controller Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:00:48 --> Email Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:00:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:00:48 --> Model Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:00:48 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:00:48 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Model Class Initialized
DEBUG - 2015-02-06 15:00:48 --> Model Class Initialized
DEBUG - 2015-02-06 15:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:00:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:00:49 --> Final output sent to browser
DEBUG - 2015-02-06 15:00:49 --> Total execution time: 1.6682
DEBUG - 2015-02-06 15:01:51 --> Config Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:01:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:01:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:01:51 --> URI Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Router Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Output Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Security Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Input Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:01:51 --> Language Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Loader Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:01:51 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:01:51 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:01:51 --> Model Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Model Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Controller Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:01:51 --> Email Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:01:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:01:51 --> Model Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:01:51 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:01:51 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:01:51 --> Model Class Initialized
DEBUG - 2015-02-06 15:01:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:01:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:01:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:01:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:01:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:01:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:01:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:01:52 --> Final output sent to browser
DEBUG - 2015-02-06 15:01:52 --> Total execution time: 1.1431
DEBUG - 2015-02-06 15:02:09 --> Config Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:02:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:02:09 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:02:09 --> URI Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Router Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Output Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Security Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Input Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:02:09 --> Language Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Loader Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:02:09 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:02:09 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:02:09 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Controller Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:02:09 --> Email Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:02:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:02:09 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:02:09 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:02:09 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:02:09 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:10 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:02:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:02:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:02:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:02:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:02:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:02:10 --> Final output sent to browser
DEBUG - 2015-02-06 15:02:10 --> Total execution time: 1.1341
DEBUG - 2015-02-06 15:02:24 --> Config Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:02:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:02:24 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:02:24 --> URI Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Router Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Output Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Security Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Input Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:02:24 --> Language Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Loader Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:02:24 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:02:24 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:02:24 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Controller Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:02:24 --> Email Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:02:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:02:24 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:02:24 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:02:24 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:02:24 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:25 --> Model Class Initialized
DEBUG - 2015-02-06 15:02:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:02:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:02:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:02:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:02:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:02:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:02:26 --> Final output sent to browser
DEBUG - 2015-02-06 15:02:26 --> Total execution time: 1.5622
DEBUG - 2015-02-06 15:14:11 --> Config Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:14:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:14:11 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:14:11 --> URI Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Router Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Output Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Security Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Input Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:14:11 --> Language Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Loader Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:14:11 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:14:11 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:14:11 --> Model Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Model Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Controller Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:14:11 --> Email Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:14:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:14:11 --> Model Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:14:11 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:14:11 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:14:11 --> Model Class Initialized
DEBUG - 2015-02-06 15:14:12 --> Model Class Initialized
DEBUG - 2015-02-06 15:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:14:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:14:12 --> Final output sent to browser
DEBUG - 2015-02-06 15:14:12 --> Total execution time: 1.3041
DEBUG - 2015-02-06 15:15:28 --> Config Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:15:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:15:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:15:28 --> URI Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Router Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Output Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Security Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Input Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:15:28 --> Language Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Loader Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:15:28 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:15:28 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:15:28 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Controller Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:15:28 --> Email Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:15:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:15:28 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:15:28 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:15:28 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:15:28 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:29 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:15:29 --> Final output sent to browser
DEBUG - 2015-02-06 15:15:29 --> Total execution time: 1.3211
DEBUG - 2015-02-06 15:15:53 --> Config Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:15:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:15:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:15:53 --> URI Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Router Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Output Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Security Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Input Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:15:53 --> Language Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Loader Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:15:53 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:15:53 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:15:53 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Controller Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:15:53 --> Email Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:15:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:15:53 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:15:53 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:15:53 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:15:53 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:54 --> Model Class Initialized
DEBUG - 2015-02-06 15:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:15:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:15:55 --> Final output sent to browser
DEBUG - 2015-02-06 15:15:55 --> Total execution time: 1.9222
DEBUG - 2015-02-06 15:16:47 --> Config Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:16:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:16:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:16:47 --> URI Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Router Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Output Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Security Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Input Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:16:47 --> Language Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Loader Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:16:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:16:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:16:47 --> Model Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Model Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Controller Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:16:47 --> Email Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:16:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:16:47 --> Model Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:16:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:16:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:16:47 --> Model Class Initialized
DEBUG - 2015-02-06 15:16:48 --> Model Class Initialized
DEBUG - 2015-02-06 15:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:16:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:16:48 --> Final output sent to browser
DEBUG - 2015-02-06 15:16:48 --> Total execution time: 1.2111
DEBUG - 2015-02-06 15:17:16 --> Config Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:17:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:17:16 --> URI Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Router Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Output Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Security Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Input Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:17:16 --> Language Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Loader Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:17:16 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:17:16 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:17:16 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Controller Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:17:16 --> Email Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:17:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:17:16 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:17:16 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:17:16 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:17:16 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:17 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:17:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:17:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:17:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:17:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:17:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:17:17 --> Final output sent to browser
DEBUG - 2015-02-06 15:17:17 --> Total execution time: 1.1621
DEBUG - 2015-02-06 15:17:35 --> Config Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:17:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:17:35 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:17:35 --> URI Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Router Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Output Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Security Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Input Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:17:35 --> Language Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Loader Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:17:35 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:17:35 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Controller Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:17:35 --> Email Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:17:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:17:35 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:17:35 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:17:35 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:36 --> Model Class Initialized
DEBUG - 2015-02-06 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:17:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:17:37 --> Final output sent to browser
DEBUG - 2015-02-06 15:17:37 --> Total execution time: 1.5302
DEBUG - 2015-02-06 15:18:07 --> Config Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:18:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:18:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:18:07 --> URI Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Router Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Output Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Security Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Input Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:18:07 --> Language Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Loader Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:18:07 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:18:07 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Controller Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:18:07 --> Email Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:18:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:18:07 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:18:07 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:18:07 --> Model Class Initialized
DEBUG - 2015-02-06 15:18:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:18:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:18:08 --> Final output sent to browser
DEBUG - 2015-02-06 15:18:08 --> Total execution time: 1.1391
DEBUG - 2015-02-06 15:19:30 --> Config Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:19:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:19:30 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:19:30 --> URI Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Router Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Output Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Security Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Input Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:19:30 --> Language Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Loader Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:19:30 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:19:30 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:19:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Controller Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:19:30 --> Email Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:19:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:19:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:19:30 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:19:30 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:19:30 --> Model Class Initialized
ERROR - 2015-02-06 15:19:31 --> Severity: Warning --> Missing argument 1 for getTag(), called in D:\phutx\project\ups\myblog\application\views\layout\nav.php on line 45 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-06 15:19:31 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\helpers\link_helper.php 34
ERROR - 2015-02-06 15:19:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\application\helpers\link_helper.php 34
ERROR - 2015-02-06 15:19:31 --> Severity: Warning --> Missing argument 1 for getTag(), called in D:\phutx\project\ups\myblog\application\views\layout\nav.php on line 50 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-06 15:19:31 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\helpers\link_helper.php 34
ERROR - 2015-02-06 15:19:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\application\helpers\link_helper.php 34
ERROR - 2015-02-06 15:19:31 --> Severity: Warning --> Missing argument 1 for getTag(), called in D:\phutx\project\ups\myblog\application\views\layout\nav.php on line 55 and defined D:\phutx\project\ups\myblog\application\helpers\link_helper.php 32
ERROR - 2015-02-06 15:19:31 --> Severity: Notice --> Undefined variable: article D:\phutx\project\ups\myblog\application\helpers\link_helper.php 34
ERROR - 2015-02-06 15:19:31 --> Severity: Warning --> Invalid argument supplied for foreach() D:\phutx\project\ups\myblog\application\helpers\link_helper.php 34
DEBUG - 2015-02-06 15:19:31 --> Model Class Initialized
DEBUG - 2015-02-06 15:19:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:19:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:19:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:19:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:19:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:19:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:19:31 --> Final output sent to browser
DEBUG - 2015-02-06 15:19:31 --> Total execution time: 1.2361
DEBUG - 2015-02-06 15:24:33 --> Config Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:24:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:24:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:24:33 --> URI Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Router Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Output Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Security Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Input Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:24:33 --> Language Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Loader Class Initialized
DEBUG - 2015-02-06 15:24:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:24:33 --> Helper loaded: url_helper
ERROR - 2015-02-06 15:24:33 --> Severity: Compile Error --> Cannot redeclare getTag() (previously declared in D:\phutx\project\ups\myblog\application\helpers\admin_helper.php:95) D:\phutx\project\ups\myblog\application\helpers\link_helper.php 38
DEBUG - 2015-02-06 15:25:34 --> Config Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:25:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:25:34 --> URI Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Router Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Output Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Security Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Input Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:25:34 --> Language Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Loader Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:25:34 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:25:34 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:25:34 --> Model Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Model Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Controller Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:25:34 --> Email Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:25:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:25:34 --> Model Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:25:34 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:25:34 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:25:34 --> Model Class Initialized
DEBUG - 2015-02-06 15:25:35 --> Model Class Initialized
ERROR - 2015-02-06 15:25:35 --> Severity: Notice --> Undefined property: article::$tag_model D:\phutx\project\ups\myblog\application\helpers\admin_helper.php 98
ERROR - 2015-02-06 15:25:35 --> Severity: Error --> Call to a member function getAll() on a non-object D:\phutx\project\ups\myblog\application\helpers\admin_helper.php 98
DEBUG - 2015-02-06 15:25:59 --> Config Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:25:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:25:59 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:25:59 --> URI Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Router Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Output Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Security Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Input Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:25:59 --> Language Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Loader Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:25:59 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:25:59 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:25:59 --> Model Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Model Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Controller Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:25:59 --> Email Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:25:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:25:59 --> Model Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:25:59 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:25:59 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:25:59 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:00 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:00 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:26:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:26:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:26:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:26:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:26:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:26:01 --> Final output sent to browser
DEBUG - 2015-02-06 15:26:01 --> Total execution time: 1.3361
DEBUG - 2015-02-06 15:26:01 --> Config Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:26:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:26:01 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:26:01 --> URI Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Router Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Output Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Security Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Input Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:26:01 --> Language Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Loader Class Initialized
DEBUG - 2015-02-06 15:26:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:26:01 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:26:01 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:26:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:26:01 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:26:01 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:26:02 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Controller Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:26:02 --> Email Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:26:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:26:02 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:26:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:26:02 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:26:02 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:26:02 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:02 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:03 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:26:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:26:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:26:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:26:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:26:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:26:03 --> Final output sent to browser
DEBUG - 2015-02-06 15:26:03 --> Total execution time: 1.4171
DEBUG - 2015-02-06 15:26:30 --> Config Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:26:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:26:30 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:26:30 --> URI Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Router Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Output Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Security Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Input Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:26:30 --> Language Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Loader Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:26:30 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:26:30 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:26:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Controller Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:26:30 --> Email Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:26:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:26:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:26:30 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:26:30 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:26:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:31 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:31 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:26:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:26:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:26:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:26:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:26:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:26:31 --> Final output sent to browser
DEBUG - 2015-02-06 15:26:31 --> Total execution time: 1.3951
DEBUG - 2015-02-06 15:26:48 --> Config Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:26:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:26:48 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:26:48 --> URI Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Router Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Output Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Security Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Input Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:26:48 --> Language Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Loader Class Initialized
DEBUG - 2015-02-06 15:26:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:26:48 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:26:48 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:26:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:26:48 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:26:48 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:26:49 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Controller Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:26:49 --> Email Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:26:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:26:49 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:26:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:26:49 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:26:49 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:26:49 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:49 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:50 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:26:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:26:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:26:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:26:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:26:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:26:50 --> Final output sent to browser
DEBUG - 2015-02-06 15:26:50 --> Total execution time: 1.3401
DEBUG - 2015-02-06 15:26:57 --> Config Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:26:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:26:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:26:57 --> URI Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Router Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Output Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Security Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Input Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:26:57 --> Language Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Loader Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:26:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:26:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:26:57 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Controller Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:26:57 --> Email Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:26:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:26:57 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:26:57 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:26:57 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:26:57 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:58 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:58 --> Model Class Initialized
DEBUG - 2015-02-06 15:26:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:26:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:26:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:26:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:26:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:26:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:26:59 --> Final output sent to browser
DEBUG - 2015-02-06 15:26:59 --> Total execution time: 1.3961
DEBUG - 2015-02-06 15:27:02 --> Config Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:27:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:27:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:27:02 --> URI Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Router Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Output Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Security Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Input Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:27:02 --> Language Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Loader Class Initialized
DEBUG - 2015-02-06 15:27:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:27:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:27:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:27:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:27:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:27:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:27:03 --> Model Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Model Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Controller Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:27:03 --> Email Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:27:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:27:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:27:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:27:03 --> Model Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:27:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:27:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Model Class Initialized
DEBUG - 2015-02-06 15:27:03 --> Model Class Initialized
DEBUG - 2015-02-06 15:27:04 --> Model Class Initialized
DEBUG - 2015-02-06 15:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:27:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:27:04 --> Final output sent to browser
DEBUG - 2015-02-06 15:27:04 --> Total execution time: 1.6712
DEBUG - 2015-02-06 15:28:01 --> Config Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:28:01 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:28:01 --> URI Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Router Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Output Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Security Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Input Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:28:01 --> Language Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Loader Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:28:01 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:28:01 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:28:01 --> Model Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Model Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Controller Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:28:01 --> Email Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:28:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:28:01 --> Model Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:28:01 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:28:01 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:28:01 --> Model Class Initialized
DEBUG - 2015-02-06 15:28:02 --> Model Class Initialized
DEBUG - 2015-02-06 15:28:02 --> Model Class Initialized
DEBUG - 2015-02-06 15:28:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:28:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:28:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:28:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:28:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:28:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:28:02 --> Final output sent to browser
DEBUG - 2015-02-06 15:28:02 --> Total execution time: 1.3481
DEBUG - 2015-02-06 15:31:51 --> Config Class Initialized
DEBUG - 2015-02-06 15:31:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:31:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:31:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:31:51 --> URI Class Initialized
DEBUG - 2015-02-06 15:31:51 --> Router Class Initialized
DEBUG - 2015-02-06 15:31:51 --> Output Class Initialized
DEBUG - 2015-02-06 15:31:51 --> Security Class Initialized
DEBUG - 2015-02-06 15:31:51 --> Input Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:31:52 --> Language Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Loader Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:31:52 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:31:52 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:31:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Controller Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:31:52 --> Email Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:31:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:31:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:31:52 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:31:52 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:31:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:31:53 --> Model Class Initialized
DEBUG - 2015-02-06 15:31:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:31:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:31:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:31:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:31:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:31:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:31:53 --> Final output sent to browser
DEBUG - 2015-02-06 15:31:53 --> Total execution time: 1.5402
DEBUG - 2015-02-06 15:33:37 --> Config Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:33:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:33:37 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:33:37 --> URI Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Router Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Output Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Security Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Input Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:33:37 --> Language Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Loader Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:33:37 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:33:37 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:33:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Controller Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:33:37 --> Email Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:33:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:33:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:33:37 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:33:37 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:33:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:33:38 --> Model Class Initialized
DEBUG - 2015-02-06 15:33:38 --> Model Class Initialized
DEBUG - 2015-02-06 15:33:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:33:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:33:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 15:33:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:33:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:33:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:33:38 --> Final output sent to browser
DEBUG - 2015-02-06 15:33:38 --> Total execution time: 1.3501
DEBUG - 2015-02-06 15:36:13 --> Config Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:36:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:36:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:36:13 --> URI Class Initialized
DEBUG - 2015-02-06 15:36:13 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:36:13 --> Router Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Output Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Security Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Input Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:36:13 --> Language Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Loader Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:36:13 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:36:13 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:36:13 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Controller Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:36:13 --> Email Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:36:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:36:13 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:36:13 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:36:13 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:36:13 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:36:14 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:14 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:36:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:36:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:36:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:36:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:36:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:36:14 --> Final output sent to browser
DEBUG - 2015-02-06 15:36:14 --> Total execution time: 1.3031
DEBUG - 2015-02-06 15:36:39 --> Config Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:36:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:36:39 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:36:39 --> URI Class Initialized
DEBUG - 2015-02-06 15:36:39 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:36:39 --> Router Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Output Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Security Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Input Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:36:39 --> Language Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Loader Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:36:39 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:36:39 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:36:39 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Controller Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:36:39 --> Email Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:36:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:36:39 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:36:39 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:36:39 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:36:39 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:36:40 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:40 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:36:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:36:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:36:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:36:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:36:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:36:40 --> Final output sent to browser
DEBUG - 2015-02-06 15:36:40 --> Total execution time: 1.2401
DEBUG - 2015-02-06 15:36:46 --> Config Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:36:46 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:36:46 --> URI Class Initialized
DEBUG - 2015-02-06 15:36:46 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:36:46 --> Router Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Output Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Security Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Input Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:36:46 --> Language Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Loader Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:36:46 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:36:46 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:36:46 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Controller Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:36:46 --> Email Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:36:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:36:46 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:36:46 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:36:46 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:36:46 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:46 --> Model Class Initialized
DEBUG - 2015-02-06 15:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:36:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:36:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:36:47 --> Final output sent to browser
DEBUG - 2015-02-06 15:36:47 --> Total execution time: 1.2081
DEBUG - 2015-02-06 15:38:08 --> Config Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:38:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:38:08 --> URI Class Initialized
DEBUG - 2015-02-06 15:38:08 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:38:08 --> Router Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Output Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Security Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Input Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:38:08 --> Language Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Loader Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:38:08 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:38:08 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:38:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:38:08 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:38:08 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Controller Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:38:08 --> Email Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:38:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:38:08 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:38:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:38:08 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:38:09 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:38:09 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:38:09 --> Model Class Initialized
DEBUG - 2015-02-06 15:38:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:38:09 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:38:09 --> Model Class Initialized
DEBUG - 2015-02-06 15:38:09 --> Model Class Initialized
DEBUG - 2015-02-06 15:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:38:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:38:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:38:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:38:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:38:10 --> Final output sent to browser
DEBUG - 2015-02-06 15:38:10 --> Total execution time: 1.2721
DEBUG - 2015-02-06 15:39:04 --> Config Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:39:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:39:04 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:39:04 --> URI Class Initialized
DEBUG - 2015-02-06 15:39:04 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:39:04 --> Router Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Output Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Security Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Input Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:39:04 --> Language Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Loader Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:39:04 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:39:04 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:39:04 --> Model Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Model Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Controller Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:39:04 --> Email Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:39:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:39:04 --> Model Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:39:04 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:39:04 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Model Class Initialized
DEBUG - 2015-02-06 15:39:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:39:04 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:39:05 --> Model Class Initialized
DEBUG - 2015-02-06 15:39:05 --> Model Class Initialized
DEBUG - 2015-02-06 15:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:39:05 --> Final output sent to browser
DEBUG - 2015-02-06 15:39:05 --> Total execution time: 1.2251
DEBUG - 2015-02-06 15:40:08 --> Config Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:40:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:40:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:40:08 --> URI Class Initialized
DEBUG - 2015-02-06 15:40:08 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:40:08 --> Router Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Output Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Security Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Input Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:40:08 --> Language Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Loader Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:40:08 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:40:08 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:40:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Controller Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:40:08 --> Email Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:40:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:40:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:40:08 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:40:08 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:40:08 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:08 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:40:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:40:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:40:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:40:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:40:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:40:09 --> Final output sent to browser
DEBUG - 2015-02-06 15:40:09 --> Total execution time: 1.2321
DEBUG - 2015-02-06 15:40:23 --> Config Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:40:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:40:23 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:40:23 --> URI Class Initialized
DEBUG - 2015-02-06 15:40:23 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:40:23 --> Router Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Output Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Security Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Input Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:40:23 --> Language Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Loader Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:40:23 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:40:23 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:40:23 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Controller Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:40:23 --> Email Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:40:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:40:23 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:40:23 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:40:23 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:40:23 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:23 --> Model Class Initialized
DEBUG - 2015-02-06 15:40:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:40:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:40:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:40:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:40:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:40:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:40:24 --> Final output sent to browser
DEBUG - 2015-02-06 15:40:24 --> Total execution time: 1.3031
DEBUG - 2015-02-06 15:41:29 --> Config Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:41:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:41:29 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:41:29 --> URI Class Initialized
DEBUG - 2015-02-06 15:41:29 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:41:29 --> Router Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Output Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Security Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Input Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:41:29 --> Language Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Loader Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:41:29 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:41:29 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:41:29 --> Model Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Model Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Controller Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:41:29 --> Email Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:41:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:41:29 --> Model Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:41:29 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:41:29 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Model Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:41:29 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:41:29 --> Model Class Initialized
DEBUG - 2015-02-06 15:41:30 --> Model Class Initialized
DEBUG - 2015-02-06 15:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:41:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:41:30 --> Final output sent to browser
DEBUG - 2015-02-06 15:41:30 --> Total execution time: 1.2461
DEBUG - 2015-02-06 15:43:37 --> Config Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:43:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:43:37 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:43:37 --> URI Class Initialized
DEBUG - 2015-02-06 15:43:37 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:43:37 --> Router Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Output Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Security Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Input Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:43:37 --> Language Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Loader Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:43:37 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:43:37 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:43:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Controller Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:43:37 --> Email Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:43:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:43:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:43:37 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:43:37 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Model Class Initialized
DEBUG - 2015-02-06 15:43:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:43:37 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:43:38 --> Model Class Initialized
ERROR - 2015-02-06 15:43:38 --> Severity: error --> Exception: Unrecognized field: 0 D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 70
DEBUG - 2015-02-06 15:44:15 --> Config Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:44:15 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:44:15 --> URI Class Initialized
DEBUG - 2015-02-06 15:44:15 --> No URI present. Default controller set.
DEBUG - 2015-02-06 15:44:15 --> Router Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Output Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Security Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Input Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:44:15 --> Language Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Loader Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:44:15 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:44:15 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:44:15 --> Model Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Model Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Controller Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:44:15 --> Email Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:44:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:44:15 --> Model Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:44:15 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:44:15 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Model Class Initialized
DEBUG - 2015-02-06 15:44:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:44:15 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:44:16 --> Model Class Initialized
DEBUG - 2015-02-06 15:44:16 --> Model Class Initialized
DEBUG - 2015-02-06 15:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:44:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:44:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:44:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:44:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:44:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:44:17 --> Final output sent to browser
DEBUG - 2015-02-06 15:44:17 --> Total execution time: 1.2181
DEBUG - 2015-02-06 15:55:52 --> Config Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:55:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:55:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:55:52 --> URI Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Router Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Output Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Security Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Input Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:55:52 --> Language Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Loader Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:55:52 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Session: Regenerate ID
DEBUG - 2015-02-06 15:55:52 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:55:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Controller Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:55:52 --> Email Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:55:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:55:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:55:52 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:55:52 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:55:52 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:55:52 --> Model Class Initialized
DEBUG - 2015-02-06 15:55:53 --> Model Class Initialized
DEBUG - 2015-02-06 15:55:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:55:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:55:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:55:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:55:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:55:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:55:53 --> Final output sent to browser
DEBUG - 2015-02-06 15:55:53 --> Total execution time: 1.1821
DEBUG - 2015-02-06 15:57:25 --> Config Class Initialized
DEBUG - 2015-02-06 15:57:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 15:57:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 15:57:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 15:57:25 --> URI Class Initialized
DEBUG - 2015-02-06 15:57:25 --> Router Class Initialized
DEBUG - 2015-02-06 15:57:25 --> Output Class Initialized
DEBUG - 2015-02-06 15:57:25 --> Security Class Initialized
DEBUG - 2015-02-06 15:57:25 --> Input Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 15:57:26 --> Language Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Loader Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: url_helper
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: link_helper
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 15:57:26 --> CI_Session Class Initialized
DEBUG - 2015-02-06 15:57:26 --> CI_Session routines successfully run
DEBUG - 2015-02-06 15:57:26 --> Model Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Model Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Controller Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 15:57:26 --> Email Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: language_helper
DEBUG - 2015-02-06 15:57:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 15:57:26 --> Model Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Database Driver Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: date_helper
DEBUG - 2015-02-06 15:57:26 --> Helper loaded: form_helper
DEBUG - 2015-02-06 15:57:26 --> Form Validation Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Model Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 15:57:26 --> Pagination Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Model Class Initialized
DEBUG - 2015-02-06 15:57:26 --> Model Class Initialized
DEBUG - 2015-02-06 15:57:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 15:57:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 15:57:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 15:57:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 15:57:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 15:57:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 15:57:27 --> Final output sent to browser
DEBUG - 2015-02-06 15:57:27 --> Total execution time: 1.1171
DEBUG - 2015-02-06 16:00:29 --> Config Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:00:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:00:29 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:00:29 --> URI Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Router Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Output Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Security Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Input Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:00:29 --> Language Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Loader Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:00:29 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:00:29 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:00:29 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Controller Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:00:29 --> Email Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:00:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:00:29 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:00:29 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:00:29 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:00:29 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:00:30 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:30 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:00:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:00:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:00:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:00:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:00:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:00:30 --> Final output sent to browser
DEBUG - 2015-02-06 16:00:30 --> Total execution time: 1.0781
DEBUG - 2015-02-06 16:00:34 --> Config Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:00:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:00:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:00:34 --> URI Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Router Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Output Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Security Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Input Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:00:34 --> Language Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Loader Class Initialized
DEBUG - 2015-02-06 16:00:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:00:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:00:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:00:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:00:35 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:00:35 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:00:35 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Controller Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:00:35 --> Email Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:00:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:00:35 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:00:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:00:35 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:00:35 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:00:35 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:00:35 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:35 --> Model Class Initialized
DEBUG - 2015-02-06 16:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:00:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:00:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:00:36 --> Final output sent to browser
DEBUG - 2015-02-06 16:00:36 --> Total execution time: 1.2031
DEBUG - 2015-02-06 16:01:14 --> Config Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:01:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:01:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:01:14 --> URI Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Router Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Output Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Security Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Input Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:01:14 --> Language Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Loader Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:01:14 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Session: Regenerate ID
DEBUG - 2015-02-06 16:01:14 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:01:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Controller Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:01:14 --> Email Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:01:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:01:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:01:14 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:01:14 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:01:14 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:01:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:01:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:01:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:01:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:01:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:01:15 --> Final output sent to browser
DEBUG - 2015-02-06 16:01:15 --> Total execution time: 1.2511
DEBUG - 2015-02-06 16:01:27 --> Config Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:01:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:01:27 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:01:27 --> URI Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Router Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Output Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Security Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Input Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:01:27 --> Language Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Loader Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:01:27 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:01:27 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:01:27 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Controller Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:01:27 --> Email Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:01:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:01:27 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:01:27 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:01:27 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:01:27 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:01:27 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:28 --> Model Class Initialized
DEBUG - 2015-02-06 16:01:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:01:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:01:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:01:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:01:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:01:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:01:28 --> Final output sent to browser
DEBUG - 2015-02-06 16:01:28 --> Total execution time: 1.2541
DEBUG - 2015-02-06 16:02:12 --> Config Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:02:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:02:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:02:12 --> URI Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Router Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Output Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Security Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Input Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:02:12 --> Language Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Loader Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:02:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:02:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Controller Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:02:12 --> Email Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:02:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:02:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:02:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:02:12 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 16:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 16:02:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:02:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:02:13 --> Final output sent to browser
DEBUG - 2015-02-06 16:02:13 --> Total execution time: 1.3011
DEBUG - 2015-02-06 16:03:54 --> Config Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:03:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:03:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:03:54 --> URI Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Router Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Output Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Security Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Input Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:03:54 --> Language Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Loader Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:03:54 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:03:54 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:03:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Controller Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:03:54 --> Email Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:03:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:03:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:03:54 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:03:54 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:03:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:03:54 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:03:55 --> Model Class Initialized
DEBUG - 2015-02-06 16:03:55 --> Model Class Initialized
DEBUG - 2015-02-06 16:03:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:03:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:03:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:03:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:03:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:03:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:03:55 --> Final output sent to browser
DEBUG - 2015-02-06 16:03:55 --> Total execution time: 1.3911
DEBUG - 2015-02-06 16:04:22 --> Config Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:04:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:04:22 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:04:22 --> URI Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Router Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Output Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Security Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Input Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:04:22 --> Language Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Loader Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:04:22 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:04:22 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:04:22 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Controller Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:04:22 --> Email Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:04:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:04:22 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:04:22 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:04:22 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:04:22 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:22 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:04:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:04:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:04:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:04:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:04:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:04:23 --> Final output sent to browser
DEBUG - 2015-02-06 16:04:23 --> Total execution time: 1.3441
DEBUG - 2015-02-06 16:04:58 --> Config Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:04:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:04:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:04:58 --> URI Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Router Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Output Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Security Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Input Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:04:58 --> Language Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Loader Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:04:58 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:04:58 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:04:58 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Controller Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:04:58 --> Email Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:04:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:04:58 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:04:58 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:04:58 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:04:58 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:04:58 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:59 --> Model Class Initialized
DEBUG - 2015-02-06 16:04:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:04:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:04:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:04:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:04:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:04:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:04:59 --> Final output sent to browser
DEBUG - 2015-02-06 16:04:59 --> Total execution time: 1.2431
DEBUG - 2015-02-06 16:20:02 --> Config Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:20:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:20:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:20:02 --> URI Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Router Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Output Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Security Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Input Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:20:02 --> Language Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Loader Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:20:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Session: Regenerate ID
DEBUG - 2015-02-06 16:20:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:20:02 --> Model Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Model Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Controller Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:20:02 --> Email Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:20:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:20:02 --> Model Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:20:02 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:20:02 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Model Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:20:02 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Model Class Initialized
DEBUG - 2015-02-06 16:20:02 --> Model Class Initialized
DEBUG - 2015-02-06 16:20:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:20:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:20:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:20:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:20:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:20:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:20:03 --> Final output sent to browser
DEBUG - 2015-02-06 16:20:03 --> Total execution time: 1.2941
DEBUG - 2015-02-06 16:35:05 --> Config Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:35:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:35:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:35:05 --> URI Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Router Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Output Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Security Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Input Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:35:05 --> Language Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Loader Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:35:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Session: Regenerate ID
DEBUG - 2015-02-06 16:35:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:35:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Controller Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:35:05 --> Email Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:35:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:35:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:35:05 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:35:05 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:35:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:35:05 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:35:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:35:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:35:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:35:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:35:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:35:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:35:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:35:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:35:07 --> Final output sent to browser
DEBUG - 2015-02-06 16:35:07 --> Total execution time: 1.5112
DEBUG - 2015-02-06 16:38:08 --> Config Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:38:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:38:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:38:08 --> URI Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Router Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Output Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Security Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Input Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:38:08 --> Language Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Loader Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:38:08 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:38:08 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Controller Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:38:08 --> Email Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:38:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:38:08 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:38:08 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:38:08 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:38:08 --> Model Class Initialized
DEBUG - 2015-02-06 16:38:09 --> Model Class Initialized
DEBUG - 2015-02-06 16:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:38:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:38:09 --> Final output sent to browser
DEBUG - 2015-02-06 16:38:09 --> Total execution time: 1.4962
DEBUG - 2015-02-06 16:40:18 --> Config Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:40:18 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:40:18 --> URI Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Router Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Output Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Security Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Input Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:40:18 --> Language Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Loader Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:40:18 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Session: Regenerate ID
DEBUG - 2015-02-06 16:40:18 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:40:18 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Controller Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:40:18 --> Email Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:40:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:40:18 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:40:18 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:40:18 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:40:18 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:40:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:40:19 --> Final output sent to browser
DEBUG - 2015-02-06 16:40:19 --> Total execution time: 1.2761
DEBUG - 2015-02-06 16:40:25 --> Config Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:40:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:40:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:40:25 --> URI Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Router Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Output Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Security Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Input Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:40:25 --> Language Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Loader Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:40:25 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:40:25 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:40:25 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Controller Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:40:25 --> Email Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:40:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:40:25 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:40:25 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:40:25 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:40:25 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:40:25 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:26 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:40:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:40:26 --> Final output sent to browser
DEBUG - 2015-02-06 16:40:26 --> Total execution time: 1.3311
DEBUG - 2015-02-06 16:40:43 --> Config Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:40:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:40:43 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:40:43 --> URI Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Router Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Output Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Security Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Input Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:40:43 --> Language Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Loader Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:40:43 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:40:43 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:40:43 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Controller Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:40:43 --> Email Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:40:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:40:43 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:40:43 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:40:43 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:40:43 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:40:43 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:44 --> Model Class Initialized
DEBUG - 2015-02-06 16:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:40:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:40:44 --> Final output sent to browser
DEBUG - 2015-02-06 16:40:44 --> Total execution time: 1.2741
DEBUG - 2015-02-06 16:43:34 --> Config Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:43:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:43:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:43:34 --> URI Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Router Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Output Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Security Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Input Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:43:34 --> Language Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Loader Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:43:34 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:43:34 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:43:34 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Controller Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:43:34 --> Email Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:43:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:43:34 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:43:34 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:43:34 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:43:34 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:43:34 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:35 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:43:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:43:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:43:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:43:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:43:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:43:35 --> Final output sent to browser
DEBUG - 2015-02-06 16:43:35 --> Total execution time: 1.4161
DEBUG - 2015-02-06 16:43:55 --> Config Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:43:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:43:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:43:55 --> URI Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Router Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Output Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Security Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Input Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:43:55 --> Language Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Loader Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:43:55 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:43:55 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:43:55 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Controller Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:43:55 --> Email Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:43:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:43:55 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:43:55 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:43:55 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:43:55 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:43:56 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:56 --> Model Class Initialized
DEBUG - 2015-02-06 16:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:43:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:43:56 --> Final output sent to browser
DEBUG - 2015-02-06 16:43:56 --> Total execution time: 1.3151
DEBUG - 2015-02-06 16:45:04 --> Config Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:45:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:45:04 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:45:04 --> URI Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Router Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Output Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Security Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Input Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:45:04 --> Language Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Loader Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:45:04 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:45:04 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:45:04 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Controller Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:45:04 --> Email Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:45:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:45:04 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:45:04 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:45:04 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:45:04 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:45:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:45:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:45:05 --> Final output sent to browser
DEBUG - 2015-02-06 16:45:05 --> Total execution time: 1.2231
DEBUG - 2015-02-06 16:45:32 --> Config Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:45:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:45:32 --> URI Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Router Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Output Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Security Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Input Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:45:32 --> Language Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Loader Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:45:32 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Session: Regenerate ID
DEBUG - 2015-02-06 16:45:32 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:45:32 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Controller Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:45:32 --> Email Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:45:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:45:32 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:45:32 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:45:32 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:45:32 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:45:32 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:45:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:45:33 --> Final output sent to browser
DEBUG - 2015-02-06 16:45:33 --> Total execution time: 1.2471
DEBUG - 2015-02-06 16:45:57 --> Config Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:45:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:45:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:45:57 --> URI Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Router Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Output Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Security Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Input Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:45:57 --> Language Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Loader Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:45:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:45:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:45:57 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Controller Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:45:57 --> Email Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:45:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:45:57 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:45:57 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:45:57 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:45:57 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:45:58 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:58 --> Model Class Initialized
DEBUG - 2015-02-06 16:45:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:45:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:45:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:45:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:45:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:45:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:45:58 --> Final output sent to browser
DEBUG - 2015-02-06 16:45:58 --> Total execution time: 1.3001
DEBUG - 2015-02-06 16:47:38 --> Config Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:47:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:47:38 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:47:38 --> URI Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Router Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Output Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Security Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Input Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:47:38 --> Language Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Loader Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:47:38 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:47:38 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:47:38 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Controller Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:47:38 --> Email Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:47:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:47:38 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:47:38 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:47:38 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:47:38 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:47:39 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:39 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:47:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:47:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:47:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:47:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:47:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:47:40 --> Final output sent to browser
DEBUG - 2015-02-06 16:47:40 --> Total execution time: 1.4761
DEBUG - 2015-02-06 16:47:54 --> Config Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:47:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:47:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:47:54 --> URI Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Router Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Output Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Security Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Input Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:47:54 --> Language Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Loader Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:47:54 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:47:54 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:47:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Controller Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:47:54 --> Email Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:47:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:47:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:47:54 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:47:54 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:47:54 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:47:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:55 --> Model Class Initialized
DEBUG - 2015-02-06 16:47:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:47:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:47:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:47:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:47:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:47:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:47:55 --> Final output sent to browser
DEBUG - 2015-02-06 16:47:55 --> Total execution time: 1.2931
DEBUG - 2015-02-06 16:48:40 --> Config Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:48:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:48:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:48:40 --> URI Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Router Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Output Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Security Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Input Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:48:40 --> Language Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Loader Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:48:40 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:48:40 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:48:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:48:40 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:48:40 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:48:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Controller Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:48:40 --> Email Class Initialized
DEBUG - 2015-02-06 16:48:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:48:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:48:40 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:48:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:48:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:48:41 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:48:41 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:48:41 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:48:41 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:48:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:48:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:48:41 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:48:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:48:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:48:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:48:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:48:42 --> Final output sent to browser
DEBUG - 2015-02-06 16:48:42 --> Total execution time: 1.3001
DEBUG - 2015-02-06 16:49:05 --> Config Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:49:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:49:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:49:05 --> URI Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Router Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Output Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Security Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Input Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:49:05 --> Language Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Loader Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:49:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:49:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:49:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Controller Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:49:05 --> Email Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:49:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:49:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:49:05 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:49:05 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Model Class Initialized
DEBUG - 2015-02-06 16:49:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:49:05 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:49:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:49:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:49:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:49:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:49:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:49:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:49:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:49:07 --> Final output sent to browser
DEBUG - 2015-02-06 16:49:07 --> Total execution time: 1.3431
DEBUG - 2015-02-06 16:50:35 --> Config Class Initialized
DEBUG - 2015-02-06 16:50:35 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:50:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:50:35 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:50:35 --> URI Class Initialized
DEBUG - 2015-02-06 16:50:35 --> Router Class Initialized
DEBUG - 2015-02-06 16:50:35 --> Output Class Initialized
DEBUG - 2015-02-06 16:50:35 --> Security Class Initialized
DEBUG - 2015-02-06 16:50:35 --> Input Class Initialized
DEBUG - 2015-02-06 16:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:50:35 --> Language Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Loader Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:50:36 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Session: Regenerate ID
DEBUG - 2015-02-06 16:50:36 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:50:36 --> Model Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Model Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Controller Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:50:36 --> Email Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:50:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:50:36 --> Model Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:50:36 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:50:36 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Model Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:50:36 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Model Class Initialized
DEBUG - 2015-02-06 16:50:36 --> Model Class Initialized
DEBUG - 2015-02-06 16:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:50:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:50:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:50:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:50:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:50:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:50:37 --> Final output sent to browser
DEBUG - 2015-02-06 16:50:37 --> Total execution time: 1.2661
DEBUG - 2015-02-06 16:51:37 --> Config Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:51:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:51:37 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:51:37 --> URI Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Router Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Output Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Security Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Input Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:51:37 --> Language Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Loader Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:51:37 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:51:37 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:51:37 --> Model Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Model Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Controller Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:51:37 --> Email Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:51:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:51:37 --> Model Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:51:37 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:51:37 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Model Class Initialized
DEBUG - 2015-02-06 16:51:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:51:37 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:51:38 --> Model Class Initialized
DEBUG - 2015-02-06 16:51:38 --> Model Class Initialized
DEBUG - 2015-02-06 16:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:51:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:51:38 --> Final output sent to browser
DEBUG - 2015-02-06 16:51:38 --> Total execution time: 1.2041
DEBUG - 2015-02-06 16:52:09 --> Config Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:52:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:52:09 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:52:09 --> URI Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Router Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Output Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Security Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Input Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:52:09 --> Language Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Loader Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:52:09 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:52:09 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:52:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:52:09 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:52:09 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:52:09 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:09 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Controller Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:52:10 --> Email Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:52:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:52:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:52:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:52:10 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:52:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:52:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:52:10 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:10 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:52:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:52:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:52:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:52:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:52:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:52:10 --> Final output sent to browser
DEBUG - 2015-02-06 16:52:10 --> Total execution time: 1.1241
DEBUG - 2015-02-06 16:52:33 --> Config Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:52:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:52:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:52:33 --> URI Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Router Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Output Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Security Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Input Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:52:33 --> Language Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Loader Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:52:33 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:52:33 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:52:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Controller Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:52:33 --> Email Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:52:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:52:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:52:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:52:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:52:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:52:34 --> Final output sent to browser
DEBUG - 2015-02-06 16:52:34 --> Total execution time: 1.2881
DEBUG - 2015-02-06 16:53:03 --> Config Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:53:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:53:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:53:03 --> URI Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Router Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Output Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Security Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Input Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:53:03 --> Language Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Loader Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:53:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:53:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:53:03 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Controller Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:53:03 --> Email Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:53:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:53:03 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:53:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:53:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:03 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:53:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:53:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:53:04 --> Final output sent to browser
DEBUG - 2015-02-06 16:53:04 --> Total execution time: 1.2151
DEBUG - 2015-02-06 16:53:14 --> Config Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:53:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:53:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:53:14 --> URI Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Router Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Output Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Security Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Input Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:53:14 --> Language Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Loader Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:53:14 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:53:14 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:53:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Controller Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:53:14 --> Email Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:53:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:53:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:53:14 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:53:14 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:53:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:15 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:15 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:53:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:53:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:53:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:53:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:53:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:53:16 --> Final output sent to browser
DEBUG - 2015-02-06 16:53:16 --> Total execution time: 1.2921
DEBUG - 2015-02-06 16:53:33 --> Config Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:53:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:53:33 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:53:33 --> URI Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Router Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Output Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Security Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Input Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:53:33 --> Language Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Loader Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:53:33 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:53:33 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:53:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Controller Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:53:33 --> Email Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:53:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:53:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:53:33 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:53:33 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:33 --> Model Class Initialized
DEBUG - 2015-02-06 16:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:53:34 --> Final output sent to browser
DEBUG - 2015-02-06 16:53:34 --> Total execution time: 1.4041
DEBUG - 2015-02-06 16:55:19 --> Config Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:55:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:55:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:55:19 --> URI Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Router Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Output Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Security Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Input Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:55:19 --> Language Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Loader Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:55:19 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:55:19 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:55:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Controller Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:55:19 --> Email Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:55:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:55:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:55:19 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:55:19 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:55:19 --> Model Class Initialized
DEBUG - 2015-02-06 16:55:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:55:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:55:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:55:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:55:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:55:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:55:20 --> Final output sent to browser
DEBUG - 2015-02-06 16:55:20 --> Total execution time: 1.2801
DEBUG - 2015-02-06 16:56:54 --> Config Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:56:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:56:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:56:54 --> URI Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Router Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Output Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Security Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Input Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:56:54 --> Language Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Loader Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:56:54 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Session: Regenerate ID
DEBUG - 2015-02-06 16:56:54 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Controller Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:56:54 --> Email Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:56:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:56:54 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:56:54 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:56:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:56:55 --> Final output sent to browser
DEBUG - 2015-02-06 16:56:55 --> Total execution time: 1.3241
DEBUG - 2015-02-06 16:57:41 --> Config Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:57:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:57:41 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:57:41 --> URI Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Router Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Output Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Security Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Input Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:57:41 --> Language Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Loader Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:57:41 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:57:41 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:57:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Controller Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:57:41 --> Email Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:57:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:57:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:57:41 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:57:41 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:57:41 --> Model Class Initialized
DEBUG - 2015-02-06 16:57:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:57:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:57:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:57:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:57:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:57:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:57:42 --> Final output sent to browser
DEBUG - 2015-02-06 16:57:42 --> Total execution time: 1.2151
DEBUG - 2015-02-06 16:58:06 --> Config Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:58:06 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:58:06 --> URI Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Router Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Output Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Security Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Input Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:58:06 --> Language Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Loader Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:58:06 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:58:06 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:58:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Controller Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:58:06 --> Email Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:58:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:58:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:58:06 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:58:06 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:06 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:58:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:58:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:58:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:58:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:58:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:58:07 --> Final output sent to browser
DEBUG - 2015-02-06 16:58:07 --> Total execution time: 1.2281
DEBUG - 2015-02-06 16:58:54 --> Config Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:58:54 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:58:54 --> URI Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Router Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Output Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Security Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Input Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:58:54 --> Language Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Loader Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:58:54 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:58:54 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Controller Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:58:54 --> Email Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:58:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:58:54 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:58:54 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:54 --> Model Class Initialized
DEBUG - 2015-02-06 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:58:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:58:55 --> Final output sent to browser
DEBUG - 2015-02-06 16:58:55 --> Total execution time: 1.2051
DEBUG - 2015-02-06 16:59:13 --> Config Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:59:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:59:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:59:13 --> URI Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Router Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Output Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Security Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Input Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:59:13 --> Language Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Loader Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:59:13 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:59:13 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:59:13 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Controller Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:59:13 --> Email Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:59:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:59:13 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:59:13 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:59:13 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:13 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:14 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:59:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:59:14 --> Final output sent to browser
DEBUG - 2015-02-06 16:59:14 --> Total execution time: 1.2391
DEBUG - 2015-02-06 16:59:40 --> Config Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:59:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:59:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:59:40 --> URI Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Router Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Output Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Security Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Input Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:59:40 --> Language Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Loader Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:59:40 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:59:40 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:59:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Controller Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:59:40 --> Email Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:59:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:59:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:59:40 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:59:40 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:40 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:59:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 16:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:59:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:59:41 --> Final output sent to browser
DEBUG - 2015-02-06 16:59:41 --> Total execution time: 1.2741
DEBUG - 2015-02-06 16:59:51 --> Config Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 16:59:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 16:59:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 16:59:51 --> URI Class Initialized
DEBUG - 2015-02-06 16:59:51 --> No URI present. Default controller set.
DEBUG - 2015-02-06 16:59:51 --> Router Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Output Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Security Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Input Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 16:59:51 --> Language Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Loader Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: url_helper
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: link_helper
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 16:59:51 --> CI_Session Class Initialized
DEBUG - 2015-02-06 16:59:51 --> CI_Session routines successfully run
DEBUG - 2015-02-06 16:59:51 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Controller Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 16:59:51 --> Email Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: language_helper
DEBUG - 2015-02-06 16:59:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 16:59:51 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Database Driver Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: date_helper
DEBUG - 2015-02-06 16:59:51 --> Helper loaded: form_helper
DEBUG - 2015-02-06 16:59:51 --> Form Validation Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 16:59:51 --> Pagination Class Initialized
DEBUG - 2015-02-06 16:59:51 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:52 --> Model Class Initialized
DEBUG - 2015-02-06 16:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 16:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 16:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 16:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 16:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 16:59:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 16:59:52 --> Final output sent to browser
DEBUG - 2015-02-06 16:59:52 --> Total execution time: 1.2501
DEBUG - 2015-02-06 17:01:57 --> Config Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:01:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:01:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:01:57 --> URI Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Router Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Output Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Security Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Input Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:01:57 --> Language Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Loader Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:01:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:01:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:01:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:01:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:01:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:01:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Controller Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:01:57 --> Email Class Initialized
DEBUG - 2015-02-06 17:01:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:01:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:01:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:01:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:01:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:01:58 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:01:58 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:01:58 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:01:58 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:01:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:01:58 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:01:58 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:01:58 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 17:01:58 --> Helper loaded: string_helper
DEBUG - 2015-02-06 17:01:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:01:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:01:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:01:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:01:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:01:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 17:01:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:01:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:01:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:01:58 --> Final output sent to browser
DEBUG - 2015-02-06 17:01:58 --> Total execution time: 1.1701
DEBUG - 2015-02-06 17:02:05 --> Config Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:02:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:02:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:02:05 --> URI Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Router Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Output Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Security Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Input Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:02:05 --> Language Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Loader Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:02:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:02:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:02:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Controller Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:02:05 --> Email Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:02:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:02:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:02:05 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:02:05 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:02:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:02:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:02:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:02:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:02:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:02:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:02:06 --> Final output sent to browser
DEBUG - 2015-02-06 17:02:06 --> Total execution time: 1.6242
DEBUG - 2015-02-06 17:02:12 --> Config Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:02:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:02:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:02:12 --> URI Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Router Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Output Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Security Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Input Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:02:12 --> Language Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Loader Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:02:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:02:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Controller Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:02:12 --> Email Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:02:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:02:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:02:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:13 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:02:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:02:13 --> Final output sent to browser
DEBUG - 2015-02-06 17:02:13 --> Total execution time: 1.3191
DEBUG - 2015-02-06 17:02:28 --> Config Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:02:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:02:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:02:28 --> URI Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Router Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Output Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Security Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Input Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:02:28 --> Language Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Loader Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:02:28 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:02:28 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Controller Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:02:28 --> Email Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:02:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:02:28 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:02:28 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:02:28 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:29 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:29 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:02:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:02:29 --> Final output sent to browser
DEBUG - 2015-02-06 17:02:29 --> Total execution time: 1.3751
DEBUG - 2015-02-06 17:02:38 --> Config Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:02:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:02:38 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:02:38 --> URI Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Router Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Output Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Security Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Input Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:02:38 --> Language Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Loader Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:02:38 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:02:38 --> A session cookie was not found.
DEBUG - 2015-02-06 17:02:38 --> Session: Creating new session (bf11fbebc0fdf0645af1f36b2d7a0a87)
DEBUG - 2015-02-06 17:02:38 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:02:38 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Controller Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:02:38 --> Email Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:02:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:02:38 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:02:38 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:02:38 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:02:38 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:39 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:39 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:02:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:02:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:02:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:02:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:02:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
ERROR - 2015-02-06 17:02:39 --> Severity: error --> Exception: The identifier id is missing for a query of Entity\Users D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 160
DEBUG - 2015-02-06 17:02:55 --> Config Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:02:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:02:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:02:55 --> URI Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Router Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Output Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Security Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Input Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:02:55 --> Language Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Loader Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:02:55 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:02:55 --> A session cookie was not found.
DEBUG - 2015-02-06 17:02:55 --> Session: Creating new session (44f38705585821516a2d298f0c801c40)
DEBUG - 2015-02-06 17:02:55 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:02:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Controller Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:02:55 --> Email Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:02:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:02:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:02:55 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:02:55 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:02:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:56 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:56 --> Model Class Initialized
DEBUG - 2015-02-06 17:02:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:02:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:02:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:02:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:02:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:02:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
ERROR - 2015-02-06 17:02:56 --> Severity: error --> Exception: The identifier id is missing for a query of Entity\Users D:\phutx\project\ups\myblog\vendor\doctrine\orm\lib\Doctrine\ORM\ORMException.php 160
DEBUG - 2015-02-06 17:03:23 --> Config Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:03:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:03:23 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:03:23 --> URI Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Router Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Output Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Security Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Input Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:03:23 --> Language Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Loader Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:03:23 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:03:23 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:03:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Controller Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:03:23 --> Email Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:03:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:03:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:03:23 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:03:23 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:03:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:24 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:24 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:03:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:03:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:03:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:03:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:03:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:03:25 --> Final output sent to browser
DEBUG - 2015-02-06 17:03:25 --> Total execution time: 1.3621
DEBUG - 2015-02-06 17:03:40 --> Config Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:03:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:03:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:03:40 --> URI Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Router Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Output Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Security Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Input Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:03:40 --> Language Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Loader Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:03:40 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:03:40 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:03:40 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Controller Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:03:40 --> Email Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:03:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:03:40 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:03:40 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:03:40 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:03:40 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:03:40 --> Session: Creating new session (78f67945effeb7425ff4b4d832c72a1b)
DEBUG - 2015-02-06 17:03:40 --> Config Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:03:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:03:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:03:40 --> URI Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Router Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Output Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Security Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Input Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:03:40 --> Language Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Loader Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:03:40 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:03:40 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:03:40 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Controller Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:03:40 --> Email Class Initialized
DEBUG - 2015-02-06 17:03:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:03:40 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:03:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:03:40 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:41 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:03:41 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:03:41 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:03:41 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:03:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:03:41 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:03:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:03:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:03:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:03:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:03:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 17:03:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:03:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:03:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:03:41 --> Final output sent to browser
DEBUG - 2015-02-06 17:03:41 --> Total execution time: 0.8881
DEBUG - 2015-02-06 17:04:35 --> Config Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:04:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:04:35 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:04:35 --> URI Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Router Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Output Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Security Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Input Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:04:35 --> Language Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Loader Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:04:35 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:04:35 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:04:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Controller Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:04:35 --> Email Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:04:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:04:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:04:35 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:04:35 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:04:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:04:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:04:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:04:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:04:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:04:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:04:36 --> Final output sent to browser
DEBUG - 2015-02-06 17:04:36 --> Total execution time: 1.2701
DEBUG - 2015-02-06 17:04:40 --> Config Class Initialized
DEBUG - 2015-02-06 17:04:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:04:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:04:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:04:40 --> URI Class Initialized
DEBUG - 2015-02-06 17:04:40 --> Router Class Initialized
DEBUG - 2015-02-06 17:04:40 --> Output Class Initialized
DEBUG - 2015-02-06 17:04:40 --> Security Class Initialized
DEBUG - 2015-02-06 17:04:40 --> Input Class Initialized
DEBUG - 2015-02-06 17:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:04:40 --> Language Class Initialized
DEBUG - 2015-02-06 17:04:40 --> Loader Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:04:41 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:04:41 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:04:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Controller Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:04:41 --> Email Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:04:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:04:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:04:41 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:04:41 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:04:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:42 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:42 --> Model Class Initialized
DEBUG - 2015-02-06 17:04:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:04:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:04:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:04:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:04:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:04:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:04:42 --> Final output sent to browser
DEBUG - 2015-02-06 17:04:42 --> Total execution time: 1.4131
DEBUG - 2015-02-06 17:05:26 --> Config Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:05:26 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:05:26 --> URI Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Router Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Output Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Security Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Input Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:05:26 --> Language Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Loader Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:05:26 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:05:26 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:05:26 --> Model Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Model Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Controller Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:05:26 --> Email Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:05:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:05:26 --> Model Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:05:26 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:05:26 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:05:26 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:05:26 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:05:26 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:05:26 --> Model Class Initialized
DEBUG - 2015-02-06 17:05:26 --> Model Class Initialized
DEBUG - 2015-02-06 17:05:27 --> Model Class Initialized
DEBUG - 2015-02-06 17:05:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:05:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:05:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:05:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:05:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:05:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:05:27 --> Final output sent to browser
DEBUG - 2015-02-06 17:05:27 --> Total execution time: 0.8271
DEBUG - 2015-02-06 17:07:55 --> Config Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:07:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:07:55 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:07:55 --> URI Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Router Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Output Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Security Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Input Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:07:55 --> Language Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Loader Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:07:55 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:07:55 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:07:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Controller Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:07:55 --> Email Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:07:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:07:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:07:55 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:07:55 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:07:55 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:07:55 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:07:55 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:07:55 --> Severity: Notice --> Undefined property: Auth::$captcha D:\phutx\project\ups\myblog\application\controllers\auth.php 348
ERROR - 2015-02-06 17:07:55 --> Severity: Error --> Call to a member function create_captcha() on a non-object D:\phutx\project\ups\myblog\application\controllers\auth.php 348
DEBUG - 2015-02-06 17:08:05 --> Config Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:08:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:08:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:08:05 --> URI Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Router Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Output Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Security Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Input Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:08:05 --> Language Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Loader Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:08:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:08:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Controller Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:08:05 --> Email Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:08:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:08:05 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:08:05 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:08:05 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:08:05 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:08:05 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:08:05 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:08:05 --> Model Class Initialized
DEBUG - 2015-02-06 17:08:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:08:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:08:06 --> Final output sent to browser
DEBUG - 2015-02-06 17:08:06 --> Total execution time: 0.8771
DEBUG - 2015-02-06 17:11:35 --> Config Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:11:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:11:35 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:11:35 --> URI Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Router Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Output Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Security Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Input Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:11:35 --> Language Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Loader Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:11:35 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:11:35 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:11:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Controller Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:11:35 --> Email Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:11:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:11:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:11:35 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:11:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:11:35 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:11:35 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:11:35 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:11:35 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:11:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:11:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:11:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:11:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:11:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:11:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:11:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:11:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:11:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:11:36 --> Final output sent to browser
DEBUG - 2015-02-06 17:11:36 --> Total execution time: 0.8451
DEBUG - 2015-02-06 17:12:20 --> Config Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:12:20 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:12:20 --> URI Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Router Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Output Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Security Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Input Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:12:20 --> Language Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Loader Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:12:20 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:12:20 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:12:20 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Controller Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:12:20 --> Email Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:12:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:12:20 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:12:20 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:12:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:12:20 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:12:20 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:12:20 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:12:21 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:12:21 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:21 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:21 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:12:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:12:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:12:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:12:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:12:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:12:21 --> Final output sent to browser
DEBUG - 2015-02-06 17:12:21 --> Total execution time: 1.1631
DEBUG - 2015-02-06 17:12:58 --> Config Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:12:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:12:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:12:58 --> URI Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Router Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Output Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Security Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Input Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:12:58 --> Language Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Loader Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:12:58 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:12:58 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:12:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Controller Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:12:58 --> Email Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:12:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:12:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:12:58 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:12:58 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:12:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:12:58 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:12:58 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:12:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:59 --> Model Class Initialized
DEBUG - 2015-02-06 17:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:12:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:12:59 --> Final output sent to browser
DEBUG - 2015-02-06 17:12:59 --> Total execution time: 0.9671
DEBUG - 2015-02-06 17:14:36 --> Config Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:14:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:14:36 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:14:36 --> URI Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Router Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Output Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Security Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Input Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:14:36 --> Language Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Loader Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:14:36 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:14:36 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:14:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Controller Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:14:36 --> Email Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:14:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:14:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:14:36 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:14:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:14:36 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:14:36 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:14:36 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:14:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:14:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:14:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:14:37 --> Final output sent to browser
DEBUG - 2015-02-06 17:14:37 --> Total execution time: 1.0331
DEBUG - 2015-02-06 17:15:52 --> Config Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:15:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:15:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:15:52 --> URI Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Router Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Output Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Security Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Input Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:15:52 --> Language Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Loader Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:15:52 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:15:52 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:15:52 --> Model Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Model Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Controller Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:15:52 --> Email Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:15:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:15:52 --> Model Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:15:52 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:15:52 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:15:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:15:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:15:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:15:53 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:15:53 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:15:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:15:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:15:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:15:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:15:53 --> Final output sent to browser
DEBUG - 2015-02-06 17:15:53 --> Total execution time: 0.9571
DEBUG - 2015-02-06 17:15:59 --> Config Class Initialized
DEBUG - 2015-02-06 17:15:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:16:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:16:00 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:16:00 --> URI Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Router Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Output Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Security Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Input Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:16:00 --> Language Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Loader Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:16:00 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:16:00 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:16:00 --> Model Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Model Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Controller Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:16:00 --> Email Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:16:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:16:00 --> Model Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:16:00 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:16:00 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:16:00 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:16:00 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:16:00 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:16:00 --> Model Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Model Class Initialized
DEBUG - 2015-02-06 17:16:00 --> Model Class Initialized
DEBUG - 2015-02-06 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:16:00 --> Final output sent to browser
DEBUG - 2015-02-06 17:16:00 --> Total execution time: 0.9101
DEBUG - 2015-02-06 17:17:06 --> Config Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:17:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:17:06 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:17:06 --> URI Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Router Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Output Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Security Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Input Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:17:06 --> Language Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Loader Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:17:06 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:17:06 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:17:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Controller Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:17:06 --> Email Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:17:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:17:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:17:06 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:17:06 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:17:06 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:17:06 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:17:06 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:17:06 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:17:06 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:07 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:07 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:17:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:17:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:17:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:17:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:17:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:17:07 --> Final output sent to browser
DEBUG - 2015-02-06 17:17:07 --> Total execution time: 0.8951
DEBUG - 2015-02-06 17:17:50 --> Config Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:17:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:17:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:17:50 --> URI Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Router Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Output Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Security Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Input Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:17:50 --> Language Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Loader Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:17:50 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:17:50 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Controller Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:17:50 --> Email Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:17:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:17:50 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:17:50 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:17:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:17:50 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:17:50 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:17:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:17:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:17:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:17:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:17:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:17:51 --> Final output sent to browser
DEBUG - 2015-02-06 17:17:51 --> Total execution time: 0.9261
DEBUG - 2015-02-06 17:17:57 --> Config Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:17:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:17:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:17:57 --> URI Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Router Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Output Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Security Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Input Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:17:57 --> Language Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Loader Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:17:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:17:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:17:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Controller Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:17:57 --> Email Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:17:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:17:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:17:57 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:17:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:17:57 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:17:57 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:17:57 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:17:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:58 --> Model Class Initialized
DEBUG - 2015-02-06 17:17:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:17:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:17:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:17:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:17:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:17:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:17:58 --> Final output sent to browser
DEBUG - 2015-02-06 17:17:58 --> Total execution time: 0.9161
DEBUG - 2015-02-06 17:28:23 --> Config Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:28:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:28:23 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:28:23 --> URI Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Router Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Output Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Security Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Input Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:28:23 --> Language Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Loader Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:28:23 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:28:23 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:28:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Controller Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:28:23 --> Email Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:28:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:28:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:28:23 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:28:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:28:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:28:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:28:23 --> Helper loaded: captcha_helper
ERROR - 2015-02-06 17:28:23 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:28:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:28:24 --> Model Class Initialized
DEBUG - 2015-02-06 17:28:24 --> Model Class Initialized
DEBUG - 2015-02-06 17:28:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:28:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:28:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:28:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:28:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:28:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:28:24 --> Final output sent to browser
DEBUG - 2015-02-06 17:28:24 --> Total execution time: 0.9281
DEBUG - 2015-02-06 17:38:21 --> Config Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:38:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:38:21 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:38:21 --> URI Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Router Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Output Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Security Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Input Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:38:21 --> Language Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Loader Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:38:21 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:38:21 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:38:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:38:21 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:38:21 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:38:21 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:38:22 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:22 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:22 --> Controller Class Initialized
DEBUG - 2015-02-06 17:38:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:38:22 --> Email Class Initialized
DEBUG - 2015-02-06 17:38:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:38:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:38:22 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:38:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:38:22 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:22 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:38:23 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:38:23 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:38:23 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:38:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:38:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:38:23 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:38:23 --> Severity: Error --> Class 'CaptchaBuilder' not found D:\phutx\project\ups\myblog\application\controllers\auth.php 348
DEBUG - 2015-02-06 17:38:47 --> Config Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:38:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:38:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:38:47 --> URI Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Router Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Output Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Security Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Input Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:38:47 --> Language Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Loader Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:38:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:38:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:38:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Controller Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:38:47 --> Email Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:38:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:38:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:38:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:38:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:38:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:38:47 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:38:47 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:38:53 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:38:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:54 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:55 --> Model Class Initialized
DEBUG - 2015-02-06 17:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:38:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:38:55 --> Final output sent to browser
DEBUG - 2015-02-06 17:38:55 --> Total execution time: 8.2298
DEBUG - 2015-02-06 17:39:34 --> Config Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:39:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:39:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:39:34 --> URI Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Router Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Output Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Security Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Input Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:39:34 --> Language Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Loader Class Initialized
DEBUG - 2015-02-06 17:39:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:39:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:39:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:39:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:39:34 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:39:34 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:39:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:39:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:39:35 --> Controller Class Initialized
DEBUG - 2015-02-06 17:39:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:39:35 --> Email Class Initialized
DEBUG - 2015-02-06 17:39:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:39:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:39:35 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:39:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:39:35 --> Model Class Initialized
DEBUG - 2015-02-06 17:39:35 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:39:35 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:39:35 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:39:35 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:39:35 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:39:35 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:39:35 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:39:41 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:39:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:39:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:39:41 --> Model Class Initialized
DEBUG - 2015-02-06 17:39:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:39:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:39:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:39:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:39:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:39:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:39:41 --> Final output sent to browser
DEBUG - 2015-02-06 17:39:41 --> Total execution time: 7.0357
DEBUG - 2015-02-06 17:43:37 --> Config Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:43:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:43:37 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:43:37 --> URI Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Router Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Output Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Security Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Input Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:43:37 --> Language Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Loader Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:43:37 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:43:37 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:43:37 --> Model Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Model Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Controller Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:43:37 --> Email Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:43:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:43:37 --> Model Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:43:37 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:43:37 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:43:37 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:43:37 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:43:37 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:43:37 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:43:43 --> Model Class Initialized
DEBUG - 2015-02-06 17:43:43 --> Model Class Initialized
DEBUG - 2015-02-06 17:43:43 --> Model Class Initialized
DEBUG - 2015-02-06 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:43:43 --> Final output sent to browser
DEBUG - 2015-02-06 17:43:43 --> Total execution time: 6.6577
DEBUG - 2015-02-06 17:46:18 --> Config Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:46:18 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:46:18 --> URI Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Router Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Output Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Security Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Input Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:46:18 --> Language Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Loader Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:46:18 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:46:18 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:46:18 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Controller Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:46:18 --> Email Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:46:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:46:18 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:46:18 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:46:18 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:46:18 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:46:18 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:46:18 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:46:18 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:46:21 --> Config Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:46:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:46:21 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:46:21 --> URI Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Router Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Output Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Security Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Input Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:46:21 --> Language Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Loader Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:46:21 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:46:21 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:46:21 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Controller Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:46:21 --> Email Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:46:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:46:21 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:46:21 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:46:21 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:46:21 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:46:21 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:46:21 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:46:21 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:46:27 --> Config Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:46:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:46:27 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:46:27 --> URI Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Router Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Output Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Security Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Input Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:46:27 --> Language Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Loader Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:46:27 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:46:27 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:46:27 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Controller Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:46:27 --> Email Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:46:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:46:27 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:46:27 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:46:27 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:46:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:46:27 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:46:27 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:46:27 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:46:33 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:34 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:34 --> Model Class Initialized
DEBUG - 2015-02-06 17:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:46:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:46:34 --> Final output sent to browser
DEBUG - 2015-02-06 17:46:34 --> Total execution time: 6.9407
DEBUG - 2015-02-06 17:47:03 --> Config Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:47:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:47:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:47:03 --> URI Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Router Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Output Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Security Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Input Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:47:03 --> Language Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Loader Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:47:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:47:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:47:03 --> Model Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Model Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Controller Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:47:03 --> Email Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:47:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:47:03 --> Model Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:47:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:47:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:47:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:47:03 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:47:03 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:47:04 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:47:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 17:48:36 --> Config Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:48:36 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:48:36 --> URI Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Router Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Output Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Security Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Input Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:48:36 --> Language Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Loader Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:48:36 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:48:36 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:48:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Controller Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:48:36 --> Email Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:48:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:48:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:48:36 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:48:36 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:48:36 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:48:36 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:48:36 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:48:36 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:48:42 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:42 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:42 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:48:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:48:42 --> Final output sent to browser
DEBUG - 2015-02-06 17:48:42 --> Total execution time: 6.6417
DEBUG - 2015-02-06 17:48:45 --> Config Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:48:45 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:48:45 --> URI Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Router Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Output Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Security Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Input Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:48:45 --> Language Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Loader Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:48:45 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:48:45 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:48:45 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Controller Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:48:45 --> Email Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:48:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:48:45 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:48:45 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:48:45 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:48:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:48:45 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:48:45 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:48:45 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:48:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 17:48:52 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:52 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:52 --> Model Class Initialized
DEBUG - 2015-02-06 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:48:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:48:52 --> Final output sent to browser
DEBUG - 2015-02-06 17:48:52 --> Total execution time: 7.0937
DEBUG - 2015-02-06 17:49:32 --> Config Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:49:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:49:32 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:49:32 --> URI Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Router Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Output Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Security Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Input Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:49:32 --> Language Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Loader Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:49:32 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:49:32 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:49:32 --> Model Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Model Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Controller Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:49:32 --> Email Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:49:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:49:32 --> Model Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:49:32 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:49:32 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:49:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:49:32 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:49:32 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:49:32 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:49:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-06 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-06 17:49:39 --> Model Class Initialized
DEBUG - 2015-02-06 17:49:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:49:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:49:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:49:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:49:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:49:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:49:39 --> Final output sent to browser
DEBUG - 2015-02-06 17:49:39 --> Total execution time: 6.9897
DEBUG - 2015-02-06 17:51:16 --> Config Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:51:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:51:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:51:16 --> URI Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Router Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Output Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Security Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Input Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:51:16 --> Language Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Loader Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:51:16 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:51:16 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:51:16 --> Model Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Model Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Controller Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:51:16 --> Email Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:51:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:51:16 --> Model Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:51:16 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:51:16 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:51:16 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:51:16 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:51:16 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:51:16 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:51:16 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 17:51:22 --> Model Class Initialized
DEBUG - 2015-02-06 17:51:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:51:23 --> Model Class Initialized
DEBUG - 2015-02-06 17:51:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:51:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:51:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:51:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:51:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:51:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:51:23 --> Final output sent to browser
DEBUG - 2015-02-06 17:51:23 --> Total execution time: 6.8277
DEBUG - 2015-02-06 17:53:57 --> Config Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:53:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:53:57 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:53:57 --> URI Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Router Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Output Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Security Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Input Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:53:57 --> Language Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Loader Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:53:57 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:53:57 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:53:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Controller Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:53:57 --> Email Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:53:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:53:57 --> Model Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:53:57 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:53:57 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:53:57 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:53:57 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:53:57 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:53:57 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:54:03 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:04 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:04 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:54:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:54:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:54:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:54:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:54:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:54:04 --> Final output sent to browser
DEBUG - 2015-02-06 17:54:04 --> Total execution time: 6.8057
DEBUG - 2015-02-06 17:54:30 --> Config Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:54:30 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:54:30 --> URI Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Router Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Output Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Security Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Input Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:54:30 --> Language Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Loader Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:54:30 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:54:30 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:54:30 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Controller Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:54:30 --> Email Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:54:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:54:30 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:54:30 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:54:30 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:54:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:54:31 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:54:31 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:54:31 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:54:36 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:37 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:37 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:54:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:54:37 --> Final output sent to browser
DEBUG - 2015-02-06 17:54:37 --> Total execution time: 6.6867
DEBUG - 2015-02-06 17:54:44 --> Config Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:54:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:54:44 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:54:44 --> URI Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Router Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Output Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Security Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Input Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:54:44 --> Language Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Loader Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:54:44 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:54:44 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:54:44 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Controller Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:54:44 --> Email Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:54:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:54:44 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:54:44 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:54:44 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:54:44 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:45 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:45 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:54:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:54:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 17:54:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:54:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:54:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:54:45 --> Final output sent to browser
DEBUG - 2015-02-06 17:54:45 --> Total execution time: 1.4351
DEBUG - 2015-02-06 17:54:49 --> Config Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:54:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:54:49 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:54:49 --> URI Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Router Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Output Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Security Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Input Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:54:49 --> Language Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Loader Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:54:49 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:54:49 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:54:49 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Controller Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:54:49 --> Email Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:54:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:54:49 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:54:49 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:54:49 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:54:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:54:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:54:49 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:54:49 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:54:56 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:56 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:56 --> Model Class Initialized
DEBUG - 2015-02-06 17:54:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:54:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:54:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:54:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:54:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:54:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:54:56 --> Final output sent to browser
DEBUG - 2015-02-06 17:54:56 --> Total execution time: 7.1317
DEBUG - 2015-02-06 17:55:31 --> Config Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:55:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:55:31 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:55:31 --> URI Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Router Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Output Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Security Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Input Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:55:31 --> Language Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Loader Class Initialized
DEBUG - 2015-02-06 17:55:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:55:31 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:55:31 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:55:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:55:31 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:55:31 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:55:32 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:32 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:32 --> Controller Class Initialized
DEBUG - 2015-02-06 17:55:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:55:32 --> Email Class Initialized
DEBUG - 2015-02-06 17:55:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:55:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:55:32 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:55:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:32 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:32 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:55:32 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:55:32 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:55:32 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:55:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:55:32 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:32 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:55:32 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:55:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 17:55:38 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:38 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:38 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:55:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:55:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-06 17:55:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:55:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:55:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:55:38 --> Final output sent to browser
DEBUG - 2015-02-06 17:55:38 --> Total execution time: 7.0627
DEBUG - 2015-02-06 17:55:49 --> Config Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:55:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:55:49 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:55:49 --> URI Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Router Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Output Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Security Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Input Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:55:49 --> Language Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Loader Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:55:49 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:55:49 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:55:49 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Controller Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:55:49 --> Email Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:55:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:49 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:55:49 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:55:49 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:55:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:55:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:49 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:55:49 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-06 17:55:49 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 17:55:50 --> Config Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:55:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:55:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:55:50 --> URI Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Router Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Output Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Security Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Input Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:55:50 --> Language Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Loader Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:55:50 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:55:50 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:55:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Controller Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:55:50 --> Email Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:55:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:50 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:55:50 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:55:50 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:55:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:55:50 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:55:51 --> Config Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:55:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:55:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:55:51 --> URI Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Router Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Output Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Security Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Input Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:55:51 --> Language Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Loader Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:55:51 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:55:51 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:55:51 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Controller Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:55:51 --> Email Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:55:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:51 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:55:51 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:55:51 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:55:51 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:55:51 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:55:51 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:51 --> Model Class Initialized
DEBUG - 2015-02-06 17:55:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:55:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:55:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 17:55:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:55:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:55:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:55:52 --> Final output sent to browser
DEBUG - 2015-02-06 17:55:52 --> Total execution time: 1.0001
DEBUG - 2015-02-06 17:56:01 --> Config Class Initialized
DEBUG - 2015-02-06 17:56:01 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:56:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:56:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:56:02 --> URI Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Router Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Output Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Security Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Input Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:56:02 --> Language Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Loader Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:56:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:56:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:56:02 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Controller Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:56:02 --> Email Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:56:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:02 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:56:02 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:56:02 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 17:56:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 17:56:02 --> Config Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:56:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:56:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:56:02 --> URI Class Initialized
DEBUG - 2015-02-06 17:56:02 --> No URI present. Default controller set.
DEBUG - 2015-02-06 17:56:02 --> Router Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Output Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Security Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Input Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:56:02 --> Language Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Loader Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:56:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:56:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:56:02 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Controller Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:56:02 --> Email Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:56:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:02 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:56:02 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:56:02 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 17:56:02 --> Pagination Class Initialized
DEBUG - 2015-02-06 17:56:03 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:03 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:56:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:56:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 17:56:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:56:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:56:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:56:04 --> Final output sent to browser
DEBUG - 2015-02-06 17:56:04 --> Total execution time: 1.5582
DEBUG - 2015-02-06 17:56:08 --> Config Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:56:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:56:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:56:08 --> URI Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Router Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Output Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Security Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Input Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:56:08 --> Language Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Loader Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:56:08 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:56:08 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:56:08 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Controller Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:56:08 --> Email Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:56:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:08 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:56:08 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:56:08 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:08 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:56:08 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 17:56:08 --> Helper loaded: string_helper
DEBUG - 2015-02-06 17:56:08 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:08 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:09 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:56:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:56:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 17:56:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:56:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:56:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:56:09 --> Final output sent to browser
DEBUG - 2015-02-06 17:56:09 --> Total execution time: 0.9651
DEBUG - 2015-02-06 17:56:12 --> Config Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:56:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:56:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:56:12 --> URI Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Router Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Output Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Security Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Input Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:56:12 --> Language Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Loader Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:56:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:56:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:56:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Controller Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:56:12 --> Email Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:56:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:12 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:56:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:56:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Config Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:56:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:56:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:56:53 --> URI Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Router Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Output Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Security Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Input Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:56:53 --> Language Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Loader Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:56:53 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:56:53 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:56:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Controller Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:56:53 --> Email Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:56:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:56:53 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:56:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:56:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:56:53 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:56:53 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 17:56:53 --> Helper loaded: string_helper
DEBUG - 2015-02-06 17:56:53 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:54 --> Model Class Initialized
DEBUG - 2015-02-06 17:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 17:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:56:54 --> Final output sent to browser
DEBUG - 2015-02-06 17:56:54 --> Total execution time: 1.0371
DEBUG - 2015-02-06 17:59:47 --> Config Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 17:59:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 17:59:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 17:59:47 --> URI Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Router Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Output Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Security Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Input Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 17:59:47 --> Language Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Loader Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 17:59:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Session: Regenerate ID
DEBUG - 2015-02-06 17:59:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 17:59:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Controller Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 17:59:47 --> Email Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 17:59:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 17:59:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 17:59:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 17:59:47 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 17:59:47 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 17:59:47 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 17:59:47 --> Helper loaded: string_helper
DEBUG - 2015-02-06 17:59:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:59:47 --> Model Class Initialized
DEBUG - 2015-02-06 17:59:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 17:59:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 17:59:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 17:59:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 17:59:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 17:59:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 17:59:48 --> Final output sent to browser
DEBUG - 2015-02-06 17:59:48 --> Total execution time: 0.9401
DEBUG - 2015-02-06 18:00:12 --> Config Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:00:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:00:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:00:12 --> URI Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Router Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Output Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Security Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Input Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:00:12 --> Language Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Loader Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:00:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:00:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:00:12 --> Model Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Model Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Controller Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:00:12 --> Email Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:00:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:00:12 --> Model Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:00:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:00:12 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:00:12 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 18:00:12 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 18:00:12 --> Helper loaded: string_helper
DEBUG - 2015-02-06 18:00:12 --> Model Class Initialized
DEBUG - 2015-02-06 18:00:12 --> Model Class Initialized
DEBUG - 2015-02-06 18:00:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:00:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:00:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:00:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 18:00:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:00:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:00:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:00:13 --> Final output sent to browser
DEBUG - 2015-02-06 18:00:13 --> Total execution time: 0.9061
DEBUG - 2015-02-06 18:02:29 --> Config Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:02:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:02:29 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:02:29 --> URI Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Router Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Output Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Security Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Input Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:02:29 --> Language Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Loader Class Initialized
DEBUG - 2015-02-06 18:02:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:02:29 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:02:29 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:02:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:02:30 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:02:30 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:02:30 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Controller Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:02:30 --> Email Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:02:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:02:30 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:02:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:30 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:02:30 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:02:30 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:02:30 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:30 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 18:02:30 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 18:02:30 --> Helper loaded: string_helper
DEBUG - 2015-02-06 18:02:30 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:30 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 18:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:02:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:02:30 --> Final output sent to browser
DEBUG - 2015-02-06 18:02:30 --> Total execution time: 0.9771
DEBUG - 2015-02-06 18:02:47 --> Config Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:02:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:02:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:02:47 --> URI Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Router Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Output Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Security Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Input Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:02:47 --> Language Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Loader Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:02:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:02:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:02:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Controller Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:02:47 --> Email Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:02:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:02:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:02:47 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:47 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-06 18:02:47 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-06 18:02:47 --> Helper loaded: string_helper
DEBUG - 2015-02-06 18:02:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:48 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:02:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:02:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-06 18:02:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:02:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:02:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:02:48 --> Final output sent to browser
DEBUG - 2015-02-06 18:02:48 --> Total execution time: 1.0701
DEBUG - 2015-02-06 18:02:52 --> Config Class Initialized
DEBUG - 2015-02-06 18:02:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:02:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:02:52 --> URI Class Initialized
DEBUG - 2015-02-06 18:02:52 --> Router Class Initialized
DEBUG - 2015-02-06 18:02:52 --> Output Class Initialized
DEBUG - 2015-02-06 18:02:52 --> Security Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Input Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:02:53 --> Language Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Loader Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:02:53 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:02:53 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Controller Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:02:53 --> Email Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:02:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:02:53 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:02:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:02:53 --> Session: Creating new session (ca930fbd4ca51e11cf53a1a83b459820)
DEBUG - 2015-02-06 18:02:53 --> Config Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:02:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:02:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:02:53 --> URI Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Router Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Output Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Security Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Input Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:02:53 --> Language Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Loader Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:02:53 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:02:53 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Controller Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:02:53 --> Email Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:02:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:02:53 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:02:53 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:02:53 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:02:53 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:54 --> Model Class Initialized
DEBUG - 2015-02-06 18:02:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:02:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:02:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 18:02:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:02:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:02:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:02:54 --> Final output sent to browser
DEBUG - 2015-02-06 18:02:54 --> Total execution time: 0.8011
DEBUG - 2015-02-06 18:03:04 --> Config Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:03:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:03:04 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:03:04 --> URI Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Router Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Output Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Security Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Input Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:03:04 --> Language Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Loader Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:03:04 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:03:04 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:03:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Controller Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:03:04 --> Email Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:03:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:03:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:03:04 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:03:04 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:03:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:03:04 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:03:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:03:04 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2015-02-06 18:03:04 --> Severity: Error --> Call to undefined method CI_DB_mysql_driver::get_last_query() D:\phutx\project\ups\myblog\application\models\Ion_auth_model.php 1731
DEBUG - 2015-02-06 18:03:29 --> Config Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:03:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:03:29 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:03:29 --> URI Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Router Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Output Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Security Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Input Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:03:29 --> Language Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Loader Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:03:29 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:03:29 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:03:29 --> Model Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Model Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Controller Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:03:29 --> Email Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:03:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:03:29 --> Model Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:03:29 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:03:29 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:03:29 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:03:29 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:03:29 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:03:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 18:04:11 --> Config Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:04:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:04:11 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:04:11 --> URI Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Router Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Output Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Security Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Input Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:04:11 --> Language Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Loader Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:04:11 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:04:11 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:04:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Controller Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:04:11 --> Email Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:04:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:04:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:04:11 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:04:11 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:04:11 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:04:11 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:04:11 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:04:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 18:05:02 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:02 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:02 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:02 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:02 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:05:02 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:02 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:05:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 18:05:02 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:02 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:02 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:05:02 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:02 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:02 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:02 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:02 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:05:02 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:05:03 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:03 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:05:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:05:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:05:04 --> Final output sent to browser
DEBUG - 2015-02-06 18:05:04 --> Total execution time: 1.2551
DEBUG - 2015-02-06 18:05:23 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:23 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:23 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:23 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:05:23 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:23 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:23 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:23 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:23 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:23 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:23 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:23 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:23 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:05:23 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:23 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:05:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:05:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:05:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:05:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:05:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:05:24 --> Final output sent to browser
DEBUG - 2015-02-06 18:05:24 --> Total execution time: 1.2801
DEBUG - 2015-02-06 18:05:34 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:34 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:34 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:34 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:34 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:34 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:34 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:34 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:34 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:05:34 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:05:34 --> Session: Creating new session (df9ba70a55945689ade7bfbcde6e88cf)
DEBUG - 2015-02-06 18:05:34 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:34 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:34 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:34 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:34 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:34 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:34 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:34 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:34 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:34 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:34 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:34 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:05:34 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:34 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:05:34 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:35 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:35 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 18:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:05:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:05:35 --> Final output sent to browser
DEBUG - 2015-02-06 18:05:35 --> Total execution time: 0.8271
DEBUG - 2015-02-06 18:05:45 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:45 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:45 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:45 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:45 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:45 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:45 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:45 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:45 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:45 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:45 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:05:45 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:45 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:05:45 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 18:05:45 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:45 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:45 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:45 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:46 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:05:46 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:46 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:46 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:46 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:46 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:46 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:46 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:46 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:46 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:05:46 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:46 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:05:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:05:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:05:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:05:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:05:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:05:47 --> Final output sent to browser
DEBUG - 2015-02-06 18:05:47 --> Total execution time: 1.3181
DEBUG - 2015-02-06 18:05:50 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:50 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:50 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:50 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:50 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:50 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:50 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:50 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:50 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:05:50 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:05:50 --> Session: Creating new session (afa2bb66e68232c9f59b0fae69a9a6c4)
DEBUG - 2015-02-06 18:05:50 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:50 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:50 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:50 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:50 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:50 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:50 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:50 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:50 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:50 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:50 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:05:50 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:05:50 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:51 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:51 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:05:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:05:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 18:05:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:05:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:05:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:05:51 --> Final output sent to browser
DEBUG - 2015-02-06 18:05:51 --> Total execution time: 0.8591
DEBUG - 2015-02-06 18:05:59 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:59 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:59 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:59 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:59 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:59 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:59 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:59 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:05:59 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:05:59 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 18:05:59 --> Config Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:05:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:05:59 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:05:59 --> URI Class Initialized
DEBUG - 2015-02-06 18:05:59 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:05:59 --> Router Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Output Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Security Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Input Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:05:59 --> Language Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Loader Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:05:59 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:05:59 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:05:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Controller Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:05:59 --> Email Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:05:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:05:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:05:59 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:05:59 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:05:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:05:59 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:06:00 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:00 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:06:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:06:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:06:01 --> Final output sent to browser
DEBUG - 2015-02-06 18:06:01 --> Total execution time: 1.2751
DEBUG - 2015-02-06 18:06:03 --> Config Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:06:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:06:03 --> URI Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Router Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Output Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Security Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Input Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:06:03 --> Language Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Loader Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:06:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:06:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:06:03 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Controller Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:06:03 --> Email Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:06:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:06:03 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:06:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:06:03 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:06:03 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:06:03 --> Session: Creating new session (75fcae5b34cddd172407dd1cae3deb9d)
DEBUG - 2015-02-06 18:06:03 --> Config Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:06:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:06:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:06:03 --> URI Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Router Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Output Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Security Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Input Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:06:03 --> Language Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Loader Class Initialized
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:06:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:06:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:06:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:06:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Controller Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:06:04 --> Email Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:06:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:06:04 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:06:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:06:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:06:04 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:06:04 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:06:04 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:06:04 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:06:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-06 18:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:06:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:06:04 --> Final output sent to browser
DEBUG - 2015-02-06 18:06:04 --> Total execution time: 0.8321
DEBUG - 2015-02-06 18:06:14 --> Config Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:06:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:06:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:06:14 --> URI Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Router Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Output Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Security Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Input Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:06:14 --> Language Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Loader Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:06:14 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:06:14 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:06:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Controller Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:06:14 --> Email Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:06:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:06:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:06:14 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:06:14 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:06:14 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-06 18:06:14 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-06 18:06:14 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-06 18:06:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-06 18:06:15 --> Config Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:06:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:06:15 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:06:15 --> URI Class Initialized
DEBUG - 2015-02-06 18:06:15 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:06:15 --> Router Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Output Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Security Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Input Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:06:15 --> Language Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Loader Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:06:15 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:06:15 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:06:15 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Controller Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:06:15 --> Email Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:06:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:06:15 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:06:15 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:06:15 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:06:15 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:15 --> Model Class Initialized
DEBUG - 2015-02-06 18:06:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:06:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:06:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:06:16 --> Final output sent to browser
DEBUG - 2015-02-06 18:06:16 --> Total execution time: 1.2341
DEBUG - 2015-02-06 18:07:10 --> Config Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:07:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:07:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:07:10 --> URI Class Initialized
DEBUG - 2015-02-06 18:07:10 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:07:10 --> Router Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Output Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Security Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Input Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:07:10 --> Language Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Loader Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:07:10 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:07:10 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:07:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Controller Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:07:10 --> Email Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:07:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:07:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:07:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:07:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:07:10 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:07:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:07:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:07:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:07:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:07:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:07:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:07:12 --> Final output sent to browser
DEBUG - 2015-02-06 18:07:12 --> Total execution time: 1.2981
DEBUG - 2015-02-06 18:07:16 --> Config Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:07:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:07:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:07:16 --> URI Class Initialized
DEBUG - 2015-02-06 18:07:16 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:07:16 --> Router Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Output Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Security Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Input Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:07:16 --> Language Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Loader Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:07:16 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:07:16 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:07:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Controller Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:07:16 --> Email Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:07:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:07:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:07:16 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:07:16 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:07:16 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:07:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:17 --> Model Class Initialized
DEBUG - 2015-02-06 18:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:07:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:07:17 --> Final output sent to browser
DEBUG - 2015-02-06 18:07:17 --> Total execution time: 1.2261
DEBUG - 2015-02-06 18:08:14 --> Config Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:08:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:08:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:08:14 --> URI Class Initialized
DEBUG - 2015-02-06 18:08:14 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:08:14 --> Router Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Output Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Security Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Input Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:08:14 --> Language Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Loader Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:08:14 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:08:14 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:08:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Controller Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:08:14 --> Email Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:08:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:08:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:08:14 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:08:14 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:08:14 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:08:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:08:15 --> Final output sent to browser
DEBUG - 2015-02-06 18:08:15 --> Total execution time: 1.4651
DEBUG - 2015-02-06 18:08:44 --> Config Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:08:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:08:44 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:08:44 --> URI Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Router Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Output Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Security Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Input Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:08:44 --> Language Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Loader Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:08:44 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:08:44 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:08:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:08:44 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:08:44 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:08:44 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Controller Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:08:44 --> Email Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:08:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:08:44 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:08:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:08:44 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:08:44 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:08:45 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:08:45 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:08:45 --> Model Class Initialized
ERROR - 2015-02-06 18:08:45 --> Severity: 4096 --> Argument 1 passed to Article_model::getCategoryBySlugName() must be an instance of Entity\Articles, null given, called in D:\phutx\project\ups\myblog\application\controllers\article.php on line 11 and defined D:\phutx\project\ups\myblog\application\models\Article_model.php 193
ERROR - 2015-02-06 18:08:45 --> Severity: 4096 --> Argument 1 passed to Article_model::getTagBySlugName() must be an instance of Entity\Articles, null given, called in D:\phutx\project\ups\myblog\application\controllers\article.php on line 19 and defined D:\phutx\project\ups\myblog\application\models\Article_model.php 198
DEBUG - 2015-02-06 18:08:45 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:45 --> Model Class Initialized
DEBUG - 2015-02-06 18:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:08:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-06 18:08:45 --> Severity: Error --> Call to a member function getTitle() on a non-object D:\phutx\project\ups\myblog\application\views\article\index.php 13
DEBUG - 2015-02-06 18:09:44 --> Config Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:09:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:09:44 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:09:44 --> URI Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Router Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Output Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Security Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Input Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:09:44 --> Language Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Loader Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:09:44 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:09:44 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:09:44 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Controller Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:09:44 --> Email Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:09:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:09:44 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:09:44 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:09:44 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:09:44 --> Model Class Initialized
ERROR - 2015-02-06 18:09:45 --> Severity: 4096 --> Argument 1 passed to Article_model::getCategoryBySlugName() must be an instance of Entity\Articles, null given, called in D:\phutx\project\ups\myblog\application\controllers\article.php on line 11 and defined D:\phutx\project\ups\myblog\application\models\Article_model.php 193
ERROR - 2015-02-06 18:09:45 --> Severity: 4096 --> Argument 1 passed to Article_model::getTagBySlugName() must be an instance of Entity\Articles, null given, called in D:\phutx\project\ups\myblog\application\controllers\article.php on line 19 and defined D:\phutx\project\ups\myblog\application\models\Article_model.php 198
DEBUG - 2015-02-06 18:09:45 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:45 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:09:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
ERROR - 2015-02-06 18:09:45 --> Severity: Error --> Call to a member function getTitle() on a non-object D:\phutx\project\ups\myblog\application\views\article\index.php 13
DEBUG - 2015-02-06 18:09:58 --> Config Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:09:58 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:09:58 --> URI Class Initialized
DEBUG - 2015-02-06 18:09:58 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:09:58 --> Router Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Output Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Security Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Input Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:09:58 --> Language Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Loader Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:09:58 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:09:58 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Controller Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:09:58 --> Email Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:09:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:09:58 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:09:58 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:09:58 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:09:58 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:59 --> Model Class Initialized
DEBUG - 2015-02-06 18:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:09:59 --> Final output sent to browser
DEBUG - 2015-02-06 18:09:59 --> Total execution time: 1.2191
DEBUG - 2015-02-06 18:10:08 --> Config Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:10:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:10:08 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:10:08 --> URI Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Router Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Output Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Security Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Input Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:10:08 --> Language Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Loader Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:10:08 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:10:08 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:10:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Controller Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:10:08 --> Email Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:10:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:10:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:10:08 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:10:08 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:09 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:10:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:10:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 18:10:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:10:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:10:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:10:09 --> Final output sent to browser
DEBUG - 2015-02-06 18:10:09 --> Total execution time: 1.3731
DEBUG - 2015-02-06 18:10:16 --> Config Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:10:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:10:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:10:16 --> URI Class Initialized
DEBUG - 2015-02-06 18:10:16 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:10:16 --> Router Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Output Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Security Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Input Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:10:16 --> Language Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Loader Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:10:16 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:10:16 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Controller Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:10:16 --> Email Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:10:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:10:16 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:10:16 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:10:16 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:10:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:10:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:10:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:10:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:10:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:10:17 --> Final output sent to browser
DEBUG - 2015-02-06 18:10:17 --> Total execution time: 1.2801
DEBUG - 2015-02-06 18:10:47 --> Config Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:10:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:10:47 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:10:47 --> URI Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Router Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Output Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Security Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Input Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:10:47 --> Language Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Loader Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:10:47 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:10:47 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:10:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Controller Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:10:47 --> Email Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:10:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:10:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:10:47 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:10:47 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:10:47 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:48 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:48 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 18:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:10:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:10:48 --> Final output sent to browser
DEBUG - 2015-02-06 18:10:48 --> Total execution time: 1.7212
DEBUG - 2015-02-06 18:10:52 --> Config Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:10:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:10:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:10:52 --> URI Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Router Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Output Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Security Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Input Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:10:52 --> Language Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Loader Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:10:52 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:10:52 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Controller Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:10:52 --> Email Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:10:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:10:52 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Config Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:10:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:10:52 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:10:52 --> URI Class Initialized
DEBUG - 2015-02-06 18:10:52 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:10:52 --> Router Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Output Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Security Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Input Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:10:52 --> Language Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Loader Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:10:52 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:10:52 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Controller Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:10:52 --> Email Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:10:52 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:10:52 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:10:52 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:52 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:10:52 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:10:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:53 --> Model Class Initialized
DEBUG - 2015-02-06 18:10:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:10:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:10:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:10:54 --> Final output sent to browser
DEBUG - 2015-02-06 18:10:54 --> Total execution time: 1.3691
DEBUG - 2015-02-06 18:11:38 --> Config Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:11:38 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:11:38 --> URI Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Router Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Output Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Security Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Input Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:11:38 --> Language Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Loader Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:11:38 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Session: Regenerate ID
DEBUG - 2015-02-06 18:11:38 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:11:38 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Controller Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:11:38 --> Email Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:11:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:11:38 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:11:38 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:11:38 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:11:38 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:39 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:39 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 18:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:11:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:11:39 --> Final output sent to browser
DEBUG - 2015-02-06 18:11:39 --> Total execution time: 1.3841
DEBUG - 2015-02-06 18:11:40 --> Config Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:11:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:11:40 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:11:40 --> URI Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Router Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Output Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Security Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Input Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:11:40 --> Language Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Loader Class Initialized
DEBUG - 2015-02-06 18:11:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:11:40 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:11:40 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:11:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:11:40 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:11:40 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:11:41 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:41 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:41 --> Controller Class Initialized
DEBUG - 2015-02-06 18:11:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:11:41 --> Email Class Initialized
DEBUG - 2015-02-06 18:11:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:11:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:11:41 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:11:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:11:41 --> Model Class Initialized
DEBUG - 2015-02-06 18:11:41 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:11:41 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:11:41 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:11:41 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:11:41 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Config Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:12:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:12:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:12:10 --> URI Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Router Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Output Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Security Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Input Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:12:10 --> Language Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Loader Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:12:10 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:12:10 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:12:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Controller Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:12:10 --> Email Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:12:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:12:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:12:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:12:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:12:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:12:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:12:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-06 18:12:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:12:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:12:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:12:11 --> Final output sent to browser
DEBUG - 2015-02-06 18:12:11 --> Total execution time: 1.3931
DEBUG - 2015-02-06 18:12:13 --> Config Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:12:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:12:13 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:12:13 --> URI Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Router Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Output Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Security Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Input Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:12:13 --> Language Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Loader Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:12:13 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:12:13 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:12:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Controller Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:12:13 --> Email Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:12:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:12:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:12:13 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:12:13 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:12:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 18:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:12:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:12:14 --> Final output sent to browser
DEBUG - 2015-02-06 18:12:14 --> Total execution time: 1.1811
DEBUG - 2015-02-06 18:12:16 --> Config Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:12:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:12:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:12:16 --> URI Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Router Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Output Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Security Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Input Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:12:16 --> Language Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Loader Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:12:16 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:12:16 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:12:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:12:16 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:12:16 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:12:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Controller Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:12:16 --> Email Class Initialized
DEBUG - 2015-02-06 18:12:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:12:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:12:16 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:12:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:12:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:12:17 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:12:17 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:12:17 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:12:17 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:12:17 --> Model Class Initialized
ERROR - 2015-02-06 18:12:17 --> Severity: Notice --> Undefined offset: 0 D:\phutx\project\ups\myblog\application\controllers\category.php 18
ERROR - 2015-02-06 18:12:17 --> Severity: Error --> Call to a member function getArticles() on a non-object D:\phutx\project\ups\myblog\application\controllers\category.php 18
DEBUG - 2015-02-06 18:13:02 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:02 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:02 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:02 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:02 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:02 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:02 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:02 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:02 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:02 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:04 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:04 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:04 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:04 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:04 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:04 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:04 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:04 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:04 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:13:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:13:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\category/index.php
DEBUG - 2015-02-06 18:13:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:13:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:13:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:13:05 --> Final output sent to browser
DEBUG - 2015-02-06 18:13:05 --> Total execution time: 1.1371
DEBUG - 2015-02-06 18:13:07 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:07 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:07 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:07 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:07 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:07 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:07 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:07 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\tag/index.php
DEBUG - 2015-02-06 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:13:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:13:08 --> Final output sent to browser
DEBUG - 2015-02-06 18:13:08 --> Total execution time: 1.1981
DEBUG - 2015-02-06 18:13:10 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:10 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:10 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:10 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:10 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:10 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:10 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:10 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:10 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:10 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:11 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:13:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:13:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\tag/view.php
DEBUG - 2015-02-06 18:13:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:13:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:13:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:13:11 --> Final output sent to browser
DEBUG - 2015-02-06 18:13:11 --> Total execution time: 1.1321
DEBUG - 2015-02-06 18:13:14 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:14 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:14 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:14 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:14 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:14 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:14 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:14 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:14 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:16 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:16 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:16 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:16 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:16 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:16 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:16 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:16 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:16 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:17 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:13:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:13:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\tag/view.php
DEBUG - 2015-02-06 18:13:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:13:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:13:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:13:17 --> Final output sent to browser
DEBUG - 2015-02-06 18:13:17 --> Total execution time: 1.2121
DEBUG - 2015-02-06 18:13:20 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:20 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:20 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:20 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:20 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:20 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:20 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:20 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:20 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:20 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:20 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:20 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:21 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:13:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:13:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\tag/index.php
DEBUG - 2015-02-06 18:13:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:13:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:13:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:13:21 --> Final output sent to browser
DEBUG - 2015-02-06 18:13:21 --> Total execution time: 1.1721
DEBUG - 2015-02-06 18:13:23 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:23 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:23 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:23 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:23 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:23 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:23 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:23 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:23 --> Language Class Initialized
ERROR - 2015-02-06 18:13:23 --> 404 Page Not Found: Tag1/index
DEBUG - 2015-02-06 18:13:25 --> Config Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:13:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:13:25 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:13:25 --> URI Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Router Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Output Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Security Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Input Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:13:25 --> Language Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Loader Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:13:25 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:13:25 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:13:25 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Controller Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:13:25 --> Email Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:13:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:13:25 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:13:25 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:13:25 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:25 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:26 --> Model Class Initialized
DEBUG - 2015-02-06 18:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\tag/index.php
DEBUG - 2015-02-06 18:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:13:26 --> Final output sent to browser
DEBUG - 2015-02-06 18:13:26 --> Total execution time: 1.2211
DEBUG - 2015-02-06 18:15:05 --> Config Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:15:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:15:05 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:15:05 --> URI Class Initialized
DEBUG - 2015-02-06 18:15:05 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:15:05 --> Router Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Output Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Security Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Input Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:15:05 --> Language Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Loader Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:15:05 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:15:05 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:15:05 --> Model Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Model Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Controller Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:15:05 --> Email Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:15:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:15:05 --> Model Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:15:05 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:15:05 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Model Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:15:05 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:15:05 --> Model Class Initialized
DEBUG - 2015-02-06 18:15:06 --> Model Class Initialized
DEBUG - 2015-02-06 18:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:15:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:15:06 --> Final output sent to browser
DEBUG - 2015-02-06 18:15:06 --> Total execution time: 1.2981
DEBUG - 2015-02-06 18:30:07 --> Config Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:30:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:30:07 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:30:07 --> URI Class Initialized
DEBUG - 2015-02-06 18:30:07 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:30:07 --> Router Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Output Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Security Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Input Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:30:07 --> Language Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Loader Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:30:07 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Session: Regenerate ID
DEBUG - 2015-02-06 18:30:07 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Controller Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:30:07 --> Email Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:30:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:30:07 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:30:07 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:30:07 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:30:07 --> Model Class Initialized
DEBUG - 2015-02-06 18:30:08 --> Model Class Initialized
DEBUG - 2015-02-06 18:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:30:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:30:08 --> Final output sent to browser
DEBUG - 2015-02-06 18:30:08 --> Total execution time: 1.1631
DEBUG - 2015-02-06 18:45:12 --> Config Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 18:45:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 18:45:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 18:45:12 --> URI Class Initialized
DEBUG - 2015-02-06 18:45:12 --> No URI present. Default controller set.
DEBUG - 2015-02-06 18:45:12 --> Router Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Output Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Security Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Input Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 18:45:12 --> Language Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Loader Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 18:45:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 18:45:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 18:45:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 18:45:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 18:45:12 --> Session: Regenerate ID
DEBUG - 2015-02-06 18:45:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 18:45:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Controller Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 18:45:13 --> Email Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 18:45:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 18:45:13 --> Helper loaded: language_helper
DEBUG - 2015-02-06 18:45:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 18:45:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Database Driver Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Helper loaded: date_helper
DEBUG - 2015-02-06 18:45:13 --> Helper loaded: form_helper
DEBUG - 2015-02-06 18:45:13 --> Form Validation Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 18:45:13 --> Pagination Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:45:13 --> Model Class Initialized
DEBUG - 2015-02-06 18:45:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 18:45:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 18:45:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 18:45:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 18:45:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 18:45:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 18:45:14 --> Final output sent to browser
DEBUG - 2015-02-06 18:45:14 --> Total execution time: 1.1611
DEBUG - 2015-02-06 19:00:15 --> Config Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Hooks Class Initialized
DEBUG - 2015-02-06 19:00:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 19:00:15 --> Utf8 Class Initialized
DEBUG - 2015-02-06 19:00:15 --> URI Class Initialized
DEBUG - 2015-02-06 19:00:15 --> No URI present. Default controller set.
DEBUG - 2015-02-06 19:00:15 --> Router Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Output Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Security Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Input Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 19:00:15 --> Language Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Loader Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: url_helper
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: link_helper
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 19:00:15 --> CI_Session Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Session: Regenerate ID
DEBUG - 2015-02-06 19:00:15 --> CI_Session routines successfully run
DEBUG - 2015-02-06 19:00:15 --> Model Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Model Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Controller Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 19:00:15 --> Email Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: language_helper
DEBUG - 2015-02-06 19:00:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 19:00:15 --> Model Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Database Driver Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: date_helper
DEBUG - 2015-02-06 19:00:15 --> Helper loaded: form_helper
DEBUG - 2015-02-06 19:00:15 --> Form Validation Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Model Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 19:00:15 --> Pagination Class Initialized
DEBUG - 2015-02-06 19:00:15 --> Model Class Initialized
DEBUG - 2015-02-06 19:00:16 --> Model Class Initialized
DEBUG - 2015-02-06 19:00:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 19:00:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 19:00:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 19:00:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 19:00:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 19:00:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 19:00:16 --> Final output sent to browser
DEBUG - 2015-02-06 19:00:16 --> Total execution time: 1.1371
DEBUG - 2015-02-06 19:15:19 --> Config Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Hooks Class Initialized
DEBUG - 2015-02-06 19:15:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 19:15:19 --> Utf8 Class Initialized
DEBUG - 2015-02-06 19:15:19 --> URI Class Initialized
DEBUG - 2015-02-06 19:15:19 --> No URI present. Default controller set.
DEBUG - 2015-02-06 19:15:19 --> Router Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Output Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Security Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Input Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 19:15:19 --> Language Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Loader Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 19:15:19 --> Helper loaded: url_helper
DEBUG - 2015-02-06 19:15:19 --> Helper loaded: link_helper
DEBUG - 2015-02-06 19:15:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 19:15:19 --> CI_Session Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Session: Regenerate ID
DEBUG - 2015-02-06 19:15:19 --> CI_Session routines successfully run
DEBUG - 2015-02-06 19:15:19 --> Model Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Model Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Controller Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 19:15:19 --> Email Class Initialized
DEBUG - 2015-02-06 19:15:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 19:15:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 19:15:19 --> Helper loaded: language_helper
DEBUG - 2015-02-06 19:15:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 19:15:19 --> Model Class Initialized
DEBUG - 2015-02-06 19:15:20 --> Database Driver Class Initialized
DEBUG - 2015-02-06 19:15:20 --> Helper loaded: date_helper
DEBUG - 2015-02-06 19:15:20 --> Helper loaded: form_helper
DEBUG - 2015-02-06 19:15:20 --> Form Validation Class Initialized
DEBUG - 2015-02-06 19:15:20 --> Model Class Initialized
DEBUG - 2015-02-06 19:15:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 19:15:20 --> Pagination Class Initialized
DEBUG - 2015-02-06 19:15:20 --> Model Class Initialized
DEBUG - 2015-02-06 19:15:20 --> Model Class Initialized
DEBUG - 2015-02-06 19:15:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 19:15:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 19:15:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 19:15:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 19:15:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 19:15:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 19:15:20 --> Final output sent to browser
DEBUG - 2015-02-06 19:15:20 --> Total execution time: 1.1331
DEBUG - 2015-02-06 19:30:22 --> Config Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Hooks Class Initialized
DEBUG - 2015-02-06 19:30:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 19:30:22 --> Utf8 Class Initialized
DEBUG - 2015-02-06 19:30:22 --> URI Class Initialized
DEBUG - 2015-02-06 19:30:22 --> No URI present. Default controller set.
DEBUG - 2015-02-06 19:30:22 --> Router Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Output Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Security Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Input Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 19:30:22 --> Language Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Loader Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: url_helper
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: link_helper
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 19:30:22 --> CI_Session Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Session: Regenerate ID
DEBUG - 2015-02-06 19:30:22 --> CI_Session routines successfully run
DEBUG - 2015-02-06 19:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Controller Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 19:30:22 --> Email Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: language_helper
DEBUG - 2015-02-06 19:30:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 19:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Database Driver Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: date_helper
DEBUG - 2015-02-06 19:30:22 --> Helper loaded: form_helper
DEBUG - 2015-02-06 19:30:22 --> Form Validation Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 19:30:22 --> Pagination Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 19:30:22 --> Model Class Initialized
DEBUG - 2015-02-06 19:30:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 19:30:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 19:30:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 19:30:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 19:30:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 19:30:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 19:30:23 --> Final output sent to browser
DEBUG - 2015-02-06 19:30:23 --> Total execution time: 1.1311
DEBUG - 2015-02-06 19:45:24 --> Config Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Hooks Class Initialized
DEBUG - 2015-02-06 19:45:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 19:45:24 --> Utf8 Class Initialized
DEBUG - 2015-02-06 19:45:24 --> URI Class Initialized
DEBUG - 2015-02-06 19:45:24 --> No URI present. Default controller set.
DEBUG - 2015-02-06 19:45:24 --> Router Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Output Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Security Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Input Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 19:45:24 --> Language Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Loader Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: url_helper
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: link_helper
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 19:45:24 --> CI_Session Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Session: Regenerate ID
DEBUG - 2015-02-06 19:45:24 --> CI_Session routines successfully run
DEBUG - 2015-02-06 19:45:24 --> Model Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Model Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Controller Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 19:45:24 --> Email Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: language_helper
DEBUG - 2015-02-06 19:45:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 19:45:24 --> Model Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Database Driver Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: date_helper
DEBUG - 2015-02-06 19:45:24 --> Helper loaded: form_helper
DEBUG - 2015-02-06 19:45:24 --> Form Validation Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Model Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 19:45:24 --> Pagination Class Initialized
DEBUG - 2015-02-06 19:45:24 --> Model Class Initialized
DEBUG - 2015-02-06 19:45:25 --> Model Class Initialized
DEBUG - 2015-02-06 19:45:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 19:45:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 19:45:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 19:45:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 19:45:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 19:45:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 19:45:25 --> Final output sent to browser
DEBUG - 2015-02-06 19:45:25 --> Total execution time: 1.1581
DEBUG - 2015-02-06 20:00:26 --> Config Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Hooks Class Initialized
DEBUG - 2015-02-06 20:00:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 20:00:26 --> Utf8 Class Initialized
DEBUG - 2015-02-06 20:00:26 --> URI Class Initialized
DEBUG - 2015-02-06 20:00:26 --> No URI present. Default controller set.
DEBUG - 2015-02-06 20:00:26 --> Router Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Output Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Security Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Input Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 20:00:26 --> Language Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Loader Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: url_helper
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: link_helper
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 20:00:26 --> CI_Session Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Session: Regenerate ID
DEBUG - 2015-02-06 20:00:26 --> CI_Session routines successfully run
DEBUG - 2015-02-06 20:00:26 --> Model Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Model Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Controller Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 20:00:26 --> Email Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: language_helper
DEBUG - 2015-02-06 20:00:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 20:00:26 --> Model Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Database Driver Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: date_helper
DEBUG - 2015-02-06 20:00:26 --> Helper loaded: form_helper
DEBUG - 2015-02-06 20:00:26 --> Form Validation Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Model Class Initialized
DEBUG - 2015-02-06 20:00:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 20:00:26 --> Pagination Class Initialized
DEBUG - 2015-02-06 20:00:27 --> Model Class Initialized
DEBUG - 2015-02-06 20:00:27 --> Model Class Initialized
DEBUG - 2015-02-06 20:00:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 20:00:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 20:00:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 20:00:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 20:00:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 20:00:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 20:00:27 --> Final output sent to browser
DEBUG - 2015-02-06 20:00:27 --> Total execution time: 1.1961
DEBUG - 2015-02-06 20:15:28 --> Config Class Initialized
DEBUG - 2015-02-06 20:15:28 --> Hooks Class Initialized
DEBUG - 2015-02-06 20:15:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 20:15:28 --> Utf8 Class Initialized
DEBUG - 2015-02-06 20:15:28 --> URI Class Initialized
DEBUG - 2015-02-06 20:15:28 --> No URI present. Default controller set.
DEBUG - 2015-02-06 20:15:28 --> Router Class Initialized
DEBUG - 2015-02-06 20:15:28 --> Output Class Initialized
DEBUG - 2015-02-06 20:15:28 --> Security Class Initialized
DEBUG - 2015-02-06 20:15:28 --> Input Class Initialized
DEBUG - 2015-02-06 20:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 20:15:28 --> Language Class Initialized
DEBUG - 2015-02-06 20:15:28 --> Loader Class Initialized
DEBUG - 2015-02-06 20:15:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 20:15:28 --> Helper loaded: url_helper
DEBUG - 2015-02-06 20:15:28 --> Helper loaded: link_helper
DEBUG - 2015-02-06 20:15:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 20:15:29 --> CI_Session Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Session: Regenerate ID
DEBUG - 2015-02-06 20:15:29 --> CI_Session routines successfully run
DEBUG - 2015-02-06 20:15:29 --> Model Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Model Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Controller Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 20:15:29 --> Email Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 20:15:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 20:15:29 --> Helper loaded: language_helper
DEBUG - 2015-02-06 20:15:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 20:15:29 --> Model Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Database Driver Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Helper loaded: date_helper
DEBUG - 2015-02-06 20:15:29 --> Helper loaded: form_helper
DEBUG - 2015-02-06 20:15:29 --> Form Validation Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Model Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 20:15:29 --> Pagination Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Model Class Initialized
DEBUG - 2015-02-06 20:15:29 --> Model Class Initialized
DEBUG - 2015-02-06 20:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 20:15:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 20:15:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 20:15:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 20:15:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 20:15:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 20:15:30 --> Final output sent to browser
DEBUG - 2015-02-06 20:15:30 --> Total execution time: 1.1551
DEBUG - 2015-02-06 20:30:31 --> Config Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Hooks Class Initialized
DEBUG - 2015-02-06 20:30:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 20:30:31 --> Utf8 Class Initialized
DEBUG - 2015-02-06 20:30:31 --> URI Class Initialized
DEBUG - 2015-02-06 20:30:31 --> No URI present. Default controller set.
DEBUG - 2015-02-06 20:30:31 --> Router Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Output Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Security Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Input Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 20:30:31 --> Language Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Loader Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: url_helper
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: link_helper
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 20:30:31 --> CI_Session Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Session: Regenerate ID
DEBUG - 2015-02-06 20:30:31 --> CI_Session routines successfully run
DEBUG - 2015-02-06 20:30:31 --> Model Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Model Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Controller Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 20:30:31 --> Email Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: language_helper
DEBUG - 2015-02-06 20:30:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 20:30:31 --> Model Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Database Driver Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: date_helper
DEBUG - 2015-02-06 20:30:31 --> Helper loaded: form_helper
DEBUG - 2015-02-06 20:30:31 --> Form Validation Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Model Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 20:30:31 --> Pagination Class Initialized
DEBUG - 2015-02-06 20:30:31 --> Model Class Initialized
DEBUG - 2015-02-06 20:30:32 --> Model Class Initialized
DEBUG - 2015-02-06 20:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 20:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 20:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 20:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 20:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 20:30:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 20:30:32 --> Final output sent to browser
DEBUG - 2015-02-06 20:30:32 --> Total execution time: 1.1661
DEBUG - 2015-02-06 20:45:42 --> Config Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Hooks Class Initialized
DEBUG - 2015-02-06 20:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 20:45:42 --> Utf8 Class Initialized
DEBUG - 2015-02-06 20:45:42 --> URI Class Initialized
DEBUG - 2015-02-06 20:45:42 --> No URI present. Default controller set.
DEBUG - 2015-02-06 20:45:42 --> Router Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Output Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Security Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Input Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 20:45:42 --> Language Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Loader Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: url_helper
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: link_helper
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 20:45:42 --> CI_Session Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Session: Regenerate ID
DEBUG - 2015-02-06 20:45:42 --> CI_Session routines successfully run
DEBUG - 2015-02-06 20:45:42 --> Model Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Model Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Controller Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 20:45:42 --> Email Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: language_helper
DEBUG - 2015-02-06 20:45:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 20:45:42 --> Model Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Database Driver Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: date_helper
DEBUG - 2015-02-06 20:45:42 --> Helper loaded: form_helper
DEBUG - 2015-02-06 20:45:42 --> Form Validation Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Model Class Initialized
DEBUG - 2015-02-06 20:45:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 20:45:42 --> Pagination Class Initialized
DEBUG - 2015-02-06 20:45:43 --> Model Class Initialized
DEBUG - 2015-02-06 20:45:43 --> Model Class Initialized
DEBUG - 2015-02-06 20:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 20:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 20:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 20:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 20:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 20:45:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 20:45:43 --> Final output sent to browser
DEBUG - 2015-02-06 20:45:43 --> Total execution time: 1.1671
DEBUG - 2015-02-06 21:00:45 --> Config Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Hooks Class Initialized
DEBUG - 2015-02-06 21:00:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 21:00:45 --> Utf8 Class Initialized
DEBUG - 2015-02-06 21:00:45 --> URI Class Initialized
DEBUG - 2015-02-06 21:00:45 --> No URI present. Default controller set.
DEBUG - 2015-02-06 21:00:45 --> Router Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Output Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Security Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Input Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 21:00:45 --> Language Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Loader Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: url_helper
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: link_helper
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 21:00:45 --> CI_Session Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Session: Regenerate ID
DEBUG - 2015-02-06 21:00:45 --> CI_Session routines successfully run
DEBUG - 2015-02-06 21:00:45 --> Model Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Model Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Controller Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 21:00:45 --> Email Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: language_helper
DEBUG - 2015-02-06 21:00:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 21:00:45 --> Model Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Database Driver Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: date_helper
DEBUG - 2015-02-06 21:00:45 --> Helper loaded: form_helper
DEBUG - 2015-02-06 21:00:45 --> Form Validation Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Model Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 21:00:45 --> Pagination Class Initialized
DEBUG - 2015-02-06 21:00:45 --> Model Class Initialized
DEBUG - 2015-02-06 21:00:46 --> Model Class Initialized
DEBUG - 2015-02-06 21:00:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 21:00:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 21:00:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 21:00:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 21:00:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 21:00:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 21:00:46 --> Final output sent to browser
DEBUG - 2015-02-06 21:00:46 --> Total execution time: 1.2121
DEBUG - 2015-02-06 21:15:48 --> Config Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Hooks Class Initialized
DEBUG - 2015-02-06 21:15:48 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 21:15:48 --> Utf8 Class Initialized
DEBUG - 2015-02-06 21:15:48 --> URI Class Initialized
DEBUG - 2015-02-06 21:15:48 --> No URI present. Default controller set.
DEBUG - 2015-02-06 21:15:48 --> Router Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Output Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Security Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Input Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 21:15:48 --> Language Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Loader Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 21:15:48 --> Helper loaded: url_helper
DEBUG - 2015-02-06 21:15:48 --> Helper loaded: link_helper
DEBUG - 2015-02-06 21:15:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 21:15:48 --> CI_Session Class Initialized
DEBUG - 2015-02-06 21:15:48 --> Session: Regenerate ID
DEBUG - 2015-02-06 21:15:48 --> CI_Session routines successfully run
DEBUG - 2015-02-06 21:15:49 --> Model Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Model Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Controller Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 21:15:49 --> Email Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 21:15:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 21:15:49 --> Helper loaded: language_helper
DEBUG - 2015-02-06 21:15:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 21:15:49 --> Model Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Database Driver Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Helper loaded: date_helper
DEBUG - 2015-02-06 21:15:49 --> Helper loaded: form_helper
DEBUG - 2015-02-06 21:15:49 --> Form Validation Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Model Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 21:15:49 --> Pagination Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Model Class Initialized
DEBUG - 2015-02-06 21:15:49 --> Model Class Initialized
DEBUG - 2015-02-06 21:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 21:15:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 21:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 21:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 21:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 21:15:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 21:15:50 --> Final output sent to browser
DEBUG - 2015-02-06 21:15:50 --> Total execution time: 1.1381
DEBUG - 2015-02-06 21:30:51 --> Config Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Hooks Class Initialized
DEBUG - 2015-02-06 21:30:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 21:30:51 --> Utf8 Class Initialized
DEBUG - 2015-02-06 21:30:51 --> URI Class Initialized
DEBUG - 2015-02-06 21:30:51 --> No URI present. Default controller set.
DEBUG - 2015-02-06 21:30:51 --> Router Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Output Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Security Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Input Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 21:30:51 --> Language Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Loader Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: url_helper
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: link_helper
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 21:30:51 --> CI_Session Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Session: Regenerate ID
DEBUG - 2015-02-06 21:30:51 --> CI_Session routines successfully run
DEBUG - 2015-02-06 21:30:51 --> Model Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Model Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Controller Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 21:30:51 --> Email Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: language_helper
DEBUG - 2015-02-06 21:30:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 21:30:51 --> Model Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Database Driver Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: date_helper
DEBUG - 2015-02-06 21:30:51 --> Helper loaded: form_helper
DEBUG - 2015-02-06 21:30:51 --> Form Validation Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Model Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 21:30:51 --> Pagination Class Initialized
DEBUG - 2015-02-06 21:30:51 --> Model Class Initialized
DEBUG - 2015-02-06 21:30:52 --> Model Class Initialized
DEBUG - 2015-02-06 21:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 21:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 21:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 21:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 21:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 21:30:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 21:30:52 --> Final output sent to browser
DEBUG - 2015-02-06 21:30:52 --> Total execution time: 1.1701
DEBUG - 2015-02-06 21:45:53 --> Config Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Hooks Class Initialized
DEBUG - 2015-02-06 21:45:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 21:45:53 --> Utf8 Class Initialized
DEBUG - 2015-02-06 21:45:53 --> URI Class Initialized
DEBUG - 2015-02-06 21:45:53 --> No URI present. Default controller set.
DEBUG - 2015-02-06 21:45:53 --> Router Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Output Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Security Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Input Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 21:45:53 --> Language Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Loader Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: url_helper
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: link_helper
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 21:45:53 --> CI_Session Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Session: Regenerate ID
DEBUG - 2015-02-06 21:45:53 --> CI_Session routines successfully run
DEBUG - 2015-02-06 21:45:53 --> Model Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Model Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Controller Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 21:45:53 --> Email Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: language_helper
DEBUG - 2015-02-06 21:45:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 21:45:53 --> Model Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Database Driver Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: date_helper
DEBUG - 2015-02-06 21:45:53 --> Helper loaded: form_helper
DEBUG - 2015-02-06 21:45:53 --> Form Validation Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Model Class Initialized
DEBUG - 2015-02-06 21:45:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 21:45:53 --> Pagination Class Initialized
DEBUG - 2015-02-06 21:45:54 --> Model Class Initialized
DEBUG - 2015-02-06 21:45:54 --> Model Class Initialized
DEBUG - 2015-02-06 21:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 21:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 21:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 21:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 21:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 21:45:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 21:45:54 --> Final output sent to browser
DEBUG - 2015-02-06 21:45:54 --> Total execution time: 1.2011
DEBUG - 2015-02-06 22:00:56 --> Config Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Hooks Class Initialized
DEBUG - 2015-02-06 22:00:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 22:00:56 --> Utf8 Class Initialized
DEBUG - 2015-02-06 22:00:56 --> URI Class Initialized
DEBUG - 2015-02-06 22:00:56 --> No URI present. Default controller set.
DEBUG - 2015-02-06 22:00:56 --> Router Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Output Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Security Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Input Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 22:00:56 --> Language Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Loader Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: url_helper
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: link_helper
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 22:00:56 --> CI_Session Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Session: Regenerate ID
DEBUG - 2015-02-06 22:00:56 --> CI_Session routines successfully run
DEBUG - 2015-02-06 22:00:56 --> Model Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Model Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Controller Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 22:00:56 --> Email Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: language_helper
DEBUG - 2015-02-06 22:00:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 22:00:56 --> Model Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Database Driver Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: date_helper
DEBUG - 2015-02-06 22:00:56 --> Helper loaded: form_helper
DEBUG - 2015-02-06 22:00:56 --> Form Validation Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Model Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 22:00:56 --> Pagination Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Model Class Initialized
DEBUG - 2015-02-06 22:00:56 --> Model Class Initialized
DEBUG - 2015-02-06 22:00:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 22:00:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 22:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 22:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 22:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 22:00:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 22:00:57 --> Final output sent to browser
DEBUG - 2015-02-06 22:00:57 --> Total execution time: 1.1941
DEBUG - 2015-02-06 22:15:59 --> Config Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Hooks Class Initialized
DEBUG - 2015-02-06 22:15:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 22:15:59 --> Utf8 Class Initialized
DEBUG - 2015-02-06 22:15:59 --> URI Class Initialized
DEBUG - 2015-02-06 22:15:59 --> No URI present. Default controller set.
DEBUG - 2015-02-06 22:15:59 --> Router Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Output Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Security Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Input Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 22:15:59 --> Language Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Loader Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: url_helper
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: link_helper
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 22:15:59 --> CI_Session Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Session: Regenerate ID
DEBUG - 2015-02-06 22:15:59 --> CI_Session routines successfully run
DEBUG - 2015-02-06 22:15:59 --> Model Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Model Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Controller Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 22:15:59 --> Email Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: language_helper
DEBUG - 2015-02-06 22:15:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 22:15:59 --> Model Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Database Driver Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: date_helper
DEBUG - 2015-02-06 22:15:59 --> Helper loaded: form_helper
DEBUG - 2015-02-06 22:15:59 --> Form Validation Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Model Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 22:15:59 --> Pagination Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Model Class Initialized
DEBUG - 2015-02-06 22:15:59 --> Model Class Initialized
DEBUG - 2015-02-06 22:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 22:15:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 22:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 22:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 22:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 22:16:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 22:16:00 --> Final output sent to browser
DEBUG - 2015-02-06 22:16:00 --> Total execution time: 1.1891
DEBUG - 2015-02-06 22:31:01 --> Config Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Hooks Class Initialized
DEBUG - 2015-02-06 22:31:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 22:31:01 --> Utf8 Class Initialized
DEBUG - 2015-02-06 22:31:01 --> URI Class Initialized
DEBUG - 2015-02-06 22:31:01 --> No URI present. Default controller set.
DEBUG - 2015-02-06 22:31:01 --> Router Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Output Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Security Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Input Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 22:31:01 --> Language Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Loader Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: url_helper
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: link_helper
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 22:31:01 --> CI_Session Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Session: Regenerate ID
DEBUG - 2015-02-06 22:31:01 --> CI_Session routines successfully run
DEBUG - 2015-02-06 22:31:01 --> Model Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Model Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Controller Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 22:31:01 --> Email Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: language_helper
DEBUG - 2015-02-06 22:31:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 22:31:01 --> Model Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Database Driver Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: date_helper
DEBUG - 2015-02-06 22:31:01 --> Helper loaded: form_helper
DEBUG - 2015-02-06 22:31:01 --> Form Validation Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Model Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 22:31:01 --> Pagination Class Initialized
DEBUG - 2015-02-06 22:31:01 --> Model Class Initialized
DEBUG - 2015-02-06 22:31:02 --> Model Class Initialized
DEBUG - 2015-02-06 22:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 22:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 22:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 22:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 22:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 22:31:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 22:31:02 --> Final output sent to browser
DEBUG - 2015-02-06 22:31:02 --> Total execution time: 1.1841
DEBUG - 2015-02-06 22:46:03 --> Config Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Hooks Class Initialized
DEBUG - 2015-02-06 22:46:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 22:46:03 --> Utf8 Class Initialized
DEBUG - 2015-02-06 22:46:03 --> URI Class Initialized
DEBUG - 2015-02-06 22:46:03 --> No URI present. Default controller set.
DEBUG - 2015-02-06 22:46:03 --> Router Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Output Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Security Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Input Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 22:46:03 --> Language Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Loader Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: url_helper
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: link_helper
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 22:46:03 --> CI_Session Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Session: Regenerate ID
DEBUG - 2015-02-06 22:46:03 --> CI_Session routines successfully run
DEBUG - 2015-02-06 22:46:03 --> Model Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Model Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Controller Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 22:46:03 --> Email Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: language_helper
DEBUG - 2015-02-06 22:46:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 22:46:03 --> Model Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Database Driver Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: date_helper
DEBUG - 2015-02-06 22:46:03 --> Helper loaded: form_helper
DEBUG - 2015-02-06 22:46:03 --> Form Validation Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Model Class Initialized
DEBUG - 2015-02-06 22:46:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 22:46:03 --> Pagination Class Initialized
DEBUG - 2015-02-06 22:46:04 --> Model Class Initialized
DEBUG - 2015-02-06 22:46:04 --> Model Class Initialized
DEBUG - 2015-02-06 22:46:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 22:46:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 22:46:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 22:46:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 22:46:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 22:46:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 22:46:04 --> Final output sent to browser
DEBUG - 2015-02-06 22:46:04 --> Total execution time: 1.2171
DEBUG - 2015-02-06 23:01:06 --> Config Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Hooks Class Initialized
DEBUG - 2015-02-06 23:01:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 23:01:06 --> Utf8 Class Initialized
DEBUG - 2015-02-06 23:01:06 --> URI Class Initialized
DEBUG - 2015-02-06 23:01:06 --> No URI present. Default controller set.
DEBUG - 2015-02-06 23:01:06 --> Router Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Output Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Security Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Input Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 23:01:06 --> Language Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Loader Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: url_helper
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: link_helper
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 23:01:06 --> CI_Session Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Session: Regenerate ID
DEBUG - 2015-02-06 23:01:06 --> CI_Session routines successfully run
DEBUG - 2015-02-06 23:01:06 --> Model Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Model Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Controller Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 23:01:06 --> Email Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: language_helper
DEBUG - 2015-02-06 23:01:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 23:01:06 --> Model Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Database Driver Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: date_helper
DEBUG - 2015-02-06 23:01:06 --> Helper loaded: form_helper
DEBUG - 2015-02-06 23:01:06 --> Form Validation Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Model Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 23:01:06 --> Pagination Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Model Class Initialized
DEBUG - 2015-02-06 23:01:06 --> Model Class Initialized
DEBUG - 2015-02-06 23:01:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 23:01:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 23:01:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 23:01:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 23:01:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 23:01:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 23:01:07 --> Final output sent to browser
DEBUG - 2015-02-06 23:01:07 --> Total execution time: 1.1521
DEBUG - 2015-02-06 23:16:09 --> Config Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Hooks Class Initialized
DEBUG - 2015-02-06 23:16:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 23:16:09 --> Utf8 Class Initialized
DEBUG - 2015-02-06 23:16:09 --> URI Class Initialized
DEBUG - 2015-02-06 23:16:09 --> No URI present. Default controller set.
DEBUG - 2015-02-06 23:16:09 --> Router Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Output Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Security Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Input Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 23:16:09 --> Language Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Loader Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: url_helper
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: link_helper
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 23:16:09 --> CI_Session Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Session: Regenerate ID
DEBUG - 2015-02-06 23:16:09 --> CI_Session routines successfully run
DEBUG - 2015-02-06 23:16:09 --> Model Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Model Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Controller Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 23:16:09 --> Email Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: language_helper
DEBUG - 2015-02-06 23:16:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 23:16:09 --> Model Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Database Driver Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: date_helper
DEBUG - 2015-02-06 23:16:09 --> Helper loaded: form_helper
DEBUG - 2015-02-06 23:16:09 --> Form Validation Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Model Class Initialized
DEBUG - 2015-02-06 23:16:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 23:16:09 --> Pagination Class Initialized
DEBUG - 2015-02-06 23:16:10 --> Model Class Initialized
DEBUG - 2015-02-06 23:16:10 --> Model Class Initialized
DEBUG - 2015-02-06 23:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 23:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 23:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 23:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 23:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 23:16:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 23:16:10 --> Final output sent to browser
DEBUG - 2015-02-06 23:16:10 --> Total execution time: 1.1481
DEBUG - 2015-02-06 23:31:12 --> Config Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Hooks Class Initialized
DEBUG - 2015-02-06 23:31:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 23:31:12 --> Utf8 Class Initialized
DEBUG - 2015-02-06 23:31:12 --> URI Class Initialized
DEBUG - 2015-02-06 23:31:12 --> No URI present. Default controller set.
DEBUG - 2015-02-06 23:31:12 --> Router Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Output Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Security Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Input Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 23:31:12 --> Language Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Loader Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: url_helper
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: link_helper
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 23:31:12 --> CI_Session Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Session: Regenerate ID
DEBUG - 2015-02-06 23:31:12 --> CI_Session routines successfully run
DEBUG - 2015-02-06 23:31:12 --> Model Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Model Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Controller Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 23:31:12 --> Email Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: language_helper
DEBUG - 2015-02-06 23:31:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 23:31:12 --> Model Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Database Driver Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: date_helper
DEBUG - 2015-02-06 23:31:12 --> Helper loaded: form_helper
DEBUG - 2015-02-06 23:31:12 --> Form Validation Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Model Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 23:31:12 --> Pagination Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Model Class Initialized
DEBUG - 2015-02-06 23:31:12 --> Model Class Initialized
DEBUG - 2015-02-06 23:31:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 23:31:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 23:31:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 23:31:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 23:31:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 23:31:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 23:31:13 --> Final output sent to browser
DEBUG - 2015-02-06 23:31:13 --> Total execution time: 1.2171
DEBUG - 2015-02-06 23:46:14 --> Config Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Hooks Class Initialized
DEBUG - 2015-02-06 23:46:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-06 23:46:14 --> Utf8 Class Initialized
DEBUG - 2015-02-06 23:46:14 --> URI Class Initialized
DEBUG - 2015-02-06 23:46:14 --> No URI present. Default controller set.
DEBUG - 2015-02-06 23:46:14 --> Router Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Output Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Security Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Input Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-06 23:46:14 --> Language Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Loader Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: url_helper
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: link_helper
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-06 23:46:14 --> CI_Session Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Session: Regenerate ID
DEBUG - 2015-02-06 23:46:14 --> CI_Session routines successfully run
DEBUG - 2015-02-06 23:46:14 --> Model Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Model Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Controller Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-06 23:46:14 --> Email Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: language_helper
DEBUG - 2015-02-06 23:46:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-06 23:46:14 --> Model Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Database Driver Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: date_helper
DEBUG - 2015-02-06 23:46:14 --> Helper loaded: form_helper
DEBUG - 2015-02-06 23:46:14 --> Form Validation Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Model Class Initialized
DEBUG - 2015-02-06 23:46:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-06 23:46:14 --> Pagination Class Initialized
DEBUG - 2015-02-06 23:46:15 --> Model Class Initialized
DEBUG - 2015-02-06 23:46:15 --> Model Class Initialized
DEBUG - 2015-02-06 23:46:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-06 23:46:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-06 23:46:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-06 23:46:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-06 23:46:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-06 23:46:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-06 23:46:15 --> Final output sent to browser
DEBUG - 2015-02-06 23:46:15 --> Total execution time: 1.1431
