<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-15 00:08:05 --> Config Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Hooks Class Initialized
DEBUG - 2015-02-15 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 00:08:05 --> Utf8 Class Initialized
DEBUG - 2015-02-15 00:08:05 --> URI Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Router Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Output Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Security Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Input Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 00:08:05 --> Language Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Loader Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 00:08:05 --> Helper loaded: url_helper
DEBUG - 2015-02-15 00:08:05 --> Helper loaded: link_helper
DEBUG - 2015-02-15 00:08:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 00:08:05 --> CI_Session Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Session: Regenerate ID
DEBUG - 2015-02-15 00:08:05 --> CI_Session routines successfully run
DEBUG - 2015-02-15 00:08:05 --> Model Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Model Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Controller Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 00:08:05 --> Email Class Initialized
DEBUG - 2015-02-15 00:08:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 00:08:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 00:08:05 --> Helper loaded: language_helper
DEBUG - 2015-02-15 00:08:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 00:08:06 --> Model Class Initialized
DEBUG - 2015-02-15 00:08:06 --> Database Driver Class Initialized
DEBUG - 2015-02-15 00:08:06 --> Helper loaded: date_helper
DEBUG - 2015-02-15 00:08:06 --> Helper loaded: form_helper
DEBUG - 2015-02-15 00:08:06 --> Form Validation Class Initialized
DEBUG - 2015-02-15 00:08:06 --> Model Class Initialized
DEBUG - 2015-02-15 00:08:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 00:08:06 --> Pagination Class Initialized
DEBUG - 2015-02-15 00:08:06 --> Model Class Initialized
DEBUG - 2015-02-15 00:08:06 --> Model Class Initialized
DEBUG - 2015-02-15 00:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 00:08:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 00:08:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 00:08:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 00:08:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 00:08:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 00:08:07 --> Final output sent to browser
DEBUG - 2015-02-15 00:08:07 --> Total execution time: 1.5502
DEBUG - 2015-02-15 00:23:08 --> Config Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Hooks Class Initialized
DEBUG - 2015-02-15 00:23:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 00:23:08 --> Utf8 Class Initialized
DEBUG - 2015-02-15 00:23:08 --> URI Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Router Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Output Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Security Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Input Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 00:23:08 --> Language Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Loader Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: url_helper
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: link_helper
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 00:23:08 --> CI_Session Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Session: Regenerate ID
DEBUG - 2015-02-15 00:23:08 --> CI_Session routines successfully run
DEBUG - 2015-02-15 00:23:08 --> Model Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Model Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Controller Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 00:23:08 --> Email Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: language_helper
DEBUG - 2015-02-15 00:23:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 00:23:08 --> Model Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Database Driver Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: date_helper
DEBUG - 2015-02-15 00:23:08 --> Helper loaded: form_helper
DEBUG - 2015-02-15 00:23:08 --> Form Validation Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Model Class Initialized
DEBUG - 2015-02-15 00:23:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 00:23:08 --> Pagination Class Initialized
DEBUG - 2015-02-15 00:23:09 --> Model Class Initialized
DEBUG - 2015-02-15 00:23:09 --> Model Class Initialized
DEBUG - 2015-02-15 00:23:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 00:23:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 00:23:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 00:23:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 00:23:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 00:23:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 00:23:09 --> Final output sent to browser
DEBUG - 2015-02-15 00:23:09 --> Total execution time: 1.3451
DEBUG - 2015-02-15 00:38:10 --> Config Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Hooks Class Initialized
DEBUG - 2015-02-15 00:38:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 00:38:10 --> Utf8 Class Initialized
DEBUG - 2015-02-15 00:38:10 --> URI Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Router Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Output Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Security Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Input Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 00:38:10 --> Language Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Loader Class Initialized
DEBUG - 2015-02-15 00:38:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 00:38:10 --> Helper loaded: url_helper
DEBUG - 2015-02-15 00:38:10 --> Helper loaded: link_helper
DEBUG - 2015-02-15 00:38:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 00:38:10 --> CI_Session Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Session: Regenerate ID
DEBUG - 2015-02-15 00:38:11 --> CI_Session routines successfully run
DEBUG - 2015-02-15 00:38:11 --> Model Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Model Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Controller Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 00:38:11 --> Email Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 00:38:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 00:38:11 --> Helper loaded: language_helper
DEBUG - 2015-02-15 00:38:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 00:38:11 --> Model Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Database Driver Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Helper loaded: date_helper
DEBUG - 2015-02-15 00:38:11 --> Helper loaded: form_helper
DEBUG - 2015-02-15 00:38:11 --> Form Validation Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Model Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 00:38:11 --> Pagination Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Model Class Initialized
DEBUG - 2015-02-15 00:38:11 --> Model Class Initialized
DEBUG - 2015-02-15 00:38:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 00:38:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 00:38:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 00:38:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 00:38:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 00:38:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 00:38:12 --> Final output sent to browser
DEBUG - 2015-02-15 00:38:12 --> Total execution time: 1.3641
DEBUG - 2015-02-15 00:53:13 --> Config Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Hooks Class Initialized
DEBUG - 2015-02-15 00:53:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 00:53:13 --> Utf8 Class Initialized
DEBUG - 2015-02-15 00:53:13 --> URI Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Router Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Output Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Security Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Input Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 00:53:13 --> Language Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Loader Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: url_helper
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: link_helper
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 00:53:13 --> CI_Session Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Session: Regenerate ID
DEBUG - 2015-02-15 00:53:13 --> CI_Session routines successfully run
DEBUG - 2015-02-15 00:53:13 --> Model Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Model Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Controller Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 00:53:13 --> Email Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: language_helper
DEBUG - 2015-02-15 00:53:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 00:53:13 --> Model Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Database Driver Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: date_helper
DEBUG - 2015-02-15 00:53:13 --> Helper loaded: form_helper
DEBUG - 2015-02-15 00:53:13 --> Form Validation Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Model Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 00:53:13 --> Pagination Class Initialized
DEBUG - 2015-02-15 00:53:13 --> Model Class Initialized
DEBUG - 2015-02-15 00:53:14 --> Model Class Initialized
DEBUG - 2015-02-15 00:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 00:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 00:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 00:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 00:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 00:53:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 00:53:14 --> Final output sent to browser
DEBUG - 2015-02-15 00:53:14 --> Total execution time: 1.3501
DEBUG - 2015-02-15 01:08:16 --> Config Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Hooks Class Initialized
DEBUG - 2015-02-15 01:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 01:08:16 --> Utf8 Class Initialized
DEBUG - 2015-02-15 01:08:16 --> URI Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Router Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Output Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Security Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Input Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 01:08:16 --> Language Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Loader Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: url_helper
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: link_helper
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 01:08:16 --> CI_Session Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Session: Regenerate ID
DEBUG - 2015-02-15 01:08:16 --> CI_Session routines successfully run
DEBUG - 2015-02-15 01:08:16 --> Model Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Model Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Controller Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 01:08:16 --> Email Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: language_helper
DEBUG - 2015-02-15 01:08:16 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 01:08:16 --> Model Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Database Driver Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: date_helper
DEBUG - 2015-02-15 01:08:16 --> Helper loaded: form_helper
DEBUG - 2015-02-15 01:08:16 --> Form Validation Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Model Class Initialized
DEBUG - 2015-02-15 01:08:16 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 01:08:16 --> Pagination Class Initialized
DEBUG - 2015-02-15 01:08:17 --> Model Class Initialized
DEBUG - 2015-02-15 01:08:17 --> Model Class Initialized
DEBUG - 2015-02-15 01:08:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 01:08:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 01:08:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 01:08:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 01:08:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 01:08:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 01:08:18 --> Final output sent to browser
DEBUG - 2015-02-15 01:08:18 --> Total execution time: 1.3711
DEBUG - 2015-02-15 01:23:19 --> Config Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Hooks Class Initialized
DEBUG - 2015-02-15 01:23:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 01:23:19 --> Utf8 Class Initialized
DEBUG - 2015-02-15 01:23:19 --> URI Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Router Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Output Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Security Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Input Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 01:23:19 --> Language Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Loader Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: url_helper
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: link_helper
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 01:23:19 --> CI_Session Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Session: Regenerate ID
DEBUG - 2015-02-15 01:23:19 --> CI_Session routines successfully run
DEBUG - 2015-02-15 01:23:19 --> Model Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Model Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Controller Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 01:23:19 --> Email Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: language_helper
DEBUG - 2015-02-15 01:23:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 01:23:19 --> Model Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Database Driver Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: date_helper
DEBUG - 2015-02-15 01:23:19 --> Helper loaded: form_helper
DEBUG - 2015-02-15 01:23:19 --> Form Validation Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Model Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 01:23:19 --> Pagination Class Initialized
DEBUG - 2015-02-15 01:23:19 --> Model Class Initialized
DEBUG - 2015-02-15 01:23:20 --> Model Class Initialized
DEBUG - 2015-02-15 01:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 01:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 01:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 01:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 01:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 01:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 01:23:20 --> Final output sent to browser
DEBUG - 2015-02-15 01:23:20 --> Total execution time: 1.3941
DEBUG - 2015-02-15 01:38:21 --> Config Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Hooks Class Initialized
DEBUG - 2015-02-15 01:38:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 01:38:21 --> Utf8 Class Initialized
DEBUG - 2015-02-15 01:38:21 --> URI Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Router Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Output Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Security Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Input Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 01:38:21 --> Language Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Loader Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: url_helper
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: link_helper
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 01:38:21 --> CI_Session Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Session: Regenerate ID
DEBUG - 2015-02-15 01:38:21 --> CI_Session routines successfully run
DEBUG - 2015-02-15 01:38:21 --> Model Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Model Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Controller Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 01:38:21 --> Email Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: language_helper
DEBUG - 2015-02-15 01:38:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 01:38:21 --> Model Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Database Driver Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: date_helper
DEBUG - 2015-02-15 01:38:21 --> Helper loaded: form_helper
DEBUG - 2015-02-15 01:38:21 --> Form Validation Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Model Class Initialized
DEBUG - 2015-02-15 01:38:21 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 01:38:21 --> Pagination Class Initialized
DEBUG - 2015-02-15 01:38:22 --> Model Class Initialized
DEBUG - 2015-02-15 01:38:22 --> Model Class Initialized
DEBUG - 2015-02-15 01:38:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 01:38:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 01:38:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 01:38:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 01:38:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 01:38:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 01:38:23 --> Final output sent to browser
DEBUG - 2015-02-15 01:38:23 --> Total execution time: 1.3961
DEBUG - 2015-02-15 01:53:23 --> Config Class Initialized
DEBUG - 2015-02-15 01:53:23 --> Hooks Class Initialized
DEBUG - 2015-02-15 01:53:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 01:53:23 --> Utf8 Class Initialized
DEBUG - 2015-02-15 01:53:23 --> URI Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Router Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Output Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Security Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Input Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 01:53:24 --> Language Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Loader Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: url_helper
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: link_helper
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 01:53:24 --> CI_Session Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Session: Regenerate ID
DEBUG - 2015-02-15 01:53:24 --> CI_Session routines successfully run
DEBUG - 2015-02-15 01:53:24 --> Model Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Model Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Controller Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 01:53:24 --> Email Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: language_helper
DEBUG - 2015-02-15 01:53:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 01:53:24 --> Model Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Database Driver Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: date_helper
DEBUG - 2015-02-15 01:53:24 --> Helper loaded: form_helper
DEBUG - 2015-02-15 01:53:24 --> Form Validation Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Model Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 01:53:24 --> Pagination Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Model Class Initialized
DEBUG - 2015-02-15 01:53:24 --> Model Class Initialized
DEBUG - 2015-02-15 01:53:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 01:53:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 01:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 01:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 01:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 01:53:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 01:53:25 --> Final output sent to browser
DEBUG - 2015-02-15 01:53:25 --> Total execution time: 1.3941
DEBUG - 2015-02-15 02:08:26 --> Config Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Hooks Class Initialized
DEBUG - 2015-02-15 02:08:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 02:08:26 --> Utf8 Class Initialized
DEBUG - 2015-02-15 02:08:26 --> URI Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Router Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Output Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Security Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Input Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 02:08:26 --> Language Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Loader Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: url_helper
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: link_helper
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 02:08:26 --> CI_Session Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Session: Regenerate ID
DEBUG - 2015-02-15 02:08:26 --> CI_Session routines successfully run
DEBUG - 2015-02-15 02:08:26 --> Model Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Model Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Controller Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 02:08:26 --> Email Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: language_helper
DEBUG - 2015-02-15 02:08:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 02:08:26 --> Model Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Database Driver Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: date_helper
DEBUG - 2015-02-15 02:08:26 --> Helper loaded: form_helper
DEBUG - 2015-02-15 02:08:26 --> Form Validation Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Model Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 02:08:26 --> Pagination Class Initialized
DEBUG - 2015-02-15 02:08:26 --> Model Class Initialized
DEBUG - 2015-02-15 02:08:27 --> Model Class Initialized
DEBUG - 2015-02-15 02:08:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 02:08:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 02:08:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 02:08:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 02:08:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 02:08:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 02:08:27 --> Final output sent to browser
DEBUG - 2015-02-15 02:08:27 --> Total execution time: 1.5792
DEBUG - 2015-02-15 02:23:28 --> Config Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Hooks Class Initialized
DEBUG - 2015-02-15 02:23:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 02:23:28 --> Utf8 Class Initialized
DEBUG - 2015-02-15 02:23:28 --> URI Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Router Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Output Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Security Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Input Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 02:23:28 --> Language Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Loader Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: url_helper
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: link_helper
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 02:23:28 --> CI_Session Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Session: Regenerate ID
DEBUG - 2015-02-15 02:23:28 --> CI_Session routines successfully run
DEBUG - 2015-02-15 02:23:28 --> Model Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Model Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Controller Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 02:23:28 --> Email Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: language_helper
DEBUG - 2015-02-15 02:23:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 02:23:28 --> Model Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Database Driver Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: date_helper
DEBUG - 2015-02-15 02:23:28 --> Helper loaded: form_helper
DEBUG - 2015-02-15 02:23:28 --> Form Validation Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Model Class Initialized
DEBUG - 2015-02-15 02:23:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 02:23:28 --> Pagination Class Initialized
DEBUG - 2015-02-15 02:23:29 --> Model Class Initialized
DEBUG - 2015-02-15 02:23:29 --> Model Class Initialized
DEBUG - 2015-02-15 02:23:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 02:23:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 02:23:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 02:23:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 02:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 02:23:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 02:23:30 --> Final output sent to browser
DEBUG - 2015-02-15 02:23:30 --> Total execution time: 1.3331
DEBUG - 2015-02-15 02:38:31 --> Config Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Hooks Class Initialized
DEBUG - 2015-02-15 02:38:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 02:38:31 --> Utf8 Class Initialized
DEBUG - 2015-02-15 02:38:31 --> URI Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Router Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Output Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Security Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Input Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 02:38:31 --> Language Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Loader Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: url_helper
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: link_helper
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 02:38:31 --> CI_Session Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Session: Regenerate ID
DEBUG - 2015-02-15 02:38:31 --> CI_Session routines successfully run
DEBUG - 2015-02-15 02:38:31 --> Model Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Model Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Controller Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 02:38:31 --> Email Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: language_helper
DEBUG - 2015-02-15 02:38:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 02:38:31 --> Model Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Database Driver Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: date_helper
DEBUG - 2015-02-15 02:38:31 --> Helper loaded: form_helper
DEBUG - 2015-02-15 02:38:31 --> Form Validation Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Model Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 02:38:31 --> Pagination Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Model Class Initialized
DEBUG - 2015-02-15 02:38:31 --> Model Class Initialized
DEBUG - 2015-02-15 02:38:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 02:38:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 02:38:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 02:38:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 02:38:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 02:38:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 02:38:32 --> Final output sent to browser
DEBUG - 2015-02-15 02:38:32 --> Total execution time: 1.4331
DEBUG - 2015-02-15 02:53:33 --> Config Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Hooks Class Initialized
DEBUG - 2015-02-15 02:53:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 02:53:33 --> Utf8 Class Initialized
DEBUG - 2015-02-15 02:53:33 --> URI Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Router Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Output Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Security Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Input Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 02:53:33 --> Language Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Loader Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: url_helper
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: link_helper
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 02:53:33 --> CI_Session Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Session: Regenerate ID
DEBUG - 2015-02-15 02:53:33 --> CI_Session routines successfully run
DEBUG - 2015-02-15 02:53:33 --> Model Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Model Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Controller Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 02:53:33 --> Email Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: language_helper
DEBUG - 2015-02-15 02:53:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 02:53:33 --> Model Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Database Driver Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: date_helper
DEBUG - 2015-02-15 02:53:33 --> Helper loaded: form_helper
DEBUG - 2015-02-15 02:53:33 --> Form Validation Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Model Class Initialized
DEBUG - 2015-02-15 02:53:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 02:53:33 --> Pagination Class Initialized
DEBUG - 2015-02-15 02:53:34 --> Model Class Initialized
DEBUG - 2015-02-15 02:53:34 --> Model Class Initialized
DEBUG - 2015-02-15 02:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 02:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 02:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 02:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 02:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 02:53:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 02:53:34 --> Final output sent to browser
DEBUG - 2015-02-15 02:53:34 --> Total execution time: 1.3411
DEBUG - 2015-02-15 03:08:35 --> Config Class Initialized
DEBUG - 2015-02-15 03:08:35 --> Hooks Class Initialized
DEBUG - 2015-02-15 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 03:08:35 --> Utf8 Class Initialized
DEBUG - 2015-02-15 03:08:35 --> URI Class Initialized
DEBUG - 2015-02-15 03:08:35 --> Router Class Initialized
DEBUG - 2015-02-15 03:08:35 --> Output Class Initialized
DEBUG - 2015-02-15 03:08:35 --> Security Class Initialized
DEBUG - 2015-02-15 03:08:35 --> Input Class Initialized
DEBUG - 2015-02-15 03:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 03:08:35 --> Language Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Loader Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: url_helper
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: link_helper
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 03:08:36 --> CI_Session Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Session: Regenerate ID
DEBUG - 2015-02-15 03:08:36 --> CI_Session routines successfully run
DEBUG - 2015-02-15 03:08:36 --> Model Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Model Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Controller Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 03:08:36 --> Email Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: language_helper
DEBUG - 2015-02-15 03:08:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 03:08:36 --> Model Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Database Driver Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: date_helper
DEBUG - 2015-02-15 03:08:36 --> Helper loaded: form_helper
DEBUG - 2015-02-15 03:08:36 --> Form Validation Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Model Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 03:08:36 --> Pagination Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Model Class Initialized
DEBUG - 2015-02-15 03:08:36 --> Model Class Initialized
DEBUG - 2015-02-15 03:08:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 03:08:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 03:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 03:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 03:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 03:08:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 03:08:37 --> Final output sent to browser
DEBUG - 2015-02-15 03:08:37 --> Total execution time: 1.5982
DEBUG - 2015-02-15 03:23:38 --> Config Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Hooks Class Initialized
DEBUG - 2015-02-15 03:23:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 03:23:38 --> Utf8 Class Initialized
DEBUG - 2015-02-15 03:23:38 --> URI Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Router Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Output Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Security Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Input Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 03:23:38 --> Language Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Loader Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: url_helper
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: link_helper
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 03:23:38 --> CI_Session Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Session: Regenerate ID
DEBUG - 2015-02-15 03:23:38 --> CI_Session routines successfully run
DEBUG - 2015-02-15 03:23:38 --> Model Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Model Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Controller Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 03:23:38 --> Email Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: language_helper
DEBUG - 2015-02-15 03:23:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 03:23:38 --> Model Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Database Driver Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: date_helper
DEBUG - 2015-02-15 03:23:38 --> Helper loaded: form_helper
DEBUG - 2015-02-15 03:23:38 --> Form Validation Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Model Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 03:23:38 --> Pagination Class Initialized
DEBUG - 2015-02-15 03:23:38 --> Model Class Initialized
DEBUG - 2015-02-15 03:23:39 --> Model Class Initialized
DEBUG - 2015-02-15 03:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 03:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 03:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 03:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 03:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 03:23:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 03:23:39 --> Final output sent to browser
DEBUG - 2015-02-15 03:23:39 --> Total execution time: 1.3429
DEBUG - 2015-02-15 03:38:40 --> Config Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Hooks Class Initialized
DEBUG - 2015-02-15 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 03:38:40 --> Utf8 Class Initialized
DEBUG - 2015-02-15 03:38:40 --> URI Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Router Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Output Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Security Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Input Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 03:38:40 --> Language Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Loader Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: url_helper
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: link_helper
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 03:38:40 --> CI_Session Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Session: Regenerate ID
DEBUG - 2015-02-15 03:38:40 --> CI_Session routines successfully run
DEBUG - 2015-02-15 03:38:40 --> Model Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Model Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Controller Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 03:38:40 --> Email Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: language_helper
DEBUG - 2015-02-15 03:38:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 03:38:40 --> Model Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Database Driver Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: date_helper
DEBUG - 2015-02-15 03:38:40 --> Helper loaded: form_helper
DEBUG - 2015-02-15 03:38:40 --> Form Validation Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Model Class Initialized
DEBUG - 2015-02-15 03:38:40 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 03:38:40 --> Pagination Class Initialized
DEBUG - 2015-02-15 03:38:41 --> Model Class Initialized
DEBUG - 2015-02-15 03:38:41 --> Model Class Initialized
DEBUG - 2015-02-15 03:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 03:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 03:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 03:38:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 03:38:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 03:38:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 03:38:42 --> Final output sent to browser
DEBUG - 2015-02-15 03:38:42 --> Total execution time: 1.4081
DEBUG - 2015-02-15 03:53:43 --> Config Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Hooks Class Initialized
DEBUG - 2015-02-15 03:53:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 03:53:43 --> Utf8 Class Initialized
DEBUG - 2015-02-15 03:53:43 --> URI Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Router Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Output Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Security Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Input Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 03:53:43 --> Language Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Loader Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: url_helper
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: link_helper
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 03:53:43 --> CI_Session Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Session: Regenerate ID
DEBUG - 2015-02-15 03:53:43 --> CI_Session routines successfully run
DEBUG - 2015-02-15 03:53:43 --> Model Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Model Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Controller Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 03:53:43 --> Email Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: language_helper
DEBUG - 2015-02-15 03:53:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 03:53:43 --> Model Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Database Driver Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: date_helper
DEBUG - 2015-02-15 03:53:43 --> Helper loaded: form_helper
DEBUG - 2015-02-15 03:53:43 --> Form Validation Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Model Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 03:53:43 --> Pagination Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Model Class Initialized
DEBUG - 2015-02-15 03:53:43 --> Model Class Initialized
DEBUG - 2015-02-15 03:53:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 03:53:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 03:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 03:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 03:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 03:53:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 03:53:44 --> Final output sent to browser
DEBUG - 2015-02-15 03:53:44 --> Total execution time: 1.3391
DEBUG - 2015-02-15 04:08:45 --> Config Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Hooks Class Initialized
DEBUG - 2015-02-15 04:08:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 04:08:45 --> Utf8 Class Initialized
DEBUG - 2015-02-15 04:08:45 --> URI Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Router Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Output Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Security Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Input Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 04:08:45 --> Language Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Loader Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: url_helper
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: link_helper
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 04:08:45 --> CI_Session Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Session: Regenerate ID
DEBUG - 2015-02-15 04:08:45 --> CI_Session routines successfully run
DEBUG - 2015-02-15 04:08:45 --> Model Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Model Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Controller Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 04:08:45 --> Email Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: language_helper
DEBUG - 2015-02-15 04:08:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 04:08:45 --> Model Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Database Driver Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: date_helper
DEBUG - 2015-02-15 04:08:45 --> Helper loaded: form_helper
DEBUG - 2015-02-15 04:08:45 --> Form Validation Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Model Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 04:08:45 --> Pagination Class Initialized
DEBUG - 2015-02-15 04:08:45 --> Model Class Initialized
DEBUG - 2015-02-15 04:08:46 --> Model Class Initialized
DEBUG - 2015-02-15 04:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 04:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 04:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 04:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 04:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 04:08:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 04:08:46 --> Final output sent to browser
DEBUG - 2015-02-15 04:08:46 --> Total execution time: 1.3951
DEBUG - 2015-02-15 04:23:47 --> Config Class Initialized
DEBUG - 2015-02-15 04:23:47 --> Hooks Class Initialized
DEBUG - 2015-02-15 04:23:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 04:23:47 --> Utf8 Class Initialized
DEBUG - 2015-02-15 04:23:47 --> URI Class Initialized
DEBUG - 2015-02-15 04:23:47 --> Router Class Initialized
DEBUG - 2015-02-15 04:23:47 --> Output Class Initialized
DEBUG - 2015-02-15 04:23:47 --> Security Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Input Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 04:23:48 --> Language Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Loader Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: url_helper
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: link_helper
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 04:23:48 --> CI_Session Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Session: Regenerate ID
DEBUG - 2015-02-15 04:23:48 --> CI_Session routines successfully run
DEBUG - 2015-02-15 04:23:48 --> Model Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Model Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Controller Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 04:23:48 --> Email Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: language_helper
DEBUG - 2015-02-15 04:23:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 04:23:48 --> Model Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Database Driver Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: date_helper
DEBUG - 2015-02-15 04:23:48 --> Helper loaded: form_helper
DEBUG - 2015-02-15 04:23:48 --> Form Validation Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Model Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 04:23:48 --> Pagination Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Model Class Initialized
DEBUG - 2015-02-15 04:23:48 --> Model Class Initialized
DEBUG - 2015-02-15 04:23:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 04:23:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 04:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 04:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 04:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 04:23:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 04:23:49 --> Final output sent to browser
DEBUG - 2015-02-15 04:23:49 --> Total execution time: 1.3791
DEBUG - 2015-02-15 04:38:50 --> Config Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Hooks Class Initialized
DEBUG - 2015-02-15 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 04:38:50 --> Utf8 Class Initialized
DEBUG - 2015-02-15 04:38:50 --> URI Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Router Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Output Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Security Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Input Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 04:38:50 --> Language Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Loader Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: url_helper
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: link_helper
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 04:38:50 --> CI_Session Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Session: Regenerate ID
DEBUG - 2015-02-15 04:38:50 --> CI_Session routines successfully run
DEBUG - 2015-02-15 04:38:50 --> Model Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Model Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Controller Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 04:38:50 --> Email Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: language_helper
DEBUG - 2015-02-15 04:38:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 04:38:50 --> Model Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Database Driver Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: date_helper
DEBUG - 2015-02-15 04:38:50 --> Helper loaded: form_helper
DEBUG - 2015-02-15 04:38:50 --> Form Validation Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Model Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 04:38:50 --> Pagination Class Initialized
DEBUG - 2015-02-15 04:38:50 --> Model Class Initialized
DEBUG - 2015-02-15 04:38:51 --> Model Class Initialized
DEBUG - 2015-02-15 04:38:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 04:38:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 04:38:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 04:38:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 04:38:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 04:38:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 04:38:51 --> Final output sent to browser
DEBUG - 2015-02-15 04:38:51 --> Total execution time: 1.3591
DEBUG - 2015-02-15 04:53:53 --> Config Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Hooks Class Initialized
DEBUG - 2015-02-15 04:53:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 04:53:53 --> Utf8 Class Initialized
DEBUG - 2015-02-15 04:53:53 --> URI Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Router Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Output Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Security Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Input Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 04:53:53 --> Language Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Loader Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 04:53:53 --> Helper loaded: url_helper
DEBUG - 2015-02-15 04:53:53 --> Helper loaded: link_helper
DEBUG - 2015-02-15 04:53:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 04:53:53 --> CI_Session Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Session: Regenerate ID
DEBUG - 2015-02-15 04:53:53 --> CI_Session routines successfully run
DEBUG - 2015-02-15 04:53:53 --> Model Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Model Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Controller Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 04:53:53 --> Email Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 04:53:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 04:53:53 --> Helper loaded: language_helper
DEBUG - 2015-02-15 04:53:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 04:53:53 --> Model Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Database Driver Class Initialized
DEBUG - 2015-02-15 04:53:53 --> Helper loaded: date_helper
DEBUG - 2015-02-15 04:53:54 --> Helper loaded: form_helper
DEBUG - 2015-02-15 04:53:54 --> Form Validation Class Initialized
DEBUG - 2015-02-15 04:53:54 --> Model Class Initialized
DEBUG - 2015-02-15 04:53:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 04:53:54 --> Pagination Class Initialized
DEBUG - 2015-02-15 04:53:54 --> Model Class Initialized
DEBUG - 2015-02-15 04:53:54 --> Model Class Initialized
DEBUG - 2015-02-15 04:53:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 04:53:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 04:53:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 04:53:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 04:53:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 04:53:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 04:53:55 --> Final output sent to browser
DEBUG - 2015-02-15 04:53:55 --> Total execution time: 1.5212
DEBUG - 2015-02-15 05:08:57 --> Config Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Hooks Class Initialized
DEBUG - 2015-02-15 05:08:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 05:08:57 --> Utf8 Class Initialized
DEBUG - 2015-02-15 05:08:57 --> URI Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Router Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Output Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Security Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Input Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 05:08:57 --> Language Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Loader Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: url_helper
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: link_helper
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 05:08:57 --> CI_Session Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Session: Regenerate ID
DEBUG - 2015-02-15 05:08:57 --> CI_Session routines successfully run
DEBUG - 2015-02-15 05:08:57 --> Model Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Model Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Controller Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 05:08:57 --> Email Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: language_helper
DEBUG - 2015-02-15 05:08:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 05:08:57 --> Model Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Database Driver Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: date_helper
DEBUG - 2015-02-15 05:08:57 --> Helper loaded: form_helper
DEBUG - 2015-02-15 05:08:57 --> Form Validation Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Model Class Initialized
DEBUG - 2015-02-15 05:08:57 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 05:08:57 --> Pagination Class Initialized
DEBUG - 2015-02-15 05:08:58 --> Model Class Initialized
DEBUG - 2015-02-15 05:08:58 --> Model Class Initialized
DEBUG - 2015-02-15 05:08:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 05:08:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 05:08:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 05:08:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 05:08:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 05:08:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 05:08:59 --> Final output sent to browser
DEBUG - 2015-02-15 05:08:59 --> Total execution time: 1.3541
DEBUG - 2015-02-15 05:24:01 --> Config Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Hooks Class Initialized
DEBUG - 2015-02-15 05:24:01 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 05:24:01 --> Utf8 Class Initialized
DEBUG - 2015-02-15 05:24:01 --> URI Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Router Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Output Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Security Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Input Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 05:24:01 --> Language Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Loader Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: url_helper
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: link_helper
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 05:24:01 --> CI_Session Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Session: Regenerate ID
DEBUG - 2015-02-15 05:24:01 --> CI_Session routines successfully run
DEBUG - 2015-02-15 05:24:01 --> Model Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Model Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Controller Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 05:24:01 --> Email Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: language_helper
DEBUG - 2015-02-15 05:24:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 05:24:01 --> Model Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Database Driver Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: date_helper
DEBUG - 2015-02-15 05:24:01 --> Helper loaded: form_helper
DEBUG - 2015-02-15 05:24:01 --> Form Validation Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Model Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 05:24:01 --> Pagination Class Initialized
DEBUG - 2015-02-15 05:24:01 --> Model Class Initialized
DEBUG - 2015-02-15 05:24:02 --> Model Class Initialized
DEBUG - 2015-02-15 05:24:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 05:24:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 05:24:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 05:24:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 05:24:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 05:24:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 05:24:02 --> Final output sent to browser
DEBUG - 2015-02-15 05:24:02 --> Total execution time: 1.3831
DEBUG - 2015-02-15 05:39:03 --> Config Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Hooks Class Initialized
DEBUG - 2015-02-15 05:39:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 05:39:03 --> Utf8 Class Initialized
DEBUG - 2015-02-15 05:39:03 --> URI Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Router Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Output Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Security Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Input Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 05:39:03 --> Language Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Loader Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: url_helper
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: link_helper
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 05:39:03 --> CI_Session Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Session: Regenerate ID
DEBUG - 2015-02-15 05:39:03 --> CI_Session routines successfully run
DEBUG - 2015-02-15 05:39:03 --> Model Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Model Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Controller Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 05:39:03 --> Email Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: language_helper
DEBUG - 2015-02-15 05:39:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 05:39:03 --> Model Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Database Driver Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: date_helper
DEBUG - 2015-02-15 05:39:03 --> Helper loaded: form_helper
DEBUG - 2015-02-15 05:39:03 --> Form Validation Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Model Class Initialized
DEBUG - 2015-02-15 05:39:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 05:39:03 --> Pagination Class Initialized
DEBUG - 2015-02-15 05:39:04 --> Model Class Initialized
DEBUG - 2015-02-15 05:39:04 --> Model Class Initialized
DEBUG - 2015-02-15 05:39:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 05:39:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 05:39:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 05:39:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 05:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 05:39:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 05:39:05 --> Final output sent to browser
DEBUG - 2015-02-15 05:39:05 --> Total execution time: 1.3891
DEBUG - 2015-02-15 05:54:06 --> Config Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Hooks Class Initialized
DEBUG - 2015-02-15 05:54:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 05:54:06 --> Utf8 Class Initialized
DEBUG - 2015-02-15 05:54:06 --> URI Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Router Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Output Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Security Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Input Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 05:54:06 --> Language Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Loader Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: url_helper
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: link_helper
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 05:54:06 --> CI_Session Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Session: Regenerate ID
DEBUG - 2015-02-15 05:54:06 --> CI_Session routines successfully run
DEBUG - 2015-02-15 05:54:06 --> Model Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Model Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Controller Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 05:54:06 --> Email Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: language_helper
DEBUG - 2015-02-15 05:54:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 05:54:06 --> Model Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Database Driver Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: date_helper
DEBUG - 2015-02-15 05:54:06 --> Helper loaded: form_helper
DEBUG - 2015-02-15 05:54:06 --> Form Validation Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Model Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 05:54:06 --> Pagination Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Model Class Initialized
DEBUG - 2015-02-15 05:54:06 --> Model Class Initialized
DEBUG - 2015-02-15 05:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 05:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 05:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 05:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 05:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 05:54:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 05:54:07 --> Final output sent to browser
DEBUG - 2015-02-15 05:54:07 --> Total execution time: 1.5512
DEBUG - 2015-02-15 06:09:08 --> Config Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Hooks Class Initialized
DEBUG - 2015-02-15 06:09:08 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 06:09:08 --> Utf8 Class Initialized
DEBUG - 2015-02-15 06:09:08 --> URI Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Router Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Output Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Security Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Input Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 06:09:08 --> Language Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Loader Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: url_helper
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: link_helper
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 06:09:08 --> CI_Session Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Session: Regenerate ID
DEBUG - 2015-02-15 06:09:08 --> CI_Session routines successfully run
DEBUG - 2015-02-15 06:09:08 --> Model Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Model Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Controller Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 06:09:08 --> Email Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: language_helper
DEBUG - 2015-02-15 06:09:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 06:09:08 --> Model Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Database Driver Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: date_helper
DEBUG - 2015-02-15 06:09:08 --> Helper loaded: form_helper
DEBUG - 2015-02-15 06:09:08 --> Form Validation Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Model Class Initialized
DEBUG - 2015-02-15 06:09:08 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 06:09:08 --> Pagination Class Initialized
DEBUG - 2015-02-15 06:09:09 --> Model Class Initialized
DEBUG - 2015-02-15 06:09:09 --> Model Class Initialized
DEBUG - 2015-02-15 06:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 06:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 06:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 06:09:09 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 06:09:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 06:09:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 06:09:10 --> Final output sent to browser
DEBUG - 2015-02-15 06:09:10 --> Total execution time: 1.3381
DEBUG - 2015-02-15 06:24:11 --> Config Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Hooks Class Initialized
DEBUG - 2015-02-15 06:24:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 06:24:11 --> Utf8 Class Initialized
DEBUG - 2015-02-15 06:24:11 --> URI Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Router Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Output Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Security Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Input Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 06:24:11 --> Language Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Loader Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: url_helper
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: link_helper
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 06:24:11 --> CI_Session Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Session: Regenerate ID
DEBUG - 2015-02-15 06:24:11 --> CI_Session routines successfully run
DEBUG - 2015-02-15 06:24:11 --> Model Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Model Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Controller Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 06:24:11 --> Email Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: language_helper
DEBUG - 2015-02-15 06:24:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 06:24:11 --> Model Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Database Driver Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: date_helper
DEBUG - 2015-02-15 06:24:11 --> Helper loaded: form_helper
DEBUG - 2015-02-15 06:24:11 --> Form Validation Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Model Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 06:24:11 --> Pagination Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Model Class Initialized
DEBUG - 2015-02-15 06:24:11 --> Model Class Initialized
DEBUG - 2015-02-15 06:24:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 06:24:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 06:24:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 06:24:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 06:24:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 06:24:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 06:24:12 --> Final output sent to browser
DEBUG - 2015-02-15 06:24:12 --> Total execution time: 1.3491
DEBUG - 2015-02-15 06:39:13 --> Config Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Hooks Class Initialized
DEBUG - 2015-02-15 06:39:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 06:39:13 --> Utf8 Class Initialized
DEBUG - 2015-02-15 06:39:13 --> URI Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Router Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Output Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Security Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Input Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 06:39:13 --> Language Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Loader Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: url_helper
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: link_helper
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 06:39:13 --> CI_Session Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Session: Regenerate ID
DEBUG - 2015-02-15 06:39:13 --> CI_Session routines successfully run
DEBUG - 2015-02-15 06:39:13 --> Model Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Model Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Controller Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 06:39:13 --> Email Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: language_helper
DEBUG - 2015-02-15 06:39:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 06:39:13 --> Model Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Database Driver Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: date_helper
DEBUG - 2015-02-15 06:39:13 --> Helper loaded: form_helper
DEBUG - 2015-02-15 06:39:13 --> Form Validation Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Model Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 06:39:13 --> Pagination Class Initialized
DEBUG - 2015-02-15 06:39:13 --> Model Class Initialized
DEBUG - 2015-02-15 06:39:14 --> Model Class Initialized
DEBUG - 2015-02-15 06:39:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 06:39:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 06:39:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 06:39:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 06:39:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 06:39:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 06:39:14 --> Final output sent to browser
DEBUG - 2015-02-15 06:39:14 --> Total execution time: 1.3571
DEBUG - 2015-02-15 06:54:15 --> Config Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Hooks Class Initialized
DEBUG - 2015-02-15 06:54:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 06:54:15 --> Utf8 Class Initialized
DEBUG - 2015-02-15 06:54:15 --> URI Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Router Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Output Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Security Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Input Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 06:54:15 --> Language Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Loader Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: url_helper
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: link_helper
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 06:54:15 --> CI_Session Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Session: Regenerate ID
DEBUG - 2015-02-15 06:54:15 --> CI_Session routines successfully run
DEBUG - 2015-02-15 06:54:15 --> Model Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Model Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Controller Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 06:54:15 --> Email Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: language_helper
DEBUG - 2015-02-15 06:54:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 06:54:15 --> Model Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Database Driver Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: date_helper
DEBUG - 2015-02-15 06:54:15 --> Helper loaded: form_helper
DEBUG - 2015-02-15 06:54:15 --> Form Validation Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Model Class Initialized
DEBUG - 2015-02-15 06:54:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 06:54:15 --> Pagination Class Initialized
DEBUG - 2015-02-15 06:54:16 --> Model Class Initialized
DEBUG - 2015-02-15 06:54:16 --> Model Class Initialized
DEBUG - 2015-02-15 06:54:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 06:54:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 06:54:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 06:54:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 06:54:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 06:54:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 06:54:17 --> Final output sent to browser
DEBUG - 2015-02-15 06:54:17 --> Total execution time: 1.3441
DEBUG - 2015-02-15 07:09:18 --> Config Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Hooks Class Initialized
DEBUG - 2015-02-15 07:09:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 07:09:18 --> Utf8 Class Initialized
DEBUG - 2015-02-15 07:09:18 --> URI Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Router Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Output Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Security Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Input Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 07:09:18 --> Language Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Loader Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: url_helper
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: link_helper
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 07:09:18 --> CI_Session Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Session: Regenerate ID
DEBUG - 2015-02-15 07:09:18 --> CI_Session routines successfully run
DEBUG - 2015-02-15 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Controller Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 07:09:18 --> Email Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: language_helper
DEBUG - 2015-02-15 07:09:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Database Driver Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: date_helper
DEBUG - 2015-02-15 07:09:18 --> Helper loaded: form_helper
DEBUG - 2015-02-15 07:09:18 --> Form Validation Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 07:09:18 --> Pagination Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-15 07:09:18 --> Model Class Initialized
DEBUG - 2015-02-15 07:09:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 07:09:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 07:09:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 07:09:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 07:09:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 07:09:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 07:09:19 --> Final output sent to browser
DEBUG - 2015-02-15 07:09:19 --> Total execution time: 1.4001
DEBUG - 2015-02-15 07:24:20 --> Config Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Hooks Class Initialized
DEBUG - 2015-02-15 07:24:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 07:24:20 --> Utf8 Class Initialized
DEBUG - 2015-02-15 07:24:20 --> URI Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Router Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Output Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Security Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Input Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 07:24:20 --> Language Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Loader Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: url_helper
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: link_helper
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 07:24:20 --> CI_Session Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Session: Regenerate ID
DEBUG - 2015-02-15 07:24:20 --> CI_Session routines successfully run
DEBUG - 2015-02-15 07:24:20 --> Model Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Model Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Controller Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 07:24:20 --> Email Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: language_helper
DEBUG - 2015-02-15 07:24:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 07:24:20 --> Model Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Database Driver Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: date_helper
DEBUG - 2015-02-15 07:24:20 --> Helper loaded: form_helper
DEBUG - 2015-02-15 07:24:20 --> Form Validation Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Model Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 07:24:20 --> Pagination Class Initialized
DEBUG - 2015-02-15 07:24:20 --> Model Class Initialized
DEBUG - 2015-02-15 07:24:21 --> Model Class Initialized
DEBUG - 2015-02-15 07:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 07:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 07:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 07:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 07:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 07:24:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 07:24:21 --> Final output sent to browser
DEBUG - 2015-02-15 07:24:21 --> Total execution time: 1.3551
DEBUG - 2015-02-15 07:39:22 --> Config Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Hooks Class Initialized
DEBUG - 2015-02-15 07:39:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 07:39:22 --> Utf8 Class Initialized
DEBUG - 2015-02-15 07:39:22 --> URI Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Router Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Output Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Security Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Input Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 07:39:22 --> Language Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Loader Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 07:39:22 --> Helper loaded: url_helper
DEBUG - 2015-02-15 07:39:22 --> Helper loaded: link_helper
DEBUG - 2015-02-15 07:39:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 07:39:22 --> CI_Session Class Initialized
DEBUG - 2015-02-15 07:39:22 --> Session: Regenerate ID
DEBUG - 2015-02-15 07:39:23 --> CI_Session routines successfully run
DEBUG - 2015-02-15 07:39:23 --> Model Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Model Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Controller Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 07:39:23 --> Email Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 07:39:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 07:39:23 --> Helper loaded: language_helper
DEBUG - 2015-02-15 07:39:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 07:39:23 --> Model Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Database Driver Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Helper loaded: date_helper
DEBUG - 2015-02-15 07:39:23 --> Helper loaded: form_helper
DEBUG - 2015-02-15 07:39:23 --> Form Validation Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Model Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 07:39:23 --> Pagination Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Model Class Initialized
DEBUG - 2015-02-15 07:39:23 --> Model Class Initialized
DEBUG - 2015-02-15 07:39:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 07:39:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 07:39:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 07:39:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 07:39:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 07:39:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 07:39:24 --> Final output sent to browser
DEBUG - 2015-02-15 07:39:24 --> Total execution time: 1.4811
DEBUG - 2015-02-15 07:54:25 --> Config Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Hooks Class Initialized
DEBUG - 2015-02-15 07:54:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 07:54:25 --> Utf8 Class Initialized
DEBUG - 2015-02-15 07:54:25 --> URI Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Router Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Output Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Security Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Input Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 07:54:25 --> Language Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Loader Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: url_helper
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: link_helper
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 07:54:25 --> CI_Session Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Session: Regenerate ID
DEBUG - 2015-02-15 07:54:25 --> CI_Session routines successfully run
DEBUG - 2015-02-15 07:54:25 --> Model Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Model Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Controller Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 07:54:25 --> Email Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: language_helper
DEBUG - 2015-02-15 07:54:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 07:54:25 --> Model Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Database Driver Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: date_helper
DEBUG - 2015-02-15 07:54:25 --> Helper loaded: form_helper
DEBUG - 2015-02-15 07:54:25 --> Form Validation Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Model Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 07:54:25 --> Pagination Class Initialized
DEBUG - 2015-02-15 07:54:25 --> Model Class Initialized
DEBUG - 2015-02-15 07:54:26 --> Model Class Initialized
DEBUG - 2015-02-15 07:54:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 07:54:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 07:54:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 07:54:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 07:54:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 07:54:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 07:54:26 --> Final output sent to browser
DEBUG - 2015-02-15 07:54:26 --> Total execution time: 1.3761
DEBUG - 2015-02-15 08:09:27 --> Config Class Initialized
DEBUG - 2015-02-15 08:09:27 --> Hooks Class Initialized
DEBUG - 2015-02-15 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 08:09:27 --> Utf8 Class Initialized
DEBUG - 2015-02-15 08:09:27 --> URI Class Initialized
DEBUG - 2015-02-15 08:09:27 --> Router Class Initialized
DEBUG - 2015-02-15 08:09:27 --> Output Class Initialized
DEBUG - 2015-02-15 08:09:27 --> Security Class Initialized
DEBUG - 2015-02-15 08:09:27 --> Input Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 08:09:28 --> Language Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Loader Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: url_helper
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: link_helper
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 08:09:28 --> CI_Session Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Session: Regenerate ID
DEBUG - 2015-02-15 08:09:28 --> CI_Session routines successfully run
DEBUG - 2015-02-15 08:09:28 --> Model Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Model Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Controller Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 08:09:28 --> Email Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: language_helper
DEBUG - 2015-02-15 08:09:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 08:09:28 --> Model Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Database Driver Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: date_helper
DEBUG - 2015-02-15 08:09:28 --> Helper loaded: form_helper
DEBUG - 2015-02-15 08:09:28 --> Form Validation Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Model Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 08:09:28 --> Pagination Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Model Class Initialized
DEBUG - 2015-02-15 08:09:28 --> Model Class Initialized
DEBUG - 2015-02-15 08:09:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 08:09:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 08:09:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 08:09:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 08:09:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 08:09:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 08:09:29 --> Final output sent to browser
DEBUG - 2015-02-15 08:09:29 --> Total execution time: 1.6232
DEBUG - 2015-02-15 08:24:30 --> Config Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Hooks Class Initialized
DEBUG - 2015-02-15 08:24:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 08:24:30 --> Utf8 Class Initialized
DEBUG - 2015-02-15 08:24:30 --> URI Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Router Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Output Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Security Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Input Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 08:24:30 --> Language Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Loader Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: url_helper
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: link_helper
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 08:24:30 --> CI_Session Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Session: Regenerate ID
DEBUG - 2015-02-15 08:24:30 --> CI_Session routines successfully run
DEBUG - 2015-02-15 08:24:30 --> Model Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Model Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Controller Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 08:24:30 --> Email Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: language_helper
DEBUG - 2015-02-15 08:24:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 08:24:30 --> Model Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Database Driver Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: date_helper
DEBUG - 2015-02-15 08:24:30 --> Helper loaded: form_helper
DEBUG - 2015-02-15 08:24:30 --> Form Validation Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Model Class Initialized
DEBUG - 2015-02-15 08:24:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 08:24:30 --> Pagination Class Initialized
DEBUG - 2015-02-15 08:24:31 --> Model Class Initialized
DEBUG - 2015-02-15 08:24:31 --> Model Class Initialized
DEBUG - 2015-02-15 08:24:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 08:24:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 08:24:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 08:24:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 08:24:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 08:24:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 08:24:32 --> Final output sent to browser
DEBUG - 2015-02-15 08:24:32 --> Total execution time: 1.3361
DEBUG - 2015-02-15 08:39:33 --> Config Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Hooks Class Initialized
DEBUG - 2015-02-15 08:39:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 08:39:33 --> Utf8 Class Initialized
DEBUG - 2015-02-15 08:39:33 --> URI Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Router Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Output Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Security Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Input Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 08:39:33 --> Language Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Loader Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: url_helper
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: link_helper
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 08:39:33 --> CI_Session Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Session: Regenerate ID
DEBUG - 2015-02-15 08:39:33 --> CI_Session routines successfully run
DEBUG - 2015-02-15 08:39:33 --> Model Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Model Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Controller Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 08:39:33 --> Email Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: language_helper
DEBUG - 2015-02-15 08:39:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 08:39:33 --> Model Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Database Driver Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: date_helper
DEBUG - 2015-02-15 08:39:33 --> Helper loaded: form_helper
DEBUG - 2015-02-15 08:39:33 --> Form Validation Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Model Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 08:39:33 --> Pagination Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Model Class Initialized
DEBUG - 2015-02-15 08:39:33 --> Model Class Initialized
DEBUG - 2015-02-15 08:39:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 08:39:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 08:39:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 08:39:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 08:39:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 08:39:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 08:39:34 --> Final output sent to browser
DEBUG - 2015-02-15 08:39:34 --> Total execution time: 1.4251
DEBUG - 2015-02-15 08:54:35 --> Config Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Hooks Class Initialized
DEBUG - 2015-02-15 08:54:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 08:54:35 --> Utf8 Class Initialized
DEBUG - 2015-02-15 08:54:35 --> URI Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Router Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Output Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Security Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Input Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 08:54:35 --> Language Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Loader Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: url_helper
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: link_helper
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 08:54:35 --> CI_Session Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Session: Regenerate ID
DEBUG - 2015-02-15 08:54:35 --> CI_Session routines successfully run
DEBUG - 2015-02-15 08:54:35 --> Model Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Model Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Controller Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 08:54:35 --> Email Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: language_helper
DEBUG - 2015-02-15 08:54:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 08:54:35 --> Model Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Database Driver Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: date_helper
DEBUG - 2015-02-15 08:54:35 --> Helper loaded: form_helper
DEBUG - 2015-02-15 08:54:35 --> Form Validation Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Model Class Initialized
DEBUG - 2015-02-15 08:54:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 08:54:35 --> Pagination Class Initialized
DEBUG - 2015-02-15 08:54:36 --> Model Class Initialized
DEBUG - 2015-02-15 08:54:36 --> Model Class Initialized
DEBUG - 2015-02-15 08:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 08:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 08:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 08:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 08:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 08:54:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 08:54:36 --> Final output sent to browser
DEBUG - 2015-02-15 08:54:36 --> Total execution time: 1.3261
DEBUG - 2015-02-15 09:09:39 --> Config Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Hooks Class Initialized
DEBUG - 2015-02-15 09:09:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 09:09:39 --> Utf8 Class Initialized
DEBUG - 2015-02-15 09:09:39 --> URI Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Router Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Output Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Security Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Input Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 09:09:39 --> Language Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Loader Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: url_helper
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: link_helper
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 09:09:39 --> CI_Session Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Session: Regenerate ID
DEBUG - 2015-02-15 09:09:39 --> CI_Session routines successfully run
DEBUG - 2015-02-15 09:09:39 --> Model Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Model Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Controller Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 09:09:39 --> Email Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: language_helper
DEBUG - 2015-02-15 09:09:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 09:09:39 --> Model Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Database Driver Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: date_helper
DEBUG - 2015-02-15 09:09:39 --> Helper loaded: form_helper
DEBUG - 2015-02-15 09:09:39 --> Form Validation Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Model Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 09:09:39 --> Pagination Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Model Class Initialized
DEBUG - 2015-02-15 09:09:39 --> Model Class Initialized
DEBUG - 2015-02-15 09:09:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 09:09:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 09:09:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 09:09:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 09:09:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 09:09:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 09:09:40 --> Final output sent to browser
DEBUG - 2015-02-15 09:09:40 --> Total execution time: 1.4561
DEBUG - 2015-02-15 09:24:45 --> Config Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Hooks Class Initialized
DEBUG - 2015-02-15 09:24:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 09:24:45 --> Utf8 Class Initialized
DEBUG - 2015-02-15 09:24:45 --> URI Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Router Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Output Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Security Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Input Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 09:24:45 --> Language Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Loader Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: url_helper
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: link_helper
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 09:24:45 --> CI_Session Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Session: Regenerate ID
DEBUG - 2015-02-15 09:24:45 --> CI_Session routines successfully run
DEBUG - 2015-02-15 09:24:45 --> Model Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Model Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Controller Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 09:24:45 --> Email Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: language_helper
DEBUG - 2015-02-15 09:24:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 09:24:45 --> Model Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Database Driver Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: date_helper
DEBUG - 2015-02-15 09:24:45 --> Helper loaded: form_helper
DEBUG - 2015-02-15 09:24:45 --> Form Validation Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Model Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 09:24:45 --> Pagination Class Initialized
DEBUG - 2015-02-15 09:24:45 --> Model Class Initialized
DEBUG - 2015-02-15 09:24:46 --> Model Class Initialized
DEBUG - 2015-02-15 09:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 09:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 09:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 09:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 09:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 09:24:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 09:24:46 --> Final output sent to browser
DEBUG - 2015-02-15 09:24:46 --> Total execution time: 1.4331
DEBUG - 2015-02-15 09:39:47 --> Config Class Initialized
DEBUG - 2015-02-15 09:39:47 --> Hooks Class Initialized
DEBUG - 2015-02-15 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 09:39:47 --> Utf8 Class Initialized
DEBUG - 2015-02-15 09:39:47 --> URI Class Initialized
DEBUG - 2015-02-15 09:39:47 --> Router Class Initialized
DEBUG - 2015-02-15 09:39:47 --> Output Class Initialized
DEBUG - 2015-02-15 09:39:47 --> Security Class Initialized
DEBUG - 2015-02-15 09:39:47 --> Input Class Initialized
DEBUG - 2015-02-15 09:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 09:39:47 --> Language Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Loader Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: url_helper
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: link_helper
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 09:39:48 --> CI_Session Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Session: Regenerate ID
DEBUG - 2015-02-15 09:39:48 --> CI_Session routines successfully run
DEBUG - 2015-02-15 09:39:48 --> Model Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Model Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Controller Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 09:39:48 --> Email Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: language_helper
DEBUG - 2015-02-15 09:39:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 09:39:48 --> Model Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Database Driver Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: date_helper
DEBUG - 2015-02-15 09:39:48 --> Helper loaded: form_helper
DEBUG - 2015-02-15 09:39:48 --> Form Validation Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Model Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 09:39:48 --> Pagination Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Model Class Initialized
DEBUG - 2015-02-15 09:39:48 --> Model Class Initialized
DEBUG - 2015-02-15 09:39:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 09:39:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 09:39:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 09:39:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 09:39:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 09:39:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 09:39:49 --> Final output sent to browser
DEBUG - 2015-02-15 09:39:49 --> Total execution time: 1.3601
DEBUG - 2015-02-15 09:54:50 --> Config Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Hooks Class Initialized
DEBUG - 2015-02-15 09:54:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 09:54:50 --> Utf8 Class Initialized
DEBUG - 2015-02-15 09:54:50 --> URI Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Router Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Output Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Security Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Input Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 09:54:50 --> Language Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Loader Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: url_helper
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: link_helper
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 09:54:50 --> CI_Session Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Session: Regenerate ID
DEBUG - 2015-02-15 09:54:50 --> CI_Session routines successfully run
DEBUG - 2015-02-15 09:54:50 --> Model Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Model Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Controller Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 09:54:50 --> Email Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: language_helper
DEBUG - 2015-02-15 09:54:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 09:54:50 --> Model Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Database Driver Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: date_helper
DEBUG - 2015-02-15 09:54:50 --> Helper loaded: form_helper
DEBUG - 2015-02-15 09:54:50 --> Form Validation Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Model Class Initialized
DEBUG - 2015-02-15 09:54:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 09:54:50 --> Pagination Class Initialized
DEBUG - 2015-02-15 09:54:51 --> Model Class Initialized
DEBUG - 2015-02-15 09:54:51 --> Model Class Initialized
DEBUG - 2015-02-15 09:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 09:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 09:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 09:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 09:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 09:54:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 09:54:51 --> Final output sent to browser
DEBUG - 2015-02-15 09:54:51 --> Total execution time: 1.3981
DEBUG - 2015-02-15 10:09:52 --> Config Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Hooks Class Initialized
DEBUG - 2015-02-15 10:09:52 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 10:09:52 --> Utf8 Class Initialized
DEBUG - 2015-02-15 10:09:52 --> URI Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Router Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Output Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Security Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Input Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 10:09:52 --> Language Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Loader Class Initialized
DEBUG - 2015-02-15 10:09:52 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 10:09:52 --> Helper loaded: url_helper
DEBUG - 2015-02-15 10:09:52 --> Helper loaded: link_helper
DEBUG - 2015-02-15 10:09:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 10:09:53 --> CI_Session Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Session: Regenerate ID
DEBUG - 2015-02-15 10:09:53 --> CI_Session routines successfully run
DEBUG - 2015-02-15 10:09:53 --> Model Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Model Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Controller Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 10:09:53 --> Email Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 10:09:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 10:09:53 --> Helper loaded: language_helper
DEBUG - 2015-02-15 10:09:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 10:09:53 --> Model Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Database Driver Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Helper loaded: date_helper
DEBUG - 2015-02-15 10:09:53 --> Helper loaded: form_helper
DEBUG - 2015-02-15 10:09:53 --> Form Validation Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Model Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 10:09:53 --> Pagination Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Model Class Initialized
DEBUG - 2015-02-15 10:09:53 --> Model Class Initialized
DEBUG - 2015-02-15 10:09:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 10:09:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 10:09:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 10:09:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 10:09:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 10:09:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 10:09:54 --> Final output sent to browser
DEBUG - 2015-02-15 10:09:54 --> Total execution time: 1.4781
DEBUG - 2015-02-15 10:24:55 --> Config Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Hooks Class Initialized
DEBUG - 2015-02-15 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 10:24:55 --> Utf8 Class Initialized
DEBUG - 2015-02-15 10:24:55 --> URI Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Router Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Output Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Security Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Input Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 10:24:55 --> Language Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Loader Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: url_helper
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: link_helper
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 10:24:55 --> CI_Session Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Session: Regenerate ID
DEBUG - 2015-02-15 10:24:55 --> CI_Session routines successfully run
DEBUG - 2015-02-15 10:24:55 --> Model Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Model Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Controller Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 10:24:55 --> Email Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: language_helper
DEBUG - 2015-02-15 10:24:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 10:24:55 --> Model Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Database Driver Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: date_helper
DEBUG - 2015-02-15 10:24:55 --> Helper loaded: form_helper
DEBUG - 2015-02-15 10:24:55 --> Form Validation Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Model Class Initialized
DEBUG - 2015-02-15 10:24:55 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 10:24:55 --> Pagination Class Initialized
DEBUG - 2015-02-15 10:24:56 --> Model Class Initialized
DEBUG - 2015-02-15 10:24:56 --> Model Class Initialized
DEBUG - 2015-02-15 10:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 10:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 10:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 10:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 10:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 10:24:56 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 10:24:56 --> Final output sent to browser
DEBUG - 2015-02-15 10:24:56 --> Total execution time: 1.4801
DEBUG - 2015-02-15 10:39:58 --> Config Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Hooks Class Initialized
DEBUG - 2015-02-15 10:39:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 10:39:58 --> Utf8 Class Initialized
DEBUG - 2015-02-15 10:39:58 --> URI Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Router Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Output Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Security Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Input Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 10:39:58 --> Language Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Loader Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: url_helper
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: link_helper
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 10:39:58 --> CI_Session Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Session: Regenerate ID
DEBUG - 2015-02-15 10:39:58 --> CI_Session routines successfully run
DEBUG - 2015-02-15 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Controller Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 10:39:58 --> Email Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: language_helper
DEBUG - 2015-02-15 10:39:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Database Driver Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: date_helper
DEBUG - 2015-02-15 10:39:58 --> Helper loaded: form_helper
DEBUG - 2015-02-15 10:39:58 --> Form Validation Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 10:39:58 --> Pagination Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-15 10:39:58 --> Model Class Initialized
DEBUG - 2015-02-15 10:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 10:39:58 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 10:39:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 10:39:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 10:39:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 10:39:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 10:39:59 --> Final output sent to browser
DEBUG - 2015-02-15 10:39:59 --> Total execution time: 1.3601
DEBUG - 2015-02-15 10:55:00 --> Config Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Hooks Class Initialized
DEBUG - 2015-02-15 10:55:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 10:55:00 --> Utf8 Class Initialized
DEBUG - 2015-02-15 10:55:00 --> URI Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Router Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Output Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Security Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Input Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 10:55:00 --> Language Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Loader Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: url_helper
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: link_helper
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 10:55:00 --> CI_Session Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Session: Regenerate ID
DEBUG - 2015-02-15 10:55:00 --> CI_Session routines successfully run
DEBUG - 2015-02-15 10:55:00 --> Model Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Model Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Controller Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 10:55:00 --> Email Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: language_helper
DEBUG - 2015-02-15 10:55:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 10:55:00 --> Model Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Database Driver Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: date_helper
DEBUG - 2015-02-15 10:55:00 --> Helper loaded: form_helper
DEBUG - 2015-02-15 10:55:00 --> Form Validation Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Model Class Initialized
DEBUG - 2015-02-15 10:55:00 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 10:55:00 --> Pagination Class Initialized
DEBUG - 2015-02-15 10:55:01 --> Model Class Initialized
DEBUG - 2015-02-15 10:55:01 --> Model Class Initialized
DEBUG - 2015-02-15 10:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 10:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 10:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 10:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 10:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 10:55:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 10:55:01 --> Final output sent to browser
DEBUG - 2015-02-15 10:55:01 --> Total execution time: 1.3351
DEBUG - 2015-02-15 11:10:02 --> Config Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:10:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:10:02 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:10:02 --> URI Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Router Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Output Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Security Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Input Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:10:02 --> Language Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Loader Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 11:10:02 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:10:02 --> Helper loaded: link_helper
DEBUG - 2015-02-15 11:10:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 11:10:02 --> CI_Session Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Session: Regenerate ID
DEBUG - 2015-02-15 11:10:02 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:10:02 --> Model Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Model Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Controller Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 11:10:02 --> Email Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 11:10:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 11:10:02 --> Helper loaded: language_helper
DEBUG - 2015-02-15 11:10:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 11:10:02 --> Model Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:10:02 --> Helper loaded: date_helper
DEBUG - 2015-02-15 11:10:03 --> Helper loaded: form_helper
DEBUG - 2015-02-15 11:10:03 --> Form Validation Class Initialized
DEBUG - 2015-02-15 11:10:03 --> Model Class Initialized
DEBUG - 2015-02-15 11:10:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 11:10:03 --> Pagination Class Initialized
DEBUG - 2015-02-15 11:10:03 --> Model Class Initialized
DEBUG - 2015-02-15 11:10:03 --> Model Class Initialized
DEBUG - 2015-02-15 11:10:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 11:10:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 11:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 11:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 11:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 11:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 11:10:04 --> Final output sent to browser
DEBUG - 2015-02-15 11:10:04 --> Total execution time: 1.4191
DEBUG - 2015-02-15 11:25:05 --> Config Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:25:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:25:05 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:25:05 --> URI Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Router Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Output Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Security Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Input Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:25:05 --> Language Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Loader Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: link_helper
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 11:25:05 --> CI_Session Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Session: Regenerate ID
DEBUG - 2015-02-15 11:25:05 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:25:05 --> Model Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Model Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Controller Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 11:25:05 --> Email Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: language_helper
DEBUG - 2015-02-15 11:25:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 11:25:05 --> Model Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: date_helper
DEBUG - 2015-02-15 11:25:05 --> Helper loaded: form_helper
DEBUG - 2015-02-15 11:25:05 --> Form Validation Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Model Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 11:25:05 --> Pagination Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Model Class Initialized
DEBUG - 2015-02-15 11:25:05 --> Model Class Initialized
DEBUG - 2015-02-15 11:25:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 11:25:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 11:25:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 11:25:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 11:25:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 11:25:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 11:25:06 --> Final output sent to browser
DEBUG - 2015-02-15 11:25:06 --> Total execution time: 1.3521
DEBUG - 2015-02-15 11:40:07 --> Config Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:40:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:40:07 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:40:07 --> URI Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Router Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Output Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Security Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Input Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:40:07 --> Language Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Loader Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: link_helper
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 11:40:07 --> CI_Session Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Session: Regenerate ID
DEBUG - 2015-02-15 11:40:07 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:40:07 --> Model Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Model Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Controller Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 11:40:07 --> Email Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: language_helper
DEBUG - 2015-02-15 11:40:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 11:40:07 --> Model Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: date_helper
DEBUG - 2015-02-15 11:40:07 --> Helper loaded: form_helper
DEBUG - 2015-02-15 11:40:07 --> Form Validation Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Model Class Initialized
DEBUG - 2015-02-15 11:40:07 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 11:40:07 --> Pagination Class Initialized
DEBUG - 2015-02-15 11:40:08 --> Model Class Initialized
DEBUG - 2015-02-15 11:40:08 --> Model Class Initialized
DEBUG - 2015-02-15 11:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 11:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 11:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 11:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 11:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 11:40:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 11:40:08 --> Final output sent to browser
DEBUG - 2015-02-15 11:40:08 --> Total execution time: 1.3581
DEBUG - 2015-02-15 11:55:09 --> Config Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:55:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:55:09 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:55:09 --> URI Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Router Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Output Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Security Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Input Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:55:09 --> Language Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Loader Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 11:55:09 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:55:09 --> Helper loaded: link_helper
DEBUG - 2015-02-15 11:55:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 11:55:09 --> CI_Session Class Initialized
DEBUG - 2015-02-15 11:55:09 --> Session: Regenerate ID
DEBUG - 2015-02-15 11:55:09 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:55:10 --> Model Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Model Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Controller Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 11:55:10 --> Email Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 11:55:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 11:55:10 --> Helper loaded: language_helper
DEBUG - 2015-02-15 11:55:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 11:55:10 --> Model Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Helper loaded: date_helper
DEBUG - 2015-02-15 11:55:10 --> Helper loaded: form_helper
DEBUG - 2015-02-15 11:55:10 --> Form Validation Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Model Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 11:55:10 --> Pagination Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Model Class Initialized
DEBUG - 2015-02-15 11:55:10 --> Model Class Initialized
DEBUG - 2015-02-15 11:55:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 11:55:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 11:55:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 11:55:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 11:55:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 11:55:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 11:55:11 --> Final output sent to browser
DEBUG - 2015-02-15 11:55:11 --> Total execution time: 1.3801
DEBUG - 2015-02-15 12:10:12 --> Config Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Hooks Class Initialized
DEBUG - 2015-02-15 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 12:10:12 --> Utf8 Class Initialized
DEBUG - 2015-02-15 12:10:12 --> URI Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Router Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Output Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Security Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Input Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 12:10:12 --> Language Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Loader Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: url_helper
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: link_helper
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 12:10:12 --> CI_Session Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Session: Regenerate ID
DEBUG - 2015-02-15 12:10:12 --> CI_Session routines successfully run
DEBUG - 2015-02-15 12:10:12 --> Model Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Model Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Controller Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 12:10:12 --> Email Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: language_helper
DEBUG - 2015-02-15 12:10:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 12:10:12 --> Model Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Database Driver Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: date_helper
DEBUG - 2015-02-15 12:10:12 --> Helper loaded: form_helper
DEBUG - 2015-02-15 12:10:12 --> Form Validation Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Model Class Initialized
DEBUG - 2015-02-15 12:10:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 12:10:12 --> Pagination Class Initialized
DEBUG - 2015-02-15 12:10:13 --> Model Class Initialized
DEBUG - 2015-02-15 12:10:13 --> Model Class Initialized
DEBUG - 2015-02-15 12:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 12:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 12:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 12:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 12:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 12:10:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 12:10:13 --> Final output sent to browser
DEBUG - 2015-02-15 12:10:13 --> Total execution time: 1.3781
DEBUG - 2015-02-15 12:25:15 --> Config Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Hooks Class Initialized
DEBUG - 2015-02-15 12:25:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 12:25:15 --> Utf8 Class Initialized
DEBUG - 2015-02-15 12:25:15 --> URI Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Router Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Output Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Security Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Input Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 12:25:15 --> Language Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Loader Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: url_helper
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: link_helper
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 12:25:15 --> CI_Session Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Session: Regenerate ID
DEBUG - 2015-02-15 12:25:15 --> CI_Session routines successfully run
DEBUG - 2015-02-15 12:25:15 --> Model Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Model Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Controller Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 12:25:15 --> Email Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: language_helper
DEBUG - 2015-02-15 12:25:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 12:25:15 --> Model Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Database Driver Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: date_helper
DEBUG - 2015-02-15 12:25:15 --> Helper loaded: form_helper
DEBUG - 2015-02-15 12:25:15 --> Form Validation Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Model Class Initialized
DEBUG - 2015-02-15 12:25:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 12:25:15 --> Pagination Class Initialized
DEBUG - 2015-02-15 12:25:16 --> Model Class Initialized
DEBUG - 2015-02-15 12:25:16 --> Model Class Initialized
DEBUG - 2015-02-15 12:25:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 12:25:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 12:25:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 12:25:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 12:25:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 12:25:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 12:25:17 --> Final output sent to browser
DEBUG - 2015-02-15 12:25:17 --> Total execution time: 1.3553
DEBUG - 2015-02-15 12:40:18 --> Config Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Hooks Class Initialized
DEBUG - 2015-02-15 12:40:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 12:40:18 --> Utf8 Class Initialized
DEBUG - 2015-02-15 12:40:18 --> URI Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Router Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Output Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Security Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Input Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 12:40:18 --> Language Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Loader Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 12:40:18 --> Helper loaded: url_helper
DEBUG - 2015-02-15 12:40:18 --> Helper loaded: link_helper
DEBUG - 2015-02-15 12:40:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 12:40:18 --> CI_Session Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Session: Regenerate ID
DEBUG - 2015-02-15 12:40:18 --> CI_Session routines successfully run
DEBUG - 2015-02-15 12:40:18 --> Model Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Model Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Controller Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 12:40:18 --> Email Class Initialized
DEBUG - 2015-02-15 12:40:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 12:40:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 12:40:19 --> Helper loaded: language_helper
DEBUG - 2015-02-15 12:40:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 12:40:19 --> Model Class Initialized
DEBUG - 2015-02-15 12:40:19 --> Database Driver Class Initialized
DEBUG - 2015-02-15 12:40:19 --> Helper loaded: date_helper
DEBUG - 2015-02-15 12:40:19 --> Helper loaded: form_helper
DEBUG - 2015-02-15 12:40:19 --> Form Validation Class Initialized
DEBUG - 2015-02-15 12:40:19 --> Model Class Initialized
DEBUG - 2015-02-15 12:40:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 12:40:19 --> Pagination Class Initialized
DEBUG - 2015-02-15 12:40:19 --> Model Class Initialized
DEBUG - 2015-02-15 12:40:19 --> Model Class Initialized
DEBUG - 2015-02-15 12:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 12:40:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 12:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 12:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 12:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 12:40:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 12:40:20 --> Final output sent to browser
DEBUG - 2015-02-15 12:40:20 --> Total execution time: 1.3600
DEBUG - 2015-02-15 12:55:22 --> Config Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Hooks Class Initialized
DEBUG - 2015-02-15 12:55:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 12:55:22 --> Utf8 Class Initialized
DEBUG - 2015-02-15 12:55:22 --> URI Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Router Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Output Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Security Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Input Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 12:55:22 --> Language Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Loader Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: url_helper
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: link_helper
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 12:55:22 --> CI_Session Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Session: Regenerate ID
DEBUG - 2015-02-15 12:55:22 --> CI_Session routines successfully run
DEBUG - 2015-02-15 12:55:22 --> Model Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Model Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Controller Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 12:55:22 --> Email Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: language_helper
DEBUG - 2015-02-15 12:55:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 12:55:22 --> Model Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Database Driver Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: date_helper
DEBUG - 2015-02-15 12:55:22 --> Helper loaded: form_helper
DEBUG - 2015-02-15 12:55:22 --> Form Validation Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Model Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 12:55:22 --> Pagination Class Initialized
DEBUG - 2015-02-15 12:55:22 --> Model Class Initialized
DEBUG - 2015-02-15 12:55:23 --> Model Class Initialized
DEBUG - 2015-02-15 12:55:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 12:55:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 12:55:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 12:55:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 12:55:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 12:55:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 12:55:23 --> Final output sent to browser
DEBUG - 2015-02-15 12:55:23 --> Total execution time: 1.3551
DEBUG - 2015-02-15 13:10:24 --> Config Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Hooks Class Initialized
DEBUG - 2015-02-15 13:10:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 13:10:24 --> Utf8 Class Initialized
DEBUG - 2015-02-15 13:10:24 --> URI Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Router Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Output Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Security Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Input Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 13:10:24 --> Language Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Loader Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: url_helper
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: link_helper
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 13:10:24 --> CI_Session Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Session: Regenerate ID
DEBUG - 2015-02-15 13:10:24 --> CI_Session routines successfully run
DEBUG - 2015-02-15 13:10:24 --> Model Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Model Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Controller Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 13:10:24 --> Email Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: language_helper
DEBUG - 2015-02-15 13:10:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 13:10:24 --> Model Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Database Driver Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: date_helper
DEBUG - 2015-02-15 13:10:24 --> Helper loaded: form_helper
DEBUG - 2015-02-15 13:10:24 --> Form Validation Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Model Class Initialized
DEBUG - 2015-02-15 13:10:24 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 13:10:24 --> Pagination Class Initialized
DEBUG - 2015-02-15 13:10:25 --> Model Class Initialized
DEBUG - 2015-02-15 13:10:25 --> Model Class Initialized
DEBUG - 2015-02-15 13:10:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 13:10:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 13:10:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 13:10:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 13:10:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 13:10:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 13:10:26 --> Final output sent to browser
DEBUG - 2015-02-15 13:10:26 --> Total execution time: 1.3301
DEBUG - 2015-02-15 13:25:27 --> Config Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Hooks Class Initialized
DEBUG - 2015-02-15 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 13:25:27 --> Utf8 Class Initialized
DEBUG - 2015-02-15 13:25:27 --> URI Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Router Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Output Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Security Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Input Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 13:25:27 --> Language Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Loader Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: url_helper
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: link_helper
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 13:25:27 --> CI_Session Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Session: Regenerate ID
DEBUG - 2015-02-15 13:25:27 --> CI_Session routines successfully run
DEBUG - 2015-02-15 13:25:27 --> Model Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Model Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Controller Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 13:25:27 --> Email Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: language_helper
DEBUG - 2015-02-15 13:25:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 13:25:27 --> Model Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Database Driver Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: date_helper
DEBUG - 2015-02-15 13:25:27 --> Helper loaded: form_helper
DEBUG - 2015-02-15 13:25:27 --> Form Validation Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Model Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 13:25:27 --> Pagination Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Model Class Initialized
DEBUG - 2015-02-15 13:25:27 --> Model Class Initialized
DEBUG - 2015-02-15 13:25:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 13:25:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 13:25:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 13:25:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 13:25:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 13:25:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 13:25:28 --> Final output sent to browser
DEBUG - 2015-02-15 13:25:28 --> Total execution time: 1.3341
DEBUG - 2015-02-15 13:40:30 --> Config Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Hooks Class Initialized
DEBUG - 2015-02-15 13:40:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 13:40:30 --> Utf8 Class Initialized
DEBUG - 2015-02-15 13:40:30 --> URI Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Router Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Output Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Security Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Input Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 13:40:30 --> Language Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Loader Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: url_helper
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: link_helper
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 13:40:30 --> CI_Session Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Session: Regenerate ID
DEBUG - 2015-02-15 13:40:30 --> CI_Session routines successfully run
DEBUG - 2015-02-15 13:40:30 --> Model Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Model Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Controller Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 13:40:30 --> Email Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: language_helper
DEBUG - 2015-02-15 13:40:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 13:40:30 --> Model Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Database Driver Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: date_helper
DEBUG - 2015-02-15 13:40:30 --> Helper loaded: form_helper
DEBUG - 2015-02-15 13:40:30 --> Form Validation Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Model Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 13:40:30 --> Pagination Class Initialized
DEBUG - 2015-02-15 13:40:30 --> Model Class Initialized
DEBUG - 2015-02-15 13:40:31 --> Model Class Initialized
DEBUG - 2015-02-15 13:40:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 13:40:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 13:40:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 13:40:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 13:40:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 13:40:31 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 13:40:31 --> Final output sent to browser
DEBUG - 2015-02-15 13:40:31 --> Total execution time: 1.3441
DEBUG - 2015-02-15 13:55:33 --> Config Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Hooks Class Initialized
DEBUG - 2015-02-15 13:55:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 13:55:33 --> Utf8 Class Initialized
DEBUG - 2015-02-15 13:55:33 --> URI Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Router Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Output Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Security Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Input Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 13:55:33 --> Language Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Loader Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: url_helper
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: link_helper
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 13:55:33 --> CI_Session Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Session: Regenerate ID
DEBUG - 2015-02-15 13:55:33 --> CI_Session routines successfully run
DEBUG - 2015-02-15 13:55:33 --> Model Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Model Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Controller Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 13:55:33 --> Email Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: language_helper
DEBUG - 2015-02-15 13:55:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 13:55:33 --> Model Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Database Driver Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: date_helper
DEBUG - 2015-02-15 13:55:33 --> Helper loaded: form_helper
DEBUG - 2015-02-15 13:55:33 --> Form Validation Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Model Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 13:55:33 --> Pagination Class Initialized
DEBUG - 2015-02-15 13:55:33 --> Model Class Initialized
DEBUG - 2015-02-15 13:55:34 --> Model Class Initialized
DEBUG - 2015-02-15 13:55:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 13:55:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 13:55:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 13:55:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 13:55:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 13:55:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 13:55:34 --> Final output sent to browser
DEBUG - 2015-02-15 13:55:34 --> Total execution time: 1.3721
DEBUG - 2015-02-15 14:10:35 --> Config Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Hooks Class Initialized
DEBUG - 2015-02-15 14:10:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 14:10:35 --> Utf8 Class Initialized
DEBUG - 2015-02-15 14:10:35 --> URI Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Router Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Output Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Security Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Input Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 14:10:35 --> Language Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Loader Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 14:10:35 --> Helper loaded: url_helper
DEBUG - 2015-02-15 14:10:35 --> Helper loaded: link_helper
DEBUG - 2015-02-15 14:10:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 14:10:35 --> CI_Session Class Initialized
DEBUG - 2015-02-15 14:10:35 --> Session: Regenerate ID
DEBUG - 2015-02-15 14:10:36 --> CI_Session routines successfully run
DEBUG - 2015-02-15 14:10:36 --> Model Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Model Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Controller Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 14:10:36 --> Email Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 14:10:36 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 14:10:36 --> Helper loaded: language_helper
DEBUG - 2015-02-15 14:10:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 14:10:36 --> Model Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Database Driver Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Helper loaded: date_helper
DEBUG - 2015-02-15 14:10:36 --> Helper loaded: form_helper
DEBUG - 2015-02-15 14:10:36 --> Form Validation Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Model Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 14:10:36 --> Pagination Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Model Class Initialized
DEBUG - 2015-02-15 14:10:36 --> Model Class Initialized
DEBUG - 2015-02-15 14:10:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 14:10:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 14:10:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 14:10:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 14:10:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 14:10:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 14:10:37 --> Final output sent to browser
DEBUG - 2015-02-15 14:10:37 --> Total execution time: 1.4591
DEBUG - 2015-02-15 14:25:38 --> Config Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Hooks Class Initialized
DEBUG - 2015-02-15 14:25:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 14:25:38 --> Utf8 Class Initialized
DEBUG - 2015-02-15 14:25:38 --> URI Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Router Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Output Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Security Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Input Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 14:25:38 --> Language Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Loader Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: url_helper
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: link_helper
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 14:25:38 --> CI_Session Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Session: Regenerate ID
DEBUG - 2015-02-15 14:25:38 --> CI_Session routines successfully run
DEBUG - 2015-02-15 14:25:38 --> Model Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Model Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Controller Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 14:25:38 --> Email Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: language_helper
DEBUG - 2015-02-15 14:25:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 14:25:38 --> Model Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Database Driver Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: date_helper
DEBUG - 2015-02-15 14:25:38 --> Helper loaded: form_helper
DEBUG - 2015-02-15 14:25:38 --> Form Validation Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Model Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 14:25:38 --> Pagination Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Model Class Initialized
DEBUG - 2015-02-15 14:25:38 --> Model Class Initialized
DEBUG - 2015-02-15 14:25:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 14:25:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 14:25:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 14:25:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 14:25:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 14:25:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 14:25:39 --> Final output sent to browser
DEBUG - 2015-02-15 14:25:39 --> Total execution time: 1.3451
DEBUG - 2015-02-15 14:40:44 --> Config Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Hooks Class Initialized
DEBUG - 2015-02-15 14:40:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 14:40:44 --> Utf8 Class Initialized
DEBUG - 2015-02-15 14:40:44 --> URI Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Router Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Output Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Security Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Input Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 14:40:44 --> Language Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Loader Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: url_helper
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: link_helper
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 14:40:44 --> CI_Session Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Session: Regenerate ID
DEBUG - 2015-02-15 14:40:44 --> CI_Session routines successfully run
DEBUG - 2015-02-15 14:40:44 --> Model Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Model Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Controller Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 14:40:44 --> Email Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: language_helper
DEBUG - 2015-02-15 14:40:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 14:40:44 --> Model Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Database Driver Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: date_helper
DEBUG - 2015-02-15 14:40:44 --> Helper loaded: form_helper
DEBUG - 2015-02-15 14:40:44 --> Form Validation Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Model Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 14:40:44 --> Pagination Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Model Class Initialized
DEBUG - 2015-02-15 14:40:44 --> Model Class Initialized
DEBUG - 2015-02-15 14:40:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 14:40:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 14:40:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 14:40:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 14:40:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 14:40:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 14:40:45 --> Final output sent to browser
DEBUG - 2015-02-15 14:40:45 --> Total execution time: 1.3461
DEBUG - 2015-02-15 14:55:46 --> Config Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Hooks Class Initialized
DEBUG - 2015-02-15 14:55:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 14:55:46 --> Utf8 Class Initialized
DEBUG - 2015-02-15 14:55:46 --> URI Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Router Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Output Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Security Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Input Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 14:55:46 --> Language Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Loader Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: url_helper
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: link_helper
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 14:55:46 --> CI_Session Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Session: Regenerate ID
DEBUG - 2015-02-15 14:55:46 --> CI_Session routines successfully run
DEBUG - 2015-02-15 14:55:46 --> Model Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Model Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Controller Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 14:55:46 --> Email Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: language_helper
DEBUG - 2015-02-15 14:55:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 14:55:46 --> Model Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Database Driver Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: date_helper
DEBUG - 2015-02-15 14:55:46 --> Helper loaded: form_helper
DEBUG - 2015-02-15 14:55:46 --> Form Validation Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Model Class Initialized
DEBUG - 2015-02-15 14:55:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 14:55:46 --> Pagination Class Initialized
DEBUG - 2015-02-15 14:55:47 --> Model Class Initialized
DEBUG - 2015-02-15 14:55:47 --> Model Class Initialized
DEBUG - 2015-02-15 14:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 14:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 14:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 14:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 14:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 14:55:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 14:55:47 --> Final output sent to browser
DEBUG - 2015-02-15 14:55:47 --> Total execution time: 1.3651
DEBUG - 2015-02-15 15:10:49 --> Config Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Hooks Class Initialized
DEBUG - 2015-02-15 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 15:10:49 --> Utf8 Class Initialized
DEBUG - 2015-02-15 15:10:49 --> URI Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Router Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Output Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Security Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Input Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 15:10:49 --> Language Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Loader Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: url_helper
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: link_helper
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 15:10:49 --> CI_Session Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Session: Regenerate ID
DEBUG - 2015-02-15 15:10:49 --> CI_Session routines successfully run
DEBUG - 2015-02-15 15:10:49 --> Model Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Model Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Controller Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 15:10:49 --> Email Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: language_helper
DEBUG - 2015-02-15 15:10:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 15:10:49 --> Model Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Database Driver Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: date_helper
DEBUG - 2015-02-15 15:10:49 --> Helper loaded: form_helper
DEBUG - 2015-02-15 15:10:49 --> Form Validation Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Model Class Initialized
DEBUG - 2015-02-15 15:10:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 15:10:49 --> Pagination Class Initialized
DEBUG - 2015-02-15 15:10:50 --> Model Class Initialized
DEBUG - 2015-02-15 15:10:50 --> Model Class Initialized
DEBUG - 2015-02-15 15:10:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 15:10:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 15:10:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 15:10:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 15:10:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 15:10:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 15:10:51 --> Final output sent to browser
DEBUG - 2015-02-15 15:10:51 --> Total execution time: 1.4581
DEBUG - 2015-02-15 15:25:53 --> Config Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Hooks Class Initialized
DEBUG - 2015-02-15 15:25:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 15:25:53 --> Utf8 Class Initialized
DEBUG - 2015-02-15 15:25:53 --> URI Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Router Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Output Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Security Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Input Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 15:25:53 --> Language Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Loader Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: url_helper
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: link_helper
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 15:25:53 --> CI_Session Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Session: Regenerate ID
DEBUG - 2015-02-15 15:25:53 --> CI_Session routines successfully run
DEBUG - 2015-02-15 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Controller Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 15:25:53 --> Email Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: language_helper
DEBUG - 2015-02-15 15:25:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Database Driver Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: date_helper
DEBUG - 2015-02-15 15:25:53 --> Helper loaded: form_helper
DEBUG - 2015-02-15 15:25:53 --> Form Validation Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 15:25:53 --> Pagination Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-15 15:25:53 --> Model Class Initialized
DEBUG - 2015-02-15 15:25:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 15:25:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 15:25:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 15:25:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 15:25:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 15:25:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 15:25:54 --> Final output sent to browser
DEBUG - 2015-02-15 15:25:54 --> Total execution time: 1.3441
DEBUG - 2015-02-15 15:40:56 --> Config Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Hooks Class Initialized
DEBUG - 2015-02-15 15:40:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 15:40:56 --> Utf8 Class Initialized
DEBUG - 2015-02-15 15:40:56 --> URI Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Router Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Output Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Security Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Input Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 15:40:56 --> Language Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Loader Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: url_helper
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: link_helper
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 15:40:56 --> CI_Session Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Session: Regenerate ID
DEBUG - 2015-02-15 15:40:56 --> CI_Session routines successfully run
DEBUG - 2015-02-15 15:40:56 --> Model Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Model Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Controller Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 15:40:56 --> Email Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: language_helper
DEBUG - 2015-02-15 15:40:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 15:40:56 --> Model Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Database Driver Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: date_helper
DEBUG - 2015-02-15 15:40:56 --> Helper loaded: form_helper
DEBUG - 2015-02-15 15:40:56 --> Form Validation Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Model Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 15:40:56 --> Pagination Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Model Class Initialized
DEBUG - 2015-02-15 15:40:56 --> Model Class Initialized
DEBUG - 2015-02-15 15:40:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 15:40:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 15:40:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 15:40:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 15:40:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 15:40:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 15:40:57 --> Final output sent to browser
DEBUG - 2015-02-15 15:40:57 --> Total execution time: 1.3551
DEBUG - 2015-02-15 15:55:58 --> Config Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Hooks Class Initialized
DEBUG - 2015-02-15 15:55:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 15:55:58 --> Utf8 Class Initialized
DEBUG - 2015-02-15 15:55:58 --> URI Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Router Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Output Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Security Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Input Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 15:55:58 --> Language Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Loader Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: url_helper
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: link_helper
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 15:55:58 --> CI_Session Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Session: Regenerate ID
DEBUG - 2015-02-15 15:55:58 --> CI_Session routines successfully run
DEBUG - 2015-02-15 15:55:58 --> Model Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Model Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Controller Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 15:55:58 --> Email Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: language_helper
DEBUG - 2015-02-15 15:55:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 15:55:58 --> Model Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Database Driver Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: date_helper
DEBUG - 2015-02-15 15:55:58 --> Helper loaded: form_helper
DEBUG - 2015-02-15 15:55:58 --> Form Validation Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Model Class Initialized
DEBUG - 2015-02-15 15:55:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 15:55:58 --> Pagination Class Initialized
DEBUG - 2015-02-15 15:55:59 --> Model Class Initialized
DEBUG - 2015-02-15 15:55:59 --> Model Class Initialized
DEBUG - 2015-02-15 15:55:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 15:55:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 15:55:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 15:55:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 15:55:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 15:55:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 15:55:59 --> Final output sent to browser
DEBUG - 2015-02-15 15:55:59 --> Total execution time: 1.3681
DEBUG - 2015-02-15 16:11:00 --> Config Class Initialized
DEBUG - 2015-02-15 16:11:00 --> Hooks Class Initialized
DEBUG - 2015-02-15 16:11:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 16:11:00 --> Utf8 Class Initialized
DEBUG - 2015-02-15 16:11:00 --> URI Class Initialized
DEBUG - 2015-02-15 16:11:00 --> Router Class Initialized
DEBUG - 2015-02-15 16:11:00 --> Output Class Initialized
DEBUG - 2015-02-15 16:11:00 --> Security Class Initialized
DEBUG - 2015-02-15 16:11:00 --> Input Class Initialized
DEBUG - 2015-02-15 16:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 16:11:00 --> Language Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Loader Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: url_helper
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: link_helper
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 16:11:01 --> CI_Session Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Session: Regenerate ID
DEBUG - 2015-02-15 16:11:01 --> CI_Session routines successfully run
DEBUG - 2015-02-15 16:11:01 --> Model Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Model Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Controller Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 16:11:01 --> Email Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: language_helper
DEBUG - 2015-02-15 16:11:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 16:11:01 --> Model Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Database Driver Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: date_helper
DEBUG - 2015-02-15 16:11:01 --> Helper loaded: form_helper
DEBUG - 2015-02-15 16:11:01 --> Form Validation Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Model Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 16:11:01 --> Pagination Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Model Class Initialized
DEBUG - 2015-02-15 16:11:01 --> Model Class Initialized
DEBUG - 2015-02-15 16:11:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 16:11:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 16:11:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 16:11:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 16:11:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 16:11:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 16:11:02 --> Final output sent to browser
DEBUG - 2015-02-15 16:11:02 --> Total execution time: 1.5492
DEBUG - 2015-02-15 16:26:03 --> Config Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Hooks Class Initialized
DEBUG - 2015-02-15 16:26:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 16:26:03 --> Utf8 Class Initialized
DEBUG - 2015-02-15 16:26:03 --> URI Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Router Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Output Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Security Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Input Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 16:26:03 --> Language Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Loader Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 16:26:03 --> Helper loaded: url_helper
DEBUG - 2015-02-15 16:26:03 --> Helper loaded: link_helper
DEBUG - 2015-02-15 16:26:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 16:26:03 --> CI_Session Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Session: Regenerate ID
DEBUG - 2015-02-15 16:26:03 --> CI_Session routines successfully run
DEBUG - 2015-02-15 16:26:03 --> Model Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Model Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Controller Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 16:26:03 --> Email Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 16:26:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 16:26:03 --> Helper loaded: language_helper
DEBUG - 2015-02-15 16:26:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 16:26:03 --> Model Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Database Driver Class Initialized
DEBUG - 2015-02-15 16:26:03 --> Helper loaded: date_helper
DEBUG - 2015-02-15 16:26:04 --> Helper loaded: form_helper
DEBUG - 2015-02-15 16:26:04 --> Form Validation Class Initialized
DEBUG - 2015-02-15 16:26:04 --> Model Class Initialized
DEBUG - 2015-02-15 16:26:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 16:26:04 --> Pagination Class Initialized
DEBUG - 2015-02-15 16:26:04 --> Model Class Initialized
DEBUG - 2015-02-15 16:26:04 --> Model Class Initialized
DEBUG - 2015-02-15 16:26:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 16:26:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 16:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 16:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 16:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 16:26:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 16:26:05 --> Final output sent to browser
DEBUG - 2015-02-15 16:26:05 --> Total execution time: 1.3481
DEBUG - 2015-02-15 16:41:06 --> Config Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Hooks Class Initialized
DEBUG - 2015-02-15 16:41:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 16:41:06 --> Utf8 Class Initialized
DEBUG - 2015-02-15 16:41:06 --> URI Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Router Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Output Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Security Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Input Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 16:41:06 --> Language Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Loader Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: url_helper
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: link_helper
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 16:41:06 --> CI_Session Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Session: Regenerate ID
DEBUG - 2015-02-15 16:41:06 --> CI_Session routines successfully run
DEBUG - 2015-02-15 16:41:06 --> Model Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Model Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Controller Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 16:41:06 --> Email Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: language_helper
DEBUG - 2015-02-15 16:41:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 16:41:06 --> Model Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Database Driver Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: date_helper
DEBUG - 2015-02-15 16:41:06 --> Helper loaded: form_helper
DEBUG - 2015-02-15 16:41:06 --> Form Validation Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Model Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 16:41:06 --> Pagination Class Initialized
DEBUG - 2015-02-15 16:41:06 --> Model Class Initialized
DEBUG - 2015-02-15 16:41:07 --> Model Class Initialized
DEBUG - 2015-02-15 16:41:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 16:41:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 16:41:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 16:41:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 16:41:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 16:41:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 16:41:07 --> Final output sent to browser
DEBUG - 2015-02-15 16:41:07 --> Total execution time: 1.4741
DEBUG - 2015-02-15 16:56:09 --> Config Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Hooks Class Initialized
DEBUG - 2015-02-15 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 16:56:09 --> Utf8 Class Initialized
DEBUG - 2015-02-15 16:56:09 --> URI Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Router Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Output Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Security Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Input Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 16:56:09 --> Language Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Loader Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: url_helper
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: link_helper
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 16:56:09 --> CI_Session Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Session: Regenerate ID
DEBUG - 2015-02-15 16:56:09 --> CI_Session routines successfully run
DEBUG - 2015-02-15 16:56:09 --> Model Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Model Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Controller Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 16:56:09 --> Email Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: language_helper
DEBUG - 2015-02-15 16:56:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 16:56:09 --> Model Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Database Driver Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: date_helper
DEBUG - 2015-02-15 16:56:09 --> Helper loaded: form_helper
DEBUG - 2015-02-15 16:56:09 --> Form Validation Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Model Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 16:56:09 --> Pagination Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Model Class Initialized
DEBUG - 2015-02-15 16:56:09 --> Model Class Initialized
DEBUG - 2015-02-15 16:56:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 16:56:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 16:56:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 16:56:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 16:56:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 16:56:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 16:56:10 --> Final output sent to browser
DEBUG - 2015-02-15 16:56:10 --> Total execution time: 1.3421
DEBUG - 2015-02-15 17:11:11 --> Config Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Hooks Class Initialized
DEBUG - 2015-02-15 17:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 17:11:11 --> Utf8 Class Initialized
DEBUG - 2015-02-15 17:11:11 --> URI Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Router Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Output Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Security Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Input Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 17:11:11 --> Language Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Loader Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 17:11:11 --> Helper loaded: url_helper
DEBUG - 2015-02-15 17:11:11 --> Helper loaded: link_helper
DEBUG - 2015-02-15 17:11:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 17:11:11 --> CI_Session Class Initialized
DEBUG - 2015-02-15 17:11:11 --> Session: Regenerate ID
DEBUG - 2015-02-15 17:11:11 --> CI_Session routines successfully run
DEBUG - 2015-02-15 17:11:12 --> Model Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Model Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Controller Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 17:11:12 --> Email Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 17:11:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 17:11:12 --> Helper loaded: language_helper
DEBUG - 2015-02-15 17:11:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 17:11:12 --> Model Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Database Driver Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Helper loaded: date_helper
DEBUG - 2015-02-15 17:11:12 --> Helper loaded: form_helper
DEBUG - 2015-02-15 17:11:12 --> Form Validation Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Model Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 17:11:12 --> Pagination Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Model Class Initialized
DEBUG - 2015-02-15 17:11:12 --> Model Class Initialized
DEBUG - 2015-02-15 17:11:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 17:11:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 17:11:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 17:11:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 17:11:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 17:11:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 17:11:13 --> Final output sent to browser
DEBUG - 2015-02-15 17:11:13 --> Total execution time: 1.4151
DEBUG - 2015-02-15 17:26:15 --> Config Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Hooks Class Initialized
DEBUG - 2015-02-15 17:26:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 17:26:15 --> Utf8 Class Initialized
DEBUG - 2015-02-15 17:26:15 --> URI Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Router Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Output Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Security Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Input Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 17:26:15 --> Language Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Loader Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: url_helper
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: link_helper
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 17:26:15 --> CI_Session Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Session: Regenerate ID
DEBUG - 2015-02-15 17:26:15 --> CI_Session routines successfully run
DEBUG - 2015-02-15 17:26:15 --> Model Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Model Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Controller Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 17:26:15 --> Email Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: language_helper
DEBUG - 2015-02-15 17:26:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 17:26:15 --> Model Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Database Driver Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: date_helper
DEBUG - 2015-02-15 17:26:15 --> Helper loaded: form_helper
DEBUG - 2015-02-15 17:26:15 --> Form Validation Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Model Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 17:26:15 --> Pagination Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Model Class Initialized
DEBUG - 2015-02-15 17:26:15 --> Model Class Initialized
DEBUG - 2015-02-15 17:26:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 17:26:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 17:26:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 17:26:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 17:26:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 17:26:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 17:26:16 --> Final output sent to browser
DEBUG - 2015-02-15 17:26:16 --> Total execution time: 1.4181
DEBUG - 2015-02-15 17:41:25 --> Config Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Hooks Class Initialized
DEBUG - 2015-02-15 17:41:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 17:41:25 --> Utf8 Class Initialized
DEBUG - 2015-02-15 17:41:25 --> URI Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Router Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Output Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Security Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Input Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 17:41:25 --> Language Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Loader Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: url_helper
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: link_helper
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 17:41:25 --> CI_Session Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Session: Regenerate ID
DEBUG - 2015-02-15 17:41:25 --> CI_Session routines successfully run
DEBUG - 2015-02-15 17:41:25 --> Model Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Model Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Controller Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 17:41:25 --> Email Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: language_helper
DEBUG - 2015-02-15 17:41:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 17:41:25 --> Model Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Database Driver Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: date_helper
DEBUG - 2015-02-15 17:41:25 --> Helper loaded: form_helper
DEBUG - 2015-02-15 17:41:25 --> Form Validation Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Model Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 17:41:25 --> Pagination Class Initialized
DEBUG - 2015-02-15 17:41:25 --> Model Class Initialized
DEBUG - 2015-02-15 17:41:26 --> Model Class Initialized
DEBUG - 2015-02-15 17:41:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 17:41:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 17:41:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 17:41:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 17:41:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 17:41:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 17:41:26 --> Final output sent to browser
DEBUG - 2015-02-15 17:41:26 --> Total execution time: 1.4401
DEBUG - 2015-02-15 17:56:28 --> Config Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Hooks Class Initialized
DEBUG - 2015-02-15 17:56:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 17:56:28 --> Utf8 Class Initialized
DEBUG - 2015-02-15 17:56:28 --> URI Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Router Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Output Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Security Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Input Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 17:56:28 --> Language Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Loader Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: url_helper
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: link_helper
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 17:56:28 --> CI_Session Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Session: Regenerate ID
DEBUG - 2015-02-15 17:56:28 --> CI_Session routines successfully run
DEBUG - 2015-02-15 17:56:28 --> Model Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Model Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Controller Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 17:56:28 --> Email Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: language_helper
DEBUG - 2015-02-15 17:56:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 17:56:28 --> Model Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Database Driver Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: date_helper
DEBUG - 2015-02-15 17:56:28 --> Helper loaded: form_helper
DEBUG - 2015-02-15 17:56:28 --> Form Validation Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Model Class Initialized
DEBUG - 2015-02-15 17:56:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 17:56:28 --> Pagination Class Initialized
DEBUG - 2015-02-15 17:56:29 --> Model Class Initialized
DEBUG - 2015-02-15 17:56:29 --> Model Class Initialized
DEBUG - 2015-02-15 17:56:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 17:56:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 17:56:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 17:56:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 17:56:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 17:56:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 17:56:29 --> Final output sent to browser
DEBUG - 2015-02-15 17:56:29 --> Total execution time: 1.3461
DEBUG - 2015-02-15 18:11:31 --> Config Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Hooks Class Initialized
DEBUG - 2015-02-15 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 18:11:31 --> Utf8 Class Initialized
DEBUG - 2015-02-15 18:11:31 --> URI Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Router Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Output Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Security Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Input Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 18:11:31 --> Language Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Loader Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: url_helper
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: link_helper
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 18:11:31 --> CI_Session Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Session: Regenerate ID
DEBUG - 2015-02-15 18:11:31 --> CI_Session routines successfully run
DEBUG - 2015-02-15 18:11:31 --> Model Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Model Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Controller Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 18:11:31 --> Email Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: language_helper
DEBUG - 2015-02-15 18:11:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 18:11:31 --> Model Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Database Driver Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: date_helper
DEBUG - 2015-02-15 18:11:31 --> Helper loaded: form_helper
DEBUG - 2015-02-15 18:11:31 --> Form Validation Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Model Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 18:11:31 --> Pagination Class Initialized
DEBUG - 2015-02-15 18:11:31 --> Model Class Initialized
DEBUG - 2015-02-15 18:11:32 --> Model Class Initialized
DEBUG - 2015-02-15 18:11:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 18:11:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 18:11:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 18:11:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 18:11:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 18:11:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 18:11:32 --> Final output sent to browser
DEBUG - 2015-02-15 18:11:32 --> Total execution time: 1.5452
DEBUG - 2015-02-15 18:26:35 --> Config Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Hooks Class Initialized
DEBUG - 2015-02-15 18:26:35 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 18:26:35 --> Utf8 Class Initialized
DEBUG - 2015-02-15 18:26:35 --> URI Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Router Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Output Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Security Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Input Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 18:26:35 --> Language Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Loader Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: url_helper
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: link_helper
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 18:26:35 --> CI_Session Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Session: Regenerate ID
DEBUG - 2015-02-15 18:26:35 --> CI_Session routines successfully run
DEBUG - 2015-02-15 18:26:35 --> Model Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Model Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Controller Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 18:26:35 --> Email Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: language_helper
DEBUG - 2015-02-15 18:26:35 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 18:26:35 --> Model Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Database Driver Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: date_helper
DEBUG - 2015-02-15 18:26:35 --> Helper loaded: form_helper
DEBUG - 2015-02-15 18:26:35 --> Form Validation Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Model Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 18:26:35 --> Pagination Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Model Class Initialized
DEBUG - 2015-02-15 18:26:35 --> Model Class Initialized
DEBUG - 2015-02-15 18:26:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 18:26:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 18:26:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 18:26:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 18:26:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 18:26:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 18:26:36 --> Final output sent to browser
DEBUG - 2015-02-15 18:26:36 --> Total execution time: 1.3811
DEBUG - 2015-02-15 18:41:37 --> Config Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Hooks Class Initialized
DEBUG - 2015-02-15 18:41:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 18:41:37 --> Utf8 Class Initialized
DEBUG - 2015-02-15 18:41:37 --> URI Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Router Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Output Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Security Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Input Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 18:41:37 --> Language Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Loader Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 18:41:37 --> Helper loaded: url_helper
DEBUG - 2015-02-15 18:41:37 --> Helper loaded: link_helper
DEBUG - 2015-02-15 18:41:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 18:41:37 --> CI_Session Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Session: Regenerate ID
DEBUG - 2015-02-15 18:41:37 --> CI_Session routines successfully run
DEBUG - 2015-02-15 18:41:37 --> Model Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Model Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Controller Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 18:41:37 --> Email Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 18:41:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 18:41:37 --> Helper loaded: language_helper
DEBUG - 2015-02-15 18:41:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 18:41:37 --> Model Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Database Driver Class Initialized
DEBUG - 2015-02-15 18:41:37 --> Helper loaded: date_helper
DEBUG - 2015-02-15 18:41:38 --> Helper loaded: form_helper
DEBUG - 2015-02-15 18:41:38 --> Form Validation Class Initialized
DEBUG - 2015-02-15 18:41:38 --> Model Class Initialized
DEBUG - 2015-02-15 18:41:38 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 18:41:38 --> Pagination Class Initialized
DEBUG - 2015-02-15 18:41:38 --> Model Class Initialized
DEBUG - 2015-02-15 18:41:38 --> Model Class Initialized
DEBUG - 2015-02-15 18:41:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 18:41:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 18:41:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 18:41:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 18:41:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 18:41:39 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 18:41:39 --> Final output sent to browser
DEBUG - 2015-02-15 18:41:39 --> Total execution time: 1.3501
DEBUG - 2015-02-15 18:56:41 --> Config Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Hooks Class Initialized
DEBUG - 2015-02-15 18:56:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 18:56:41 --> Utf8 Class Initialized
DEBUG - 2015-02-15 18:56:41 --> URI Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Router Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Output Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Security Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Input Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 18:56:41 --> Language Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Loader Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: url_helper
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: link_helper
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 18:56:41 --> CI_Session Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Session: Regenerate ID
DEBUG - 2015-02-15 18:56:41 --> CI_Session routines successfully run
DEBUG - 2015-02-15 18:56:41 --> Model Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Model Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Controller Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 18:56:41 --> Email Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: language_helper
DEBUG - 2015-02-15 18:56:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 18:56:41 --> Model Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Database Driver Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: date_helper
DEBUG - 2015-02-15 18:56:41 --> Helper loaded: form_helper
DEBUG - 2015-02-15 18:56:41 --> Form Validation Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Model Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 18:56:41 --> Pagination Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Model Class Initialized
DEBUG - 2015-02-15 18:56:41 --> Model Class Initialized
DEBUG - 2015-02-15 18:56:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 18:56:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 18:56:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 18:56:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 18:56:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 18:56:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 18:56:42 --> Final output sent to browser
DEBUG - 2015-02-15 18:56:42 --> Total execution time: 1.3821
DEBUG - 2015-02-15 19:11:44 --> Config Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Hooks Class Initialized
DEBUG - 2015-02-15 19:11:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 19:11:44 --> Utf8 Class Initialized
DEBUG - 2015-02-15 19:11:44 --> URI Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Router Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Output Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Security Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Input Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 19:11:44 --> Language Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Loader Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: url_helper
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: link_helper
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 19:11:44 --> CI_Session Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Session: Regenerate ID
DEBUG - 2015-02-15 19:11:44 --> CI_Session routines successfully run
DEBUG - 2015-02-15 19:11:44 --> Model Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Model Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Controller Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 19:11:44 --> Email Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: language_helper
DEBUG - 2015-02-15 19:11:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 19:11:44 --> Model Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Database Driver Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: date_helper
DEBUG - 2015-02-15 19:11:44 --> Helper loaded: form_helper
DEBUG - 2015-02-15 19:11:44 --> Form Validation Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Model Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 19:11:44 --> Pagination Class Initialized
DEBUG - 2015-02-15 19:11:44 --> Model Class Initialized
DEBUG - 2015-02-15 19:11:45 --> Model Class Initialized
DEBUG - 2015-02-15 19:11:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 19:11:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 19:11:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 19:11:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 19:11:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 19:11:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 19:11:45 --> Final output sent to browser
DEBUG - 2015-02-15 19:11:45 --> Total execution time: 1.6432
DEBUG - 2015-02-15 19:26:47 --> Config Class Initialized
DEBUG - 2015-02-15 19:26:47 --> Hooks Class Initialized
DEBUG - 2015-02-15 19:26:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 19:26:47 --> Utf8 Class Initialized
DEBUG - 2015-02-15 19:26:47 --> URI Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Router Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Output Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Security Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Input Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 19:26:48 --> Language Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Loader Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: url_helper
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: link_helper
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 19:26:48 --> CI_Session Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Session: Regenerate ID
DEBUG - 2015-02-15 19:26:48 --> CI_Session routines successfully run
DEBUG - 2015-02-15 19:26:48 --> Model Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Model Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Controller Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 19:26:48 --> Email Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: language_helper
DEBUG - 2015-02-15 19:26:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 19:26:48 --> Model Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Database Driver Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: date_helper
DEBUG - 2015-02-15 19:26:48 --> Helper loaded: form_helper
DEBUG - 2015-02-15 19:26:48 --> Form Validation Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Model Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 19:26:48 --> Pagination Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Model Class Initialized
DEBUG - 2015-02-15 19:26:48 --> Model Class Initialized
DEBUG - 2015-02-15 19:26:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 19:26:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 19:26:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 19:26:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 19:26:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 19:26:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 19:26:49 --> Final output sent to browser
DEBUG - 2015-02-15 19:26:49 --> Total execution time: 1.4351
DEBUG - 2015-02-15 19:41:50 --> Config Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Hooks Class Initialized
DEBUG - 2015-02-15 19:41:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 19:41:50 --> Utf8 Class Initialized
DEBUG - 2015-02-15 19:41:50 --> URI Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Router Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Output Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Security Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Input Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 19:41:50 --> Language Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Loader Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: url_helper
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: link_helper
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 19:41:50 --> CI_Session Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Session: Regenerate ID
DEBUG - 2015-02-15 19:41:50 --> CI_Session routines successfully run
DEBUG - 2015-02-15 19:41:50 --> Model Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Model Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Controller Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 19:41:50 --> Email Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: language_helper
DEBUG - 2015-02-15 19:41:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 19:41:50 --> Model Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Database Driver Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: date_helper
DEBUG - 2015-02-15 19:41:50 --> Helper loaded: form_helper
DEBUG - 2015-02-15 19:41:50 --> Form Validation Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Model Class Initialized
DEBUG - 2015-02-15 19:41:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 19:41:50 --> Pagination Class Initialized
DEBUG - 2015-02-15 19:41:51 --> Model Class Initialized
DEBUG - 2015-02-15 19:41:51 --> Model Class Initialized
DEBUG - 2015-02-15 19:41:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 19:41:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 19:41:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 19:41:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 19:41:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 19:41:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 19:41:52 --> Final output sent to browser
DEBUG - 2015-02-15 19:41:52 --> Total execution time: 1.4301
DEBUG - 2015-02-15 19:56:53 --> Config Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Hooks Class Initialized
DEBUG - 2015-02-15 19:56:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 19:56:53 --> Utf8 Class Initialized
DEBUG - 2015-02-15 19:56:53 --> URI Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Router Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Output Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Security Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Input Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 19:56:53 --> Language Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Loader Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: url_helper
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: link_helper
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 19:56:53 --> CI_Session Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Session: Regenerate ID
DEBUG - 2015-02-15 19:56:53 --> CI_Session routines successfully run
DEBUG - 2015-02-15 19:56:53 --> Model Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Model Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Controller Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 19:56:53 --> Email Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: language_helper
DEBUG - 2015-02-15 19:56:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 19:56:53 --> Model Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Database Driver Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: date_helper
DEBUG - 2015-02-15 19:56:53 --> Helper loaded: form_helper
DEBUG - 2015-02-15 19:56:53 --> Form Validation Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Model Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 19:56:53 --> Pagination Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Model Class Initialized
DEBUG - 2015-02-15 19:56:53 --> Model Class Initialized
DEBUG - 2015-02-15 19:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 19:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 19:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 19:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 19:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 19:56:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 19:56:54 --> Final output sent to browser
DEBUG - 2015-02-15 19:56:54 --> Total execution time: 1.3871
DEBUG - 2015-02-15 20:11:56 --> Config Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Hooks Class Initialized
DEBUG - 2015-02-15 20:11:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 20:11:56 --> Utf8 Class Initialized
DEBUG - 2015-02-15 20:11:56 --> URI Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Router Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Output Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Security Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Input Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 20:11:56 --> Language Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Loader Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: url_helper
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: link_helper
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 20:11:56 --> CI_Session Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Session: Regenerate ID
DEBUG - 2015-02-15 20:11:56 --> CI_Session routines successfully run
DEBUG - 2015-02-15 20:11:56 --> Model Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Model Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Controller Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 20:11:56 --> Email Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: language_helper
DEBUG - 2015-02-15 20:11:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 20:11:56 --> Model Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Database Driver Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: date_helper
DEBUG - 2015-02-15 20:11:56 --> Helper loaded: form_helper
DEBUG - 2015-02-15 20:11:56 --> Form Validation Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Model Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 20:11:56 --> Pagination Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Model Class Initialized
DEBUG - 2015-02-15 20:11:56 --> Model Class Initialized
DEBUG - 2015-02-15 20:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 20:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 20:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 20:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 20:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 20:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 20:11:57 --> Final output sent to browser
DEBUG - 2015-02-15 20:11:57 --> Total execution time: 1.4831
DEBUG - 2015-02-15 20:26:58 --> Config Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Hooks Class Initialized
DEBUG - 2015-02-15 20:26:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 20:26:58 --> Utf8 Class Initialized
DEBUG - 2015-02-15 20:26:58 --> URI Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Router Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Output Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Security Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Input Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 20:26:58 --> Language Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Loader Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: url_helper
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: link_helper
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 20:26:58 --> CI_Session Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Session: Regenerate ID
DEBUG - 2015-02-15 20:26:58 --> CI_Session routines successfully run
DEBUG - 2015-02-15 20:26:58 --> Model Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Model Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Controller Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 20:26:58 --> Email Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: language_helper
DEBUG - 2015-02-15 20:26:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 20:26:58 --> Model Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Database Driver Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: date_helper
DEBUG - 2015-02-15 20:26:58 --> Helper loaded: form_helper
DEBUG - 2015-02-15 20:26:58 --> Form Validation Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Model Class Initialized
DEBUG - 2015-02-15 20:26:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 20:26:58 --> Pagination Class Initialized
DEBUG - 2015-02-15 20:26:59 --> Model Class Initialized
DEBUG - 2015-02-15 20:26:59 --> Model Class Initialized
DEBUG - 2015-02-15 20:26:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 20:26:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 20:26:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 20:26:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 20:27:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 20:27:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 20:27:00 --> Final output sent to browser
DEBUG - 2015-02-15 20:27:00 --> Total execution time: 1.4811
DEBUG - 2015-02-15 20:42:02 --> Config Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Hooks Class Initialized
DEBUG - 2015-02-15 20:42:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 20:42:02 --> Utf8 Class Initialized
DEBUG - 2015-02-15 20:42:02 --> URI Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Router Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Output Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Security Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Input Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 20:42:02 --> Language Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Loader Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: url_helper
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: link_helper
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 20:42:02 --> CI_Session Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Session: Regenerate ID
DEBUG - 2015-02-15 20:42:02 --> CI_Session routines successfully run
DEBUG - 2015-02-15 20:42:02 --> Model Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Model Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Controller Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 20:42:02 --> Email Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: language_helper
DEBUG - 2015-02-15 20:42:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 20:42:02 --> Model Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Database Driver Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: date_helper
DEBUG - 2015-02-15 20:42:02 --> Helper loaded: form_helper
DEBUG - 2015-02-15 20:42:02 --> Form Validation Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Model Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 20:42:02 --> Pagination Class Initialized
DEBUG - 2015-02-15 20:42:02 --> Model Class Initialized
DEBUG - 2015-02-15 20:42:03 --> Model Class Initialized
DEBUG - 2015-02-15 20:42:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 20:42:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 20:42:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 20:42:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 20:42:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 20:42:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 20:42:03 --> Final output sent to browser
DEBUG - 2015-02-15 20:42:03 --> Total execution time: 1.3841
DEBUG - 2015-02-15 20:57:05 --> Config Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Hooks Class Initialized
DEBUG - 2015-02-15 20:57:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 20:57:05 --> Utf8 Class Initialized
DEBUG - 2015-02-15 20:57:05 --> URI Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Router Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Output Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Security Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Input Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 20:57:05 --> Language Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Loader Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 20:57:05 --> Helper loaded: url_helper
DEBUG - 2015-02-15 20:57:05 --> Helper loaded: link_helper
DEBUG - 2015-02-15 20:57:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 20:57:05 --> CI_Session Class Initialized
DEBUG - 2015-02-15 20:57:05 --> Session: Regenerate ID
DEBUG - 2015-02-15 20:57:05 --> CI_Session routines successfully run
DEBUG - 2015-02-15 20:57:06 --> Model Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Model Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Controller Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 20:57:06 --> Email Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 20:57:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 20:57:06 --> Helper loaded: language_helper
DEBUG - 2015-02-15 20:57:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 20:57:06 --> Model Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Database Driver Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Helper loaded: date_helper
DEBUG - 2015-02-15 20:57:06 --> Helper loaded: form_helper
DEBUG - 2015-02-15 20:57:06 --> Form Validation Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Model Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 20:57:06 --> Pagination Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Model Class Initialized
DEBUG - 2015-02-15 20:57:06 --> Model Class Initialized
DEBUG - 2015-02-15 20:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 20:57:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 20:57:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 20:57:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 20:57:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 20:57:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 20:57:07 --> Final output sent to browser
DEBUG - 2015-02-15 20:57:07 --> Total execution time: 1.3851
DEBUG - 2015-02-15 21:12:09 --> Config Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Hooks Class Initialized
DEBUG - 2015-02-15 21:12:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 21:12:09 --> Utf8 Class Initialized
DEBUG - 2015-02-15 21:12:09 --> URI Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Router Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Output Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Security Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Input Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 21:12:09 --> Language Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Loader Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: url_helper
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: link_helper
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 21:12:09 --> CI_Session Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Session: Regenerate ID
DEBUG - 2015-02-15 21:12:09 --> CI_Session routines successfully run
DEBUG - 2015-02-15 21:12:09 --> Model Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Model Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Controller Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 21:12:09 --> Email Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: language_helper
DEBUG - 2015-02-15 21:12:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 21:12:09 --> Model Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Database Driver Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: date_helper
DEBUG - 2015-02-15 21:12:09 --> Helper loaded: form_helper
DEBUG - 2015-02-15 21:12:09 --> Form Validation Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Model Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 21:12:09 --> Pagination Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Model Class Initialized
DEBUG - 2015-02-15 21:12:09 --> Model Class Initialized
DEBUG - 2015-02-15 21:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 21:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 21:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 21:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 21:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 21:12:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 21:12:10 --> Final output sent to browser
DEBUG - 2015-02-15 21:12:10 --> Total execution time: 1.3621
DEBUG - 2015-02-15 21:27:12 --> Config Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Hooks Class Initialized
DEBUG - 2015-02-15 21:27:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 21:27:12 --> Utf8 Class Initialized
DEBUG - 2015-02-15 21:27:12 --> URI Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Router Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Output Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Security Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Input Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 21:27:12 --> Language Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Loader Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: url_helper
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: link_helper
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 21:27:12 --> CI_Session Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Session: Regenerate ID
DEBUG - 2015-02-15 21:27:12 --> CI_Session routines successfully run
DEBUG - 2015-02-15 21:27:12 --> Model Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Model Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Controller Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 21:27:12 --> Email Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: language_helper
DEBUG - 2015-02-15 21:27:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 21:27:12 --> Model Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Database Driver Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: date_helper
DEBUG - 2015-02-15 21:27:12 --> Helper loaded: form_helper
DEBUG - 2015-02-15 21:27:12 --> Form Validation Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Model Class Initialized
DEBUG - 2015-02-15 21:27:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 21:27:12 --> Pagination Class Initialized
DEBUG - 2015-02-15 21:27:13 --> Model Class Initialized
DEBUG - 2015-02-15 21:27:13 --> Model Class Initialized
DEBUG - 2015-02-15 21:27:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 21:27:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 21:27:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 21:27:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 21:27:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 21:27:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 21:27:13 --> Final output sent to browser
DEBUG - 2015-02-15 21:27:13 --> Total execution time: 1.3371
DEBUG - 2015-02-15 21:42:14 --> Config Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Hooks Class Initialized
DEBUG - 2015-02-15 21:42:14 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 21:42:14 --> Utf8 Class Initialized
DEBUG - 2015-02-15 21:42:14 --> URI Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Router Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Output Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Security Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Input Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 21:42:14 --> Language Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Loader Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: url_helper
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: link_helper
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 21:42:14 --> CI_Session Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Session: Regenerate ID
DEBUG - 2015-02-15 21:42:14 --> CI_Session routines successfully run
DEBUG - 2015-02-15 21:42:14 --> Model Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Model Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Controller Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 21:42:14 --> Email Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: language_helper
DEBUG - 2015-02-15 21:42:14 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 21:42:14 --> Model Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Database Driver Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: date_helper
DEBUG - 2015-02-15 21:42:14 --> Helper loaded: form_helper
DEBUG - 2015-02-15 21:42:14 --> Form Validation Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Model Class Initialized
DEBUG - 2015-02-15 21:42:14 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 21:42:14 --> Pagination Class Initialized
DEBUG - 2015-02-15 21:42:15 --> Model Class Initialized
DEBUG - 2015-02-15 21:42:15 --> Model Class Initialized
DEBUG - 2015-02-15 21:42:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 21:42:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 21:42:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 21:42:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 21:42:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 21:42:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 21:42:16 --> Final output sent to browser
DEBUG - 2015-02-15 21:42:16 --> Total execution time: 1.3560
DEBUG - 2015-02-15 21:57:17 --> Config Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Hooks Class Initialized
DEBUG - 2015-02-15 21:57:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 21:57:17 --> Utf8 Class Initialized
DEBUG - 2015-02-15 21:57:17 --> URI Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Router Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Output Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Security Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Input Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 21:57:17 --> Language Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Loader Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: url_helper
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: link_helper
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 21:57:17 --> CI_Session Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Session: Regenerate ID
DEBUG - 2015-02-15 21:57:17 --> CI_Session routines successfully run
DEBUG - 2015-02-15 21:57:17 --> Model Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Model Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Controller Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 21:57:17 --> Email Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: language_helper
DEBUG - 2015-02-15 21:57:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 21:57:17 --> Model Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Database Driver Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: date_helper
DEBUG - 2015-02-15 21:57:17 --> Helper loaded: form_helper
DEBUG - 2015-02-15 21:57:17 --> Form Validation Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Model Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 21:57:17 --> Pagination Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Model Class Initialized
DEBUG - 2015-02-15 21:57:17 --> Model Class Initialized
DEBUG - 2015-02-15 21:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 21:57:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 21:57:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 21:57:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 21:57:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 21:57:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 21:57:18 --> Final output sent to browser
DEBUG - 2015-02-15 21:57:18 --> Total execution time: 1.3491
DEBUG - 2015-02-15 22:12:19 --> Config Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Hooks Class Initialized
DEBUG - 2015-02-15 22:12:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 22:12:19 --> Utf8 Class Initialized
DEBUG - 2015-02-15 22:12:19 --> URI Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Router Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Output Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Security Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Input Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 22:12:19 --> Language Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Loader Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: url_helper
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: link_helper
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 22:12:19 --> CI_Session Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Session: Regenerate ID
DEBUG - 2015-02-15 22:12:19 --> CI_Session routines successfully run
DEBUG - 2015-02-15 22:12:19 --> Model Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Model Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Controller Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 22:12:19 --> Email Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: language_helper
DEBUG - 2015-02-15 22:12:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 22:12:19 --> Model Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Database Driver Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: date_helper
DEBUG - 2015-02-15 22:12:19 --> Helper loaded: form_helper
DEBUG - 2015-02-15 22:12:19 --> Form Validation Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Model Class Initialized
DEBUG - 2015-02-15 22:12:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 22:12:19 --> Pagination Class Initialized
DEBUG - 2015-02-15 22:12:20 --> Model Class Initialized
DEBUG - 2015-02-15 22:12:20 --> Model Class Initialized
DEBUG - 2015-02-15 22:12:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 22:12:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 22:12:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 22:12:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 22:12:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 22:12:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 22:12:20 --> Final output sent to browser
DEBUG - 2015-02-15 22:12:20 --> Total execution time: 1.4251
DEBUG - 2015-02-15 22:27:22 --> Config Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Hooks Class Initialized
DEBUG - 2015-02-15 22:27:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 22:27:22 --> Utf8 Class Initialized
DEBUG - 2015-02-15 22:27:22 --> URI Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Router Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Output Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Security Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Input Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 22:27:22 --> Language Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Loader Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: url_helper
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: link_helper
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 22:27:22 --> CI_Session Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Session: Regenerate ID
DEBUG - 2015-02-15 22:27:22 --> CI_Session routines successfully run
DEBUG - 2015-02-15 22:27:22 --> Model Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Model Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Controller Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 22:27:22 --> Email Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: language_helper
DEBUG - 2015-02-15 22:27:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 22:27:22 --> Model Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Database Driver Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: date_helper
DEBUG - 2015-02-15 22:27:22 --> Helper loaded: form_helper
DEBUG - 2015-02-15 22:27:22 --> Form Validation Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Model Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 22:27:22 --> Pagination Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Model Class Initialized
DEBUG - 2015-02-15 22:27:22 --> Model Class Initialized
DEBUG - 2015-02-15 22:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 22:27:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 22:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 22:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 22:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 22:27:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 22:27:23 --> Final output sent to browser
DEBUG - 2015-02-15 22:27:23 --> Total execution time: 1.4021
DEBUG - 2015-02-15 22:42:24 --> Config Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Hooks Class Initialized
DEBUG - 2015-02-15 22:42:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 22:42:24 --> Utf8 Class Initialized
DEBUG - 2015-02-15 22:42:24 --> URI Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Router Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Output Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Security Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Input Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 22:42:24 --> Language Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Loader Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 22:42:24 --> Helper loaded: url_helper
DEBUG - 2015-02-15 22:42:24 --> Helper loaded: link_helper
DEBUG - 2015-02-15 22:42:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 22:42:24 --> CI_Session Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Session: Regenerate ID
DEBUG - 2015-02-15 22:42:24 --> CI_Session routines successfully run
DEBUG - 2015-02-15 22:42:24 --> Model Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Model Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Controller Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 22:42:24 --> Email Class Initialized
DEBUG - 2015-02-15 22:42:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 22:42:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 22:42:24 --> Helper loaded: language_helper
DEBUG - 2015-02-15 22:42:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 22:42:24 --> Model Class Initialized
DEBUG - 2015-02-15 22:42:25 --> Database Driver Class Initialized
DEBUG - 2015-02-15 22:42:25 --> Helper loaded: date_helper
DEBUG - 2015-02-15 22:42:25 --> Helper loaded: form_helper
DEBUG - 2015-02-15 22:42:25 --> Form Validation Class Initialized
DEBUG - 2015-02-15 22:42:25 --> Model Class Initialized
DEBUG - 2015-02-15 22:42:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 22:42:25 --> Pagination Class Initialized
DEBUG - 2015-02-15 22:42:25 --> Model Class Initialized
DEBUG - 2015-02-15 22:42:25 --> Model Class Initialized
DEBUG - 2015-02-15 22:42:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 22:42:25 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 22:42:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 22:42:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 22:42:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 22:42:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 22:42:26 --> Final output sent to browser
DEBUG - 2015-02-15 22:42:26 --> Total execution time: 1.5822
DEBUG - 2015-02-15 22:57:31 --> Config Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Hooks Class Initialized
DEBUG - 2015-02-15 22:57:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 22:57:31 --> Utf8 Class Initialized
DEBUG - 2015-02-15 22:57:31 --> URI Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Router Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Output Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Security Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Input Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 22:57:31 --> Language Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Loader Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: url_helper
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: link_helper
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 22:57:31 --> CI_Session Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Session: Regenerate ID
DEBUG - 2015-02-15 22:57:31 --> CI_Session routines successfully run
DEBUG - 2015-02-15 22:57:31 --> Model Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Model Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Controller Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 22:57:31 --> Email Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: language_helper
DEBUG - 2015-02-15 22:57:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 22:57:31 --> Model Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Database Driver Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: date_helper
DEBUG - 2015-02-15 22:57:31 --> Helper loaded: form_helper
DEBUG - 2015-02-15 22:57:31 --> Form Validation Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Model Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 22:57:31 --> Pagination Class Initialized
DEBUG - 2015-02-15 22:57:31 --> Model Class Initialized
DEBUG - 2015-02-15 22:57:32 --> Model Class Initialized
DEBUG - 2015-02-15 22:57:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 22:57:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 22:57:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 22:57:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 22:57:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 22:57:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 22:57:32 --> Final output sent to browser
DEBUG - 2015-02-15 22:57:32 --> Total execution time: 1.3481
DEBUG - 2015-02-15 23:12:33 --> Config Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Hooks Class Initialized
DEBUG - 2015-02-15 23:12:33 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 23:12:33 --> Utf8 Class Initialized
DEBUG - 2015-02-15 23:12:33 --> URI Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Router Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Output Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Security Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Input Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 23:12:33 --> Language Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Loader Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 23:12:33 --> Helper loaded: url_helper
DEBUG - 2015-02-15 23:12:33 --> Helper loaded: link_helper
DEBUG - 2015-02-15 23:12:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 23:12:33 --> CI_Session Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Session: Regenerate ID
DEBUG - 2015-02-15 23:12:33 --> CI_Session routines successfully run
DEBUG - 2015-02-15 23:12:33 --> Model Class Initialized
DEBUG - 2015-02-15 23:12:33 --> Model Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Controller Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 23:12:34 --> Email Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 23:12:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 23:12:34 --> Helper loaded: language_helper
DEBUG - 2015-02-15 23:12:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 23:12:34 --> Model Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Database Driver Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Helper loaded: date_helper
DEBUG - 2015-02-15 23:12:34 --> Helper loaded: form_helper
DEBUG - 2015-02-15 23:12:34 --> Form Validation Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Model Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 23:12:34 --> Pagination Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Model Class Initialized
DEBUG - 2015-02-15 23:12:34 --> Model Class Initialized
DEBUG - 2015-02-15 23:12:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 23:12:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 23:12:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 23:12:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 23:12:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 23:12:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 23:12:35 --> Final output sent to browser
DEBUG - 2015-02-15 23:12:35 --> Total execution time: 1.4121
DEBUG - 2015-02-15 23:27:37 --> Config Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Hooks Class Initialized
DEBUG - 2015-02-15 23:27:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 23:27:37 --> Utf8 Class Initialized
DEBUG - 2015-02-15 23:27:37 --> URI Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Router Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Output Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Security Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Input Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 23:27:37 --> Language Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Loader Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: url_helper
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: link_helper
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 23:27:37 --> CI_Session Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Session: Regenerate ID
DEBUG - 2015-02-15 23:27:37 --> CI_Session routines successfully run
DEBUG - 2015-02-15 23:27:37 --> Model Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Model Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Controller Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 23:27:37 --> Email Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: language_helper
DEBUG - 2015-02-15 23:27:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 23:27:37 --> Model Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Database Driver Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: date_helper
DEBUG - 2015-02-15 23:27:37 --> Helper loaded: form_helper
DEBUG - 2015-02-15 23:27:37 --> Form Validation Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Model Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 23:27:37 --> Pagination Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Model Class Initialized
DEBUG - 2015-02-15 23:27:37 --> Model Class Initialized
DEBUG - 2015-02-15 23:27:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 23:27:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 23:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 23:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 23:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 23:27:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 23:27:38 --> Final output sent to browser
DEBUG - 2015-02-15 23:27:38 --> Total execution time: 1.3481
DEBUG - 2015-02-15 23:42:40 --> Config Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Hooks Class Initialized
DEBUG - 2015-02-15 23:42:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 23:42:40 --> Utf8 Class Initialized
DEBUG - 2015-02-15 23:42:40 --> URI Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Router Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Output Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Security Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Input Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 23:42:40 --> Language Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Loader Class Initialized
DEBUG - 2015-02-15 23:42:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 23:42:40 --> Helper loaded: url_helper
DEBUG - 2015-02-15 23:42:40 --> Helper loaded: link_helper
DEBUG - 2015-02-15 23:42:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 23:42:40 --> CI_Session Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Session: Regenerate ID
DEBUG - 2015-02-15 23:42:41 --> CI_Session routines successfully run
DEBUG - 2015-02-15 23:42:41 --> Model Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Model Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Controller Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 23:42:41 --> Email Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 23:42:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 23:42:41 --> Helper loaded: language_helper
DEBUG - 2015-02-15 23:42:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 23:42:41 --> Model Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Database Driver Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Helper loaded: date_helper
DEBUG - 2015-02-15 23:42:41 --> Helper loaded: form_helper
DEBUG - 2015-02-15 23:42:41 --> Form Validation Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Model Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 23:42:41 --> Pagination Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Model Class Initialized
DEBUG - 2015-02-15 23:42:41 --> Model Class Initialized
DEBUG - 2015-02-15 23:42:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 23:42:41 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 23:42:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 23:42:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 23:42:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 23:42:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 23:42:42 --> Final output sent to browser
DEBUG - 2015-02-15 23:42:42 --> Total execution time: 1.6212
DEBUG - 2015-02-15 23:57:44 --> Config Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Hooks Class Initialized
DEBUG - 2015-02-15 23:57:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 23:57:44 --> Utf8 Class Initialized
DEBUG - 2015-02-15 23:57:44 --> URI Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Router Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Output Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Security Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Input Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 23:57:44 --> Language Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Loader Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: url_helper
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: link_helper
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-15 23:57:44 --> CI_Session Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Session: Regenerate ID
DEBUG - 2015-02-15 23:57:44 --> CI_Session routines successfully run
DEBUG - 2015-02-15 23:57:44 --> Model Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Model Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Controller Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-15 23:57:44 --> Email Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: language_helper
DEBUG - 2015-02-15 23:57:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-15 23:57:44 --> Model Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Database Driver Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: date_helper
DEBUG - 2015-02-15 23:57:44 --> Helper loaded: form_helper
DEBUG - 2015-02-15 23:57:44 --> Form Validation Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Model Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-15 23:57:44 --> Pagination Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Model Class Initialized
DEBUG - 2015-02-15 23:57:44 --> Model Class Initialized
DEBUG - 2015-02-15 23:57:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-15 23:57:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-15 23:57:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-15 23:57:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-15 23:57:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-15 23:57:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-15 23:57:45 --> Final output sent to browser
DEBUG - 2015-02-15 23:57:45 --> Total execution time: 1.3821
