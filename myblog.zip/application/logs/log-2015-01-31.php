<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-31 03:19:54 --> Config Class Initialized
DEBUG - 2015-01-31 03:19:54 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:19:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:19:55 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:19:55 --> URI Class Initialized
DEBUG - 2015-01-31 03:19:55 --> Router Class Initialized
DEBUG - 2015-01-31 03:19:55 --> Output Class Initialized
DEBUG - 2015-01-31 03:19:55 --> Security Class Initialized
DEBUG - 2015-01-31 03:19:55 --> Input Class Initialized
DEBUG - 2015-01-31 03:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:19:55 --> Language Class Initialized
DEBUG - 2015-01-31 03:19:56 --> Loader Class Initialized
DEBUG - 2015-01-31 03:19:56 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:19:56 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:19:56 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:19:56 --> A session cookie was not found.
DEBUG - 2015-01-31 03:19:57 --> Session: Creating new session (011577ab19eab956a903ff636feb01fe)
DEBUG - 2015-01-31 03:19:57 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:19:59 --> Model Class Initialized
DEBUG - 2015-01-31 03:19:59 --> Model Class Initialized
DEBUG - 2015-01-31 03:19:59 --> Controller Class Initialized
DEBUG - 2015-01-31 03:19:59 --> Model Class Initialized
DEBUG - 2015-01-31 03:19:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:19:59 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:20:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:20:00 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:20:00 --> Final output sent to browser
DEBUG - 2015-01-31 03:20:00 --> Total execution time: 5.9493
DEBUG - 2015-01-31 03:20:01 --> Config Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:20:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:20:01 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:20:01 --> URI Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Router Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Output Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Security Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Input Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:20:01 --> Language Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Loader Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:20:01 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:20:01 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:20:01 --> A session cookie was not found.
DEBUG - 2015-01-31 03:20:01 --> Session: Creating new session (86b1b1e780f48c80f5d91002fcaf3511)
DEBUG - 2015-01-31 03:20:01 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:20:01 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Controller Class Initialized
DEBUG - 2015-01-31 03:20:01 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:20:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:20:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:20:01 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:20:01 --> Final output sent to browser
DEBUG - 2015-01-31 03:20:01 --> Total execution time: 0.3530
DEBUG - 2015-01-31 03:20:23 --> Config Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:20:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:20:23 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:20:23 --> URI Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Router Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Output Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Security Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Input Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:20:23 --> Language Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Loader Class Initialized
DEBUG - 2015-01-31 03:20:23 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:20:23 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:20:23 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:20:23 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:20:24 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:24 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:24 --> Controller Class Initialized
DEBUG - 2015-01-31 03:20:24 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:20:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:20:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:20:24 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:20:24 --> Final output sent to browser
DEBUG - 2015-01-31 03:20:24 --> Total execution time: 0.8370
DEBUG - 2015-01-31 03:20:26 --> Config Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:20:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:20:26 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:20:26 --> URI Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Router Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Output Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Security Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Input Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:20:26 --> Language Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Loader Class Initialized
DEBUG - 2015-01-31 03:20:26 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:20:26 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:20:26 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:20:26 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:20:27 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:27 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:27 --> Controller Class Initialized
DEBUG - 2015-01-31 03:20:27 --> Model Class Initialized
DEBUG - 2015-01-31 03:20:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:20:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:20:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:20:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:20:27 --> Final output sent to browser
DEBUG - 2015-01-31 03:20:27 --> Total execution time: 1.1431
DEBUG - 2015-01-31 03:25:10 --> Config Class Initialized
DEBUG - 2015-01-31 03:25:10 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:25:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:25:11 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:25:11 --> URI Class Initialized
DEBUG - 2015-01-31 03:25:11 --> Router Class Initialized
DEBUG - 2015-01-31 03:25:11 --> Output Class Initialized
DEBUG - 2015-01-31 03:25:11 --> Security Class Initialized
DEBUG - 2015-01-31 03:25:11 --> Input Class Initialized
DEBUG - 2015-01-31 03:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:25:11 --> Language Class Initialized
DEBUG - 2015-01-31 03:25:12 --> Loader Class Initialized
DEBUG - 2015-01-31 03:25:12 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:25:12 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:25:12 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:25:12 --> Session: Regenerate ID
DEBUG - 2015-01-31 03:25:12 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:25:15 --> Model Class Initialized
DEBUG - 2015-01-31 03:25:15 --> Model Class Initialized
DEBUG - 2015-01-31 03:25:15 --> Controller Class Initialized
DEBUG - 2015-01-31 03:25:15 --> Model Class Initialized
DEBUG - 2015-01-31 03:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:25:15 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:25:15 --> Final output sent to browser
DEBUG - 2015-01-31 03:25:15 --> Total execution time: 5.1873
DEBUG - 2015-01-31 03:26:30 --> Config Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:26:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:26:30 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:26:30 --> URI Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Router Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Output Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Security Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Input Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:26:30 --> Language Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Loader Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:26:30 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:26:30 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:26:30 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:26:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Controller Class Initialized
DEBUG - 2015-01-31 03:26:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:26:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:26:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:26:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:26:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:26:30 --> Final output sent to browser
DEBUG - 2015-01-31 03:26:30 --> Total execution time: 0.4470
DEBUG - 2015-01-31 03:29:13 --> Config Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:29:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:29:13 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:29:13 --> URI Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Router Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Output Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Security Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Input Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:29:13 --> Language Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Loader Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:29:13 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:29:13 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:29:13 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:29:13 --> Model Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Model Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Controller Class Initialized
DEBUG - 2015-01-31 03:29:13 --> Model Class Initialized
DEBUG - 2015-01-31 03:29:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:29:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:29:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:29:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:29:13 --> Final output sent to browser
DEBUG - 2015-01-31 03:29:13 --> Total execution time: 0.3970
DEBUG - 2015-01-31 03:31:01 --> Config Class Initialized
DEBUG - 2015-01-31 03:31:01 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:31:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:31:01 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:31:01 --> URI Class Initialized
DEBUG - 2015-01-31 03:31:01 --> Router Class Initialized
DEBUG - 2015-01-31 03:31:01 --> Output Class Initialized
DEBUG - 2015-01-31 03:31:01 --> Security Class Initialized
DEBUG - 2015-01-31 03:31:01 --> Input Class Initialized
DEBUG - 2015-01-31 03:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:31:01 --> Language Class Initialized
DEBUG - 2015-01-31 03:31:02 --> Loader Class Initialized
DEBUG - 2015-01-31 03:31:02 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:31:02 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:31:02 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:31:02 --> Session: Regenerate ID
DEBUG - 2015-01-31 03:31:02 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:31:02 --> Model Class Initialized
DEBUG - 2015-01-31 03:31:02 --> Model Class Initialized
DEBUG - 2015-01-31 03:31:02 --> Controller Class Initialized
DEBUG - 2015-01-31 03:31:02 --> Model Class Initialized
DEBUG - 2015-01-31 03:31:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:31:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:31:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:31:02 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:31:02 --> Final output sent to browser
DEBUG - 2015-01-31 03:31:02 --> Total execution time: 0.3920
DEBUG - 2015-01-31 03:31:36 --> Config Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:31:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:31:36 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:31:36 --> URI Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Router Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Output Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Security Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Input Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:31:36 --> Language Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Loader Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:31:36 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:31:36 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:31:36 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:31:36 --> Model Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Model Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Controller Class Initialized
DEBUG - 2015-01-31 03:31:36 --> Model Class Initialized
DEBUG - 2015-01-31 03:31:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:31:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:31:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:31:36 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:31:36 --> Final output sent to browser
DEBUG - 2015-01-31 03:31:36 --> Total execution time: 0.3020
DEBUG - 2015-01-31 03:32:27 --> Config Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:32:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:32:27 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:32:27 --> URI Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Router Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Output Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Security Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Input Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:32:27 --> Language Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Loader Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:32:27 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:32:27 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:32:27 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:32:27 --> Model Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Model Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Controller Class Initialized
DEBUG - 2015-01-31 03:32:27 --> Model Class Initialized
DEBUG - 2015-01-31 03:32:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:32:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:32:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:32:27 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:32:27 --> Final output sent to browser
DEBUG - 2015-01-31 03:32:27 --> Total execution time: 0.4670
DEBUG - 2015-01-31 03:32:56 --> Config Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:32:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:32:56 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:32:56 --> URI Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Router Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Output Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Security Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Input Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:32:56 --> Language Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Loader Class Initialized
DEBUG - 2015-01-31 03:32:56 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:32:56 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:32:56 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:32:56 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:32:57 --> Model Class Initialized
DEBUG - 2015-01-31 03:32:57 --> Model Class Initialized
DEBUG - 2015-01-31 03:32:57 --> Controller Class Initialized
DEBUG - 2015-01-31 03:32:57 --> Model Class Initialized
DEBUG - 2015-01-31 03:32:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:32:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:32:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:32:57 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:32:57 --> Final output sent to browser
DEBUG - 2015-01-31 03:32:57 --> Total execution time: 0.3240
DEBUG - 2015-01-31 03:36:17 --> Config Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:36:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:36:17 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:36:17 --> URI Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Router Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Output Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Security Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Input Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:36:17 --> Language Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Loader Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:36:17 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:36:17 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Session: Regenerate ID
DEBUG - 2015-01-31 03:36:17 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:36:17 --> Model Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Model Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Controller Class Initialized
DEBUG - 2015-01-31 03:36:17 --> Model Class Initialized
DEBUG - 2015-01-31 03:36:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:36:18 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
ERROR - 2015-01-31 03:36:18 --> Severity: Error --> Call to undefined function dv() C:\xampp\htdocs\myblog\application\controllers\admin\Articles.php 24
DEBUG - 2015-01-31 03:36:51 --> Config Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:36:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:36:51 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:36:51 --> URI Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Router Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Output Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Security Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Input Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:36:51 --> Language Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Loader Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:36:51 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:36:51 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:36:51 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:36:51 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:36:51 --> Model Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Model Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Controller Class Initialized
DEBUG - 2015-01-31 03:36:51 --> Model Class Initialized
DEBUG - 2015-01-31 03:36:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:36:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:36:51 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:38:25 --> Config Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:38:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:38:25 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:38:25 --> URI Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Router Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Output Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Security Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Input Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:38:25 --> Language Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Loader Class Initialized
DEBUG - 2015-01-31 03:38:25 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:38:25 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:38:25 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:38:25 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:38:25 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:38:26 --> Model Class Initialized
DEBUG - 2015-01-31 03:38:26 --> Model Class Initialized
DEBUG - 2015-01-31 03:38:26 --> Controller Class Initialized
DEBUG - 2015-01-31 03:38:26 --> Model Class Initialized
DEBUG - 2015-01-31 03:38:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:38:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:38:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:38:26 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:38:26 --> Final output sent to browser
DEBUG - 2015-01-31 03:38:26 --> Total execution time: 0.4040
DEBUG - 2015-01-31 03:38:55 --> Config Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:38:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:38:55 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:38:55 --> URI Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Router Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Output Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Security Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Input Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:38:55 --> Language Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Loader Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:38:55 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:38:55 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:38:55 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:38:55 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:38:55 --> Model Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Model Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Controller Class Initialized
DEBUG - 2015-01-31 03:38:55 --> Model Class Initialized
DEBUG - 2015-01-31 03:38:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:38:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:38:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:40:43 --> Config Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:40:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:40:43 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:40:43 --> URI Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Router Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Output Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Security Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Input Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:40:43 --> Language Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Loader Class Initialized
DEBUG - 2015-01-31 03:40:43 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:40:43 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:40:43 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:40:43 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:40:43 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:40:44 --> Model Class Initialized
DEBUG - 2015-01-31 03:40:44 --> Model Class Initialized
DEBUG - 2015-01-31 03:40:44 --> Controller Class Initialized
DEBUG - 2015-01-31 03:40:44 --> Model Class Initialized
DEBUG - 2015-01-31 03:40:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:40:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:40:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:40:44 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:40:44 --> Final output sent to browser
DEBUG - 2015-01-31 03:40:44 --> Total execution time: 0.9181
DEBUG - 2015-01-31 03:40:55 --> Config Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:40:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:40:55 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:40:55 --> URI Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Router Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Output Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Security Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Input Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:40:55 --> Language Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Loader Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:40:55 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:40:55 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:40:55 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:40:55 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:40:55 --> Model Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Model Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Controller Class Initialized
DEBUG - 2015-01-31 03:40:55 --> Model Class Initialized
DEBUG - 2015-01-31 03:40:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:40:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:40:55 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:49:41 --> Config Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:49:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:49:41 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:49:41 --> URI Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Router Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Output Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Security Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Input Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:49:41 --> Language Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Loader Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:49:41 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:49:41 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:49:41 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Session: Regenerate ID
DEBUG - 2015-01-31 03:49:41 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:49:41 --> Model Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Model Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Controller Class Initialized
DEBUG - 2015-01-31 03:49:41 --> Model Class Initialized
DEBUG - 2015-01-31 03:49:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:49:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:49:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
ERROR - 2015-01-31 03:49:42 --> Severity: Error --> Class 'Date' not found C:\xampp\htdocs\myblog\application\models\Article_model.php 55
DEBUG - 2015-01-31 03:51:30 --> Config Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:51:30 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:51:30 --> URI Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Router Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Output Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Security Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Input Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:51:30 --> Language Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Loader Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:51:30 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:51:30 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:51:30 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:51:30 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:51:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Controller Class Initialized
DEBUG - 2015-01-31 03:51:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:51:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:51:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:51:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:51:31 --> Config Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:51:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:51:31 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:51:31 --> URI Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Router Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Output Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Security Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Input Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:51:31 --> Language Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Loader Class Initialized
DEBUG - 2015-01-31 03:51:31 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:51:31 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:51:31 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:51:31 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:51:31 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:51:32 --> Model Class Initialized
DEBUG - 2015-01-31 03:51:32 --> Model Class Initialized
DEBUG - 2015-01-31 03:51:32 --> Controller Class Initialized
DEBUG - 2015-01-31 03:51:32 --> Model Class Initialized
DEBUG - 2015-01-31 03:51:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:51:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-01-31 03:51:32 --> Severity: Error --> Call to undefined method Entity\Articles::getUsername() C:\xampp\htdocs\myblog\application\views\admin\article\index.php 29
DEBUG - 2015-01-31 03:52:30 --> Config Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Hooks Class Initialized
DEBUG - 2015-01-31 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 03:52:30 --> Utf8 Class Initialized
DEBUG - 2015-01-31 03:52:30 --> URI Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Router Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Output Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Security Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Input Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 03:52:30 --> Language Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Loader Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Helper loaded: url_helper
DEBUG - 2015-01-31 03:52:30 --> Helper loaded: link_helper
DEBUG - 2015-01-31 03:52:30 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 03:52:30 --> CI_Session Class Initialized
DEBUG - 2015-01-31 03:52:30 --> CI_Session routines successfully run
DEBUG - 2015-01-31 03:52:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Controller Class Initialized
DEBUG - 2015-01-31 03:52:30 --> Model Class Initialized
DEBUG - 2015-01-31 03:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 03:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 03:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 03:52:30 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 03:52:30 --> Final output sent to browser
DEBUG - 2015-01-31 03:52:30 --> Total execution time: 0.4060
DEBUG - 2015-01-31 05:40:51 --> Config Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:40:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:40:51 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:40:51 --> URI Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Router Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Output Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Security Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Input Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:40:51 --> Language Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Loader Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:40:51 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:40:51 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:40:51 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:40:51 --> Session: Regenerate ID
DEBUG - 2015-01-31 05:40:51 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:40:51 --> Model Class Initialized
DEBUG - 2015-01-31 05:40:52 --> Model Class Initialized
DEBUG - 2015-01-31 05:40:52 --> Controller Class Initialized
DEBUG - 2015-01-31 05:40:52 --> Model Class Initialized
DEBUG - 2015-01-31 05:40:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:40:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:40:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:40:52 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:40:52 --> Final output sent to browser
DEBUG - 2015-01-31 05:40:52 --> Total execution time: 0.7210
DEBUG - 2015-01-31 05:43:21 --> Config Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:43:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:43:21 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:43:21 --> URI Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Router Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Output Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Security Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Input Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:43:21 --> Language Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Loader Class Initialized
DEBUG - 2015-01-31 05:43:21 --> Helper loaded: url_helper
ERROR - 2015-01-31 05:43:21 --> Severity: Notice --> Constant RS already defined C:\xampp\htdocs\myblog\application\helpers\link_helper.php 3
DEBUG - 2015-01-31 05:43:21 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:43:21 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:43:21 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:43:21 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:43:22 --> Model Class Initialized
DEBUG - 2015-01-31 05:43:22 --> Model Class Initialized
DEBUG - 2015-01-31 05:43:22 --> Controller Class Initialized
DEBUG - 2015-01-31 05:43:22 --> Model Class Initialized
DEBUG - 2015-01-31 05:43:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:43:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:43:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:43:22 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:43:22 --> Final output sent to browser
DEBUG - 2015-01-31 05:43:22 --> Total execution time: 0.9261
DEBUG - 2015-01-31 05:43:46 --> Config Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:43:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:43:46 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:43:46 --> URI Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Router Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Output Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Security Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Input Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:43:46 --> Language Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Loader Class Initialized
DEBUG - 2015-01-31 05:43:46 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:43:46 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:43:46 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:43:46 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:43:46 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:43:47 --> Model Class Initialized
DEBUG - 2015-01-31 05:43:47 --> Model Class Initialized
DEBUG - 2015-01-31 05:43:47 --> Controller Class Initialized
DEBUG - 2015-01-31 05:43:47 --> Model Class Initialized
DEBUG - 2015-01-31 05:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:43:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:43:47 --> Final output sent to browser
DEBUG - 2015-01-31 05:43:47 --> Total execution time: 0.4280
DEBUG - 2015-01-31 05:44:20 --> Config Class Initialized
DEBUG - 2015-01-31 05:44:20 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:44:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:44:20 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:44:20 --> URI Class Initialized
DEBUG - 2015-01-31 05:44:20 --> Router Class Initialized
DEBUG - 2015-01-31 05:44:20 --> Output Class Initialized
DEBUG - 2015-01-31 05:44:20 --> Security Class Initialized
DEBUG - 2015-01-31 05:44:20 --> Input Class Initialized
DEBUG - 2015-01-31 05:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:44:20 --> Language Class Initialized
DEBUG - 2015-01-31 05:44:21 --> Loader Class Initialized
DEBUG - 2015-01-31 05:44:21 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:44:21 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:44:21 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:44:21 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:44:21 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:44:21 --> Model Class Initialized
DEBUG - 2015-01-31 05:44:21 --> Model Class Initialized
DEBUG - 2015-01-31 05:44:21 --> Controller Class Initialized
DEBUG - 2015-01-31 05:44:21 --> Model Class Initialized
DEBUG - 2015-01-31 05:44:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:44:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:44:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:44:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:44:21 --> Final output sent to browser
DEBUG - 2015-01-31 05:44:21 --> Total execution time: 0.3640
DEBUG - 2015-01-31 05:44:46 --> Config Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:44:46 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:44:46 --> URI Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Router Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Output Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Security Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Input Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:44:46 --> Language Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Loader Class Initialized
DEBUG - 2015-01-31 05:44:46 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:44:46 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:44:46 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:44:46 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:44:46 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:44:47 --> Model Class Initialized
DEBUG - 2015-01-31 05:44:47 --> Model Class Initialized
DEBUG - 2015-01-31 05:44:47 --> Controller Class Initialized
DEBUG - 2015-01-31 05:44:47 --> Model Class Initialized
DEBUG - 2015-01-31 05:44:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:44:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:44:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:44:47 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:44:47 --> Final output sent to browser
DEBUG - 2015-01-31 05:44:47 --> Total execution time: 0.5360
DEBUG - 2015-01-31 05:45:04 --> Config Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:45:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:45:04 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:45:04 --> URI Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Router Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Output Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Security Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Input Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:45:04 --> Language Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Loader Class Initialized
DEBUG - 2015-01-31 05:45:04 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:45:04 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:45:04 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:45:04 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:45:04 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:45:05 --> Model Class Initialized
DEBUG - 2015-01-31 05:45:05 --> Model Class Initialized
DEBUG - 2015-01-31 05:45:05 --> Controller Class Initialized
DEBUG - 2015-01-31 05:45:05 --> Model Class Initialized
DEBUG - 2015-01-31 05:45:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:45:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:45:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:45:05 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:45:05 --> Final output sent to browser
DEBUG - 2015-01-31 05:45:05 --> Total execution time: 0.6360
DEBUG - 2015-01-31 05:51:12 --> Config Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:51:12 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:51:12 --> URI Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Router Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Output Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Security Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Input Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:51:12 --> Language Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Loader Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:51:12 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:51:12 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:51:12 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Session: Regenerate ID
DEBUG - 2015-01-31 05:51:12 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:51:12 --> Model Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Model Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Controller Class Initialized
DEBUG - 2015-01-31 05:51:12 --> Model Class Initialized
DEBUG - 2015-01-31 05:51:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:51:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-01-31 05:51:12 --> Severity: Notice --> Use of undefined constant EXT - assumed 'EXT' C:\xampp\htdocs\myblog\application\views\admin\article\add.php 39
DEBUG - 2015-01-31 05:51:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:51:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:51:12 --> Final output sent to browser
DEBUG - 2015-01-31 05:51:12 --> Total execution time: 0.4320
DEBUG - 2015-01-31 05:51:41 --> Config Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:51:41 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:51:41 --> URI Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Router Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Output Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Security Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Input Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:51:41 --> Language Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Loader Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:51:41 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:51:41 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:51:41 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:51:41 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:51:41 --> Model Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Model Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Controller Class Initialized
DEBUG - 2015-01-31 05:51:41 --> Model Class Initialized
DEBUG - 2015-01-31 05:51:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:51:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:51:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:51:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:51:41 --> Final output sent to browser
DEBUG - 2015-01-31 05:51:41 --> Total execution time: 0.3210
DEBUG - 2015-01-31 05:52:16 --> Config Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:52:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:52:16 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:52:16 --> URI Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Router Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Output Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Security Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Input Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:52:16 --> Language Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Loader Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:52:16 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:52:16 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:52:16 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:52:16 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:52:16 --> Model Class Initialized
DEBUG - 2015-01-31 05:52:16 --> Model Class Initialized
DEBUG - 2015-01-31 05:52:17 --> Controller Class Initialized
DEBUG - 2015-01-31 05:52:17 --> Model Class Initialized
DEBUG - 2015-01-31 05:52:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:52:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:52:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:52:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:52:17 --> Final output sent to browser
DEBUG - 2015-01-31 05:52:17 --> Total execution time: 0.5080
DEBUG - 2015-01-31 05:52:40 --> Config Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:52:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:52:40 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:52:40 --> URI Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Router Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Output Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Security Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Input Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:52:40 --> Language Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Loader Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:52:40 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:52:40 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:52:40 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:52:40 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:52:40 --> Model Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Model Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Controller Class Initialized
DEBUG - 2015-01-31 05:52:40 --> Model Class Initialized
DEBUG - 2015-01-31 05:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:52:40 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:52:40 --> Final output sent to browser
DEBUG - 2015-01-31 05:52:40 --> Total execution time: 0.3960
DEBUG - 2015-01-31 05:54:15 --> Config Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:54:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:54:15 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:54:15 --> URI Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Router Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Output Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Security Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Input Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:54:15 --> Language Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Loader Class Initialized
DEBUG - 2015-01-31 05:54:15 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:54:15 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:54:15 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:54:15 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:54:15 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:54:16 --> Model Class Initialized
DEBUG - 2015-01-31 05:54:16 --> Model Class Initialized
DEBUG - 2015-01-31 05:54:16 --> Controller Class Initialized
DEBUG - 2015-01-31 05:54:16 --> Model Class Initialized
DEBUG - 2015-01-31 05:54:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:54:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:54:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:54:16 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:54:16 --> Final output sent to browser
DEBUG - 2015-01-31 05:54:16 --> Total execution time: 0.2520
DEBUG - 2015-01-31 05:56:31 --> Config Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:56:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:56:31 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:56:31 --> URI Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Router Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Output Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Security Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Input Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:56:31 --> Language Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Loader Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:56:31 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:56:31 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:56:31 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:56:31 --> Session: Regenerate ID
DEBUG - 2015-01-31 05:56:31 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:56:32 --> Model Class Initialized
DEBUG - 2015-01-31 05:56:32 --> Model Class Initialized
DEBUG - 2015-01-31 05:56:32 --> Controller Class Initialized
DEBUG - 2015-01-31 05:56:32 --> Model Class Initialized
DEBUG - 2015-01-31 05:56:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:56:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:56:32 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:56:32 --> Upload Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Config Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:58:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:58:32 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:58:32 --> URI Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Router Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Output Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Security Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Input Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:58:32 --> Language Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Loader Class Initialized
DEBUG - 2015-01-31 05:58:32 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:58:32 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:58:32 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:58:32 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:58:32 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:58:33 --> Model Class Initialized
DEBUG - 2015-01-31 05:58:33 --> Model Class Initialized
DEBUG - 2015-01-31 05:58:33 --> Controller Class Initialized
DEBUG - 2015-01-31 05:58:33 --> Model Class Initialized
DEBUG - 2015-01-31 05:58:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:58:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:58:33 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:58:33 --> Upload Class Initialized
DEBUG - 2015-01-31 05:58:33 --> Language file loaded: language/english/upload_lang.php
ERROR - 2015-01-31 05:58:33 --> You did not select a file to upload.
DEBUG - 2015-01-31 05:58:42 --> Config Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Hooks Class Initialized
DEBUG - 2015-01-31 05:58:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 05:58:42 --> Utf8 Class Initialized
DEBUG - 2015-01-31 05:58:42 --> URI Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Router Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Output Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Security Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Input Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 05:58:42 --> Language Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Loader Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Helper loaded: url_helper
DEBUG - 2015-01-31 05:58:42 --> Helper loaded: link_helper
DEBUG - 2015-01-31 05:58:42 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 05:58:42 --> CI_Session Class Initialized
DEBUG - 2015-01-31 05:58:42 --> CI_Session routines successfully run
DEBUG - 2015-01-31 05:58:42 --> Model Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Model Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Controller Class Initialized
DEBUG - 2015-01-31 05:58:42 --> Model Class Initialized
DEBUG - 2015-01-31 05:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 05:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 05:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 05:58:42 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 05:58:42 --> Final output sent to browser
DEBUG - 2015-01-31 05:58:42 --> Total execution time: 0.4190
DEBUG - 2015-01-31 06:00:17 --> Config Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:00:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:00:17 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:00:17 --> URI Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Router Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Output Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Security Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Input Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:00:17 --> Language Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Loader Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:00:17 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:00:17 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:00:17 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:00:17 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:00:17 --> Model Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Model Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Controller Class Initialized
DEBUG - 2015-01-31 06:00:17 --> Model Class Initialized
DEBUG - 2015-01-31 06:00:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:00:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:00:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:00:17 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 06:00:17 --> Final output sent to browser
DEBUG - 2015-01-31 06:00:17 --> Total execution time: 0.3980
DEBUG - 2015-01-31 06:01:11 --> Config Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:01:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:01:11 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:01:11 --> URI Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Router Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Output Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Security Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Input Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:01:11 --> Language Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Loader Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:01:11 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:01:11 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:01:11 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:01:11 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:01:11 --> Model Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Model Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Controller Class Initialized
DEBUG - 2015-01-31 06:01:11 --> Model Class Initialized
DEBUG - 2015-01-31 06:01:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:01:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:01:11 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:01:11 --> Upload Class Initialized
DEBUG - 2015-01-31 06:02:20 --> Config Class Initialized
DEBUG - 2015-01-31 06:02:20 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:02:20 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:02:20 --> URI Class Initialized
DEBUG - 2015-01-31 06:02:20 --> Router Class Initialized
DEBUG - 2015-01-31 06:02:20 --> Output Class Initialized
DEBUG - 2015-01-31 06:02:20 --> Security Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Input Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:02:21 --> Language Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Loader Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:02:21 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:02:21 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:02:21 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Session: Regenerate ID
DEBUG - 2015-01-31 06:02:21 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:02:21 --> Model Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Model Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Controller Class Initialized
DEBUG - 2015-01-31 06:02:21 --> Model Class Initialized
DEBUG - 2015-01-31 06:02:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:02:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:02:21 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:02:21 --> Upload Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Config Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:07:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:07:49 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:07:49 --> URI Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Router Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Output Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Security Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Input Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:07:49 --> Language Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Loader Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:07:49 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:07:49 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:07:49 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Session: Regenerate ID
DEBUG - 2015-01-31 06:07:49 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:07:49 --> Model Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Model Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Controller Class Initialized
DEBUG - 2015-01-31 06:07:49 --> Model Class Initialized
DEBUG - 2015-01-31 06:07:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:07:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:07:49 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:07:49 --> Upload Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Config Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:16:57 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:16:57 --> URI Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Router Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Output Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Security Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Input Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:16:57 --> Language Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Loader Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:16:57 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:16:57 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:16:57 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:16:57 --> Session: Regenerate ID
DEBUG - 2015-01-31 06:16:57 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:16:58 --> Model Class Initialized
DEBUG - 2015-01-31 06:16:58 --> Model Class Initialized
DEBUG - 2015-01-31 06:16:58 --> Controller Class Initialized
DEBUG - 2015-01-31 06:16:58 --> Model Class Initialized
DEBUG - 2015-01-31 06:16:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:16:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:16:58 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:16:58 --> Upload Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Config Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:18:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:18:37 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:18:37 --> URI Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Router Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Output Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Security Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Input Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:18:37 --> Language Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Loader Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:18:37 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:18:37 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:18:37 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:18:37 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:18:37 --> Model Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Model Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Controller Class Initialized
DEBUG - 2015-01-31 06:18:37 --> Model Class Initialized
DEBUG - 2015-01-31 06:18:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:18:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:18:37 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:18:37 --> Upload Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Config Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:18:38 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:18:38 --> URI Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Router Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Output Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Security Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Input Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:18:38 --> Language Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Loader Class Initialized
DEBUG - 2015-01-31 06:18:38 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:18:38 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:18:38 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:18:38 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:18:38 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:18:39 --> Model Class Initialized
DEBUG - 2015-01-31 06:18:39 --> Model Class Initialized
DEBUG - 2015-01-31 06:18:39 --> Controller Class Initialized
DEBUG - 2015-01-31 06:18:39 --> Model Class Initialized
DEBUG - 2015-01-31 06:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:18:39 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-01-31 06:18:39 --> Severity: Error --> Call to undefined method Entity\Articles::getUsername() C:\xampp\htdocs\myblog\application\views\admin\article\index.php 29
DEBUG - 2015-01-31 06:20:40 --> Config Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:20:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:20:40 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:20:40 --> URI Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Router Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Output Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Security Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Input Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:20:40 --> Language Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Loader Class Initialized
DEBUG - 2015-01-31 06:20:40 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:20:40 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:20:40 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:20:40 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:20:40 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:20:41 --> Model Class Initialized
DEBUG - 2015-01-31 06:20:41 --> Model Class Initialized
DEBUG - 2015-01-31 06:20:41 --> Controller Class Initialized
DEBUG - 2015-01-31 06:20:41 --> Model Class Initialized
DEBUG - 2015-01-31 06:20:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:20:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:20:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:20:41 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/footer.php
DEBUG - 2015-01-31 06:20:41 --> Final output sent to browser
DEBUG - 2015-01-31 06:20:41 --> Total execution time: 0.3880
DEBUG - 2015-01-31 06:22:12 --> Config Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:22:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:22:12 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:22:12 --> URI Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Router Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Output Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Security Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Input Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:22:12 --> Language Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Loader Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:22:12 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:22:12 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:22:12 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Session: Regenerate ID
DEBUG - 2015-01-31 06:22:12 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:22:12 --> Model Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Model Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Controller Class Initialized
DEBUG - 2015-01-31 06:22:12 --> Model Class Initialized
DEBUG - 2015-01-31 06:22:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:22:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
DEBUG - 2015-01-31 06:22:12 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/article/add.php
DEBUG - 2015-01-31 06:22:12 --> Upload Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Config Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Hooks Class Initialized
DEBUG - 2015-01-31 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-31 06:22:13 --> Utf8 Class Initialized
DEBUG - 2015-01-31 06:22:13 --> URI Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Router Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Output Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Security Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Input Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-31 06:22:13 --> Language Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Loader Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Helper loaded: url_helper
DEBUG - 2015-01-31 06:22:13 --> Helper loaded: link_helper
DEBUG - 2015-01-31 06:22:13 --> Helper loaded: debug_helper
DEBUG - 2015-01-31 06:22:13 --> CI_Session Class Initialized
DEBUG - 2015-01-31 06:22:13 --> CI_Session routines successfully run
DEBUG - 2015-01-31 06:22:13 --> Model Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Model Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Controller Class Initialized
DEBUG - 2015-01-31 06:22:13 --> Model Class Initialized
DEBUG - 2015-01-31 06:22:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/nav.php
DEBUG - 2015-01-31 06:22:13 --> File loaded: C:\xampp\htdocs\myblog\application\views\admin/common/header.php
ERROR - 2015-01-31 06:22:14 --> Severity: Error --> Call to undefined method Entity\Articles::getUsername() C:\xampp\htdocs\myblog\application\views\admin\article\index.php 29
