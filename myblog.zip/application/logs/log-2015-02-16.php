<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-16 00:12:46 --> Config Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Hooks Class Initialized
DEBUG - 2015-02-16 00:12:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 00:12:46 --> Utf8 Class Initialized
DEBUG - 2015-02-16 00:12:46 --> URI Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Router Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Output Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Security Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Input Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 00:12:46 --> Language Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Loader Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: url_helper
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: link_helper
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 00:12:46 --> CI_Session Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Session: Regenerate ID
DEBUG - 2015-02-16 00:12:46 --> CI_Session routines successfully run
DEBUG - 2015-02-16 00:12:46 --> Model Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Model Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Controller Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 00:12:46 --> Email Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: language_helper
DEBUG - 2015-02-16 00:12:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 00:12:46 --> Model Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Database Driver Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: date_helper
DEBUG - 2015-02-16 00:12:46 --> Helper loaded: form_helper
DEBUG - 2015-02-16 00:12:46 --> Form Validation Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Model Class Initialized
DEBUG - 2015-02-16 00:12:46 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 00:12:46 --> Pagination Class Initialized
DEBUG - 2015-02-16 00:12:47 --> Model Class Initialized
DEBUG - 2015-02-16 00:12:47 --> Model Class Initialized
DEBUG - 2015-02-16 00:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 00:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 00:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 00:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 00:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 00:12:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 00:12:47 --> Final output sent to browser
DEBUG - 2015-02-16 00:12:47 --> Total execution time: 1.4741
DEBUG - 2015-02-16 00:27:49 --> Config Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Hooks Class Initialized
DEBUG - 2015-02-16 00:27:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 00:27:49 --> Utf8 Class Initialized
DEBUG - 2015-02-16 00:27:49 --> URI Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Router Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Output Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Security Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Input Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 00:27:49 --> Language Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Loader Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: url_helper
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: link_helper
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 00:27:49 --> CI_Session Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Session: Regenerate ID
DEBUG - 2015-02-16 00:27:49 --> CI_Session routines successfully run
DEBUG - 2015-02-16 00:27:49 --> Model Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Model Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Controller Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 00:27:49 --> Email Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: language_helper
DEBUG - 2015-02-16 00:27:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 00:27:49 --> Model Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Database Driver Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: date_helper
DEBUG - 2015-02-16 00:27:49 --> Helper loaded: form_helper
DEBUG - 2015-02-16 00:27:49 --> Form Validation Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Model Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 00:27:49 --> Pagination Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Model Class Initialized
DEBUG - 2015-02-16 00:27:49 --> Model Class Initialized
DEBUG - 2015-02-16 00:27:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 00:27:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 00:27:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 00:27:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 00:27:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 00:27:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 00:27:50 --> Final output sent to browser
DEBUG - 2015-02-16 00:27:50 --> Total execution time: 1.3761
DEBUG - 2015-02-16 00:42:51 --> Config Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Hooks Class Initialized
DEBUG - 2015-02-16 00:42:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 00:42:51 --> Utf8 Class Initialized
DEBUG - 2015-02-16 00:42:51 --> URI Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Router Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Output Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Security Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Input Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 00:42:51 --> Language Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Loader Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: url_helper
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: link_helper
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 00:42:51 --> CI_Session Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Session: Regenerate ID
DEBUG - 2015-02-16 00:42:51 --> CI_Session routines successfully run
DEBUG - 2015-02-16 00:42:51 --> Model Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Model Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Controller Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 00:42:51 --> Email Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: language_helper
DEBUG - 2015-02-16 00:42:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 00:42:51 --> Model Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Database Driver Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: date_helper
DEBUG - 2015-02-16 00:42:51 --> Helper loaded: form_helper
DEBUG - 2015-02-16 00:42:51 --> Form Validation Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Model Class Initialized
DEBUG - 2015-02-16 00:42:51 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 00:42:51 --> Pagination Class Initialized
DEBUG - 2015-02-16 00:42:52 --> Model Class Initialized
DEBUG - 2015-02-16 00:42:52 --> Model Class Initialized
DEBUG - 2015-02-16 00:42:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 00:42:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 00:42:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 00:42:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 00:42:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 00:42:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 00:42:53 --> Final output sent to browser
DEBUG - 2015-02-16 00:42:53 --> Total execution time: 1.5862
DEBUG - 2015-02-16 00:57:58 --> Config Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Hooks Class Initialized
DEBUG - 2015-02-16 00:57:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 00:57:58 --> Utf8 Class Initialized
DEBUG - 2015-02-16 00:57:58 --> URI Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Router Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Output Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Security Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Input Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 00:57:58 --> Language Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Loader Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: url_helper
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: link_helper
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 00:57:58 --> CI_Session Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Session: Regenerate ID
DEBUG - 2015-02-16 00:57:58 --> CI_Session routines successfully run
DEBUG - 2015-02-16 00:57:58 --> Model Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Model Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Controller Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 00:57:58 --> Email Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: language_helper
DEBUG - 2015-02-16 00:57:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 00:57:58 --> Model Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Database Driver Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: date_helper
DEBUG - 2015-02-16 00:57:58 --> Helper loaded: form_helper
DEBUG - 2015-02-16 00:57:58 --> Form Validation Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Model Class Initialized
DEBUG - 2015-02-16 00:57:58 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 00:57:58 --> Pagination Class Initialized
DEBUG - 2015-02-16 00:57:59 --> Model Class Initialized
DEBUG - 2015-02-16 00:57:59 --> Model Class Initialized
DEBUG - 2015-02-16 00:57:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 00:57:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 00:57:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 00:57:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 00:58:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 00:58:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 00:58:00 --> Final output sent to browser
DEBUG - 2015-02-16 00:58:00 --> Total execution time: 1.3731
DEBUG - 2015-02-16 01:13:02 --> Config Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Hooks Class Initialized
DEBUG - 2015-02-16 01:13:02 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 01:13:02 --> Utf8 Class Initialized
DEBUG - 2015-02-16 01:13:02 --> URI Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Router Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Output Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Security Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Input Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 01:13:02 --> Language Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Loader Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: url_helper
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: link_helper
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 01:13:02 --> CI_Session Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Session: Regenerate ID
DEBUG - 2015-02-16 01:13:02 --> CI_Session routines successfully run
DEBUG - 2015-02-16 01:13:02 --> Model Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Model Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Controller Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 01:13:02 --> Email Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: language_helper
DEBUG - 2015-02-16 01:13:02 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 01:13:02 --> Model Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Database Driver Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: date_helper
DEBUG - 2015-02-16 01:13:02 --> Helper loaded: form_helper
DEBUG - 2015-02-16 01:13:02 --> Form Validation Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Model Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 01:13:02 --> Pagination Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Model Class Initialized
DEBUG - 2015-02-16 01:13:02 --> Model Class Initialized
DEBUG - 2015-02-16 01:13:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 01:13:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 01:13:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 01:13:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 01:13:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 01:13:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 01:13:03 --> Final output sent to browser
DEBUG - 2015-02-16 01:13:03 --> Total execution time: 1.6042
DEBUG - 2015-02-16 01:28:05 --> Config Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Hooks Class Initialized
DEBUG - 2015-02-16 01:28:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 01:28:05 --> Utf8 Class Initialized
DEBUG - 2015-02-16 01:28:05 --> URI Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Router Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Output Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Security Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Input Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 01:28:05 --> Language Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Loader Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: url_helper
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: link_helper
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 01:28:05 --> CI_Session Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Session: Regenerate ID
DEBUG - 2015-02-16 01:28:05 --> CI_Session routines successfully run
DEBUG - 2015-02-16 01:28:05 --> Model Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Model Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Controller Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 01:28:05 --> Email Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: language_helper
DEBUG - 2015-02-16 01:28:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 01:28:05 --> Model Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Database Driver Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: date_helper
DEBUG - 2015-02-16 01:28:05 --> Helper loaded: form_helper
DEBUG - 2015-02-16 01:28:05 --> Form Validation Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Model Class Initialized
DEBUG - 2015-02-16 01:28:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 01:28:05 --> Pagination Class Initialized
DEBUG - 2015-02-16 01:28:06 --> Model Class Initialized
DEBUG - 2015-02-16 01:28:06 --> Model Class Initialized
DEBUG - 2015-02-16 01:28:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 01:28:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 01:28:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 01:28:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 01:28:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 01:28:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 01:28:07 --> Final output sent to browser
DEBUG - 2015-02-16 01:28:07 --> Total execution time: 1.3971
DEBUG - 2015-02-16 01:43:09 --> Config Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Hooks Class Initialized
DEBUG - 2015-02-16 01:43:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 01:43:09 --> Utf8 Class Initialized
DEBUG - 2015-02-16 01:43:09 --> URI Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Router Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Output Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Security Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Input Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 01:43:09 --> Language Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Loader Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: url_helper
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: link_helper
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 01:43:09 --> CI_Session Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Session: Regenerate ID
DEBUG - 2015-02-16 01:43:09 --> CI_Session routines successfully run
DEBUG - 2015-02-16 01:43:09 --> Model Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Model Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Controller Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 01:43:09 --> Email Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: language_helper
DEBUG - 2015-02-16 01:43:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 01:43:09 --> Model Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Database Driver Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: date_helper
DEBUG - 2015-02-16 01:43:09 --> Helper loaded: form_helper
DEBUG - 2015-02-16 01:43:09 --> Form Validation Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Model Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 01:43:09 --> Pagination Class Initialized
DEBUG - 2015-02-16 01:43:09 --> Model Class Initialized
DEBUG - 2015-02-16 01:43:10 --> Model Class Initialized
DEBUG - 2015-02-16 01:43:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 01:43:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 01:43:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 01:43:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 01:43:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 01:43:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 01:43:10 --> Final output sent to browser
DEBUG - 2015-02-16 01:43:10 --> Total execution time: 1.6722
DEBUG - 2015-02-16 01:58:12 --> Config Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Hooks Class Initialized
DEBUG - 2015-02-16 01:58:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 01:58:12 --> Utf8 Class Initialized
DEBUG - 2015-02-16 01:58:12 --> URI Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Router Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Output Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Security Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Input Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 01:58:12 --> Language Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Loader Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: url_helper
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: link_helper
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 01:58:12 --> CI_Session Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Session: Regenerate ID
DEBUG - 2015-02-16 01:58:12 --> CI_Session routines successfully run
DEBUG - 2015-02-16 01:58:12 --> Model Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Model Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Controller Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 01:58:12 --> Email Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: language_helper
DEBUG - 2015-02-16 01:58:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 01:58:12 --> Model Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Database Driver Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: date_helper
DEBUG - 2015-02-16 01:58:12 --> Helper loaded: form_helper
DEBUG - 2015-02-16 01:58:12 --> Form Validation Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Model Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 01:58:12 --> Pagination Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Model Class Initialized
DEBUG - 2015-02-16 01:58:12 --> Model Class Initialized
DEBUG - 2015-02-16 01:58:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 01:58:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 01:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 01:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 01:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 01:58:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 01:58:13 --> Final output sent to browser
DEBUG - 2015-02-16 01:58:13 --> Total execution time: 1.3411
DEBUG - 2015-02-16 02:13:15 --> Config Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Hooks Class Initialized
DEBUG - 2015-02-16 02:13:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 02:13:15 --> Utf8 Class Initialized
DEBUG - 2015-02-16 02:13:15 --> URI Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Router Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Output Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Security Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Input Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 02:13:15 --> Language Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Loader Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: url_helper
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: link_helper
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 02:13:15 --> CI_Session Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Session: Regenerate ID
DEBUG - 2015-02-16 02:13:15 --> CI_Session routines successfully run
DEBUG - 2015-02-16 02:13:15 --> Model Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Model Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Controller Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 02:13:15 --> Email Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: language_helper
DEBUG - 2015-02-16 02:13:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 02:13:15 --> Model Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Database Driver Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: date_helper
DEBUG - 2015-02-16 02:13:15 --> Helper loaded: form_helper
DEBUG - 2015-02-16 02:13:15 --> Form Validation Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Model Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 02:13:15 --> Pagination Class Initialized
DEBUG - 2015-02-16 02:13:15 --> Model Class Initialized
DEBUG - 2015-02-16 02:13:16 --> Model Class Initialized
DEBUG - 2015-02-16 02:13:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 02:13:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 02:13:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 02:13:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 02:13:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 02:13:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 02:13:16 --> Final output sent to browser
DEBUG - 2015-02-16 02:13:16 --> Total execution time: 1.3611
DEBUG - 2015-02-16 02:28:17 --> Config Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Hooks Class Initialized
DEBUG - 2015-02-16 02:28:17 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 02:28:17 --> Utf8 Class Initialized
DEBUG - 2015-02-16 02:28:17 --> URI Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Router Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Output Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Security Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Input Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 02:28:17 --> Language Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Loader Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: url_helper
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: link_helper
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 02:28:17 --> CI_Session Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Session: Regenerate ID
DEBUG - 2015-02-16 02:28:17 --> CI_Session routines successfully run
DEBUG - 2015-02-16 02:28:17 --> Model Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Model Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Controller Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 02:28:17 --> Email Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: language_helper
DEBUG - 2015-02-16 02:28:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 02:28:17 --> Model Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Database Driver Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: date_helper
DEBUG - 2015-02-16 02:28:17 --> Helper loaded: form_helper
DEBUG - 2015-02-16 02:28:17 --> Form Validation Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Model Class Initialized
DEBUG - 2015-02-16 02:28:17 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 02:28:17 --> Pagination Class Initialized
DEBUG - 2015-02-16 02:28:18 --> Model Class Initialized
DEBUG - 2015-02-16 02:28:18 --> Model Class Initialized
DEBUG - 2015-02-16 02:28:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 02:28:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 02:28:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 02:28:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 02:28:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 02:28:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 02:28:19 --> Final output sent to browser
DEBUG - 2015-02-16 02:28:19 --> Total execution time: 1.3461
DEBUG - 2015-02-16 02:43:20 --> Config Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Hooks Class Initialized
DEBUG - 2015-02-16 02:43:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 02:43:20 --> Utf8 Class Initialized
DEBUG - 2015-02-16 02:43:20 --> URI Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Router Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Output Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Security Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Input Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 02:43:20 --> Language Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Loader Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: url_helper
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: link_helper
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 02:43:20 --> CI_Session Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Session: Regenerate ID
DEBUG - 2015-02-16 02:43:20 --> CI_Session routines successfully run
DEBUG - 2015-02-16 02:43:20 --> Model Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Model Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Controller Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 02:43:20 --> Email Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: language_helper
DEBUG - 2015-02-16 02:43:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 02:43:20 --> Model Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Database Driver Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: date_helper
DEBUG - 2015-02-16 02:43:20 --> Helper loaded: form_helper
DEBUG - 2015-02-16 02:43:20 --> Form Validation Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Model Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 02:43:20 --> Pagination Class Initialized
DEBUG - 2015-02-16 02:43:20 --> Model Class Initialized
DEBUG - 2015-02-16 02:43:21 --> Model Class Initialized
DEBUG - 2015-02-16 02:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 02:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 02:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 02:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 02:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 02:43:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 02:43:21 --> Final output sent to browser
DEBUG - 2015-02-16 02:43:21 --> Total execution time: 1.3681
DEBUG - 2015-02-16 02:58:22 --> Config Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Hooks Class Initialized
DEBUG - 2015-02-16 02:58:22 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 02:58:22 --> Utf8 Class Initialized
DEBUG - 2015-02-16 02:58:22 --> URI Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Router Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Output Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Security Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Input Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 02:58:22 --> Language Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Loader Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: url_helper
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: link_helper
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 02:58:22 --> CI_Session Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Session: Regenerate ID
DEBUG - 2015-02-16 02:58:22 --> CI_Session routines successfully run
DEBUG - 2015-02-16 02:58:22 --> Model Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Model Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Controller Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 02:58:22 --> Email Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: language_helper
DEBUG - 2015-02-16 02:58:22 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 02:58:22 --> Model Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Database Driver Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: date_helper
DEBUG - 2015-02-16 02:58:22 --> Helper loaded: form_helper
DEBUG - 2015-02-16 02:58:22 --> Form Validation Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Model Class Initialized
DEBUG - 2015-02-16 02:58:22 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 02:58:22 --> Pagination Class Initialized
DEBUG - 2015-02-16 02:58:23 --> Model Class Initialized
DEBUG - 2015-02-16 02:58:23 --> Model Class Initialized
DEBUG - 2015-02-16 02:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 02:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 02:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 02:58:23 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 02:58:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 02:58:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 02:58:24 --> Final output sent to browser
DEBUG - 2015-02-16 02:58:24 --> Total execution time: 1.3411
DEBUG - 2015-02-16 03:13:25 --> Config Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Hooks Class Initialized
DEBUG - 2015-02-16 03:13:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 03:13:25 --> Utf8 Class Initialized
DEBUG - 2015-02-16 03:13:25 --> URI Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Router Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Output Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Security Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Input Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 03:13:25 --> Language Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Loader Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: url_helper
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: link_helper
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 03:13:25 --> CI_Session Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Session: Regenerate ID
DEBUG - 2015-02-16 03:13:25 --> CI_Session routines successfully run
DEBUG - 2015-02-16 03:13:25 --> Model Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Model Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Controller Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 03:13:25 --> Email Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: language_helper
DEBUG - 2015-02-16 03:13:25 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 03:13:25 --> Model Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Database Driver Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: date_helper
DEBUG - 2015-02-16 03:13:25 --> Helper loaded: form_helper
DEBUG - 2015-02-16 03:13:25 --> Form Validation Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Model Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 03:13:25 --> Pagination Class Initialized
DEBUG - 2015-02-16 03:13:25 --> Model Class Initialized
DEBUG - 2015-02-16 03:13:26 --> Model Class Initialized
DEBUG - 2015-02-16 03:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 03:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 03:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 03:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 03:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 03:13:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 03:13:26 --> Final output sent to browser
DEBUG - 2015-02-16 03:13:26 --> Total execution time: 1.5282
DEBUG - 2015-02-16 03:28:29 --> Config Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Hooks Class Initialized
DEBUG - 2015-02-16 03:28:29 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 03:28:29 --> Utf8 Class Initialized
DEBUG - 2015-02-16 03:28:29 --> URI Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Router Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Output Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Security Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Input Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 03:28:29 --> Language Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Loader Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: url_helper
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: link_helper
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 03:28:29 --> CI_Session Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Session: Regenerate ID
DEBUG - 2015-02-16 03:28:29 --> CI_Session routines successfully run
DEBUG - 2015-02-16 03:28:29 --> Model Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Model Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Controller Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 03:28:29 --> Email Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: language_helper
DEBUG - 2015-02-16 03:28:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 03:28:29 --> Model Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Database Driver Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: date_helper
DEBUG - 2015-02-16 03:28:29 --> Helper loaded: form_helper
DEBUG - 2015-02-16 03:28:29 --> Form Validation Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Model Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 03:28:29 --> Pagination Class Initialized
DEBUG - 2015-02-16 03:28:29 --> Model Class Initialized
DEBUG - 2015-02-16 03:28:30 --> Model Class Initialized
DEBUG - 2015-02-16 03:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 03:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 03:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 03:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 03:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 03:28:30 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 03:28:30 --> Final output sent to browser
DEBUG - 2015-02-16 03:28:30 --> Total execution time: 1.5552
DEBUG - 2015-02-16 03:43:32 --> Config Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Hooks Class Initialized
DEBUG - 2015-02-16 03:43:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 03:43:32 --> Utf8 Class Initialized
DEBUG - 2015-02-16 03:43:32 --> URI Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Router Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Output Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Security Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Input Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 03:43:32 --> Language Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Loader Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: url_helper
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: link_helper
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 03:43:32 --> CI_Session Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Session: Regenerate ID
DEBUG - 2015-02-16 03:43:32 --> CI_Session routines successfully run
DEBUG - 2015-02-16 03:43:32 --> Model Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Model Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Controller Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 03:43:32 --> Email Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: language_helper
DEBUG - 2015-02-16 03:43:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 03:43:32 --> Model Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Database Driver Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: date_helper
DEBUG - 2015-02-16 03:43:32 --> Helper loaded: form_helper
DEBUG - 2015-02-16 03:43:32 --> Form Validation Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Model Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 03:43:32 --> Pagination Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Model Class Initialized
DEBUG - 2015-02-16 03:43:32 --> Model Class Initialized
DEBUG - 2015-02-16 03:43:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 03:43:32 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 03:43:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 03:43:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 03:43:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 03:43:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 03:43:33 --> Final output sent to browser
DEBUG - 2015-02-16 03:43:33 --> Total execution time: 1.3521
DEBUG - 2015-02-16 03:58:34 --> Config Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Hooks Class Initialized
DEBUG - 2015-02-16 03:58:34 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 03:58:34 --> Utf8 Class Initialized
DEBUG - 2015-02-16 03:58:34 --> URI Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Router Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Output Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Security Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Input Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 03:58:34 --> Language Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Loader Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: url_helper
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: link_helper
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 03:58:34 --> CI_Session Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Session: Regenerate ID
DEBUG - 2015-02-16 03:58:34 --> CI_Session routines successfully run
DEBUG - 2015-02-16 03:58:34 --> Model Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Model Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Controller Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 03:58:34 --> Email Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: language_helper
DEBUG - 2015-02-16 03:58:34 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 03:58:34 --> Model Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Database Driver Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: date_helper
DEBUG - 2015-02-16 03:58:34 --> Helper loaded: form_helper
DEBUG - 2015-02-16 03:58:34 --> Form Validation Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Model Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 03:58:34 --> Pagination Class Initialized
DEBUG - 2015-02-16 03:58:34 --> Model Class Initialized
DEBUG - 2015-02-16 03:58:35 --> Model Class Initialized
DEBUG - 2015-02-16 03:58:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 03:58:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 03:58:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 03:58:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 03:58:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 03:58:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 03:58:35 --> Final output sent to browser
DEBUG - 2015-02-16 03:58:35 --> Total execution time: 1.3481
DEBUG - 2015-02-16 04:13:36 --> Config Class Initialized
DEBUG - 2015-02-16 04:13:36 --> Hooks Class Initialized
DEBUG - 2015-02-16 04:13:36 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 04:13:36 --> Utf8 Class Initialized
DEBUG - 2015-02-16 04:13:36 --> URI Class Initialized
DEBUG - 2015-02-16 04:13:36 --> Router Class Initialized
DEBUG - 2015-02-16 04:13:36 --> Output Class Initialized
DEBUG - 2015-02-16 04:13:36 --> Security Class Initialized
DEBUG - 2015-02-16 04:13:36 --> Input Class Initialized
DEBUG - 2015-02-16 04:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 04:13:36 --> Language Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Loader Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: url_helper
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: link_helper
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 04:13:37 --> CI_Session Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Session: Regenerate ID
DEBUG - 2015-02-16 04:13:37 --> CI_Session routines successfully run
DEBUG - 2015-02-16 04:13:37 --> Model Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Model Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Controller Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 04:13:37 --> Email Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: language_helper
DEBUG - 2015-02-16 04:13:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 04:13:37 --> Model Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Database Driver Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: date_helper
DEBUG - 2015-02-16 04:13:37 --> Helper loaded: form_helper
DEBUG - 2015-02-16 04:13:37 --> Form Validation Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Model Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 04:13:37 --> Pagination Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Model Class Initialized
DEBUG - 2015-02-16 04:13:37 --> Model Class Initialized
DEBUG - 2015-02-16 04:13:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 04:13:37 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 04:13:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 04:13:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 04:13:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 04:13:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 04:13:38 --> Final output sent to browser
DEBUG - 2015-02-16 04:13:38 --> Total execution time: 1.7102
DEBUG - 2015-02-16 04:28:39 --> Config Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Hooks Class Initialized
DEBUG - 2015-02-16 04:28:39 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 04:28:39 --> Utf8 Class Initialized
DEBUG - 2015-02-16 04:28:39 --> URI Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Router Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Output Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Security Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Input Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 04:28:39 --> Language Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Loader Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: url_helper
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: link_helper
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 04:28:39 --> CI_Session Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Session: Regenerate ID
DEBUG - 2015-02-16 04:28:39 --> CI_Session routines successfully run
DEBUG - 2015-02-16 04:28:39 --> Model Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Model Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Controller Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 04:28:39 --> Email Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: language_helper
DEBUG - 2015-02-16 04:28:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 04:28:39 --> Model Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Database Driver Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: date_helper
DEBUG - 2015-02-16 04:28:39 --> Helper loaded: form_helper
DEBUG - 2015-02-16 04:28:39 --> Form Validation Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Model Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 04:28:39 --> Pagination Class Initialized
DEBUG - 2015-02-16 04:28:39 --> Model Class Initialized
DEBUG - 2015-02-16 04:28:40 --> Model Class Initialized
DEBUG - 2015-02-16 04:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 04:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 04:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 04:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 04:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 04:28:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 04:28:40 --> Final output sent to browser
DEBUG - 2015-02-16 04:28:40 --> Total execution time: 1.3811
DEBUG - 2015-02-16 04:43:41 --> Config Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Hooks Class Initialized
DEBUG - 2015-02-16 04:43:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 04:43:41 --> Utf8 Class Initialized
DEBUG - 2015-02-16 04:43:41 --> URI Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Router Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Output Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Security Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Input Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 04:43:41 --> Language Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Loader Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 04:43:41 --> Helper loaded: url_helper
DEBUG - 2015-02-16 04:43:41 --> Helper loaded: link_helper
DEBUG - 2015-02-16 04:43:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 04:43:41 --> CI_Session Class Initialized
DEBUG - 2015-02-16 04:43:41 --> Session: Regenerate ID
DEBUG - 2015-02-16 04:43:41 --> CI_Session routines successfully run
DEBUG - 2015-02-16 04:43:42 --> Model Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Model Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Controller Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 04:43:42 --> Email Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 04:43:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 04:43:42 --> Helper loaded: language_helper
DEBUG - 2015-02-16 04:43:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 04:43:42 --> Model Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Database Driver Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Helper loaded: date_helper
DEBUG - 2015-02-16 04:43:42 --> Helper loaded: form_helper
DEBUG - 2015-02-16 04:43:42 --> Form Validation Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Model Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 04:43:42 --> Pagination Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Model Class Initialized
DEBUG - 2015-02-16 04:43:42 --> Model Class Initialized
DEBUG - 2015-02-16 04:43:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 04:43:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 04:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 04:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 04:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 04:43:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 04:43:43 --> Final output sent to browser
DEBUG - 2015-02-16 04:43:43 --> Total execution time: 1.3721
DEBUG - 2015-02-16 04:58:45 --> Config Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Hooks Class Initialized
DEBUG - 2015-02-16 04:58:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 04:58:45 --> Utf8 Class Initialized
DEBUG - 2015-02-16 04:58:45 --> URI Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Router Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Output Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Security Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Input Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 04:58:45 --> Language Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Loader Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: url_helper
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: link_helper
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 04:58:45 --> CI_Session Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Session: Regenerate ID
DEBUG - 2015-02-16 04:58:45 --> CI_Session routines successfully run
DEBUG - 2015-02-16 04:58:45 --> Model Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Model Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Controller Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 04:58:45 --> Email Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: language_helper
DEBUG - 2015-02-16 04:58:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 04:58:45 --> Model Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Database Driver Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: date_helper
DEBUG - 2015-02-16 04:58:45 --> Helper loaded: form_helper
DEBUG - 2015-02-16 04:58:45 --> Form Validation Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Model Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 04:58:45 --> Pagination Class Initialized
DEBUG - 2015-02-16 04:58:45 --> Model Class Initialized
DEBUG - 2015-02-16 04:58:46 --> Model Class Initialized
DEBUG - 2015-02-16 04:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 04:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 04:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 04:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 04:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 04:58:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 04:58:46 --> Final output sent to browser
DEBUG - 2015-02-16 04:58:46 --> Total execution time: 1.3621
DEBUG - 2015-02-16 05:13:47 --> Config Class Initialized
DEBUG - 2015-02-16 05:13:47 --> Hooks Class Initialized
DEBUG - 2015-02-16 05:13:47 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 05:13:47 --> Utf8 Class Initialized
DEBUG - 2015-02-16 05:13:47 --> URI Class Initialized
DEBUG - 2015-02-16 05:13:47 --> Router Class Initialized
DEBUG - 2015-02-16 05:13:47 --> Output Class Initialized
DEBUG - 2015-02-16 05:13:47 --> Security Class Initialized
DEBUG - 2015-02-16 05:13:47 --> Input Class Initialized
DEBUG - 2015-02-16 05:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 05:13:47 --> Language Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Loader Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: url_helper
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: link_helper
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 05:13:48 --> CI_Session Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Session: Regenerate ID
DEBUG - 2015-02-16 05:13:48 --> CI_Session routines successfully run
DEBUG - 2015-02-16 05:13:48 --> Model Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Model Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Controller Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 05:13:48 --> Email Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: language_helper
DEBUG - 2015-02-16 05:13:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 05:13:48 --> Model Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Database Driver Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: date_helper
DEBUG - 2015-02-16 05:13:48 --> Helper loaded: form_helper
DEBUG - 2015-02-16 05:13:48 --> Form Validation Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Model Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 05:13:48 --> Pagination Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Model Class Initialized
DEBUG - 2015-02-16 05:13:48 --> Model Class Initialized
DEBUG - 2015-02-16 05:13:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 05:13:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 05:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 05:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 05:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 05:13:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 05:13:49 --> Final output sent to browser
DEBUG - 2015-02-16 05:13:49 --> Total execution time: 1.5992
DEBUG - 2015-02-16 05:28:50 --> Config Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Hooks Class Initialized
DEBUG - 2015-02-16 05:28:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 05:28:50 --> Utf8 Class Initialized
DEBUG - 2015-02-16 05:28:50 --> URI Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Router Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Output Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Security Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Input Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 05:28:50 --> Language Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Loader Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: url_helper
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: link_helper
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 05:28:50 --> CI_Session Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Session: Regenerate ID
DEBUG - 2015-02-16 05:28:50 --> CI_Session routines successfully run
DEBUG - 2015-02-16 05:28:50 --> Model Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Model Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Controller Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 05:28:50 --> Email Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: language_helper
DEBUG - 2015-02-16 05:28:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 05:28:50 --> Model Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Database Driver Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: date_helper
DEBUG - 2015-02-16 05:28:50 --> Helper loaded: form_helper
DEBUG - 2015-02-16 05:28:50 --> Form Validation Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Model Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 05:28:50 --> Pagination Class Initialized
DEBUG - 2015-02-16 05:28:50 --> Model Class Initialized
DEBUG - 2015-02-16 05:28:51 --> Model Class Initialized
DEBUG - 2015-02-16 05:28:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 05:28:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 05:28:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 05:28:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 05:28:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 05:28:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 05:28:51 --> Final output sent to browser
DEBUG - 2015-02-16 05:28:51 --> Total execution time: 1.3541
DEBUG - 2015-02-16 05:43:53 --> Config Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Hooks Class Initialized
DEBUG - 2015-02-16 05:43:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 05:43:53 --> Utf8 Class Initialized
DEBUG - 2015-02-16 05:43:53 --> URI Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Router Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Output Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Security Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Input Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 05:43:53 --> Language Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Loader Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: url_helper
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: link_helper
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 05:43:53 --> CI_Session Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Session: Regenerate ID
DEBUG - 2015-02-16 05:43:53 --> CI_Session routines successfully run
DEBUG - 2015-02-16 05:43:53 --> Model Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Model Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Controller Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 05:43:53 --> Email Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: language_helper
DEBUG - 2015-02-16 05:43:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 05:43:53 --> Model Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Database Driver Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: date_helper
DEBUG - 2015-02-16 05:43:53 --> Helper loaded: form_helper
DEBUG - 2015-02-16 05:43:53 --> Form Validation Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Model Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 05:43:53 --> Pagination Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Model Class Initialized
DEBUG - 2015-02-16 05:43:53 --> Model Class Initialized
DEBUG - 2015-02-16 05:43:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 05:43:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 05:43:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 05:43:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 05:43:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 05:43:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 05:43:54 --> Final output sent to browser
DEBUG - 2015-02-16 05:43:54 --> Total execution time: 1.4901
DEBUG - 2015-02-16 05:58:56 --> Config Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Hooks Class Initialized
DEBUG - 2015-02-16 05:58:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 05:58:56 --> Utf8 Class Initialized
DEBUG - 2015-02-16 05:58:56 --> URI Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Router Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Output Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Security Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Input Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 05:58:56 --> Language Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Loader Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: url_helper
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: link_helper
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 05:58:56 --> CI_Session Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Session: Regenerate ID
DEBUG - 2015-02-16 05:58:56 --> CI_Session routines successfully run
DEBUG - 2015-02-16 05:58:56 --> Model Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Model Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Controller Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 05:58:56 --> Email Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: language_helper
DEBUG - 2015-02-16 05:58:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 05:58:56 --> Model Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Database Driver Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: date_helper
DEBUG - 2015-02-16 05:58:56 --> Helper loaded: form_helper
DEBUG - 2015-02-16 05:58:56 --> Form Validation Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Model Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 05:58:56 --> Pagination Class Initialized
DEBUG - 2015-02-16 05:58:56 --> Model Class Initialized
DEBUG - 2015-02-16 05:58:57 --> Model Class Initialized
DEBUG - 2015-02-16 05:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 05:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 05:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 05:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 05:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 05:58:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 05:58:57 --> Final output sent to browser
DEBUG - 2015-02-16 05:58:57 --> Total execution time: 1.3541
DEBUG - 2015-02-16 06:13:59 --> Config Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Hooks Class Initialized
DEBUG - 2015-02-16 06:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 06:13:59 --> Utf8 Class Initialized
DEBUG - 2015-02-16 06:13:59 --> URI Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Router Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Output Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Security Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Input Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 06:13:59 --> Language Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Loader Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: url_helper
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: link_helper
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 06:13:59 --> CI_Session Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Session: Regenerate ID
DEBUG - 2015-02-16 06:13:59 --> CI_Session routines successfully run
DEBUG - 2015-02-16 06:13:59 --> Model Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Model Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Controller Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 06:13:59 --> Email Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: language_helper
DEBUG - 2015-02-16 06:13:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 06:13:59 --> Model Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Database Driver Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: date_helper
DEBUG - 2015-02-16 06:13:59 --> Helper loaded: form_helper
DEBUG - 2015-02-16 06:13:59 --> Form Validation Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Model Class Initialized
DEBUG - 2015-02-16 06:13:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 06:13:59 --> Pagination Class Initialized
DEBUG - 2015-02-16 06:14:00 --> Model Class Initialized
DEBUG - 2015-02-16 06:14:00 --> Model Class Initialized
DEBUG - 2015-02-16 06:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 06:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 06:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 06:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 06:14:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 06:14:01 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 06:14:01 --> Final output sent to browser
DEBUG - 2015-02-16 06:14:01 --> Total execution time: 1.3441
DEBUG - 2015-02-16 06:29:03 --> Config Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Hooks Class Initialized
DEBUG - 2015-02-16 06:29:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 06:29:03 --> Utf8 Class Initialized
DEBUG - 2015-02-16 06:29:03 --> URI Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Router Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Output Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Security Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Input Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 06:29:03 --> Language Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Loader Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: url_helper
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: link_helper
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 06:29:03 --> CI_Session Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Session: Regenerate ID
DEBUG - 2015-02-16 06:29:03 --> CI_Session routines successfully run
DEBUG - 2015-02-16 06:29:03 --> Model Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Model Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Controller Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 06:29:03 --> Email Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: language_helper
DEBUG - 2015-02-16 06:29:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 06:29:03 --> Model Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Database Driver Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: date_helper
DEBUG - 2015-02-16 06:29:03 --> Helper loaded: form_helper
DEBUG - 2015-02-16 06:29:03 --> Form Validation Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Model Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 06:29:03 --> Pagination Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Model Class Initialized
DEBUG - 2015-02-16 06:29:03 --> Model Class Initialized
DEBUG - 2015-02-16 06:29:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 06:29:03 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 06:29:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 06:29:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 06:29:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 06:29:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 06:29:04 --> Final output sent to browser
DEBUG - 2015-02-16 06:29:04 --> Total execution time: 1.3921
DEBUG - 2015-02-16 06:44:06 --> Config Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Hooks Class Initialized
DEBUG - 2015-02-16 06:44:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 06:44:06 --> Utf8 Class Initialized
DEBUG - 2015-02-16 06:44:06 --> URI Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Router Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Output Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Security Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Input Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 06:44:06 --> Language Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Loader Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: url_helper
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: link_helper
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 06:44:06 --> CI_Session Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Session: Regenerate ID
DEBUG - 2015-02-16 06:44:06 --> CI_Session routines successfully run
DEBUG - 2015-02-16 06:44:06 --> Model Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Model Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Controller Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 06:44:06 --> Email Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: language_helper
DEBUG - 2015-02-16 06:44:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 06:44:06 --> Model Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Database Driver Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: date_helper
DEBUG - 2015-02-16 06:44:06 --> Helper loaded: form_helper
DEBUG - 2015-02-16 06:44:06 --> Form Validation Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Model Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 06:44:06 --> Pagination Class Initialized
DEBUG - 2015-02-16 06:44:06 --> Model Class Initialized
DEBUG - 2015-02-16 06:44:07 --> Model Class Initialized
DEBUG - 2015-02-16 06:44:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 06:44:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 06:44:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 06:44:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 06:44:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 06:44:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 06:44:07 --> Final output sent to browser
DEBUG - 2015-02-16 06:44:07 --> Total execution time: 1.3819
DEBUG - 2015-02-16 06:59:09 --> Config Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Hooks Class Initialized
DEBUG - 2015-02-16 06:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 06:59:09 --> Utf8 Class Initialized
DEBUG - 2015-02-16 06:59:09 --> URI Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Router Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Output Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Security Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Input Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 06:59:09 --> Language Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Loader Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: url_helper
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: link_helper
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 06:59:09 --> CI_Session Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Session: Regenerate ID
DEBUG - 2015-02-16 06:59:09 --> CI_Session routines successfully run
DEBUG - 2015-02-16 06:59:09 --> Model Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Model Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Controller Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 06:59:09 --> Email Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: language_helper
DEBUG - 2015-02-16 06:59:09 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 06:59:09 --> Model Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Database Driver Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: date_helper
DEBUG - 2015-02-16 06:59:09 --> Helper loaded: form_helper
DEBUG - 2015-02-16 06:59:09 --> Form Validation Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Model Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 06:59:09 --> Pagination Class Initialized
DEBUG - 2015-02-16 06:59:09 --> Model Class Initialized
DEBUG - 2015-02-16 06:59:10 --> Model Class Initialized
DEBUG - 2015-02-16 06:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 06:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 06:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 06:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 06:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 06:59:10 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 06:59:10 --> Final output sent to browser
DEBUG - 2015-02-16 06:59:10 --> Total execution time: 1.3471
DEBUG - 2015-02-16 07:14:12 --> Config Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Hooks Class Initialized
DEBUG - 2015-02-16 07:14:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 07:14:12 --> Utf8 Class Initialized
DEBUG - 2015-02-16 07:14:12 --> URI Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Router Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Output Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Security Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Input Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 07:14:12 --> Language Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Loader Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: url_helper
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: link_helper
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 07:14:12 --> CI_Session Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Session: Regenerate ID
DEBUG - 2015-02-16 07:14:12 --> CI_Session routines successfully run
DEBUG - 2015-02-16 07:14:12 --> Model Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Model Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Controller Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 07:14:12 --> Email Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: language_helper
DEBUG - 2015-02-16 07:14:12 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 07:14:12 --> Model Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Database Driver Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: date_helper
DEBUG - 2015-02-16 07:14:12 --> Helper loaded: form_helper
DEBUG - 2015-02-16 07:14:12 --> Form Validation Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Model Class Initialized
DEBUG - 2015-02-16 07:14:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 07:14:12 --> Pagination Class Initialized
DEBUG - 2015-02-16 07:14:13 --> Model Class Initialized
DEBUG - 2015-02-16 07:14:13 --> Model Class Initialized
DEBUG - 2015-02-16 07:14:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 07:14:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 07:14:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 07:14:13 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 07:14:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 07:14:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 07:14:14 --> Final output sent to browser
DEBUG - 2015-02-16 07:14:14 --> Total execution time: 1.5622
DEBUG - 2015-02-16 07:29:15 --> Config Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Hooks Class Initialized
DEBUG - 2015-02-16 07:29:15 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 07:29:15 --> Utf8 Class Initialized
DEBUG - 2015-02-16 07:29:15 --> URI Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Router Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Output Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Security Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Input Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 07:29:15 --> Language Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Loader Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: url_helper
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: link_helper
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 07:29:15 --> CI_Session Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Session: Regenerate ID
DEBUG - 2015-02-16 07:29:15 --> CI_Session routines successfully run
DEBUG - 2015-02-16 07:29:15 --> Model Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Model Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Controller Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 07:29:15 --> Email Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: language_helper
DEBUG - 2015-02-16 07:29:15 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 07:29:15 --> Model Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Database Driver Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: date_helper
DEBUG - 2015-02-16 07:29:15 --> Helper loaded: form_helper
DEBUG - 2015-02-16 07:29:15 --> Form Validation Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Model Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 07:29:15 --> Pagination Class Initialized
DEBUG - 2015-02-16 07:29:15 --> Model Class Initialized
DEBUG - 2015-02-16 07:29:16 --> Model Class Initialized
DEBUG - 2015-02-16 07:29:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 07:29:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 07:29:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 07:29:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 07:29:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 07:29:16 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 07:29:16 --> Final output sent to browser
DEBUG - 2015-02-16 07:29:16 --> Total execution time: 1.4811
DEBUG - 2015-02-16 07:44:18 --> Config Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Hooks Class Initialized
DEBUG - 2015-02-16 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 07:44:18 --> Utf8 Class Initialized
DEBUG - 2015-02-16 07:44:18 --> URI Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Router Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Output Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Security Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Input Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 07:44:18 --> Language Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Loader Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: url_helper
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: link_helper
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 07:44:18 --> CI_Session Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Session: Regenerate ID
DEBUG - 2015-02-16 07:44:18 --> CI_Session routines successfully run
DEBUG - 2015-02-16 07:44:18 --> Model Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Model Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Controller Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 07:44:18 --> Email Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: language_helper
DEBUG - 2015-02-16 07:44:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 07:44:18 --> Model Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Database Driver Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: date_helper
DEBUG - 2015-02-16 07:44:18 --> Helper loaded: form_helper
DEBUG - 2015-02-16 07:44:18 --> Form Validation Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Model Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 07:44:18 --> Pagination Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Model Class Initialized
DEBUG - 2015-02-16 07:44:18 --> Model Class Initialized
DEBUG - 2015-02-16 07:44:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 07:44:18 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 07:44:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 07:44:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 07:44:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 07:44:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 07:44:19 --> Final output sent to browser
DEBUG - 2015-02-16 07:44:19 --> Total execution time: 1.3331
DEBUG - 2015-02-16 07:59:20 --> Config Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Hooks Class Initialized
DEBUG - 2015-02-16 07:59:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 07:59:20 --> Utf8 Class Initialized
DEBUG - 2015-02-16 07:59:20 --> URI Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Router Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Output Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Security Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Input Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 07:59:20 --> Language Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Loader Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: url_helper
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: link_helper
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 07:59:20 --> CI_Session Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Session: Regenerate ID
DEBUG - 2015-02-16 07:59:20 --> CI_Session routines successfully run
DEBUG - 2015-02-16 07:59:20 --> Model Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Model Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Controller Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 07:59:20 --> Email Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: language_helper
DEBUG - 2015-02-16 07:59:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 07:59:20 --> Model Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Database Driver Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: date_helper
DEBUG - 2015-02-16 07:59:20 --> Helper loaded: form_helper
DEBUG - 2015-02-16 07:59:20 --> Form Validation Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Model Class Initialized
DEBUG - 2015-02-16 07:59:20 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 07:59:20 --> Pagination Class Initialized
DEBUG - 2015-02-16 07:59:21 --> Model Class Initialized
DEBUG - 2015-02-16 07:59:21 --> Model Class Initialized
DEBUG - 2015-02-16 07:59:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 07:59:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 07:59:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 07:59:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 07:59:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 07:59:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 07:59:22 --> Final output sent to browser
DEBUG - 2015-02-16 07:59:22 --> Total execution time: 1.3931
DEBUG - 2015-02-16 08:10:50 --> Config Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Hooks Class Initialized
DEBUG - 2015-02-16 08:10:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 08:10:50 --> Utf8 Class Initialized
DEBUG - 2015-02-16 08:10:50 --> URI Class Initialized
DEBUG - 2015-02-16 08:10:50 --> No URI present. Default controller set.
DEBUG - 2015-02-16 08:10:50 --> Router Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Output Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Security Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Input Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 08:10:50 --> Language Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Loader Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: url_helper
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: link_helper
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 08:10:50 --> CI_Session Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Session: Regenerate ID
DEBUG - 2015-02-16 08:10:50 --> CI_Session routines successfully run
DEBUG - 2015-02-16 08:10:50 --> Model Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Model Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Controller Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 08:10:50 --> Email Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: language_helper
DEBUG - 2015-02-16 08:10:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 08:10:50 --> Model Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Database Driver Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: date_helper
DEBUG - 2015-02-16 08:10:50 --> Helper loaded: form_helper
DEBUG - 2015-02-16 08:10:50 --> Form Validation Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Model Class Initialized
DEBUG - 2015-02-16 08:10:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 08:10:50 --> Pagination Class Initialized
DEBUG - 2015-02-16 08:10:51 --> Model Class Initialized
DEBUG - 2015-02-16 08:10:51 --> Model Class Initialized
DEBUG - 2015-02-16 08:10:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 08:10:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 08:10:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 08:10:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 08:10:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 08:10:52 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 08:10:52 --> Final output sent to browser
DEBUG - 2015-02-16 08:10:52 --> Total execution time: 2.2352
DEBUG - 2015-02-16 08:20:44 --> Config Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Hooks Class Initialized
DEBUG - 2015-02-16 08:20:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 08:20:44 --> Utf8 Class Initialized
DEBUG - 2015-02-16 08:20:44 --> URI Class Initialized
DEBUG - 2015-02-16 08:20:44 --> No URI present. Default controller set.
DEBUG - 2015-02-16 08:20:44 --> Router Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Output Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Security Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Input Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 08:20:44 --> Language Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Loader Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: url_helper
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: link_helper
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 08:20:44 --> CI_Session Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Session: Regenerate ID
DEBUG - 2015-02-16 08:20:44 --> CI_Session routines successfully run
DEBUG - 2015-02-16 08:20:44 --> Model Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Model Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Controller Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 08:20:44 --> Email Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: language_helper
DEBUG - 2015-02-16 08:20:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 08:20:44 --> Model Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Database Driver Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: date_helper
DEBUG - 2015-02-16 08:20:44 --> Helper loaded: form_helper
DEBUG - 2015-02-16 08:20:44 --> Form Validation Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Model Class Initialized
DEBUG - 2015-02-16 08:20:44 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 08:20:44 --> Pagination Class Initialized
DEBUG - 2015-02-16 08:20:45 --> Model Class Initialized
DEBUG - 2015-02-16 08:20:45 --> Model Class Initialized
DEBUG - 2015-02-16 08:20:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 08:20:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 08:20:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 08:20:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 08:20:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 08:20:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 08:20:45 --> Final output sent to browser
DEBUG - 2015-02-16 08:20:45 --> Total execution time: 1.5042
DEBUG - 2015-02-16 08:21:05 --> Config Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Hooks Class Initialized
DEBUG - 2015-02-16 08:21:05 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 08:21:05 --> Utf8 Class Initialized
DEBUG - 2015-02-16 08:21:05 --> URI Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Router Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Output Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Security Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Input Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 08:21:05 --> Language Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Loader Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: url_helper
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: link_helper
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 08:21:05 --> CI_Session Class Initialized
DEBUG - 2015-02-16 08:21:05 --> CI_Session routines successfully run
DEBUG - 2015-02-16 08:21:05 --> Model Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Model Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Controller Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 08:21:05 --> Email Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: language_helper
DEBUG - 2015-02-16 08:21:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 08:21:05 --> Model Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Database Driver Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: date_helper
DEBUG - 2015-02-16 08:21:05 --> Helper loaded: form_helper
DEBUG - 2015-02-16 08:21:05 --> Form Validation Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Model Class Initialized
DEBUG - 2015-02-16 08:21:05 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 08:21:05 --> Pagination Class Initialized
ERROR - 2015-02-16 08:21:06 --> Severity: error --> Exception: An exception occurred while executing 'SELECT id FROM articles WHERE MATCH (slug_name) AGAINST ('php') LIMIT 0, 5':

SQLSTATE[HY000]: General error: 1191 Can't find FULLTEXT index matching the column list D:\phutx\project\ups\myblog\vendor\doctrine\dbal\lib\Doctrine\DBAL\DBALException.php 47
DEBUG - 2015-02-16 08:23:19 --> Config Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Hooks Class Initialized
DEBUG - 2015-02-16 08:23:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-16 08:23:19 --> Utf8 Class Initialized
DEBUG - 2015-02-16 08:23:19 --> URI Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Router Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Output Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Security Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Input Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-16 08:23:19 --> Language Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Loader Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: url_helper
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: link_helper
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-16 08:23:19 --> CI_Session Class Initialized
DEBUG - 2015-02-16 08:23:19 --> CI_Session routines successfully run
DEBUG - 2015-02-16 08:23:19 --> Model Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Model Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Controller Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-16 08:23:19 --> Email Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: language_helper
DEBUG - 2015-02-16 08:23:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-16 08:23:19 --> Model Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Database Driver Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: date_helper
DEBUG - 2015-02-16 08:23:19 --> Helper loaded: form_helper
DEBUG - 2015-02-16 08:23:19 --> Form Validation Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Model Class Initialized
DEBUG - 2015-02-16 08:23:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-16 08:23:19 --> Pagination Class Initialized
DEBUG - 2015-02-16 08:23:20 --> Model Class Initialized
DEBUG - 2015-02-16 08:23:20 --> Model Class Initialized
DEBUG - 2015-02-16 08:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-16 08:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-16 08:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-16 08:23:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-16 08:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-16 08:23:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-16 08:23:21 --> Final output sent to browser
DEBUG - 2015-02-16 08:23:21 --> Total execution time: 1.5072
