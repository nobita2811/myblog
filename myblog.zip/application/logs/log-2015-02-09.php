<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-09 13:27:59 --> Config Class Initialized
DEBUG - 2015-02-09 13:27:59 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:27:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:27:59 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:27:59 --> URI Class Initialized
DEBUG - 2015-02-09 13:27:59 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:27:59 --> Router Class Initialized
DEBUG - 2015-02-09 13:27:59 --> Output Class Initialized
DEBUG - 2015-02-09 13:27:59 --> Security Class Initialized
DEBUG - 2015-02-09 13:27:59 --> Input Class Initialized
DEBUG - 2015-02-09 13:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:27:59 --> Language Class Initialized
DEBUG - 2015-02-09 13:28:00 --> Loader Class Initialized
DEBUG - 2015-02-09 13:28:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:28:00 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:28:00 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:28:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:28:00 --> CI_Session Class Initialized
ERROR - 2015-02-09 13:28:00 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-09 13:28:00 --> Session: Creating new session (0ae4f7d203a4b9af8a3f0d87e205fed0)
DEBUG - 2015-02-09 13:28:00 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:28:05 --> Model Class Initialized
DEBUG - 2015-02-09 13:28:05 --> Model Class Initialized
DEBUG - 2015-02-09 13:28:05 --> Controller Class Initialized
DEBUG - 2015-02-09 13:28:05 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:28:05 --> Email Class Initialized
DEBUG - 2015-02-09 13:28:05 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:28:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:28:06 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:28:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:28:06 --> Model Class Initialized
DEBUG - 2015-02-09 13:28:06 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:28:06 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:28:06 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:28:06 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:28:12 --> Model Class Initialized
DEBUG - 2015-02-09 13:28:12 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:28:12 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:28:16 --> Model Class Initialized
DEBUG - 2015-02-09 13:28:16 --> Model Class Initialized
DEBUG - 2015-02-09 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:28:17 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:28:17 --> Final output sent to browser
DEBUG - 2015-02-09 13:28:17 --> Total execution time: 18.4949
DEBUG - 2015-02-09 13:30:40 --> Config Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:30:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:30:40 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:30:40 --> URI Class Initialized
DEBUG - 2015-02-09 13:30:40 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:30:40 --> Router Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Output Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Security Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Input Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:30:40 --> Language Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Loader Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:30:40 --> CI_Session Class Initialized
DEBUG - 2015-02-09 13:30:40 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:30:40 --> Model Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Model Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Controller Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:30:40 --> Email Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:30:40 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:30:40 --> Model Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:30:40 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:30:41 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:30:45 --> Model Class Initialized
DEBUG - 2015-02-09 13:30:45 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:30:45 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:30:45 --> Model Class Initialized
DEBUG - 2015-02-09 13:30:45 --> Model Class Initialized
DEBUG - 2015-02-09 13:30:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:30:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:30:46 --> Final output sent to browser
DEBUG - 2015-02-09 13:30:46 --> Total execution time: 5.8016
DEBUG - 2015-02-09 13:33:30 --> Config Class Initialized
DEBUG - 2015-02-09 13:33:30 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:33:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:33:30 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:33:30 --> URI Class Initialized
DEBUG - 2015-02-09 13:33:30 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:33:30 --> Router Class Initialized
DEBUG - 2015-02-09 13:33:30 --> Output Class Initialized
DEBUG - 2015-02-09 13:33:30 --> Security Class Initialized
DEBUG - 2015-02-09 13:33:30 --> Input Class Initialized
DEBUG - 2015-02-09 13:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:33:30 --> Language Class Initialized
DEBUG - 2015-02-09 13:33:30 --> Loader Class Initialized
DEBUG - 2015-02-09 13:33:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:33:30 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:33:30 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:33:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:33:31 --> CI_Session Class Initialized
DEBUG - 2015-02-09 13:33:31 --> Session: Regenerate ID
DEBUG - 2015-02-09 13:33:31 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:33:31 --> Model Class Initialized
DEBUG - 2015-02-09 13:33:31 --> Model Class Initialized
DEBUG - 2015-02-09 13:33:31 --> Controller Class Initialized
DEBUG - 2015-02-09 13:33:31 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:33:31 --> Email Class Initialized
DEBUG - 2015-02-09 13:33:31 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:33:31 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:33:31 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:33:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:33:31 --> Model Class Initialized
DEBUG - 2015-02-09 13:33:31 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:33:31 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:33:31 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:33:31 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:33:35 --> Model Class Initialized
DEBUG - 2015-02-09 13:33:35 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:33:35 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:33:35 --> Model Class Initialized
DEBUG - 2015-02-09 13:33:35 --> Model Class Initialized
DEBUG - 2015-02-09 13:33:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:33:35 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:33:36 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:33:36 --> Final output sent to browser
DEBUG - 2015-02-09 13:33:36 --> Total execution time: 5.3735
DEBUG - 2015-02-09 13:35:21 --> Config Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:35:21 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:35:21 --> URI Class Initialized
DEBUG - 2015-02-09 13:35:21 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:35:21 --> Router Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Output Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Security Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Input Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:35:21 --> Language Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Loader Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:35:21 --> CI_Session Class Initialized
DEBUG - 2015-02-09 13:35:21 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Controller Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:35:21 --> Email Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:35:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:35:21 --> Model Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:35:21 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:35:21 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:35:25 --> Model Class Initialized
DEBUG - 2015-02-09 13:35:25 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:35:25 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:35:26 --> Model Class Initialized
DEBUG - 2015-02-09 13:35:26 --> Model Class Initialized
DEBUG - 2015-02-09 13:35:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:35:26 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:35:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:35:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:35:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:35:27 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:35:27 --> Final output sent to browser
DEBUG - 2015-02-09 13:35:27 --> Total execution time: 5.8406
DEBUG - 2015-02-09 13:36:43 --> Config Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:36:43 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:36:43 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:36:43 --> URI Class Initialized
DEBUG - 2015-02-09 13:36:43 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:36:43 --> Router Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Output Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Security Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Input Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:36:43 --> Language Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Loader Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:36:43 --> CI_Session Class Initialized
DEBUG - 2015-02-09 13:36:43 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:36:43 --> Model Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Model Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Controller Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:36:43 --> Email Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:36:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:36:43 --> Model Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:36:43 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:36:43 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:36:48 --> Model Class Initialized
DEBUG - 2015-02-09 13:36:48 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:36:48 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:36:48 --> Model Class Initialized
DEBUG - 2015-02-09 13:36:48 --> Model Class Initialized
DEBUG - 2015-02-09 13:36:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:36:48 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:36:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:36:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:36:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:36:49 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:36:49 --> Final output sent to browser
DEBUG - 2015-02-09 13:36:49 --> Total execution time: 5.6886
DEBUG - 2015-02-09 13:37:46 --> Config Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:37:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:37:46 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:37:46 --> URI Class Initialized
DEBUG - 2015-02-09 13:37:46 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:37:46 --> Router Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Output Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Security Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Input Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:37:46 --> Language Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Loader Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:37:46 --> CI_Session Class Initialized
DEBUG - 2015-02-09 13:37:46 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:37:46 --> Model Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Model Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Controller Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:37:46 --> Email Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:37:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:37:46 --> Model Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:37:46 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:37:46 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:37:50 --> Model Class Initialized
DEBUG - 2015-02-09 13:37:50 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:37:50 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:37:50 --> Model Class Initialized
DEBUG - 2015-02-09 13:37:51 --> Model Class Initialized
DEBUG - 2015-02-09 13:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:37:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:37:51 --> Final output sent to browser
DEBUG - 2015-02-09 13:37:51 --> Total execution time: 5.4345
DEBUG - 2015-02-09 13:39:49 --> Config Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:39:49 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:39:49 --> URI Class Initialized
DEBUG - 2015-02-09 13:39:49 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:39:49 --> Router Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Output Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Security Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Input Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:39:49 --> Language Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Loader Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:39:49 --> CI_Session Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Session: Regenerate ID
DEBUG - 2015-02-09 13:39:49 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:39:49 --> Model Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Model Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Controller Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:39:49 --> Email Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:39:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:39:49 --> Model Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:39:49 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:39:49 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-02-09 13:39:54 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:39:54 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-02-09 13:39:54 --> Model Class Initialized
DEBUG - 2015-02-09 13:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:39:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:39:55 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:39:55 --> Final output sent to browser
DEBUG - 2015-02-09 13:39:55 --> Total execution time: 5.5116
DEBUG - 2015-02-09 13:54:56 --> Config Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Hooks Class Initialized
DEBUG - 2015-02-09 13:54:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 13:54:56 --> Utf8 Class Initialized
DEBUG - 2015-02-09 13:54:56 --> URI Class Initialized
DEBUG - 2015-02-09 13:54:56 --> No URI present. Default controller set.
DEBUG - 2015-02-09 13:54:56 --> Router Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Output Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Security Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Input Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 13:54:56 --> Language Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Loader Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: url_helper
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: link_helper
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 13:54:56 --> CI_Session Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Session: Regenerate ID
DEBUG - 2015-02-09 13:54:56 --> CI_Session routines successfully run
DEBUG - 2015-02-09 13:54:56 --> Model Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Model Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Controller Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 13:54:56 --> Email Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: language_helper
DEBUG - 2015-02-09 13:54:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 13:54:56 --> Model Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Database Driver Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: date_helper
DEBUG - 2015-02-09 13:54:56 --> Helper loaded: form_helper
DEBUG - 2015-02-09 13:54:56 --> Form Validation Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Model Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 13:54:56 --> Pagination Class Initialized
DEBUG - 2015-02-09 13:54:56 --> Model Class Initialized
DEBUG - 2015-02-09 13:54:57 --> Model Class Initialized
DEBUG - 2015-02-09 13:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 13:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 13:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 13:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 13:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 13:54:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 13:54:57 --> Final output sent to browser
DEBUG - 2015-02-09 13:54:57 --> Total execution time: 1.3251
DEBUG - 2015-02-09 14:03:37 --> Config Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:03:37 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:03:37 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:03:37 --> URI Class Initialized
DEBUG - 2015-02-09 14:03:37 --> No URI present. Default controller set.
DEBUG - 2015-02-09 14:03:37 --> Router Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Output Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Security Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Input Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:03:37 --> Language Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Loader Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:03:37 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Session: Regenerate ID
DEBUG - 2015-02-09 14:03:37 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:03:37 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Controller Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:03:37 --> Email Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:03:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:03:37 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:03:37 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:03:37 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 14:03:37 --> Pagination Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:37 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:03:38 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:03:38 --> Final output sent to browser
DEBUG - 2015-02-09 14:03:38 --> Total execution time: 1.3741
DEBUG - 2015-02-09 14:03:41 --> Config Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:03:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:03:41 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:03:41 --> URI Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Router Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Output Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Security Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Input Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:03:41 --> Language Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Loader Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:03:41 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:03:41 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:03:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Controller Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:03:41 --> Email Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:03:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:03:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:03:41 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:03:41 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:03:41 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:03:41 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:03:41 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:03:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:03:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:03:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-09 14:03:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:03:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:03:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:03:42 --> Final output sent to browser
DEBUG - 2015-02-09 14:03:42 --> Total execution time: 0.8831
DEBUG - 2015-02-09 14:03:45 --> Config Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:03:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:03:45 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:03:45 --> URI Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Router Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Output Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Security Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Input Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:03:45 --> Language Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Loader Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:03:45 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:03:45 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:03:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Controller Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:03:45 --> Email Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:03:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:03:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:03:45 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:03:45 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:03:45 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:03:45 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:03:45 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:03:45 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-09 14:03:52 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:52 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:53 --> Model Class Initialized
DEBUG - 2015-02-09 14:03:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:03:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:03:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-09 14:03:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:03:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:03:53 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:03:53 --> Final output sent to browser
DEBUG - 2015-02-09 14:03:53 --> Total execution time: 7.6698
DEBUG - 2015-02-09 14:04:44 --> Config Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:04:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:04:44 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:04:44 --> URI Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Router Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Output Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Security Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Input Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:04:44 --> Language Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Loader Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:04:44 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:04:44 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:04:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Controller Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:04:44 --> Email Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:04:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:04:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:04:44 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:04:44 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:04:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:04:44 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:04:44 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:04:44 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-09 14:04:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:04:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:04:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:04:51 --> Model Class Initialized
DEBUG - 2015-02-09 14:04:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:04:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:04:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-09 14:04:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:04:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:04:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:04:51 --> Final output sent to browser
DEBUG - 2015-02-09 14:04:51 --> Total execution time: 7.3507
DEBUG - 2015-02-09 14:05:20 --> Config Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:05:20 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:05:20 --> URI Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Router Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Output Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Security Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Input Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:05:20 --> Language Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Loader Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:05:20 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:05:20 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Controller Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:05:20 --> Email Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:05:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:05:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:05:20 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:05:20 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:05:20 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:05:20 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:05:20 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:05:20 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-09 14:05:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:05:27 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:27 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:05:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:05:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-09 14:05:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:05:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:05:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:05:28 --> Final output sent to browser
DEBUG - 2015-02-09 14:05:28 --> Total execution time: 7.3957
DEBUG - 2015-02-09 14:05:51 --> Config Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:05:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:05:51 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:05:51 --> URI Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Router Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Output Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Security Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Input Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:05:51 --> Language Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Loader Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:05:51 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:05:51 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:05:51 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Controller Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:05:51 --> Email Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:05:51 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:05:51 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:05:51 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:05:51 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:05:51 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:05:51 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:05:51 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:05:51 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-09 14:05:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:05:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:05:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:05:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:05:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-09 14:05:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:05:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:05:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:05:57 --> Final output sent to browser
DEBUG - 2015-02-09 14:05:57 --> Total execution time: 6.8817
DEBUG - 2015-02-09 14:06:44 --> Config Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:06:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:06:44 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:06:44 --> URI Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Router Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Output Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Security Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Input Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:06:44 --> Language Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Loader Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:06:44 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:06:44 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:06:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Controller Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:06:44 --> Email Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:06:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:06:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:06:44 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:06:44 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:06:44 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:06:44 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:06:44 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:06:44 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-09 14:06:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:06:49 --> Config Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:06:49 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:06:49 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:06:49 --> URI Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Router Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Output Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Security Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Input Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:06:49 --> Language Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Loader Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:06:49 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:06:49 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:06:49 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Controller Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:06:49 --> Email Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:06:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:06:49 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:06:49 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:06:49 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:06:49 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:06:49 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:06:49 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:06:49 --> Config Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:06:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:06:50 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:06:50 --> URI Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Router Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Output Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Security Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Input Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:06:50 --> Language Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Loader Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:06:50 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:06:50 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:06:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Controller Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:06:50 --> Email Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:06:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:06:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:06:50 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:06:50 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:06:50 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:06:50 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:06:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-09 14:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:06:50 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:06:50 --> Final output sent to browser
DEBUG - 2015-02-09 14:06:50 --> Total execution time: 0.8581
DEBUG - 2015-02-09 14:07:27 --> Config Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:07:27 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:07:27 --> URI Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Router Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Output Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Security Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Input Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:07:27 --> Language Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Loader Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:07:27 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:07:27 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:07:27 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Controller Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:07:27 --> Email Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:07:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:07:27 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:07:27 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:07:27 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:07:27 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:07:27 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:07:27 --> Config Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:07:27 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:07:27 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:07:27 --> URI Class Initialized
DEBUG - 2015-02-09 14:07:27 --> No URI present. Default controller set.
DEBUG - 2015-02-09 14:07:27 --> Router Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Output Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Security Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Input Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:07:27 --> Language Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Loader Class Initialized
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:07:27 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:07:28 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:07:28 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:07:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Controller Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:07:28 --> Email Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:07:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:07:28 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:07:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:07:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:07:28 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:07:28 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 14:07:28 --> Pagination Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:07:28 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:07:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 14:07:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:07:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:07:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:07:29 --> Final output sent to browser
DEBUG - 2015-02-09 14:07:29 --> Total execution time: 1.8552
DEBUG - 2015-02-09 14:07:32 --> Config Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:07:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:07:32 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:07:32 --> URI Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Router Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Output Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Security Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Input Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:07:32 --> Language Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Loader Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:07:32 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:07:32 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:07:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Controller Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:07:32 --> Email Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:07:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:07:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:07:32 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:07:32 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:07:32 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:07:32 --> Could not find the language line "edit_user_validation_phone_label"
DEBUG - 2015-02-09 14:07:32 --> Helper loaded: string_helper
DEBUG - 2015-02-09 14:07:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:07:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:07:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:07:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/edit_user.php
DEBUG - 2015-02-09 14:07:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:07:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:07:34 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:07:34 --> Final output sent to browser
DEBUG - 2015-02-09 14:07:34 --> Total execution time: 1.8622
DEBUG - 2015-02-09 14:09:32 --> Config Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:09:32 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:09:32 --> URI Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Router Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Output Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Security Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Input Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:09:32 --> Language Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Loader Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:09:32 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Session: Regenerate ID
DEBUG - 2015-02-09 14:09:32 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:09:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Controller Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:09:32 --> Email Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:09:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:09:32 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:09:32 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:09:32 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:32 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:09:32 --> Session: Creating new session (7854fb109cab8575618de99feed42fc7)
DEBUG - 2015-02-09 14:09:32 --> Config Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:09:32 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:09:32 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:09:32 --> URI Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Router Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Output Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Security Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Input Class Initialized
DEBUG - 2015-02-09 14:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:09:32 --> Language Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Loader Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:09:33 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:09:33 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:09:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Controller Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:09:33 --> Email Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:09:33 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:09:33 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:09:33 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:09:33 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:33 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:09:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:09:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:09:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-09 14:09:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:09:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:09:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:09:33 --> Final output sent to browser
DEBUG - 2015-02-09 14:09:33 --> Total execution time: 0.8791
DEBUG - 2015-02-09 14:09:46 --> Config Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:09:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:09:46 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:09:46 --> URI Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Router Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Output Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Security Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Input Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:09:46 --> Language Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Loader Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:09:46 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:09:46 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:09:46 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Controller Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:09:46 --> Email Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:09:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:46 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:09:46 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:09:46 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:46 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:09:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:09:46 --> Config Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:09:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:09:46 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:09:46 --> URI Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Router Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Output Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Security Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Input Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:09:46 --> Language Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Loader Class Initialized
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:09:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:09:46 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:09:46 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:09:47 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Controller Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:09:47 --> Email Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:09:47 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:09:47 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:09:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:47 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:09:47 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:09:47 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:09:47 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:47 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:09:47 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:47 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-09 14:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:09:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:09:47 --> Final output sent to browser
DEBUG - 2015-02-09 14:09:47 --> Total execution time: 0.8181
DEBUG - 2015-02-09 14:09:58 --> Config Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:09:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:09:58 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:09:58 --> URI Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Router Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Output Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Security Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Input Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:09:58 --> Language Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Loader Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:09:58 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:09:58 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:09:58 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Controller Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:09:58 --> Email Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:09:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:58 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:09:58 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:09:58 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:09:58 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:09:58 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:58 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:09:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:09:59 --> Config Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:09:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:09:59 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:09:59 --> URI Class Initialized
DEBUG - 2015-02-09 14:09:59 --> No URI present. Default controller set.
DEBUG - 2015-02-09 14:09:59 --> Router Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Output Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Security Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Input Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:09:59 --> Language Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Loader Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:09:59 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:09:59 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:09:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Controller Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:09:59 --> Email Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:09:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:09:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:09:59 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:09:59 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 14:09:59 --> Pagination Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:09:59 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:10:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 14:10:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:10:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:10:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:10:00 --> Final output sent to browser
DEBUG - 2015-02-09 14:10:00 --> Total execution time: 1.8032
DEBUG - 2015-02-09 14:10:00 --> Config Class Initialized
DEBUG - 2015-02-09 14:10:00 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:10:00 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:10:00 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:10:00 --> URI Class Initialized
DEBUG - 2015-02-09 14:10:00 --> No URI present. Default controller set.
DEBUG - 2015-02-09 14:10:00 --> Router Class Initialized
DEBUG - 2015-02-09 14:10:00 --> Output Class Initialized
DEBUG - 2015-02-09 14:10:00 --> Security Class Initialized
DEBUG - 2015-02-09 14:10:00 --> Input Class Initialized
DEBUG - 2015-02-09 14:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:10:00 --> Language Class Initialized
DEBUG - 2015-02-09 14:10:00 --> Loader Class Initialized
DEBUG - 2015-02-09 14:10:00 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:10:00 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:10:00 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:10:00 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:10:00 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:10:00 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:10:01 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Controller Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:10:01 --> Email Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:10:01 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:10:01 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:10:01 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:10:01 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:10:01 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:10:01 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 14:10:01 --> Pagination Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:01 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:10:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:10:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 14:10:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:10:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:10:02 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:10:02 --> Final output sent to browser
DEBUG - 2015-02-09 14:10:02 --> Total execution time: 1.9402
DEBUG - 2015-02-09 14:10:04 --> Config Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:10:04 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:10:04 --> URI Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Router Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Output Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Security Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Input Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:10:04 --> Language Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Loader Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:10:04 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:10:04 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:10:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Controller Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:10:04 --> Email Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:10:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:10:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:10:04 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:10:04 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:10:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-09 14:10:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-09 14:10:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/add.php
DEBUG - 2015-02-09 14:10:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-09 14:10:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/article/addjs.php
DEBUG - 2015-02-09 14:10:05 --> Final output sent to browser
DEBUG - 2015-02-09 14:10:05 --> Total execution time: 0.7231
DEBUG - 2015-02-09 14:10:07 --> Config Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:10:07 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:10:07 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:10:07 --> URI Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Router Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Output Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Security Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Input Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:10:07 --> Language Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Loader Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:10:07 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:10:07 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:10:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Controller Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:10:07 --> Email Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:10:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:10:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:10:07 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:10:07 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:10:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-09 14:10:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-09 14:10:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-09 14:10:14 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-09 14:10:14 --> Final output sent to browser
DEBUG - 2015-02-09 14:10:14 --> Total execution time: 6.5357
DEBUG - 2015-02-09 14:10:30 --> Config Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:10:30 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:10:30 --> URI Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Router Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Output Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Security Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Input Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:10:30 --> Language Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Loader Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:10:30 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:10:30 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:10:30 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Controller Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:10:30 --> Email Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:10:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:10:30 --> Model Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:10:30 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:10:30 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:10:30 --> Model Class Initialized
ERROR - 2015-02-09 14:10:30 --> Severity: Error --> Call to undefined method User_model::getBySlugName() D:\phutx\project\ups\myblog\application\models\User_model.php 23
DEBUG - 2015-02-09 14:11:56 --> Config Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:11:56 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:11:56 --> URI Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Router Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Output Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Security Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Input Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:11:56 --> Language Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Loader Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:11:56 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:11:56 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:11:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Controller Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:11:56 --> Email Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:11:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:11:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:11:56 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:11:56 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Config Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:11:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:11:57 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:11:57 --> URI Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Router Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Output Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Security Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Input Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:11:57 --> Language Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Loader Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:11:57 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:11:57 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:11:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Controller Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:11:57 --> Email Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:11:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:11:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:11:57 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:11:57 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:11:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-09 14:11:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-09 14:12:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-09 14:12:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-09 14:12:00 --> Final output sent to browser
DEBUG - 2015-02-09 14:12:00 --> Total execution time: 3.4223
DEBUG - 2015-02-09 14:12:57 --> Config Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:12:57 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:12:57 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:12:57 --> URI Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Router Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Output Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Security Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Input Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:12:57 --> Language Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Loader Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:12:57 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:12:57 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:12:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Controller Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:12:57 --> Email Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:12:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:12:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:12:57 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:12:57 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:12:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:12:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-09 14:12:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-09 14:13:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-09 14:13:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-09 14:13:00 --> Final output sent to browser
DEBUG - 2015-02-09 14:13:00 --> Total execution time: 3.2263
DEBUG - 2015-02-09 14:13:03 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:03 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:03 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:03 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:03 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:03 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:03 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:03 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:03 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:03 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:03 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:03 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:03 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:04 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:04 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:04 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:04 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:04 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:04 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:04 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:04 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:04 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/nav.php
DEBUG - 2015-02-09 14:13:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/header.php
DEBUG - 2015-02-09 14:13:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/user/index.php
DEBUG - 2015-02-09 14:13:06 --> File loaded: D:\phutx\project\ups\myblog\application\views\admin/common/footer.php
DEBUG - 2015-02-09 14:13:06 --> Final output sent to browser
DEBUG - 2015-02-09 14:13:06 --> Total execution time: 2.6053
DEBUG - 2015-02-09 14:13:19 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:19 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:19 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:19 --> No URI present. Default controller set.
DEBUG - 2015-02-09 14:13:19 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:19 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:19 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:19 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:19 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:19 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:19 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 14:13:19 --> Pagination Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:13:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:13:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 14:13:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:13:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:13:20 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:13:20 --> Final output sent to browser
DEBUG - 2015-02-09 14:13:20 --> Total execution time: 1.3421
DEBUG - 2015-02-09 14:13:23 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:23 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:23 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:23 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:23 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:23 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:23 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:23 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:23 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:23 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:13:23 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:23 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:13:23 --> Session: Creating new session (e76c22fb0ba3101dccff459bcbed9f99)
DEBUG - 2015-02-09 14:13:24 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:24 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:24 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:24 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:24 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:24 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:24 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:24 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:24 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:24 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:13:24 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:24 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:24 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-09 14:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:13:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:13:24 --> Final output sent to browser
DEBUG - 2015-02-09 14:13:24 --> Total execution time: 0.8921
DEBUG - 2015-02-09 14:13:26 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:26 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:26 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:26 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:26 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:26 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:26 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:26 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:26 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:26 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:26 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:26 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:26 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:13:26 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:26 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:13:26 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-09 14:13:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:32 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:33 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/create_user.php
DEBUG - 2015-02-09 14:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:13:33 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:13:33 --> Final output sent to browser
DEBUG - 2015-02-09 14:13:33 --> Total execution time: 6.8847
DEBUG - 2015-02-09 14:13:53 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:53 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:53 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:53 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:53 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:53 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:53 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:53 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:54 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:54 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:54 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:54 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:54 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:54 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:54 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:54 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:54 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:54 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:54 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:54 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:54 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:54 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:54 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:13:54 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:54 --> Language file loaded: language/english/auth_lang.php
ERROR - 2015-02-09 14:13:54 --> Could not find the language line "create_user_validation_phone_label"
DEBUG - 2015-02-09 14:13:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2015-02-09 14:13:59 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:59 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:59 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:59 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:59 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:59 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:59 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:59 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:13:59 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:13:59 --> Config Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:13:59 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:13:59 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:13:59 --> URI Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Router Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Output Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Security Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Input Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:13:59 --> Language Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Loader Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:13:59 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:13:59 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:13:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Controller Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:13:59 --> Email Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:13:59 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:13:59 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:13:59 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:13:59 --> Ion_auth class already loaded. Second attempt ignored.
DEBUG - 2015-02-09 14:13:59 --> Form_validation has already been instantiated as 'form_validation'. Second attempt aborted.
DEBUG - 2015-02-09 14:13:59 --> Language file loaded: language/english/auth_lang.php
DEBUG - 2015-02-09 14:13:59 --> Model Class Initialized
DEBUG - 2015-02-09 14:14:00 --> Model Class Initialized
DEBUG - 2015-02-09 14:14:00 --> Model Class Initialized
DEBUG - 2015-02-09 14:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\auth/login.php
DEBUG - 2015-02-09 14:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:14:00 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:14:00 --> Final output sent to browser
DEBUG - 2015-02-09 14:14:00 --> Total execution time: 0.8711
DEBUG - 2015-02-09 14:15:23 --> Config Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:15:23 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:15:23 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:15:23 --> URI Class Initialized
DEBUG - 2015-02-09 14:15:23 --> No URI present. Default controller set.
DEBUG - 2015-02-09 14:15:23 --> Router Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Output Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Security Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Input Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:15:23 --> Language Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Loader Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:15:23 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:15:23 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:15:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Controller Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:15:23 --> Email Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:15:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:15:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:15:23 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:15:23 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 14:15:23 --> Pagination Class Initialized
DEBUG - 2015-02-09 14:15:23 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:24 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 14:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:15:24 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:15:24 --> Final output sent to browser
DEBUG - 2015-02-09 14:15:24 --> Total execution time: 1.2841
DEBUG - 2015-02-09 14:15:42 --> Config Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:15:42 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:15:42 --> URI Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Router Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Output Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Security Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Input Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:15:42 --> Language Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Loader Class Initialized
DEBUG - 2015-02-09 14:15:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:15:42 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:15:42 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:15:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:15:42 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:15:42 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:15:43 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Controller Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:15:43 --> Email Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:15:43 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:15:43 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:15:43 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:15:43 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:15:43 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:15:43 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:43 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:15:44 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:15:44 --> Final output sent to browser
DEBUG - 2015-02-09 14:15:44 --> Total execution time: 1.3001
DEBUG - 2015-02-09 14:25:03 --> Config Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:25:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:25:03 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:25:03 --> URI Class Initialized
DEBUG - 2015-02-09 14:25:03 --> No URI present. Default controller set.
DEBUG - 2015-02-09 14:25:03 --> Router Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Output Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Security Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Input Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:25:03 --> Language Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Loader Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:25:03 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:25:03 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:25:03 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:25:03 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:25:03 --> Session: Regenerate ID
DEBUG - 2015-02-09 14:25:03 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:25:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Controller Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:25:04 --> Email Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:25:04 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:25:04 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:25:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:25:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:25:04 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:25:04 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Language file loaded: language/english/pagination_lang.php
DEBUG - 2015-02-09 14:25:04 --> Pagination Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:25:04 --> Model Class Initialized
DEBUG - 2015-02-09 14:25:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:25:04 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:25:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\welcome_message.php
DEBUG - 2015-02-09 14:25:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:25:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:25:05 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:25:05 --> Final output sent to browser
DEBUG - 2015-02-09 14:25:05 --> Total execution time: 1.2551
DEBUG - 2015-02-09 14:30:45 --> Config Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:30:45 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:30:45 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:30:45 --> URI Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Router Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Output Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Security Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Input Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:30:45 --> Language Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Loader Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:30:45 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Session: Regenerate ID
DEBUG - 2015-02-09 14:30:45 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:30:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Controller Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:30:45 --> Email Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:30:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:30:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:30:45 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:30:45 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:30:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:30:46 --> Model Class Initialized
DEBUG - 2015-02-09 14:30:46 --> Model Class Initialized
DEBUG - 2015-02-09 14:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:30:46 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:30:46 --> Final output sent to browser
DEBUG - 2015-02-09 14:30:46 --> Total execution time: 1.1721
DEBUG - 2015-02-09 14:38:19 --> Config Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:38:19 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:38:19 --> URI Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Router Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Output Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Security Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Input Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:38:19 --> Language Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Loader Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:38:19 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Session: Regenerate ID
DEBUG - 2015-02-09 14:38:19 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:38:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Controller Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:38:19 --> Email Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:38:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:38:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:38:19 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:38:19 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:38:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:38:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:38:21 --> Model Class Initialized
DEBUG - 2015-02-09 14:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:38:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:38:21 --> Final output sent to browser
DEBUG - 2015-02-09 14:38:21 --> Total execution time: 1.4601
DEBUG - 2015-02-09 14:40:11 --> Config Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:40:11 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:40:11 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:40:11 --> URI Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Router Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Output Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Security Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Input Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:40:11 --> Language Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Loader Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:40:11 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:40:11 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:40:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Controller Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:40:11 --> Email Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:40:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:40:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:40:11 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:40:11 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:40:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:12 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:12 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:40:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:40:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:40:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:40:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:40:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:40:12 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:40:12 --> Final output sent to browser
DEBUG - 2015-02-09 14:40:12 --> Total execution time: 1.3371
DEBUG - 2015-02-09 14:40:50 --> Config Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:40:50 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:40:50 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:40:50 --> URI Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Router Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Output Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Security Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Input Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:40:50 --> Language Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Loader Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:40:50 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:40:50 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:40:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Controller Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:40:50 --> Email Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:40:50 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:40:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:40:50 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:40:50 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:40:50 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:51 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:51 --> Model Class Initialized
DEBUG - 2015-02-09 14:40:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:40:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:40:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:40:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:40:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:40:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:40:51 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:40:51 --> Final output sent to browser
DEBUG - 2015-02-09 14:40:51 --> Total execution time: 1.3061
DEBUG - 2015-02-09 14:43:44 --> Config Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:43:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:43:44 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:43:44 --> URI Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Router Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Output Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Security Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Input Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:43:44 --> Language Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Loader Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:43:44 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Session: Regenerate ID
DEBUG - 2015-02-09 14:43:44 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:43:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Controller Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:43:44 --> Email Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:43:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:43:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:43:44 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:43:44 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:43:44 --> Model Class Initialized
DEBUG - 2015-02-09 14:43:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:43:45 --> Model Class Initialized
DEBUG - 2015-02-09 14:43:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:43:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:43:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:43:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:43:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:43:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:43:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:43:45 --> Final output sent to browser
DEBUG - 2015-02-09 14:43:45 --> Total execution time: 1.2511
DEBUG - 2015-02-09 14:44:55 --> Config Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:44:55 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:44:55 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:44:55 --> URI Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Router Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Output Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Security Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Input Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:44:55 --> Language Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Loader Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:44:55 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:44:55 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:44:55 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:44:55 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:44:55 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:44:55 --> Model Class Initialized
DEBUG - 2015-02-09 14:44:55 --> Model Class Initialized
DEBUG - 2015-02-09 14:44:56 --> Controller Class Initialized
DEBUG - 2015-02-09 14:44:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:44:56 --> Email Class Initialized
DEBUG - 2015-02-09 14:44:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:44:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:44:56 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:44:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:44:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:44:56 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:44:56 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:44:56 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:44:56 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:44:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:44:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:44:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:44:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:44:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:44:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:44:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:44:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:44:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:44:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:44:57 --> Final output sent to browser
DEBUG - 2015-02-09 14:44:57 --> Total execution time: 1.3041
DEBUG - 2015-02-09 14:45:13 --> Config Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:45:13 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:45:13 --> URI Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Router Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Output Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Security Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Input Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:45:13 --> Language Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Loader Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:45:13 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:45:13 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:45:13 --> Model Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Model Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Controller Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:45:13 --> Email Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:45:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:45:13 --> Model Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:45:13 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:45:13 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:45:13 --> Model Class Initialized
DEBUG - 2015-02-09 14:45:15 --> Model Class Initialized
DEBUG - 2015-02-09 14:45:15 --> Model Class Initialized
DEBUG - 2015-02-09 14:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:45:15 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:45:15 --> Final output sent to browser
DEBUG - 2015-02-09 14:45:15 --> Total execution time: 1.4451
DEBUG - 2015-02-09 14:46:06 --> Config Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:46:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:46:06 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:46:06 --> URI Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Router Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Output Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Security Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Input Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:46:06 --> Language Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Loader Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:46:06 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:46:06 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:46:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:46:06 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:46:06 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:46:06 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:06 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Controller Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:46:07 --> Email Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:46:07 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:46:07 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:46:07 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:46:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:46:07 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:46:07 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:46:08 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:46:08 --> Final output sent to browser
DEBUG - 2015-02-09 14:46:08 --> Total execution time: 1.1901
DEBUG - 2015-02-09 14:46:41 --> Config Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:46:41 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:46:41 --> URI Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Router Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Output Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Security Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Input Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:46:41 --> Language Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Loader Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:46:41 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:46:41 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:46:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Controller Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:46:41 --> Email Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:46:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:46:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:46:41 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:46:41 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:46:41 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:46:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:46:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:46:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:46:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:46:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:46:42 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:46:42 --> Final output sent to browser
DEBUG - 2015-02-09 14:46:42 --> Total execution time: 1.1421
DEBUG - 2015-02-09 14:46:53 --> Config Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:46:53 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:46:53 --> URI Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Router Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Output Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Security Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Input Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:46:53 --> Language Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Loader Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:46:53 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:46:53 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:46:53 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Controller Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:46:53 --> Email Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:46:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:46:53 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:46:53 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:46:53 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:46:53 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:54 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:54 --> Model Class Initialized
DEBUG - 2015-02-09 14:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:46:54 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:46:54 --> Final output sent to browser
DEBUG - 2015-02-09 14:46:54 --> Total execution time: 1.2131
DEBUG - 2015-02-09 14:47:19 --> Config Class Initialized
DEBUG - 2015-02-09 14:47:19 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:47:19 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:47:19 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:47:19 --> URI Class Initialized
DEBUG - 2015-02-09 14:47:19 --> Router Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Output Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Security Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Input Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:47:20 --> Language Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Loader Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:47:20 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:47:20 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:47:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Controller Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:47:20 --> Email Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:47:20 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:47:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:47:20 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:47:20 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:47:20 --> Model Class Initialized
DEBUG - 2015-02-09 14:47:21 --> Model Class Initialized
DEBUG - 2015-02-09 14:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:47:21 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:47:21 --> Final output sent to browser
DEBUG - 2015-02-09 14:47:21 --> Total execution time: 1.1861
DEBUG - 2015-02-09 14:48:38 --> Config Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:48:38 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:48:38 --> URI Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Router Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Output Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Security Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Input Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:48:38 --> Language Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Loader Class Initialized
DEBUG - 2015-02-09 14:48:38 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:48:38 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:48:38 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:48:38 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:48:38 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:48:38 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:48:39 --> Model Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Model Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Controller Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:48:39 --> Email Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:48:39 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:48:39 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:48:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:48:39 --> Model Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:48:39 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:48:39 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Model Class Initialized
DEBUG - 2015-02-09 14:48:39 --> Model Class Initialized
DEBUG - 2015-02-09 14:48:40 --> Model Class Initialized
DEBUG - 2015-02-09 14:48:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:48:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:48:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:48:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:48:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:48:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:48:40 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:48:40 --> Final output sent to browser
DEBUG - 2015-02-09 14:48:40 --> Total execution time: 1.1861
DEBUG - 2015-02-09 14:49:06 --> Config Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:49:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:49:06 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:49:06 --> URI Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Router Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Output Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Security Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Input Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:49:06 --> Language Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Loader Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:49:06 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Session: Regenerate ID
DEBUG - 2015-02-09 14:49:06 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:49:06 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Controller Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:49:06 --> Email Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:49:06 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:49:06 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:49:06 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:49:06 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:49:06 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:07 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:49:07 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:49:07 --> Final output sent to browser
DEBUG - 2015-02-09 14:49:07 --> Total execution time: 1.2781
DEBUG - 2015-02-09 14:49:18 --> Config Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:49:18 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:49:18 --> URI Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Router Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Output Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Security Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Input Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:49:18 --> Language Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Loader Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:49:18 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:49:18 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:49:18 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Controller Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:49:18 --> Email Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:49:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:49:18 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:49:18 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:49:18 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:49:18 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:19 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:49:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:49:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:49:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:49:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:49:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:49:19 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:49:19 --> Final output sent to browser
DEBUG - 2015-02-09 14:49:19 --> Total execution time: 1.1821
DEBUG - 2015-02-09 14:49:28 --> Config Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:49:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:49:28 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:49:28 --> URI Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Router Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Output Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Security Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Input Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:49:28 --> Language Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Loader Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:49:28 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:49:28 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:49:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Controller Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:49:28 --> Email Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:49:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:49:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:49:28 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:49:28 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:49:28 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:29 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:29 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:49:29 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:49:29 --> Final output sent to browser
DEBUG - 2015-02-09 14:49:29 --> Total execution time: 1.1501
DEBUG - 2015-02-09 14:49:42 --> Config Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:49:42 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:49:42 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:49:42 --> URI Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Router Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Output Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Security Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Input Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:49:42 --> Language Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Loader Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:49:42 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:49:42 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:49:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Controller Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:49:42 --> Email Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:49:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:49:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:49:42 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:49:42 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:49:42 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:43 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:43 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:49:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:49:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:49:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:49:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:49:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:49:43 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:49:43 --> Final output sent to browser
DEBUG - 2015-02-09 14:49:43 --> Total execution time: 1.2071
DEBUG - 2015-02-09 14:49:56 --> Config Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:49:56 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:49:56 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:49:56 --> URI Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Router Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Output Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Security Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Input Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:49:56 --> Language Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Loader Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:49:56 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:49:56 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Controller Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:49:56 --> Email Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:49:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:49:56 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:49:56 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:49:56 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:57 --> Model Class Initialized
DEBUG - 2015-02-09 14:49:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:49:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:49:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:49:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:49:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:49:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:49:57 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:49:57 --> Final output sent to browser
DEBUG - 2015-02-09 14:49:57 --> Total execution time: 1.1681
DEBUG - 2015-02-09 14:50:10 --> Config Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:50:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:50:10 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:50:10 --> URI Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Router Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Output Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Security Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Input Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:50:10 --> Language Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Loader Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:50:10 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:50:10 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:50:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Controller Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:50:10 --> Email Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:50:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:50:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:50:10 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:50:10 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:50:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:50:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:50:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:50:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:50:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:50:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:50:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:50:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:50:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:50:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:50:11 --> Final output sent to browser
DEBUG - 2015-02-09 14:50:11 --> Total execution time: 1.1471
DEBUG - 2015-02-09 14:52:10 --> Config Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:52:10 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:52:10 --> URI Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Router Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Output Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Security Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Input Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:52:10 --> Language Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Loader Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:52:10 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:52:10 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:52:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Controller Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:52:10 --> Email Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:52:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:52:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:52:10 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:52:10 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:52:10 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:11 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:52:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:52:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:52:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:52:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:52:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:52:11 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:52:11 --> Final output sent to browser
DEBUG - 2015-02-09 14:52:11 --> Total execution time: 1.1281
DEBUG - 2015-02-09 14:52:21 --> Config Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Hooks Class Initialized
DEBUG - 2015-02-09 14:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 14:52:21 --> Utf8 Class Initialized
DEBUG - 2015-02-09 14:52:21 --> URI Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Router Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Output Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Security Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Input Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 14:52:21 --> Language Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Loader Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: url_helper
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: link_helper
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 14:52:21 --> CI_Session Class Initialized
DEBUG - 2015-02-09 14:52:21 --> CI_Session routines successfully run
DEBUG - 2015-02-09 14:52:21 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Controller Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 14:52:21 --> Email Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: language_helper
DEBUG - 2015-02-09 14:52:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 14:52:21 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Database Driver Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: date_helper
DEBUG - 2015-02-09 14:52:21 --> Helper loaded: form_helper
DEBUG - 2015-02-09 14:52:21 --> Form Validation Class Initialized
DEBUG - 2015-02-09 14:52:21 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:22 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:22 --> Model Class Initialized
DEBUG - 2015-02-09 14:52:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 14:52:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 14:52:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 14:52:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 14:52:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 14:52:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 14:52:22 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 14:52:22 --> Final output sent to browser
DEBUG - 2015-02-09 14:52:22 --> Total execution time: 1.2001
DEBUG - 2015-02-09 15:07:44 --> Config Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Hooks Class Initialized
DEBUG - 2015-02-09 15:07:44 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 15:07:44 --> Utf8 Class Initialized
DEBUG - 2015-02-09 15:07:44 --> URI Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Router Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Output Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Security Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Input Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 15:07:44 --> Language Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Loader Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: url_helper
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: link_helper
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 15:07:44 --> CI_Session Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Session: Regenerate ID
DEBUG - 2015-02-09 15:07:44 --> CI_Session routines successfully run
DEBUG - 2015-02-09 15:07:44 --> Model Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Model Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Controller Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 15:07:44 --> Email Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: language_helper
DEBUG - 2015-02-09 15:07:44 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 15:07:44 --> Model Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Database Driver Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: date_helper
DEBUG - 2015-02-09 15:07:44 --> Helper loaded: form_helper
DEBUG - 2015-02-09 15:07:44 --> Form Validation Class Initialized
DEBUG - 2015-02-09 15:07:44 --> Model Class Initialized
DEBUG - 2015-02-09 15:07:45 --> Model Class Initialized
DEBUG - 2015-02-09 15:07:45 --> Model Class Initialized
DEBUG - 2015-02-09 15:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 15:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 15:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 15:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 15:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 15:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 15:07:45 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 15:07:45 --> Final output sent to browser
DEBUG - 2015-02-09 15:07:45 --> Total execution time: 1.3091
DEBUG - 2015-02-09 15:22:46 --> Config Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Hooks Class Initialized
DEBUG - 2015-02-09 15:22:46 --> UTF-8 Support Enabled
DEBUG - 2015-02-09 15:22:46 --> Utf8 Class Initialized
DEBUG - 2015-02-09 15:22:46 --> URI Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Router Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Output Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Security Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Input Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-09 15:22:46 --> Language Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Loader Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: admin_helper
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: url_helper
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: link_helper
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: debug_helper
DEBUG - 2015-02-09 15:22:46 --> CI_Session Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Session: Regenerate ID
DEBUG - 2015-02-09 15:22:46 --> CI_Session routines successfully run
DEBUG - 2015-02-09 15:22:46 --> Model Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Model Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Controller Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Config file loaded: D:\phutx\project\ups\myblog\application\config/ion_auth.php
DEBUG - 2015-02-09 15:22:46 --> Email Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Language file loaded: language/english/ion_auth_lang.php
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: cookie_helper
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: language_helper
DEBUG - 2015-02-09 15:22:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-02-09 15:22:46 --> Model Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Database Driver Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: date_helper
DEBUG - 2015-02-09 15:22:46 --> Helper loaded: form_helper
DEBUG - 2015-02-09 15:22:46 --> Form Validation Class Initialized
DEBUG - 2015-02-09 15:22:46 --> Model Class Initialized
DEBUG - 2015-02-09 15:22:47 --> Model Class Initialized
DEBUG - 2015-02-09 15:22:47 --> Model Class Initialized
DEBUG - 2015-02-09 15:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/nav.php
DEBUG - 2015-02-09 15:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/header.php
DEBUG - 2015-02-09 15:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/index.php
DEBUG - 2015-02-09 15:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\article/comment.php
DEBUG - 2015-02-09 15:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/pagination.php
DEBUG - 2015-02-09 15:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/sidebar.php
DEBUG - 2015-02-09 15:22:47 --> File loaded: D:\phutx\project\ups\myblog\application\views\layout/footer.php
DEBUG - 2015-02-09 15:22:47 --> Final output sent to browser
DEBUG - 2015-02-09 15:22:47 --> Total execution time: 1.1171
